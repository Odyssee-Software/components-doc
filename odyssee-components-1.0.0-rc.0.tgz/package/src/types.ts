/**
 * Base types for Odyssee Components
 * Types and interfaces used across all components
 */

import type Pulse from "pulse-framework";

/**
 * Base component props
 */
export interface BaseComponentProps {
  id?: string;
  className?: string;
  style?: Partial<CSSStyleDeclaration> | string;
  [key: string]: any;
}

/**
 * Component size variants
 */
export type Size = "xs" | "sm" | "md" | "lg" | "xl";

/**
 * Component color variants
 */
export type Color =
  | "primary"
  | "secondary"
  | "success"
  | "danger"
  | "warning"
  | "info"
  | "light"
  | "dark";

/**
 * Component variant types
 */
export type Variant = "solid" | "outline" | "ghost" | "soft" | "link";

/**
 * Position types
 */
export type Position =
  | "top"
  | "top-start"
  | "top-end"
  | "bottom"
  | "bottom-start"
  | "bottom-end"
  | "left"
  | "left-start"
  | "left-end"
  | "right"
  | "right-start"
  | "right-end";

/**
 * Alignment types
 */
export type Alignment = "start" | "center" | "end" | "stretch" | "baseline";

/**
 * Direction types
 */
export type Direction = "horizontal" | "vertical";

/**
 * Callback types
 */
export type EventCallback<T = void> = (event?: Event) => T;
export type ChangeCallback<T = any> = (value: T) => void;
export type ClickCallback = EventCallback<void>;

/**
 * Pulse signal types
 */
export type Signal<T> = ReturnType<typeof Pulse.signal<T>>;
export type Computed<T> = ReturnType<typeof Pulse.computed<T>>;

/**
 * Button props
 */
export interface ButtonProps extends BaseComponentProps {
  type?: "button" | "submit" | "reset";
  variant?: Variant;
  color?: Color;
  size?: Size;
  disabled?: boolean;
  loading?: boolean;
  icon?: string;
  iconPosition?: "left" | "right";
  fullWidth?: boolean;
  onClick?: ClickCallback;
  children?: string | HTMLElement | HTMLElement[];
}

/**
 * Input props
 */
export interface InputProps extends BaseComponentProps {
  type?: "text" | "email" | "password" | "number" | "tel" | "url" | "search";
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  icon?: string;
  iconPosition?: "left" | "right";
  onChange?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
}

/**
 * Select option
 */
export interface SelectOption {
  value: string | number;
  label: string;
  disabled?: boolean;
  group?: string;
}

/**
 * Select props
 */
export interface SelectProps extends BaseComponentProps {
  value?: string | number | Signal<string | number>;
  options: SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  multiple?: boolean;
  searchable?: boolean;
  onChange?: ChangeCallback<string | number | (string | number)[]>;
}

/**
 * Checkbox props
 */
export interface CheckboxProps extends BaseComponentProps {
  checked?: boolean | Signal<boolean>;
  indeterminate?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: Size;
  labelPosition?: "left" | "right";
  name?: string;
  value?: string | number;
  onChange?: ChangeCallback<boolean>;
}

/**
 * Radio props
 */
export interface RadioProps extends BaseComponentProps {
  name?: string;
  value?: string | number;
  checked?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: Size;
  labelPosition?: "left" | "right";
  onChange?: ChangeCallback<string | number>;
}

/**
 * Toggle props
 */
export interface ToggleProps extends BaseComponentProps {
  checked?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: "xs" | "sm" | "md" | "lg";
  variant?: "default" | "soft";
  showIcons?: boolean;
  labelPosition?: "left" | "right";
  name?: string;
  onChange?: ChangeCallback<boolean>;
}

/**
 * Textarea props
 */
export interface TextareaProps extends BaseComponentProps {
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  rows?: number;
  maxLength?: number;
  showCount?: boolean;
  autoResize?: boolean;
  minRows?: number;
  maxRows?: number;
  onChange?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  name?: string;
  autocomplete?: string;
}

/**
 * Radio group option
 */
export interface RadioGroupOption {
  value: string | number;
  label: string;
  description?: string;
  disabled?: boolean;
}

/**
 * RadioGroup props
 */
export interface RadioGroupProps extends BaseComponentProps {
  name?: string;
  value?: string | number | Signal<string | number>;
  options: RadioGroupOption[];
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  disabled?: boolean;
  size?: Size;
  direction?: "vertical" | "horizontal";
  onChange?: ChangeCallback<string | number>;
}

/**
 * FileInput props
 */
export interface FileInputProps extends BaseComponentProps {
  label?: string;
  hint?: string;
  error?: string;
  accept?: string;
  multiple?: boolean;
  required?: boolean;
  disabled?: boolean;
  size?: Size;
  variant?: "default" | "button";
  buttonText?: string;
  placeholder?: string;
  maxSize?: number;
  onChange?: ChangeCallback<FileList>;
  name?: string;
}

/**
 * RangeSlider props
 */
export interface RangeSliderProps extends BaseComponentProps {
  value?: number | Signal<number>;
  min?: number;
  max?: number;
  step?: number;
  label?: string;
  hint?: string;
  error?: string;
  disabled?: boolean;
  showValue?: boolean;
  valueFormat?: (value: number) => string;
  onChange?: ChangeCallback<number>;
  name?: string;
}

/**
 * FormGroup props
 */
export interface FormGroupProps extends BaseComponentProps {
  label?: string;
  description?: string;
  children?: HTMLElement | HTMLElement[];
  direction?: "vertical" | "horizontal";
  gap?: Size;
  bordered?: boolean;
}

/**
 * ColorPicker props
 */
export interface ColorPickerProps extends BaseComponentProps {
  value?: string | Signal<string>;
  label?: string;
  hint?: string;
  error?: string;
  disabled?: boolean;
  required?: boolean;
  size?: Size;
  showValue?: boolean;
  onChange?: ChangeCallback<string>;
  name?: string;
}

/**
 * Modal props
 */
export interface ModalProps extends BaseComponentProps {
  isOpen?: boolean | Signal<boolean>;
  title?: string | HTMLElement;
  children?: string | HTMLElement | HTMLElement[];
  footer?: HTMLElement | HTMLElement[];
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  centered?: boolean;
  staticBackdrop?: boolean;
  fullscreen?: boolean;
  showCloseButton?: boolean;
  closeOnEscape?: boolean;
  animation?: "scale" | "slideDown" | "slideUp" | "fade";
  onClose?: EventCallback;
}

/**
 * Dropdown props
 */
export interface DropdownProps extends BaseComponentProps {
  trigger: HTMLElement;
  position?: Position;
  offset?: number;
  children?: HTMLElement | HTMLElement[];
  onOpen?: EventCallback;
  onClose?: EventCallback;
}

/**
 * Tooltip props
 */
export interface TooltipProps extends BaseComponentProps {
  content: string;
  position?: Position;
  trigger?: HTMLElement;
  children?: HTMLElement;
}

/**
 * Alert props
 */
export interface AlertProps extends BaseComponentProps {
  variant?: "solid" | "soft" | "bordered";
  color?: Color;
  title?: string | HTMLElement;
  children?: string | HTMLElement | HTMLElement[];
  icon?: string;
  dismissible?: boolean;
  isVisible?: boolean | Signal<boolean>;
  actions?: HTMLElement | HTMLElement[];
  onDismiss?: EventCallback;
}

/**
 * Badge props
 */
export interface BadgeProps extends BaseComponentProps {
  variant?: Variant;
  color?: Color;
  size?: Size;
  rounded?: boolean;
  dot?: boolean;
  children?: string | HTMLElement;
}

/**
 * Card props
 */
export interface CardProps extends BaseComponentProps {
  header?: HTMLElement | string;
  footer?: HTMLElement | string;
  image?: string;
  bordered?: boolean;
  hoverable?: boolean;
  children?: HTMLElement | HTMLElement[];
}

/**
 * Tab item
 */
export interface TabItem {
  id: string;
  label: string;
  content: HTMLElement | (() => HTMLElement);
  disabled?: boolean;
  icon?: string;
}

/**
 * Tabs props
 */
export interface TabsProps extends BaseComponentProps {
  items: TabItem[];
  activeTab?: string | Signal<string>;
  variant?: "underline" | "pills" | "bordered";
  onChange?: ChangeCallback<string>;
}

/**
 * Accordion item
 */
export interface AccordionItem {
  id: string;
  title: string;
  content: HTMLElement | string;
  disabled?: boolean;
  open?: boolean;
}

/**
 * Accordion props
 */
export interface AccordionProps extends BaseComponentProps {
  items: AccordionItem[];
  multiple?: boolean;
  bordered?: boolean;
}

/**
 * Breadcrumb item
 */
export interface BreadcrumbItem {
  label: string;
  href?: string;
  active?: boolean;
  icon?: string;
}

/**
 * Breadcrumb props
 */
export interface BreadcrumbProps extends BaseComponentProps {
  items: BreadcrumbItem[];
  separator?: string;
}

/**
 * Pagination props
 */
export interface PaginationProps extends BaseComponentProps {
  currentPage: number | Signal<number>;
  totalPages: number;
  size?: Size;
  showEdges?: boolean;
  showPrevNext?: boolean;
  onChange?: ChangeCallback<number>;
}

/**
 * Avatar props
 */
export interface AvatarProps extends BaseComponentProps {
  src?: string;
  alt?: string;
  name?: string;
  size?: Size;
  rounded?: boolean | "full";
  status?: "online" | "offline" | "away" | "busy";
  badge?: string | number;
}

/**
 * Progress props
 */
export interface ProgressProps extends BaseComponentProps {
  value: number | Signal<number>;
  max?: number;
  size?: Size;
  color?: Color;
  striped?: boolean;
  animated?: boolean;
  label?: string;
  showValue?: boolean;
}

/**
 * Spinner props
 */
export interface SpinnerProps extends BaseComponentProps {
  size?: Size;
  color?: Color;
  type?: "border" | "grow";
}

/**
 * Toast props
 */
export interface ToastProps extends BaseComponentProps {
  type?: "success" | "info" | "warning" | "danger";
  title?: string;
  message: string;
  duration?: number;
  dismissible?: boolean;
  position?:
    | "top-left"
    | "top-center"
    | "top-right"
    | "bottom-left"
    | "bottom-center"
    | "bottom-right";
  onDismiss?: EventCallback;
}

/**
 * Table column definition
 */
export interface TableColumn<T = any> {
  key: string;
  label: string;
  sortable?: boolean;
  width?: string;
  align?: "left" | "center" | "right";
  render?: (value: any, row: T) => string | HTMLElement;
}

/**
 * Table props
 */
export interface TableProps<T = any> extends BaseComponentProps {
  columns: TableColumn<T>[];
  data: T[] | Signal<T[]>;
  striped?: boolean;
  bordered?: boolean;
  hoverable?: boolean;
  loading?: boolean;
  emptyMessage?: string;
  onRowClick?: (row: T) => void;
}

/**
 * Timeline item
 */
export interface TimelineItem {
  id: string;
  title: string;
  description?: string;
  date?: string;
  icon?: string;
  color?: Color;
  content?: HTMLElement;
}

/**
 * Timeline props
 */
export interface TimelineProps extends BaseComponentProps {
  items: TimelineItem[];
  vertical?: boolean;
}

/**
 * Stepper step
 */
export interface StepperStep {
  id: string;
  title: string;
  description?: string;
  icon?: string;
  completed?: boolean;
  error?: boolean;
}

/**
 * Stepper props
 */
export interface StepperProps extends BaseComponentProps {
  steps: StepperStep[];
  currentStep: number | Signal<number>;
  vertical?: boolean;
  clickable?: boolean;
  onChange?: ChangeCallback<number>;
}

/**
 * Carousel props
 */
export interface CarouselProps extends BaseComponentProps {
  items: HTMLElement[];
  autoplay?: boolean;
  interval?: number;
  showControls?: boolean;
  showIndicators?: boolean;
  loop?: boolean;
}

/**
 * Divider props
 */
export interface DividerProps extends BaseComponentProps {
  vertical?: boolean;
  label?: string;
  labelPosition?: "left" | "center" | "right";
}

/**
 * Container props
 */
export interface ContainerProps extends BaseComponentProps {
  fluid?: boolean;
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "full";
  centered?: boolean;
  children?: HTMLElement | HTMLElement[];
}

/**
 * Grid props
 */
export interface GridProps extends BaseComponentProps {
  cols?: number | { sm?: number; md?: number; lg?: number; xl?: number };
  gap?: number | string;
  children?: HTMLElement | HTMLElement[];
}
