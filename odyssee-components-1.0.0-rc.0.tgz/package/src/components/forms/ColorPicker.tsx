/**
 * ColorPicker Component
 * A color picker component using HTML5 color input
 *
 * @example
 * ```tsx
 * import { ColorPicker } from '@odyssee/components';
 *
 * // Basic color picker
 * const colorPicker1 = ColorPicker({
 *   label: 'Choose color',
 *   onChange: (color) => console.log(color)
 * });
 *
 * // With reactive value
 * const color = Pulse.signal('#3b82f6');
 * const colorPicker2 = ColorPicker({
 *   label: 'Theme color',
 *   value: color,
 *   onChange: (val) => color(val)
 * });
 *
 * // With hint
 * const colorPicker3 = ColorPicker({
 *   label: 'Brand color',
 *   hint: 'Select your primary brand color',
 *   value: '#10b981'
 * });
 *
 * // With error
 * const colorPicker4 = ColorPicker({
 *   label: 'Color',
 *   error: 'Please select a valid color',
 *   required: true
 * });
 *
 * // Disabled
 * const colorPicker5 = ColorPicker({
 *   label: 'Color',
 *   value: '#ef4444',
 *   disabled: true
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { ColorPickerProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const ColorPicker: Pulse.Fn<ColorPickerProps> = (props) => {
  const {
    value = "#000000",
    label,
    hint,
    error,
    disabled = false,
    required = false,
    size = "md",
    showValue = true,
    onChange,
    className,
    id = generateId("color-picker"),
    name,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "w-8 h-8",
    sm: "w-10 h-10",
    md: "w-12 h-12",
    lg: "w-14 h-14",
    xl: "w-16 h-16",
  };

  // Container
  const container = (
    <div class="flex flex-col gap-1.5"></div>
  ) as unknown as HTMLElement;

  // Label
  if (label) {
    const labelEl = (
      <label
        for={id}
        class="text-sm font-medium text-gray-700 dark:text-gray-300"
      ></label>
    ) as unknown as HTMLLabelElement;

    labelEl.textContent = label;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    container.appendChild(labelEl);
  }

  // Color picker wrapper
  const pickerWrapper = (
    <div class="flex items-center gap-3"></div>
  ) as unknown as HTMLElement;

  // Base color input classes
  const baseClasses =
    "rounded-md border-2 cursor-pointer transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 focus:ring-red-500 dark:border-red-600"
    : "border-gray-300 focus:ring-primary-500 dark:border-gray-600";

  // Combine classes
  const colorClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Create color input
  const colorInput = (
    <input
      type="color"
      id={id}
      class={colorClasses}
      disabled={disabled}
      required={required}
    />
  ) as unknown as HTMLInputElement;

  if (name) colorInput.name = name;

  // Handle value (reactive or static)
  if (value !== undefined) {
    if (isSignal(value)) {
      Pulse.effect(() => {
        const val = (value as any)();
        colorInput.value = val || "#000000";
      });
    } else {
      colorInput.value = (value as string) || "#000000";
    }
  }

  // Handle change event
  colorInput.onchange = (e) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      colorInput.setAttribute(key, String(val));
    }
  });

  pickerWrapper.appendChild(colorInput);

  // Show color value if enabled
  if (showValue) {
    const valueDisplay = (
      <span class="text-sm font-mono text-gray-600 dark:text-gray-400"></span>
    ) as unknown as HTMLElement;

    // Update value display reactively
    Pulse.effect(() => {
      const currentValue = isSignal(value) ? (value as any)() : value;
      valueDisplay.textContent = currentValue || "#000000";
    });

    // Also update on input change
    colorInput.oninput = (e) => {
      const target = e.target as HTMLInputElement;
      valueDisplay.textContent = target.value;
    };

    pickerWrapper.appendChild(valueDisplay);
  }

  container.appendChild(pickerWrapper);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
