/**
 * RangeSlider Component
 * A range slider component for selecting numeric values within a defined range
 *
 * @example
 * ```tsx
 * import { RangeSlider } from '@odyssee/components';
 *
 * // Basic range slider
 * const slider1 = RangeSlider({
 *   label: 'Volume',
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With reactive value
 * const volume = Pulse.signal(50);
 * const slider2 = RangeSlider({
 *   label: 'Volume',
 *   value: volume,
 *   onChange: (val) => volume(val)
 * });
 *
 * // With min, max, and step
 * const slider3 = RangeSlider({
 *   label: 'Price',
 *   min: 0,
 *   max: 1000,
 *   step: 10,
 *   value: 500,
 *   showValue: true,
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With custom format
 * const slider4 = RangeSlider({
 *   label: 'Temperature',
 *   min: -10,
 *   max: 40,
 *   value: 20,
 *   showValue: true,
 *   valueFormat: (val) => `${val}°C`,
 *   onChange: (value) => console.log(value)
 * });
 *
 * // Disabled
 * const slider5 = RangeSlider({
 *   label: 'Brightness',
 *   value: 75,
 *   disabled: true
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { RangeSliderProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const RangeSlider: Pulse.Fn<RangeSliderProps> = (props) => {
  const {
    value = 50,
    min = 0,
    max = 100,
    step = 1,
    label,
    hint,
    error,
    disabled = false,
    showValue = false,
    valueFormat,
    onChange,
    className,
    id = generateId("range-slider"),
    name,
    ...rest
  } = props;

  // Container
  const container = (
    <div class="flex flex-col gap-1.5"></div>
  ) as unknown as HTMLElement;

  // Label with optional value display
  if (label || showValue) {
    const labelWrapper = (
      <div class="flex items-center justify-between"></div>
    ) as unknown as HTMLElement;

    if (label) {
      const labelEl = (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        ></label>
      ) as unknown as HTMLLabelElement;
      labelEl.textContent = label;
      labelWrapper.appendChild(labelEl);
    }

    if (showValue) {
      const valueDisplay = (
        <span class="text-sm text-gray-600 dark:text-gray-400"></span>
      ) as unknown as HTMLElement;

      // Update value display reactively
      Pulse.effect(() => {
        const currentValue = isSignal(value) ? (value as any)() : value;
        const displayValue = valueFormat
          ? valueFormat(currentValue)
          : String(currentValue);
        valueDisplay.textContent = displayValue;
      });

      labelWrapper.appendChild(valueDisplay);
    }

    container.appendChild(labelWrapper);
  }

  // Base range slider classes
  const baseClasses =
    "w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "focus:ring-red-500 dark:focus:ring-red-500"
    : "focus:ring-primary-500 dark:focus:ring-primary-500";

  // Combine classes
  const rangeClasses = cn(baseClasses, stateClasses, className);

  // Create range input
  const rangeInput = (
    <input
      type="range"
      id={id}
      class={rangeClasses}
      min={String(min)}
      max={String(max)}
      step={String(step)}
      disabled={disabled}
    />
  ) as unknown as HTMLInputElement;

  if (name) rangeInput.name = name;

  // Handle value (reactive or static)
  if (value !== undefined) {
    if (isSignal(value)) {
      Pulse.effect(() => {
        const val = (value as any)();
        rangeInput.value = String(val);
      });
    } else {
      rangeInput.value = String(value);
    }
  }

  // Handle input event (fires as user drags)
  rangeInput.oninput = (e) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(Number(target.value));
    }
  };

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      rangeInput.setAttribute(key, String(val));
    }
  });

  container.appendChild(rangeInput);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
