/**
 * Radio Component
 * A customizable radio button component with label, description, and validation states
 *
 * @example
 * ```tsx
 * import { Radio } from '@odyssee/components';
 *
 * // Basic radio
 * const radio1 = Radio({
 *   name: 'color',
 *   value: 'red',
 *   label: 'Red',
 *   onChange: (value) => console.log(value)
 * });
 *
 * // Radio group
 * const selectedColor = Pulse.signal('blue');
 * const radio2 = Radio({
 *   name: 'color',
 *   value: 'blue',
 *   label: 'Blue',
 *   checked: Pulse.computed(() => selectedColor() === 'blue'),
 *   onChange: (value) => selectedColor(value)
 * });
 *
 * // With description
 * const radio3 = Radio({
 *   name: 'plan',
 *   value: 'pro',
 *   label: 'Pro Plan',
 *   description: '$29/month - All features included',
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With error state
 * const radio4 = Radio({
 *   name: 'option',
 *   value: 'opt1',
 *   label: 'Option 1',
 *   error: 'This option is not available',
 *   disabled: true
 * });
 *
 * // Disabled
 * const radio5 = Radio({
 *   name: 'option',
 *   value: 'opt2',
 *   label: 'Option 2',
 *   disabled: true,
 *   checked: true
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { RadioProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Radio: Pulse.Fn<RadioProps> = (props) => {
  const {
    name,
    value,
    checked = false,
    disabled = false,
    required = false,
    label,
    description,
    error,
    success,
    size = "md",
    labelPosition = "right",
    onChange,
    className,
    id = generateId("radio"),
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5",
    xl: "w-6 h-6",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  // Base radio classes
  const baseClasses =
    "border-gray-300 text-primary-600 focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-600 dark:bg-gray-700 dark:checked:bg-primary-500 dark:checked:border-primary-500 dark:focus:ring-primary-600 dark:focus:ring-offset-gray-800 transition-colors duration-200";

  // State classes
  let stateClasses = "";
  if (error) {
    stateClasses =
      "border-red-300 text-red-600 focus:ring-red-500 dark:border-red-600";
  } else if (success) {
    stateClasses =
      "border-green-300 text-green-600 focus:ring-green-500 dark:border-green-600";
  }

  // Combine classes
  const radioClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Container
  const container = (<div class="flex flex-col gap-1.5"></div>) as unknown as HTMLElement;

  // Radio wrapper
  const radioWrapper = (
    <div
      class={cn(
        "flex items-start gap-2",
        labelPosition === "left" ? "flex-row-reverse justify-end" : "",
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Create radio input
  const radio = (
    <input type="radio" id={id} class={radioClasses} />
  ) as unknown as HTMLInputElement;

  if (name) radio.name = name;
  if (value !== undefined) radio.value = String(value);
  if (required) radio.required = required;
  radio.disabled = disabled;

  // Handle checked state reactively
  Pulse.effect(() => {
    const isChecked = isSignal(checked) ? (checked as any)() : checked;
    radio.checked = isChecked;
  });

  // Handle change event
  radio.onchange = (e) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      radio.setAttribute(key, String(val));
    }
  });

  radioWrapper.appendChild(radio);

  // Label and description
  if (label || description) {
    const labelContainer = (
      <div class="flex flex-col gap-0.5"></div>
    ) as unknown as HTMLElement;

    if (label) {
      const labelEl = (
        <label
          for={id}
          class={cn(
            "font-medium cursor-pointer",
            labelSizeClasses[size],
            error
              ? "text-red-700 dark:text-red-400"
              : success
                ? "text-green-700 dark:text-green-400"
                : "text-gray-900 dark:text-gray-100",
            disabled ? "opacity-50 cursor-not-allowed" : "",
          )}
        ></label>
      ) as unknown as HTMLLabelElement;

      labelEl.textContent = label;

      if (required) {
        const requiredSpan = (
          <span class="text-red-500 ml-1">*</span>
        ) as unknown as HTMLElement;
        labelEl.appendChild(requiredSpan);
      }

      labelContainer.appendChild(labelEl);
    }

    if (description) {
      const descEl = (
        <p
          class={cn(
            "text-xs",
            error
              ? "text-red-600 dark:text-red-400"
              : success
                ? "text-green-600 dark:text-green-400"
                : "text-gray-500 dark:text-gray-400",
            disabled ? "opacity-50" : "",
          )}
        >
          {description}
        </p>
      ) as unknown as HTMLElement;
      labelContainer.appendChild(descEl);
    }

    radioWrapper.appendChild(labelContainer);
  }

  container.appendChild(radioWrapper);

  // Error or success message
  if (error && typeof error === "string") {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400 ml-6">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  } else if (success && typeof success === "string") {
    const successEl = (
      <p class="text-xs text-green-600 dark:text-green-400 ml-6">{success}</p>
    ) as unknown as HTMLElement;
    container.appendChild(successEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
