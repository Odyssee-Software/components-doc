/**
 * FormGroup Component
 * A container component for organizing and grouping form fields
 *
 * @example
 * ```tsx
 * import { FormGroup, Input, Select } from '@odyssee/components';
 *
 * // Basic form group
 * const formGroup1 = FormGroup({
 *   label: 'Personal Information',
 *   children: [
 *     Input({ label: 'First Name', name: 'firstName' }),
 *     Input({ label: 'Last Name', name: 'lastName' })
 *   ]
 * });
 *
 * // With description
 * const formGroup2 = FormGroup({
 *   label: 'Account Settings',
 *   description: 'Manage your account preferences',
 *   children: [
 *     Input({ label: 'Email', type: 'email' }),
 *     Input({ label: 'Password', type: 'password' })
 *   ]
 * });
 *
 * // Horizontal layout
 * const formGroup3 = FormGroup({
 *   label: 'Address',
 *   direction: 'horizontal',
 *   gap: 'lg',
 *   children: [
 *     Input({ label: 'City', name: 'city' }),
 *     Input({ label: 'ZIP', name: 'zip' })
 *   ]
 * });
 *
 * // With border
 * const formGroup4 = FormGroup({
 *   label: 'Billing',
 *   bordered: true,
 *   children: [
 *     Input({ label: 'Card Number' }),
 *     Input({ label: 'CVV' })
 *   ]
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { FormGroupProps } from "../../types";
import { cn } from "../../utils";

export const FormGroup: Pulse.Fn<FormGroupProps> = (props) => {
  const {
    label,
    description,
    children,
    direction = "vertical",
    gap = "md",
    bordered = false,
    className,
    ...rest
  } = props;

  // Gap classes
  const gapClasses = {
    xs: "gap-1",
    sm: "gap-2",
    md: "gap-4",
    lg: "gap-6",
    xl: "gap-8",
  };

  // Container classes
  const containerClasses = cn(
    "form-group",
    bordered
      ? "border border-gray-200 dark:border-gray-700 rounded-lg p-4"
      : "",
    className,
  );

  // Container
  const container = (
    <div class={containerClasses}></div>
  ) as unknown as HTMLElement;

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      container.setAttribute(key, String(val));
    }
  });

  // Label and description
  if (label || description) {
    const headerEl = (<div class="mb-4"></div>) as unknown as HTMLElement;

    if (label) {
      const labelEl = (
        <h3 class="text-base font-semibold text-gray-900 dark:text-gray-100"></h3>
      ) as unknown as HTMLElement;
      labelEl.textContent = label;
      headerEl.appendChild(labelEl);
    }

    if (description) {
      const descEl = (
        <p class="text-sm text-gray-500 dark:text-gray-400 mt-1"></p>
      ) as unknown as HTMLElement;
      descEl.textContent = description;
      headerEl.appendChild(descEl);
    }

    container.appendChild(headerEl);
  }

  // Fields container
  const fieldsContainer = (
    <div
      class={cn(
        "flex",
        direction === "horizontal" ? "flex-row flex-wrap" : "flex-col",
        gapClasses[gap],
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Add children
  if (children) {
    if (Array.isArray(children)) {
      children.forEach((child) => {
        if (child) {
          fieldsContainer.appendChild(child as Node);
        }
      });
    } else {
      fieldsContainer.appendChild(children as Node);
    }
  }

  container.appendChild(fieldsContainer);

  return container as unknown as Pulse.JSX.Element;
};
