/**
 * FileInput Component
 * A file input component with label, validation, and file preview
 *
 * @example
 * ```tsx
 * import { FileInput } from '@odyssee/components';
 *
 * // Basic file input
 * const fileInput1 = FileInput({
 *   label: 'Upload file',
 *   onChange: (files) => console.log(files)
 * });
 *
 * // With accept filter
 * const fileInput2 = FileInput({
 *   label: 'Upload image',
 *   accept: 'image/*',
 *   onChange: (files) => console.log(files)
 * });
 *
 * // Multiple files
 * const fileInput3 = FileInput({
 *   label: 'Upload documents',
 *   multiple: true,
 *   accept: '.pdf,.doc,.docx',
 *   onChange: (files) => console.log(files)
 * });
 *
 * // With button style
 * const fileInput4 = FileInput({
 *   label: 'Choose profile photo',
 *   buttonText: 'Browse',
 *   variant: 'button',
 *   accept: 'image/*'
 * });
 *
 * // With error
 * const fileInput5 = FileInput({
 *   label: 'Upload',
 *   error: 'File size must be less than 5MB',
 *   required: true
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { FileInputProps } from "../../types";
import { cn, generateId } from "../../utils";

export const FileInput: Pulse.Fn<FileInputProps> = (props) => {
  const {
    label,
    hint,
    error,
    accept,
    multiple = false,
    required = false,
    disabled = false,
    size = "md",
    variant = "default",
    buttonText = "Choose file",
    placeholder = "No file chosen",
    maxSize,
    onChange,
    className,
    id = generateId("file-input"),
    name,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Container
  const container = (
    <div class="flex flex-col gap-1.5"></div>
  ) as unknown as HTMLElement;

  // Label
  if (label) {
    const labelEl = (
      <label
        for={id}
        class="text-sm font-medium text-gray-700 dark:text-gray-300"
      ></label>
    ) as unknown as HTMLLabelElement;

    labelEl.textContent = label;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    container.appendChild(labelEl);
  }

  if (variant === "button") {
    // Button style file input
    const buttonWrapper = (
      <div class="flex items-center gap-3"></div>
    ) as unknown as HTMLElement;

    const fileInput = (
      <input type="file" id={id} class="hidden" />
    ) as unknown as HTMLInputElement;

    if (name) fileInput.name = name;
    if (accept) fileInput.accept = accept;
    if (multiple) fileInput.multiple = multiple;
    if (required) fileInput.required = required;
    fileInput.disabled = disabled;

    // File name display
    const fileNameDisplay = (
      <span class="text-sm text-gray-500 dark:text-gray-400"></span>
    ) as unknown as HTMLElement;
    fileNameDisplay.textContent = placeholder;

    // Handle file change
    fileInput.onchange = (e) => {
      const target = e.target as HTMLInputElement;
      const files = target.files;

      if (files && files.length > 0) {
        // Validate file size if maxSize is specified
        if (maxSize) {
          const totalSize = Array.from(files).reduce(
            (acc, file) => acc + file.size,
            0,
          );
          if (totalSize > maxSize) {
            alert(`File size exceeds ${maxSize / 1024 / 1024}MB limit`);
            target.value = "";
            fileNameDisplay.textContent = placeholder;
            return;
          }
        }

        // Update display
        if (files.length === 1) {
          fileNameDisplay.textContent = files[0].name;
        } else {
          fileNameDisplay.textContent = `${files.length} files selected`;
        }

        // Call onChange callback
        if (onChange) {
          onChange(files);
        }
      } else {
        fileNameDisplay.textContent = placeholder;
      }
    };

    // Button to trigger file input
    const button = (
      <button
        type="button"
        class={cn(
          "inline-flex items-center justify-center gap-2 rounded-md border font-medium transition-all",
          sizeClasses[size],
          error
            ? "border-red-300 bg-red-50 text-red-700 hover:bg-red-100 dark:border-red-600 dark:bg-red-900/20 dark:text-red-400"
            : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700",
          disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
        )}
      ></button>
    ) as unknown as HTMLButtonElement;

    button.textContent = buttonText;
    button.disabled = disabled;
    button.onclick = () => fileInput.click();

    buttonWrapper.appendChild(button);
    buttonWrapper.appendChild(fileNameDisplay);
    buttonWrapper.appendChild(fileInput);
    container.appendChild(buttonWrapper);
  } else {
    // Default style file input
    const baseClasses =
      "block w-full rounded-md border transition-colors duration-200 file:border-0 file:mr-4 file:py-2 file:px-4 file:text-sm file:font-medium focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

    const stateClasses = error
      ? "border-red-300 text-red-900 file:bg-red-50 file:text-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400 dark:file:bg-red-900/20 dark:file:text-red-400"
      : "border-gray-300 text-gray-900 file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:file:bg-gray-600 dark:file:text-gray-300 dark:hover:file:bg-gray-500";

    const inputClasses = cn(
      baseClasses,
      sizeClasses[size],
      stateClasses,
      className,
    );

    const fileInput = (
      <input type="file" id={id} class={inputClasses} />
    ) as unknown as HTMLInputElement;

    if (name) fileInput.name = name;
    if (accept) fileInput.accept = accept;
    if (multiple) fileInput.multiple = multiple;
    if (required) fileInput.required = required;
    fileInput.disabled = disabled;

    // Handle file change
    fileInput.onchange = (e) => {
      const target = e.target as HTMLInputElement;
      const files = target.files;

      if (files && files.length > 0) {
        // Validate file size if maxSize is specified
        if (maxSize) {
          const totalSize = Array.from(files).reduce(
            (acc, file) => acc + file.size,
            0,
          );
          if (totalSize > maxSize) {
            alert(`File size exceeds ${maxSize / 1024 / 1024}MB limit`);
            target.value = "";
            return;
          }
        }

        // Call onChange callback
        if (onChange) {
          onChange(files);
        }
      }
    };

    // Add extra attributes
    Object.entries(rest).forEach(([key, value]) => {
      if (key.startsWith("data-") || key.startsWith("aria-")) {
        fileInput.setAttribute(key, String(value));
      }
    });

    container.appendChild(fileInput);
  }

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
