/**
 * Select Component
 * A customizable select dropdown with support for groups, search, and multiple selection
 *
 * @example
 * ```tsx
 * import { Select } from '@odyssee/components';
 *
 * // Basic select
 * const select1 = Select({
 *   options: [
 *     { value: '1', label: 'Option 1' },
 *     { value: '2', label: 'Option 2' },
 *     { value: '3', label: 'Option 3' }
 *   ],
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With label and placeholder
 * const select2 = Select({
 *   label: 'Country',
 *   placeholder: 'Select a country',
 *   options: [
 *     { value: 'us', label: 'United States' },
 *     { value: 'uk', label: 'United Kingdom' },
 *     { value: 'fr', label: 'France' }
 *   ]
 * });
 *
 * // With reactive value
 * const country = Pulse.signal('us');
 * const select3 = Select({
 *   label: 'Country',
 *   value: country,
 *   options: [...],
 *   onChange: (val) => country(val)
 * });
 *
 * // With groups
 * const select4 = Select({
 *   label: 'Fruit',
 *   options: [
 *     { value: 'apple', label: 'Apple', group: 'Common' },
 *     { value: 'banana', label: 'Banana', group: 'Common' },
 *     { value: 'mango', label: 'Mango', group: 'Exotic' },
 *     { value: 'papaya', label: 'Papaya', group: 'Exotic' }
 *   ]
 * });
 *
 * // With error
 * const select5 = Select({
 *   label: 'Status',
 *   error: 'Please select a status',
 *   options: [...]
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { SelectProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Select: Pulse.Fn<SelectProps> = (props) => {
  const {
    value,
    options,
    placeholder = "Select an option",
    disabled = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    multiple = false,
    onChange,
    className,
    id = generateId("select"),
    style,
    ...rest
  } = props;

  // Container
  const container = (<div class="flex flex-col gap-1.5"></div>) as unknown as HTMLElement;

  // Label
  if (label) {
    const labelEl = (
      <label
        for={id}
        class="text-sm font-medium text-gray-700 dark:text-gray-300"
      ></label>
    ) as unknown as HTMLLabelElement;

    labelEl.textContent = label;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    container.appendChild(labelEl);
  }

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base select classes
  const baseClasses =
    "w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed appearance-none bg-white dark:bg-gray-700";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:text-gray-100";

  // Combine classes
  const selectClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    "pr-10", // Space for dropdown arrow
    className,
  );

  // Select wrapper (for custom arrow)
  const selectWrapper = (<div class="relative"></div>) as unknown as HTMLElement;

  // Create select element
  const select = (
    <select id={id} class={selectClasses}></select>
  ) as unknown as HTMLSelectElement;

  select.disabled = disabled;
  select.required = required;
  select.multiple = multiple;

  if (style) {
    if (typeof style === "string") {
      select.setAttribute("style", style);
    } else {
      Object.assign(select.style, style);
    }
  }

  // Group options by group property
  const groupedOptions: Record<string, typeof options> = {};
  const ungroupedOptions: typeof options = [];

  options.forEach((option) => {
    if (option.group) {
      if (!groupedOptions[option.group]) {
        groupedOptions[option.group] = [];
      }
      groupedOptions[option.group].push(option);
    } else {
      ungroupedOptions.push(option);
    }
  });

  // Render options
  const renderOptions = () => {
    select.innerHTML = "";

    // Placeholder option
    if (!multiple && placeholder) {
      const placeholderOption = (
        <option value="" disabled selected={!value}>
          {placeholder}
        </option>
      ) as unknown as HTMLOptionElement;
      select.appendChild(placeholderOption);
    }

    // Render ungrouped options
    ungroupedOptions.forEach((option) => {
      const optionEl = (
        <option
          value={String(option.value)}
          disabled={option.disabled || false}
        >
          {option.label}
        </option>
      ) as unknown as HTMLOptionElement;
      select.appendChild(optionEl);
    });

    // Render grouped options
    Object.entries(groupedOptions).forEach(([groupName, groupOptions]) => {
      const optgroup = (
        <optgroup label={groupName}></optgroup>
      ) as unknown as HTMLOptGroupElement;

      groupOptions.forEach((option) => {
        const optionEl = (
          <option
            value={String(option.value)}
            disabled={option.disabled || false}
          >
            {option.label}
          </option>
        ) as unknown as HTMLOptionElement;
        optgroup.appendChild(optionEl);
      });

      select.appendChild(optgroup);
    });
  };

  renderOptions();

  // Handle value (reactive or static)
  if (value !== undefined) {
    if (isSignal(value)) {
      Pulse.effect(() => {
        const val = (value as any)();
        if (multiple && Array.isArray(val)) {
          Array.from(select.options).forEach((option) => {
            option.selected = val.includes(option.value);
          });
        } else {
          select.value = String(val || "");
        }
      });
    } else {
      if (multiple && Array.isArray(value)) {
        Array.from(select.options).forEach((option) => {
          option.selected = (value as any[]).includes(option.value);
        });
      } else {
        select.value = String(value || "");
      }
    }
  }

  // Handle change event
  if (onChange) {
    select.onchange = (e) => {
      const target = e.target as HTMLSelectElement;
      if (multiple) {
        const selectedValues = Array.from(target.selectedOptions).map(
          (option) => option.value,
        );
        onChange(selectedValues);
      } else {
        onChange(target.value);
      }
    };
  }

  // Add extra attributes
  Object.entries(rest).forEach(([key, value]) => {
    if (key.startsWith("data-") || key.startsWith("aria-") || key === "name") {
      select.setAttribute(key, String(value));
    }
  });

  // Custom dropdown arrow
  const arrowIcon = (
    <span
      class={cn(
        "absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none",
        error ? "text-red-400" : "text-gray-400 dark:text-gray-500",
      )}
    >
      <svg
        class="w-4 h-4"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2"
          d="M19 9l-7 7-7-7"
        ></path>
      </svg>
    </span>
  ) as unknown as HTMLElement;

  selectWrapper.appendChild(select);
  selectWrapper.appendChild(arrowIcon);
  container.appendChild(selectWrapper);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
