/**
 * Toggle/Switch Component
 * A customizable toggle/switch component with label, description, icons, and validation states
 *
 * @example
 * ```tsx
 * import { Toggle } from '@odyssee/components';
 *
 * // Basic toggle
 * const toggle1 = Toggle({
 *   label: 'Enable notifications',
 *   onChange: (checked) => console.log(checked)
 * });
 *
 * // With description
 * const toggle2 = Toggle({
 *   label: 'Auto-save',
 *   description: 'Automatically save your changes',
 *   onChange: (checked) => console.log(checked)
 * });
 *
 * // With reactive value
 * const isEnabled = Pulse.signal(false);
 * const toggle3 = Toggle({
 *   label: 'Dark mode',
 *   checked: isEnabled,
 *   onChange: (checked) => isEnabled(checked)
 * });
 *
 * // With icons
 * const toggle4 = Toggle({
 *   label: 'Power',
 *   showIcons: true,
 *   onChange: (checked) => console.log(checked)
 * });
 *
 * // Different sizes
 * const toggle5 = Toggle({
 *   label: 'Small toggle',
 *   size: 'sm',
 *   onChange: (checked) => console.log(checked)
 * });
 *
 * // Soft variant
 * const toggle6 = Toggle({
 *   label: 'Soft toggle',
 *   variant: 'soft',
 *   onChange: (checked) => console.log(checked)
 * });
 *
 * // With error/success state
 * const toggle7 = Toggle({
 *   label: 'Accept terms',
 *   error: 'You must accept the terms',
 *   required: true
 * });
 *
 * // Disabled
 * const toggle8 = Toggle({
 *   label: 'Disabled option',
 *   disabled: true,
 *   checked: true
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { ToggleProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Toggle: Pulse.Fn<ToggleProps> = (props) => {
  const {
    checked = false,
    disabled = false,
    required = false,
    label,
    description,
    error,
    success,
    size = "md",
    variant = "default",
    showIcons = false,
    labelPosition = "right",
    onChange,
    className,
    id = generateId("toggle"),
    name,
    ...rest
  } = props;

  // Size classes for the toggle
  const sizeClasses = {
    xs: "w-8 h-4",
    sm: "w-9 h-5",
    md: "w-11 h-6",
    lg: "w-14 h-7",
  };

  // Size classes for the toggle thumb
  const thumbSizeClasses = {
    xs: "w-3 h-3",
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  // Translation classes for checked state
  const translateClasses = {
    xs: "translate-x-4",
    sm: "translate-x-4",
    md: "translate-x-5",
    lg: "translate-x-7",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
  };

  // Container
  const container = (<div class="flex flex-col gap-1.5"></div>) as unknown as HTMLElement;

  // Toggle wrapper
  const toggleWrapper = (
    <div
      class={cn(
        "flex items-start gap-2",
        labelPosition === "left" ? "flex-row-reverse justify-end" : "",
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Hidden checkbox input (for accessibility)
  const checkbox = (
    <input type="checkbox" id={id} class="sr-only peer" />
  ) as unknown as HTMLInputElement;

  if (name) checkbox.name = name;
  if (required) checkbox.required = required;
  checkbox.disabled = disabled;

  // Handle checked state reactively
  Pulse.effect(() => {
    const isChecked = isSignal(checked) ? (checked as any)() : checked;
    checkbox.checked = isChecked;
  });

  // Handle change event
  checkbox.onchange = (e) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.checked);
    }
  };

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      checkbox.setAttribute(key, String(val));
    }
  });

  // Build toggle switch (label element that acts as the visual switch)
  let switchBgClasses = "";
  let thumbClasses = "";

  if (variant === "soft") {
    // Soft variant
    if (error) {
      switchBgClasses =
        "bg-red-100 peer-checked:bg-red-200 dark:bg-red-900 dark:peer-checked:bg-red-800";
      thumbClasses = "bg-red-500 dark:bg-red-400";
    } else if (success) {
      switchBgClasses =
        "bg-green-100 peer-checked:bg-green-200 dark:bg-green-900 dark:peer-checked:bg-green-800";
      thumbClasses = "bg-green-500 dark:bg-green-400";
    } else {
      switchBgClasses =
        "bg-gray-100 peer-checked:bg-primary-100 dark:bg-gray-700 dark:peer-checked:bg-primary-900";
      thumbClasses =
        "bg-gray-400 peer-checked:bg-primary-600 dark:bg-gray-500 dark:peer-checked:bg-primary-500";
    }
  } else {
    // Default variant
    if (error) {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-red-600 dark:bg-gray-700 dark:peer-checked:bg-red-600";
    } else if (success) {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-green-600 dark:bg-gray-700 dark:peer-checked:bg-green-600";
    } else {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-primary-600 dark:bg-gray-700 dark:peer-checked:bg-primary-600";
    }
    thumbClasses = "bg-white dark:bg-gray-300";
  }

  const switchEl = (
    <label
      for={id}
      class={cn(
        "relative inline-flex items-center cursor-pointer",
        sizeClasses[size],
        switchBgClasses,
        "rounded-full transition-colors duration-200",
        "peer-focus:ring-2 peer-focus:ring-offset-2",
        error
          ? "peer-focus:ring-red-500"
          : success
            ? "peer-focus:ring-green-500"
            : "peer-focus:ring-primary-500",
        disabled ? "opacity-50 cursor-not-allowed" : "hover:brightness-95",
        className,
      )}
    ></label>
  ) as unknown as HTMLElement;

  // Thumb (the sliding circle)
  const thumb = (
    <span
      class={cn(
        "absolute left-0.5 top-0.5 rounded-full transition-transform duration-200",
        thumbSizeClasses[size],
        thumbClasses,
        `peer-checked:${translateClasses[size]}`,
        "flex items-center justify-center",
      )}
    ></span>
  ) as unknown as HTMLElement;

  // Icons inside thumb (if showIcons is true)
  if (showIcons) {
    // Check icon (shown when checked)
    const checkIcon = (
      <svg
        class="w-2.5 h-2.5 text-current opacity-0 peer-checked:opacity-100 absolute transition-opacity duration-200"
        fill="currentColor"
        viewBox="0 0 12 12"
      >
        <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
      </svg>
    ) as unknown as SVGElement;

    // X icon (shown when unchecked)
    const xIcon = (
      <svg
        class="w-2.5 h-2.5 text-current opacity-100 peer-checked:opacity-0 absolute transition-opacity duration-200"
        fill="currentColor"
        viewBox="0 0 12 12"
      >
        <path d="M11.707 1.707A1 1 0 0010.293.293L6 4.586 1.707.293A1 1 0 00.293 1.707L4.586 6 .293 10.293a1 1 0 101.414 1.414L6 7.414l4.293 4.293a1 1 0 001.414-1.414L7.414 6l4.293-4.293z" />
      </svg>
    ) as unknown as SVGElement;

    thumb.appendChild(checkIcon);
    thumb.appendChild(xIcon);
  }

  switchEl.appendChild(thumb);

  toggleWrapper.appendChild(checkbox);
  toggleWrapper.appendChild(switchEl);

  // Label and description
  if (label || description) {
    const labelContainer = (
      <div class="flex flex-col gap-0.5"></div>
    ) as unknown as HTMLElement;

    if (label) {
      const labelEl = (
        <span
          class={cn(
            "font-medium",
            labelSizeClasses[size],
            error
              ? "text-red-700 dark:text-red-400"
              : success
                ? "text-green-700 dark:text-green-400"
                : "text-gray-900 dark:text-gray-100",
            disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
          )}
        ></span>
      ) as unknown as HTMLElement;

      labelEl.textContent = label;

      if (required) {
        const requiredSpan = (
          <span class="text-red-500 ml-1">*</span>
        ) as unknown as HTMLElement;
        labelEl.appendChild(requiredSpan);
      }

      // Make label clickable
      labelEl.onclick = () => {
        if (!disabled) {
          checkbox.click();
        }
      };

      labelContainer.appendChild(labelEl);
    }

    if (description) {
      const descEl = (
        <p
          class={cn(
            "text-xs",
            error
              ? "text-red-600 dark:text-red-400"
              : success
                ? "text-green-600 dark:text-green-400"
                : "text-gray-500 dark:text-gray-400",
            disabled ? "opacity-50" : "",
          )}
        >
          {description}
        </p>
      ) as unknown as HTMLElement;
      labelContainer.appendChild(descEl);
    }

    toggleWrapper.appendChild(labelContainer);
  }

  container.appendChild(toggleWrapper);

  // Error or success message
  if (error && typeof error === "string") {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400 ml-6">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  } else if (success && typeof success === "string") {
    const successEl = (
      <p class="text-xs text-green-600 dark:text-green-400 ml-6">{success}</p>
    ) as unknown as HTMLElement;
    container.appendChild(successEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
