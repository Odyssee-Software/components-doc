/**
 * RadioGroup Component
 * A component for managing a group of radio buttons with a single value
 *
 * @example
 * ```tsx
 * import { RadioGroup } from '@odyssee/components';
 *
 * // Basic radio group
 * const radioGroup1 = RadioGroup({
 *   name: 'color',
 *   options: [
 *     { value: 'red', label: 'Red' },
 *     { value: 'blue', label: 'Blue' },
 *     { value: 'green', label: 'Green' }
 *   ],
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With reactive value
 * const selectedColor = Pulse.signal('blue');
 * const radioGroup2 = RadioGroup({
 *   name: 'color',
 *   label: 'Choose a color',
 *   value: selectedColor,
 *   options: [
 *     { value: 'red', label: 'Red' },
 *     { value: 'blue', label: 'Blue' },
 *     { value: 'green', label: 'Green' }
 *   ],
 *   onChange: (value) => selectedColor(value)
 * });
 *
 * // With descriptions
 * const radioGroup3 = RadioGroup({
 *   name: 'plan',
 *   label: 'Select a plan',
 *   options: [
 *     { value: 'free', label: 'Free', description: 'Basic features' },
 *     { value: 'pro', label: 'Pro', description: '$29/month - All features' },
 *     { value: 'enterprise', label: 'Enterprise', description: 'Custom pricing' }
 *   ]
 * });
 *
 * // Horizontal layout
 * const radioGroup4 = RadioGroup({
 *   name: 'size',
 *   label: 'Size',
 *   direction: 'horizontal',
 *   options: [
 *     { value: 'sm', label: 'Small' },
 *     { value: 'md', label: 'Medium' },
 *     { value: 'lg', label: 'Large' }
 *   ]
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { RadioGroupProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const RadioGroup: Pulse.Fn<RadioGroupProps> = (props) => {
  const {
    name = generateId("radio-group"),
    value,
    options,
    label,
    hint,
    error,
    required = false,
    disabled = false,
    size = "md",
    direction = "vertical",
    onChange,
    className,
    ...rest
  } = props;

  // Container
  const container = (
    <div class="flex flex-col gap-1.5"></div>
  ) as unknown as HTMLElement;

  // Label
  if (label) {
    const labelEl = (
      <label class="text-sm font-medium text-gray-700 dark:text-gray-300"></label>
    ) as unknown as HTMLLabelElement;

    labelEl.textContent = label;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    container.appendChild(labelEl);
  }

  // Options container
  const optionsContainer = (
    <div
      class={cn(
        "flex gap-4",
        direction === "horizontal" ? "flex-row flex-wrap" : "flex-col",
        className,
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Size classes
  const sizeClasses = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5",
    xl: "w-6 h-6",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  // Base radio classes
  const baseClasses =
    "border-gray-300 text-primary-600 focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-600 dark:bg-gray-700 dark:checked:bg-primary-500 dark:checked:border-primary-500 dark:focus:ring-primary-600 dark:focus:ring-offset-gray-800 transition-colors duration-200";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-600 focus:ring-red-500 dark:border-red-600"
    : "";

  // Create radio options
  options.forEach((option) => {
    const optionId = generateId("radio");
    const isDisabled = disabled || option.disabled || false;

    // Option wrapper
    const optionWrapper = (
      <div class="flex items-start gap-2"></div>
    ) as unknown as HTMLElement;

    // Radio input
    const radio = (
      <input
        type="radio"
        id={optionId}
        name={name}
        class={cn(baseClasses, sizeClasses[size], stateClasses)}
      />
    ) as unknown as HTMLInputElement;

    radio.value = String(option.value);
    radio.disabled = isDisabled;

    // Handle checked state reactively
    Pulse.effect(() => {
      const currentValue = isSignal(value) ? (value as any)() : value;
      radio.checked = currentValue === option.value;
    });

    // Handle change event
    radio.onchange = () => {
      if (onChange) {
        onChange(option.value);
      }
    };

    optionWrapper.appendChild(radio);

    // Label and description
    if (option.label || option.description) {
      const labelContainer = (
        <div class="flex flex-col gap-0.5"></div>
      ) as unknown as HTMLElement;

      if (option.label) {
        const labelEl = (
          <label
            for={optionId}
            class={cn(
              "font-medium cursor-pointer",
              labelSizeClasses[size],
              error
                ? "text-red-700 dark:text-red-400"
                : "text-gray-900 dark:text-gray-100",
              isDisabled ? "opacity-50 cursor-not-allowed" : "",
            )}
          ></label>
        ) as unknown as HTMLLabelElement;

        labelEl.textContent = option.label;
        labelContainer.appendChild(labelEl);
      }

      if (option.description) {
        const descEl = (
          <p
            class={cn(
              "text-xs",
              error
                ? "text-red-600 dark:text-red-400"
                : "text-gray-500 dark:text-gray-400",
              isDisabled ? "opacity-50" : "",
            )}
          >
            {option.description}
          </p>
        ) as unknown as HTMLElement;
        labelContainer.appendChild(descEl);
      }

      optionWrapper.appendChild(labelContainer);
    }

    optionsContainer.appendChild(optionWrapper);
  });

  container.appendChild(optionsContainer);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  // Add extra attributes
  Object.entries(rest).forEach(([key, val]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      container.setAttribute(key, String(val));
    }
  });

  return container as unknown as Pulse.JSX.Element;
};
