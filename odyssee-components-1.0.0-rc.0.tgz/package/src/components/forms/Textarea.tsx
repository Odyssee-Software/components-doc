/**
 * Textarea Component
 * A flexible textarea component with labels, hints, validation, and auto-resize
 *
 * @example
 * ```tsx
 * import { Textarea } from '@odyssee/components';
 *
 * // Basic textarea
 * const textarea1 = Textarea({
 *   placeholder: 'Enter your message',
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With label and hint
 * const textarea2 = Textarea({
 *   label: 'Comment',
 *   hint: 'We will get back to you soon.',
 *   rows: 3,
 *   required: true
 * });
 *
 * // With reactive value
 * const message = Pulse.signal('');
 * const textarea3 = Textarea({
 *   label: 'Message',
 *   value: message,
 *   onChange: (val) => message(val)
 * });
 *
 * // With error state
 * const textarea4 = Textarea({
 *   label: 'Feedback',
 *   error: 'Your message should be at least 10 characters long',
 *   value: 'Short'
 * });
 *
 * // With character count
 * const textarea5 = Textarea({
 *   label: 'Bio',
 *   maxLength: 200,
 *   showCount: true,
 *   placeholder: 'Tell us about yourself'
 * });
 *
 * // Auto-resize
 * const textarea6 = Textarea({
 *   label: 'Description',
 *   autoResize: true,
 *   minRows: 2,
 *   maxRows: 8
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { TextareaProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Textarea: Pulse.Fn<TextareaProps> = (props) => {
  const {
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    rows = 3,
    maxLength,
    showCount = false,
    autoResize = false,
    minRows = 2,
    maxRows = 10,
    onChange,
    onFocus,
    onBlur,
    className,
    id = generateId("textarea"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base textarea classes
  const baseClasses =
    "block w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed resize-y";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-500";

  // Combine classes
  const textareaClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    autoResize ? "resize-none overflow-hidden" : "",
    className,
  );

  // Container
  const container = (<div class="flex flex-col gap-1.5"></div>) as unknown as HTMLElement;

  // Label with optional character count
  if (label) {
    const labelWrapper = (
      <div class="flex items-center justify-between"></div>
    ) as unknown as HTMLElement;

    const labelEl = (
      <label
        for={id}
        class="text-sm font-medium text-gray-700 dark:text-gray-300"
      >
        {label}
      </label>
    ) as unknown as HTMLLabelElement;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    labelWrapper.appendChild(labelEl);

    // Corner hint (character count)
    if (maxLength && showCount) {
      const countEl = (
        <span class="text-xs text-gray-500 dark:text-gray-400">
          0 / {maxLength}
        </span>
      ) as unknown as HTMLElement;

      labelWrapper.appendChild(countEl);

      // Update count reactively
      Pulse.effect(() => {
        const currentValue = isSignal(value) ? (value as any)() : value;
        const length = currentValue ? String(currentValue).length : 0;
        countEl.textContent = `${length} / ${maxLength}`;
      });
    }

    container.appendChild(labelWrapper);
  }

  // Create textarea
  const textarea = (
    <textarea
      id={id}
      class={textareaClasses}
      placeholder={placeholder}
      disabled={disabled}
      readonly={readonly}
      required={required}
      rows={autoResize ? minRows : rows}
    />
  ) as unknown as HTMLTextAreaElement;

  if (maxLength) textarea.maxLength = maxLength;

  if (style) {
    if (typeof style === "string") {
      textarea.setAttribute("style", style);
    } else {
      Object.assign(textarea.style, style);
    }
  }

  // Handle value (reactive or static)
  if (value !== undefined) {
    if (isSignal(value)) {
      Pulse.effect(() => {
        const val = (value as any)();
        textarea.value = val || "";
        if (autoResize) {
          handleAutoResize();
        }
      });
    } else {
      textarea.value = (value as string) || "";
    }
  }

  // Auto-resize function
  const handleAutoResize = () => {
    if (!autoResize) return;

    // Reset height to auto to get the correct scrollHeight
    textarea.style.height = "auto";

    // Calculate new height based on content
    const newHeight = textarea.scrollHeight;

    // Apply min/max constraints
    const lineHeight = parseInt(getComputedStyle(textarea).lineHeight) || 20;
    const minHeight = minRows * lineHeight;
    const maxHeight = maxRows * lineHeight;

    const constrainedHeight = Math.min(
      Math.max(newHeight, minHeight),
      maxHeight,
    );
    textarea.style.height = `${constrainedHeight}px`;

    // Show scrollbar if content exceeds maxHeight
    if (newHeight > maxHeight) {
      textarea.style.overflowY = "auto";
    } else {
      textarea.style.overflowY = "hidden";
    }
  };

  // Handle events
  if (onChange) {
    textarea.oninput = (e) => {
      const target = e.target as HTMLTextAreaElement;
      onChange(target.value);
      if (autoResize) {
        handleAutoResize();
      }
    };
  } else if (autoResize) {
    // Still need to handle auto-resize even without onChange
    textarea.oninput = () => {
      handleAutoResize();
    };
  }

  if (onFocus) {
    textarea.onfocus = onFocus;
  }

  if (onBlur) {
    textarea.onblur = onBlur;
  }

  // Add extra attributes
  Object.entries(rest).forEach(([key, value]) => {
    if (
      key.startsWith("data-") ||
      key.startsWith("aria-") ||
      key === "name" ||
      key === "autocomplete"
    ) {
      textarea.setAttribute(key, String(value));
    }
  });

  // Initial auto-resize
  if (autoResize && value) {
    setTimeout(() => handleAutoResize(), 0);
  }

  container.appendChild(textarea);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
