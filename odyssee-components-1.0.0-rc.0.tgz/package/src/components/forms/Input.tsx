/**
 * Input Component
 * A flexible input component with labels, hints, validation, and icons
 *
 * @example
 * ```tsx
 * import { Input } from '@odyssee/components';
 *
 * // Basic input
 * const input1 = Input({
 *   placeholder: 'Enter your name',
 *   onChange: (value) => console.log(value)
 * });
 *
 * // With label and hint
 * const input2 = Input({
 *   label: 'Email',
 *   hint: 'We will never share your email',
 *   type: 'email',
 *   required: true
 * });
 *
 * // With reactive value
 * const email = Pulse.signal('');
 * const input3 = Input({
 *   label: 'Email',
 *   value: email,
 *   onChange: (val) => email(val)
 * });
 *
 * // With error state
 * const input4 = Input({
 *   label: 'Username',
 *   error: 'Username is already taken',
 *   value: 'john'
 * });
 *
 * // With icon
 * const input5 = Input({
 *   label: 'Search',
 *   icon: '🔍',
 *   iconPosition: 'left',
 *   placeholder: 'Search...'
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { InputProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Input: Pulse.Fn<InputProps> = (props) => {
  const {
    type = "text",
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    icon,
    iconPosition = "left",
    onChange,
    onFocus,
    onBlur,
    className,
    id = generateId("input"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Icon padding classes
  const iconPaddingClasses = {
    left: {
      xs: "pl-7",
      sm: "pl-8",
      md: "pl-9",
      lg: "pl-10",
      xl: "pl-12",
    },
    right: {
      xs: "pr-7",
      sm: "pr-8",
      md: "pr-9",
      lg: "pr-10",
      xl: "pr-12",
    },
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-500";

  // Icon classes
  const iconClass =
    icon && iconPosition ? iconPaddingClasses[iconPosition][size] : "";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    iconClass,
    className,
  );

  // Container
  const container = (
    <div class="flex flex-col gap-1.5"></div>
  ) as unknown as HTMLElement;

  // Label
  if (label) {
    const labelEl = (
      <label
        for={id}
        class="text-sm font-medium text-gray-700 dark:text-gray-300"
      >
        {label}
      </label>
    ) as unknown as HTMLLabelElement;

    if (required) {
      const requiredSpan = (
        <span class="text-red-500 ml-1">*</span>
      ) as unknown as HTMLElement;
      labelEl.appendChild(requiredSpan);
    }

    container.appendChild(labelEl);
  }

  // Input wrapper (for icon positioning)
  const inputWrapper = (<div class="relative"></div>) as unknown as HTMLElement;

  // Create input
  const input = (
    <input
      type={type}
      id={id}
      class={inputClasses}
      placeholder={placeholder}
      disabled={disabled}
      readonly={readonly}
      required={required}
    />
  ) as unknown as HTMLInputElement;

  if (style) {
    if (typeof style === "string") {
      input.setAttribute("style", style);
    } else {
      Object.assign(input.style, style);
    }
  }

  // Handle value (reactive or static)
  if (value !== undefined) {
    console.log(
      "[Input] value type:",
      typeof value,
      "isSignal:",
      isSignal(value),
    );
    if (isSignal(value)) {
      console.log("[Input] Setting up reactive binding for signal");
      Pulse.effect(() => {
        const val = (value as any)();
        console.log("[Input] Signal value changed:", val);
        input.value = val || "";
      });
    } else {
      console.log("[Input] Setting static value:", value);
      input.value = (value as string) || "";
    }
  }

  // Handle events
  if (onChange) {
    input.oninput = (e) => {
      const target = e.target as HTMLInputElement;
      onChange(target.value);
    };
  }

  if (onFocus) {
    input.onfocus = onFocus;
  }

  if (onBlur) {
    input.onblur = onBlur;
  }

  // Add extra attributes
  Object.entries(rest).forEach(([key, value]) => {
    if (
      key.startsWith("data-") ||
      key.startsWith("aria-") ||
      key === "name" ||
      key === "autocomplete"
    ) {
      input.setAttribute(key, String(value));
    }
  });

  // Add icon if provided
  if (icon) {
    const iconSizes = {
      xs: "text-xs",
      sm: "text-sm",
      md: "text-base",
      lg: "text-lg",
      xl: "text-xl",
    };

    const iconEl = (
      <span
        class={cn(
          "absolute top-1/2 -translate-y-1/2 pointer-events-none",
          iconPosition === "left" ? "left-2.5" : "right-2.5",
          error ? "text-red-400" : "text-gray-400 dark:text-gray-500",
          iconSizes[size],
        )}
      >
        {icon}
      </span>
    ) as unknown as HTMLElement;

    inputWrapper.appendChild(iconEl);
  }

  inputWrapper.appendChild(input);
  container.appendChild(inputWrapper);

  // Hint text
  if (hint && !error) {
    const hintEl = (
      <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
    ) as unknown as HTMLElement;
    container.appendChild(hintEl);
  }

  // Error message
  if (error) {
    const errorEl = (
      <p class="text-xs text-red-600 dark:text-red-400">{error}</p>
    ) as unknown as HTMLElement;
    container.appendChild(errorEl);
  }

  return container as unknown as Pulse.JSX.Element;
};
