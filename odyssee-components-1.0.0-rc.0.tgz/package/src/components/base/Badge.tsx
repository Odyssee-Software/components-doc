/**
 * Badge Component
 * A small badge/label/chip component with multiple variants, colors, and states
 *
 * @example
 * ```tsx
 * import { Badge } from '@odyssee/components';
 *
 * // Basic badge
 * const badge1 = <Badge>New</Badge>;
 *
 * // Solid variant with colors
 * const badge2 = <Badge variant="solid" color="primary">Primary</Badge>;
 *
 * // Soft variant
 * const badge3 = <Badge variant="soft" color="success">Success</Badge>;
 *
 * // Outline variant
 * const badge4 = <Badge variant="outline" color="danger">Danger</Badge>;
 *
 * // With icon
 * const badge5 = <Badge variant="soft" color="info" icon="✓">Connected</Badge>;
 *
 * // With dot indicator
 * const badge6 = <Badge variant="soft" color="success" dot={true}>Active</Badge>;
 *
 * // Rounded/pill
 * const badge7 = <Badge variant="solid" color="primary" rounded="full">99+</Badge>;
 *
 * // Different sizes
 * const badge8 = <Badge size="lg">Large badge</Badge>;
 *
 * // Dismissible badge
 * const badge9 = (
 *   <Badge variant="soft" color="primary" dismissible={true} onDismiss={() => console.log('dismissed')}>
 *     Removable
 *   </Badge>
 * );
 * ```
 */

import Pulse from "pulse-framework";
import type { BadgeProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Badge: Pulse.Fn<BadgeProps> = (props) => {
  const {
    variant = "soft",
    color = "primary",
    size = "md",
    rounded = false,
    dot = false,
    icon,
    dismissible = false,
    children,
    onDismiss,
    className,
    id = generateId("badge"),
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-1.5 py-0.5 text-xs",
    sm: "px-2 py-0.5 text-xs",
    md: "px-2.5 py-1 text-sm",
    lg: "px-3 py-1.5 text-sm",
    xl: "px-4 py-2 text-base",
  };

  // Rounded classes
  const roundedClasses = {
    false: "rounded",
    true: "rounded-lg",
    full: "rounded-full",
  };

  // Variant color classes
  const variantColorClasses: any = {
    solid: {
      primary: "bg-primary-600 text-white border-primary-600",
      secondary: "bg-gray-600 text-white border-gray-600",
      info: "bg-blue-600 text-white border-blue-600",
      success: "bg-green-600 text-white border-green-600",
      danger: "bg-red-600 text-white border-red-600",
      warning: "bg-yellow-500 text-white border-yellow-500",
      light: "bg-gray-100 text-gray-800 border-gray-100",
      dark: "bg-gray-900 text-white border-gray-900",
    },
    soft: {
      primary:
        "bg-primary-100 text-primary-800 dark:bg-primary-900/20 dark:text-primary-400",
      secondary:
        "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300",
      info: "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-400",
      success:
        "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400",
      danger: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400",
      warning:
        "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400",
      light: "bg-gray-50 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
      dark: "bg-gray-800 text-gray-200 dark:bg-gray-900 dark:text-gray-300",
    },
    outline: {
      primary:
        "bg-white text-primary-600 border border-primary-600 dark:bg-transparent dark:text-primary-400 dark:border-primary-400",
      secondary:
        "bg-white text-gray-600 border border-gray-600 dark:bg-transparent dark:text-gray-300 dark:border-gray-300",
      info: "bg-white text-blue-600 border border-blue-600 dark:bg-transparent dark:text-blue-400 dark:border-blue-400",
      success:
        "bg-white text-green-600 border border-green-600 dark:bg-transparent dark:text-green-400 dark:border-green-400",
      danger:
        "bg-white text-red-600 border border-red-600 dark:bg-transparent dark:text-red-400 dark:border-red-400",
      warning:
        "bg-white text-yellow-600 border border-yellow-600 dark:bg-transparent dark:text-yellow-400 dark:border-yellow-400",
      light:
        "bg-white text-gray-500 border border-gray-300 dark:bg-transparent dark:text-gray-400 dark:border-gray-600",
      dark: "bg-white text-gray-800 border border-gray-800 dark:bg-transparent dark:text-gray-200 dark:border-gray-200",
    },
  };

  // Dot color classes
  const dotColorClasses = {
    primary: "bg-primary-600 dark:bg-primary-400",
    secondary: "bg-gray-600 dark:bg-gray-300",
    info: "bg-blue-600 dark:bg-blue-400",
    success: "bg-green-600 dark:bg-green-400",
    danger: "bg-red-600 dark:bg-red-400",
    warning: "bg-yellow-600 dark:bg-yellow-400",
    light: "bg-gray-400 dark:bg-gray-500",
    dark: "bg-gray-900 dark:bg-gray-200",
  };

  // Handle dismiss
  const handleDismiss = (e: Event) => {
    e.stopPropagation();
    if (onDismiss) {
      onDismiss();
    } else {
      // Default behavior: remove badge
      const target = e.currentTarget as HTMLElement;
      const badge = target.closest("span");
      if (badge) {
        badge.remove();
      }
    }
  };

  // Build badge JSX
  return (
    <span
      id={id}
      class={cn(
        "inline-flex items-center gap-1.5 font-medium",
        sizeClasses[size],
        roundedClasses[String(rounded) as keyof typeof roundedClasses],
        variantColorClasses[variant][color],
        className,
      )}
      {...rest}
    >
      {dot && (
        <span
          class={cn(
            "inline-block w-1.5 h-1.5 rounded-full",
            dotColorClasses[color],
          )}
        />
      )}

      {icon && <span class="inline-flex items-center">{icon}</span>}

      {children}

      {dismissible && (
        <button
          type="button"
          class="inline-flex items-center justify-center shrink-0 w-4 h-4 rounded-sm hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          aria-label="Remove"
          onclick={handleDismiss}
        >
          <svg class="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
            <path
              fill-rule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clip-rule="evenodd"
            />
          </svg>
        </button>
      )}
    </span>
  ) as Pulse.JSX.Element;
};
