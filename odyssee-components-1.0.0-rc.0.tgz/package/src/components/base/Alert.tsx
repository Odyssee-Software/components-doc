/**
 * Alert Component
 * A flexible alert/notification component with multiple variants, colors, and dismiss functionality
 *
 * @example
 * ```tsx
 * import { Alert } from '@odyssee/components';
 *
 * // Basic alert
 * const alert1 = Alert({
 *   variant: 'solid',
 *   color: 'info',
 *   children: 'This is an info alert!'
 * });
 *
 * // With title and description
 * const alert2 = Alert({
 *   variant: 'soft',
 *   color: 'success',
 *   title: 'Successfully updated',
 *   children: 'You have successfully updated your email preferences.'
 * });
 *
 * // With icon
 * const alert3 = Alert({
 *   variant: 'bordered',
 *   color: 'danger',
 *   icon: '⚠️',
 *   title: 'Error!',
 *   children: 'Your purchase has been declined.'
 * });
 *
 * // With list
 * const alert4 = Alert({
 *   variant: 'soft',
 *   color: 'danger',
 *   title: 'A problem has occurred',
 *   children: (
 *     <ul>
 *       <li>This username is already in use</li>
 *       <li>Email field can't be empty</li>
 *       <li>Please enter a valid phone number</li>
 *     </ul>
 *   )
 * });
 *
 * // Dismissible alert
 * const isVisible = Pulse.signal(true);
 * const alert5 = Alert({
 *   variant: 'solid',
 *   color: 'success',
 *   dismissible: true,
 *   isVisible: isVisible,
 *   onDismiss: () => isVisible(false),
 *   children: 'File has been successfully uploaded.'
 * });
 *
 * // With actions
 * const alert6 = Alert({
 *   variant: 'soft',
 *   color: 'primary',
 *   title: 'YouTube would like to send notifications',
 *   children: 'Notifications may include alerts, sounds and icon badges.',
 *   actions: (
 *     <>
 *       <button>Don't allow</button>
 *       <button>Allow</button>
 *     </>
 *   )
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { AlertProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Alert: Pulse.Fn<AlertProps> = (props) => {
  const {
    variant = "soft",
    color = "primary",
    title,
    children,
    icon,
    dismissible = false,
    isVisible = true,
    actions,
    onDismiss,
    className,
    id = generateId("alert"),
    ...rest
  } = props;

  // Variant color classes
  const variantColorClasses = {
    solid: {
      primary: "bg-primary-600 text-white border-primary-600",
      secondary: "bg-gray-600 text-white border-gray-600",
      info: "bg-blue-600 text-white border-blue-600",
      success: "bg-green-600 text-white border-green-600",
      danger: "bg-red-600 text-white border-red-600",
      warning: "bg-yellow-500 text-white border-yellow-500",
      light: "bg-gray-100 text-gray-800 border-gray-100",
      dark: "bg-gray-900 text-white border-gray-900",
    },
    soft: {
      primary:
        "bg-primary-50 text-primary-800 border-primary-200 dark:bg-primary-900/10 dark:text-primary-500 dark:border-primary-900",
      secondary:
        "bg-gray-50 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      info: "bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-900/10 dark:text-blue-500 dark:border-blue-900",
      success:
        "bg-green-50 text-green-800 border-green-200 dark:bg-green-900/10 dark:text-green-500 dark:border-green-900",
      danger:
        "bg-red-50 text-red-800 border-red-200 dark:bg-red-900/10 dark:text-red-500 dark:border-red-900",
      warning:
        "bg-yellow-50 text-yellow-800 border-yellow-200 dark:bg-yellow-900/10 dark:text-yellow-500 dark:border-yellow-900",
      light:
        "bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      dark: "bg-gray-800 text-gray-200 border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-800",
    },
    bordered: {
      primary:
        "bg-white text-primary-800 border-primary-300 dark:bg-gray-800 dark:text-primary-400 dark:border-primary-800",
      secondary:
        "bg-white text-gray-800 border-gray-300 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      info: "bg-white text-blue-800 border-blue-300 dark:bg-gray-800 dark:text-blue-400 dark:border-blue-800",
      success:
        "bg-white text-green-800 border-green-300 dark:bg-gray-800 dark:text-green-400 dark:border-green-800",
      danger:
        "bg-white text-red-800 border-red-300 dark:bg-gray-800 dark:text-red-400 dark:border-red-800",
      warning:
        "bg-white text-yellow-800 border-yellow-300 dark:bg-gray-800 dark:text-yellow-400 dark:border-yellow-800",
      light:
        "bg-white text-gray-600 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      dark: "bg-white text-gray-800 border-gray-800 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600",
    },
  };

  // Icon color classes (for soft variant)
  const iconColorClasses = {
    primary: "text-primary-600 dark:text-primary-400",
    secondary: "text-gray-600 dark:text-gray-400",
    info: "text-blue-600 dark:text-blue-400",
    success: "text-green-600 dark:text-green-400",
    danger: "text-red-600 dark:text-red-400",
    warning: "text-yellow-600 dark:text-yellow-400",
    light: "text-gray-500 dark:text-gray-400",
    dark: "text-gray-700 dark:text-gray-300",
  };

  // Container
  const container = (
    <div
      id={id}
      role="alert"
      class={cn(
        "flex p-4 border rounded-lg transition-all duration-200",
        variantColorClasses[variant][color],
        className,
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Handle visibility reactively
  Pulse.effect(() => {
    const visible = isSignal(isVisible) ? (isVisible as any)() : isVisible;
    container.style.display = visible ? "flex" : "none";
  });

  // Add extra attributes
  Object.entries(rest).forEach(([key, value]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      container.setAttribute(key, String(value));
    }
  });

  // Icon (if provided)
  if (icon) {
    const iconWrapper = (<div class="flex-shrink-0"></div>) as unknown as HTMLElement;

    const iconEl = (
      <span
        class={cn(
          "inline-flex items-center justify-center text-lg",
          variant === "soft" ? iconColorClasses[color] : "",
        )}
      >
        {icon}
      </span>
    ) as unknown as HTMLElement;

    iconWrapper.appendChild(iconEl);
    container.appendChild(iconWrapper);
  }

  // Content wrapper
  const contentWrapper = (<div class="flex-1 ms-3"></div>) as unknown as HTMLElement;

  // Title
  if (title) {
    const titleEl = (
      <h3 class="text-sm font-semibold mb-1">
        {typeof title === "string" ? title : ""}
      </h3>
    ) as unknown as HTMLElement;

    if (typeof title !== "string" && title instanceof HTMLElement) {
      titleEl.innerHTML = "";
      titleEl.appendChild(title);
    }

    contentWrapper.appendChild(titleEl);
  }

  // Children content
  if (children) {
    const contentEl = (<div class="text-sm"></div>) as unknown as HTMLElement;

    if (typeof children === "string") {
      contentEl.textContent = children;
    } else if (Array.isArray(children)) {
      children.forEach((child) => {
        if (child instanceof HTMLElement) {
          contentEl.appendChild(child);
        } else if (typeof child === "string") {
          const textNode = document.createTextNode(child);
          contentEl.appendChild(textNode);
        }
      });
    } else if (children instanceof HTMLElement) {
      contentEl.appendChild(children);
    }

    contentWrapper.appendChild(contentEl);
  }

  // Actions
  if (actions) {
    const actionsWrapper = (
      <div class="flex items-center gap-2 mt-3"></div>
    ) as unknown as HTMLElement;

    if (Array.isArray(actions)) {
      actions.forEach((action) => {
        if (action instanceof HTMLElement) {
          actionsWrapper.appendChild(action);
        }
      });
    } else if (actions instanceof HTMLElement) {
      actionsWrapper.appendChild(actions);
    }

    contentWrapper.appendChild(actionsWrapper);
  }

  container.appendChild(contentWrapper);

  // Dismiss button
  if (dismissible) {
    const dismissButton = (
      <button
        type="button"
        class={cn(
          "inline-flex flex-shrink-0 justify-center items-center w-5 h-5 rounded-lg opacity-50 hover:opacity-100 focus:outline-none focus:opacity-100 transition",
          variant === "solid" ? "text-white" : "",
        )}
        aria-label="Close"
      >
        <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
          <path
            fill-rule="evenodd"
            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
            clip-rule="evenodd"
          ></path>
        </svg>
      </button>
    ) as unknown as HTMLButtonElement;

    dismissButton.onclick = () => {
      if (onDismiss) {
        onDismiss();
      }
    };

    container.appendChild(dismissButton);
  }

  return container as unknown as Pulse.JSX.Element;
};
