/**
 * Modal Component
 * A flexible modal/dialog overlay component with backdrop, animations, and sizes
 *
 * @example
 * ```tsx
 * import { Modal } from '@odyssee/components';
 *
 * // Basic modal
 * const isOpen = Pulse.signal(false);
 * const modal1 = Modal({
 *   isOpen: isOpen,
 *   title: 'Modal Title',
 *   onClose: () => isOpen(false),
 *   children: <p>This is the modal content</p>
 * });
 *
 * // With footer actions
 * const modal2 = Modal({
 *   isOpen: isOpen,
 *   title: 'Confirm Action',
 *   onClose: () => isOpen(false),
 *   children: <p>Are you sure you want to proceed?</p>,
 *   footer: (
 *     <>
 *       <button onClick={() => isOpen(false)}>Cancel</button>
 *       <button onClick={handleConfirm}>Confirm</button>
 *     </>
 *   )
 * });
 *
 * // Different sizes
 * const modal3 = Modal({
 *   isOpen: isOpen,
 *   title: 'Large Modal',
 *   size: 'lg',
 *   onClose: () => isOpen(false),
 *   children: <p>Large modal content</p>
 * });
 *
 * // Centered
 * const modal4 = Modal({
 *   isOpen: isOpen,
 *   title: 'Centered Modal',
 *   centered: true,
 *   onClose: () => isOpen(false),
 *   children: <p>Centered modal content</p>
 * });
 *
 * // Static backdrop (can't close by clicking outside)
 * const modal5 = Modal({
 *   isOpen: isOpen,
 *   title: 'Static Modal',
 *   staticBackdrop: true,
 *   onClose: () => isOpen(false),
 *   children: <p>Click close button to dismiss</p>
 * });
 *
 * // Fullscreen
 * const modal6 = Modal({
 *   isOpen: isOpen,
 *   title: 'Fullscreen Modal',
 *   fullscreen: true,
 *   onClose: () => isOpen(false),
 *   children: <p>Fullscreen content</p>
 * });
 * ```
 */

import Pulse from "pulse-framework";
import type { ModalProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Modal: Pulse.Fn<ModalProps> = (props) => {
  const {
    isOpen,
    title,
    children,
    footer,
    size = "md",
    centered = false,
    staticBackdrop = false,
    fullscreen = false,
    showCloseButton = true,
    closeOnEscape = true,
    animation = "scale",
    onClose,
    className,
    id = generateId("modal"),
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    sm: "max-w-sm",
    md: "max-w-lg",
    lg: "max-w-2xl",
    xl: "max-w-4xl",
    "2xl": "max-w-6xl",
  };

  // Animation classes
  const animationClasses = {
    scale: "transition-all duration-300 ease-out",
    slideDown: "transition-all duration-300 ease-out",
    slideUp: "transition-all duration-300 ease-out",
    fade: "transition-opacity duration-300 ease-out",
  };

  // Container (fixed overlay)
  const container = (
    <div class="fixed inset-0 z-50 overflow-y-auto overflow-x-hidden"></div>
  ) as unknown as HTMLElement;

  // Handle reactive visibility
  Pulse.effect(() => {
    const open = isSignal(isOpen) ? (isOpen as any)() : isOpen;

    if (open) {
      container.style.display = "block";
      // Prevent body scroll when modal is open
      document.body.style.overflow = "hidden";

      // Small delay for animation
      setTimeout(() => {
        backdrop.classList.add("opacity-100");
        backdrop.classList.remove("opacity-0");

        modalDialog.classList.remove("opacity-0");
        modalDialog.classList.add("opacity-100");

        if (animation === "scale") {
          modalDialog.classList.remove("scale-95");
          modalDialog.classList.add("scale-100");
        } else if (animation === "slideDown") {
          modalDialog.classList.remove("-translate-y-10");
          modalDialog.classList.add("translate-y-0");
        } else if (animation === "slideUp") {
          modalDialog.classList.remove("translate-y-10");
          modalDialog.classList.add("translate-y-0");
        }
      }, 10);
    } else {
      backdrop.classList.remove("opacity-100");
      backdrop.classList.add("opacity-0");

      modalDialog.classList.remove("opacity-100");
      modalDialog.classList.add("opacity-0");

      if (animation === "scale") {
        modalDialog.classList.remove("scale-100");
        modalDialog.classList.add("scale-95");
      } else if (animation === "slideDown") {
        modalDialog.classList.remove("translate-y-0");
        modalDialog.classList.add("-translate-y-10");
      } else if (animation === "slideUp") {
        modalDialog.classList.remove("translate-y-0");
        modalDialog.classList.add("translate-y-10");
      }

      // Wait for animation to complete before hiding
      setTimeout(() => {
        container.style.display = "none";
        document.body.style.overflow = "";
      }, 300);
    }
  });

  // Backdrop
  const backdrop = (
    <div class="fixed inset-0 bg-black bg-opacity-50 transition-opacity duration-300 opacity-0"></div>
  ) as unknown as HTMLElement;

  // Handle backdrop click
  backdrop.onclick = () => {
    if (!staticBackdrop && onClose) {
      onClose();
    }
  };

  container.appendChild(backdrop);

  // Modal wrapper (for centering)
  const modalWrapper = (
    <div
      class={cn(
        "flex min-h-full items-start justify-center p-4 text-center",
        centered ? "items-center" : "sm:items-center",
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Prevent clicks on wrapper from closing modal
  modalWrapper.onclick = (e) => {
    if (e.target === modalWrapper && !staticBackdrop && onClose) {
      onClose();
    }
  };

  // Modal dialog
  const initialAnimationClasses =
    animation === "scale"
      ? "opacity-0 scale-95"
      : animation === "slideDown"
        ? "opacity-0 -translate-y-10"
        : animation === "slideUp"
          ? "opacity-0 translate-y-10"
          : "opacity-0";

  const modalDialog = (
    <div
      id={id}
      role="dialog"
      aria-modal="true"
      class={cn(
        "relative w-full my-8 mx-auto transform text-left shadow-xl",
        "bg-white dark:bg-gray-800 rounded-lg",
        animationClasses[animation],
        initialAnimationClasses,
        fullscreen
          ? "min-h-screen w-screen max-w-none m-0 rounded-none"
          : sizeClasses[size],
        className,
      )}
    ></div>
  ) as unknown as HTMLElement;

  // Prevent clicks inside modal from closing it
  modalDialog.onclick = (e) => {
    e.stopPropagation();
  };

  // Add extra attributes
  Object.entries(rest).forEach(([key, value]) => {
    if (key.startsWith("data-") || key.startsWith("aria-")) {
      modalDialog.setAttribute(key, String(value));
    }
  });

  // Modal header
  if (title || showCloseButton) {
    const header = (
      <div class="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-gray-700"></div>
    ) as unknown as HTMLElement;

    if (title) {
      const titleEl = (
        <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">
          {typeof title === "string" ? title : ""}
        </h3>
      ) as unknown as HTMLElement;

      if (typeof title !== "string") {
        titleEl.innerHTML = "";
        if (title instanceof HTMLElement) {
          titleEl.appendChild(title);
        }
      }

      header.appendChild(titleEl);
    }

    if (showCloseButton) {
      const closeButton = (
        <button
          type="button"
          class="inline-flex items-center justify-center w-8 h-8 text-sm text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 dark:hover:text-gray-300 transition-colors"
          aria-label="Close"
        >
          <svg
            class="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M6 18L18 6M6 6l12 12"
            ></path>
          </svg>
        </button>
      ) as unknown as HTMLButtonElement;

      closeButton.onclick = () => {
        if (onClose) {
          onClose();
        }
      };

      header.appendChild(closeButton);
    }

    modalDialog.appendChild(header);
  }

  // Modal body
  const body = (
    <div class="px-4 py-4 overflow-y-auto max-h-[calc(100vh-200px)]"></div>
  ) as unknown as HTMLElement;

  if (children) {
    if (typeof children === "string") {
      body.textContent = children;
    } else if (Array.isArray(children)) {
      children.forEach((child) => {
        if (child instanceof HTMLElement) {
          body.appendChild(child);
        } else if (typeof child === "string") {
          const textNode = document.createTextNode(child);
          body.appendChild(textNode);
        }
      });
    } else if (children instanceof HTMLElement) {
      body.appendChild(children);
    }
  }

  modalDialog.appendChild(body);

  // Modal footer
  if (footer) {
    const footerEl = (
      <div class="flex items-center justify-end gap-2 px-4 py-3 border-t border-gray-200 dark:border-gray-700"></div>
    ) as unknown as HTMLElement;

    if (Array.isArray(footer)) {
      footer.forEach((item) => {
        if (item instanceof HTMLElement) {
          footerEl.appendChild(item);
        }
      });
    } else if (footer instanceof HTMLElement) {
      footerEl.appendChild(footer);
    }

    modalDialog.appendChild(footerEl);
  }

  modalWrapper.appendChild(modalDialog);
  container.appendChild(modalWrapper);

  // Handle escape key
  if (closeOnEscape) {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        const open = isSignal(isOpen) ? (isOpen as any)() : isOpen;
        if (open && onClose) {
          onClose();
        }
      }
    };

    document.addEventListener("keydown", handleEscape);

    // Cleanup (Note: in a real implementation, you'd want to track this properly)
    // For now, this is a simplified version
  }

  // Initially hidden
  container.style.display = "none";

  return container as unknown as Pulse.JSX.Element;
};
