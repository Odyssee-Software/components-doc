# Odyssee Components

A comprehensive UI component library built with **Pulse Framework** and styled with **Tailwind CSS** + **Preline**.

## 🚀 Features

- ✅ Built with Pulse Framework (reactive signals)
- ✅ Styled with Tailwind CSS + Preline patterns
- ✅ Fully typed with TypeScript
- ✅ JSX syntax for clean component composition
- ✅ Accessible and responsive
- ✅ Dark mode support

## 📦 Installation

```bash
npm install @odyssee/components
```

## 🎯 Available Components

### ✅ Form Components (Completed)

- **Input** - Text input with label, hint, validation, icons
- **Textarea** - Multi-line text input with auto-resize
- **Select** - Dropdown select with groups and options
- **Checkbox** - Checkbox with label, description, validation
- **Radio** - Radio button with label and description
- **RadioGroup** - Group of radio buttons managed together
- **Toggle** - Switch/toggle with variants and icons
- **FileInput** - File upload with button and default variants
- **RangeSlider** - Numeric range slider with value display
- **ColorPicker** - HTML5 color picker with hex value display
- **FormGroup** - Container for organizing form fields

### ✅ Base Components (Completed)

- **Button** - Versatile button with variants, colors, sizes, icons, loading state
- **Alert** - Alert/notification with variants, colors, icons, dismissible
- **Badge** - Badge/label/chip with variants, colors, icons, dismissible

### ✅ Overlay Components (Completed)

- **Modal** - Dialog/popup with sizes, animations, backdrop

### 🚧 To Be Implemented

See Preline documentation for patterns:
- Card
- Tabs
- Accordion
- Dropdown
- Tooltip
- Avatar
- Progress
- Spinner
- Toast
- And many more...

## 📖 Usage Examples

### Button

```tsx
import { Button, Pulse } from '@odyssee/components';

// Basic button
const btn = <Button onClick={() => console.log('clicked')}>Click me</Button>;

// With loading state
const isLoading = Pulse.signal(false);
const submitBtn = (
  <Button 
    variant="solid" 
    color="primary" 
    loading={isLoading}
    onClick={async () => {
      isLoading(true);
      await submitForm();
      isLoading(false);
    }}
  >
    Submit
  </Button>
);
```

### Input

```tsx
import { Input, Pulse } from '@odyssee/components';

const email = Pulse.signal('');
const input = (
  <Input 
    type="email"
    label="Email"
    placeholder="Enter your email"
    value={email}
    onChange={(val) => email(val)}
    hint="We will never share your email"
  />
);
```

### Select

```tsx
import { Select, Pulse } from '@odyssee/components';

const country = Pulse.signal('us');
const select = (
  <Select 
    label="Country"
    value={country}
    options={[
      { value: 'us', label: 'United States' },
      { value: 'uk', label: 'United Kingdom' },
      { value: 'fr', label: 'France' }
    ]}
    onChange={(val) => country(val)}
  />
);
```

### Checkbox

```tsx
import { Checkbox, Pulse } from '@odyssee/components';

const isChecked = Pulse.signal(false);
const checkbox = (
  <Checkbox 
    label="Accept terms"
    description="I agree to the terms and conditions"
    checked={isChecked}
    onChange={(val) => isChecked(val)}
  />
);
```

### Toggle

```tsx
import { Toggle, Pulse } from '@odyssee/components';

const isDarkMode = Pulse.signal(false);
const toggle = (
  <Toggle 
    label="Dark Mode"
    variant="soft"
    showIcons={true}
    checked={isDarkMode}
    onChange={(val) => isDarkMode(val)}
  />
);
```

### RadioGroup

```tsx
import { RadioGroup, Pulse } from '@odyssee/components';

const plan = Pulse.signal('free');
const radioGroup = (
  <RadioGroup 
    name="subscription"
    label="Select a plan"
    value={plan}
    options={[
      { value: 'free', label: 'Free', description: 'Basic features' },
      { value: 'pro', label: 'Pro', description: '$29/month' },
      { value: 'enterprise', label: 'Enterprise', description: 'Custom pricing' }
    ]}
    onChange={(val) => plan(val)}
  />
);
```

### FileInput

```tsx
import { FileInput } from '@odyssee/components';

const fileInput = (
  <FileInput 
    label="Upload image"
    variant="button"
    buttonText="Browse"
    accept="image/*"
    maxSize={5242880} // 5MB
    onChange={(files) => console.log(files)}
  />
);
```

### RangeSlider

```tsx
import { RangeSlider, Pulse } from '@odyssee/components';

const volume = Pulse.signal(50);
const slider = (
  <RangeSlider 
    label="Volume"
    value={volume}
    min={0}
    max={100}
    showValue={true}
    valueFormat={(val) => `${val}%`}
    onChange={(val) => volume(val)}
  />
);
```

### ColorPicker

```tsx
import { ColorPicker, Pulse } from '@odyssee/components';

const color = Pulse.signal('#3b82f6');
const picker = (
  <ColorPicker 
    label="Brand Color"
    value={color}
    showValue={true}
    onChange={(val) => color(val)}
  />
);
```

### FormGroup

```tsx
import { FormGroup, Input } from '@odyssee/components';

const formGroup = (
  <FormGroup 
    label="Personal Information"
    description="Enter your personal details"
    bordered={true}
  >
    <Input label="First Name" name="firstName" />
    <Input label="Last Name" name="lastName" />
    <Input label="Email" type="email" name="email" />
  </FormGroup>
);
```

### Modal

```tsx
import { Modal, Button, Pulse } from '@odyssee/components';

const isOpen = Pulse.signal(false);
const modal = (
  <Modal 
    isOpen={isOpen}
    title="Confirm Action"
    size="md"
    centered={true}
    onClose={() => isOpen(false)}
    footer={
      <>
        <Button onClick={() => isOpen(false)}>Cancel</Button>
        <Button onClick={() => { handleConfirm(); isOpen(false); }}>Confirm</Button>
      </>
    }
  >
    <p>Are you sure you want to proceed?</p>
  </Modal>
);
```

### Alert

```tsx
import { Alert } from '@odyssee/components';

const alert = (
  <Alert 
    variant="soft"
    color="success"
    icon="✓"
    title="Success!"
    dismissible={true}
  >
    Your changes have been saved.
  </Alert>
);
```

### Badge

```tsx
import { Badge } from '@odyssee/components';

const badge = (
  <Badge 
    variant="soft"
    color="primary"
    dot={true}
  >
    New
  </Badge>
);
```

## 🎨 Styling

All components use Tailwind CSS classes and follow Preline design patterns. You can customize:

- **Variants**: `solid`, `soft`, `outline`, `ghost`, `link`, `bordered`
- **Colors**: `primary`, `secondary`, `success`, `danger`, `warning`, `info`, `light`, `dark`
- **Sizes**: `xs`, `sm`, `md`, `lg`, `xl`

## 📚 Preline Documentation Reference

## 📖 Documentation

- [Complete Form Components Reference](./FORM_COMPONENTS.md) - Detailed documentation for all form components

## Pulse

### 🚀 Pulse Framework - Quick Reference Guide

```md

Guide de référence rapide pour l'utilisation correcte des signals dans Pulse Framework.

## 📌 Règles d'or

### 1️⃣ Les signals sont des FONCTIONS

```typescript
// ❌ FAUX
const value = mySignal.value;
mySignal.value = newValue;

// ✅ CORRECT
const value = mySignal();
mySignal(newValue);
```

### 2️⃣ Les composants ne se re-render PAS

```typescript
// ❌ FAUX - Valeur figée au montage
function MyComponent() {
  const text = mySignal();
  return <div>{text}</div>;
}

// ✅ CORRECT - Passer le signal directement
function MyComponent() {
  return <div>{mySignal}</div>;
}
```

### 3️⃣ Utiliser `computed()` pour les valeurs dérivées

```typescript
// ❌ FAUX - Pas réactif
const fullName = () => firstName() + " " + lastName();

// ✅ CORRECT - Réactif
const fullName = Pulse.computed(() => firstName() + " " + lastName());
```

### 4️⃣ Utiliser `effect()` pour les listes dynamiques

```typescript
// ❌ FAUX - .map() exécuté une seule fois
{items().map(item => <Item data={item} />)}

// ✅ CORRECT - Effect qui met à jour le DOM
Pulse.effect(() => {
  const currentItems = items();
  container.innerHTML = "";
  currentItems.forEach(item => {
    container.appendChild(Item({ data: item }));
  });
});
```

---

## 📖 Cheat Sheet

### Créer un signal

```typescript
import Pulse from "pulse-framework";

// Signal simple
const count = Pulse.signal(0);

// Signal typé
const user = Pulse.signal<User | null>(null);

// Signal avec tableau
const items = Pulse.signal<Item[]>([]);
```

### Lire un signal

```typescript
// Lire la valeur
const currentCount = count();

// Dans un JSX - passer le signal directement
<div>{count}</div>

// Dans un attribut réactif
<input value={inputValue} />
```

### Modifier un signal

```typescript
// Définir une nouvelle valeur
count(5);

// Incrémenter
count(count() + 1);

// Ajouter à un tableau
items([...items(), newItem]);

// Filtrer un tableau
items(items().filter(item => item.id !== deleteId));

// Mapper un tableau
items(items().map(item => 
  item.id === updateId ? { ...item, done: true } : item
));
```

### Computed

```typescript
// Valeur dérivée simple
const doubled = Pulse.computed(() => count() * 2);

// Valeur dérivée complexe
const filteredItems = Pulse.computed(() => {
  const search = searchTerm();
  return items().filter(item => 
    item.name.toLowerCase().includes(search.toLowerCase())
  );
});

// Utilisation dans JSX
<div>{doubled}</div>
<div class={isOpen}>{/* class réactive */}</div>
```

### Effects

```typescript
// Effect simple
Pulse.effect(() => {
  console.log("Count changed:", count());
});

// Effect avec cleanup
const cleanup = Pulse.effect(() => {
  const interval = setInterval(() => {
    console.log(count());
  }, 1000);
  
  return () => clearInterval(interval);
});

// Effect pour liste réactive
Pulse.effect(() => {
  const currentItems = items();
  container.innerHTML = "";
  currentItems.forEach(item => {
    const el = ItemComponent({ item });
    container.appendChild(el);
  });
});
```

---

## 🎯 Patterns courants

### Pattern 1 : Formulaire réactif

```typescript
function LoginForm() {
  const email = Pulse.signal("");
  const password = Pulse.signal("");
  const isValid = Pulse.computed(() => 
    email().includes("@") && password().length >= 8
  );

  const handleSubmit = (e: Event) => {
    e.preventDefault();
    if (isValid()) {
      login(email(), password());
    }
  };

  return (
    <form onsubmit={handleSubmit}>
      <input 
        type="email" 
        value={email}
        oninput={(e) => email((e.target as HTMLInputElement).value)}
      />
      <input 
        type="password" 
        value={password}
        oninput={(e) => password((e.target as HTMLInputElement).value)}
      />
      <button disabled={Pulse.computed(() => !isValid())}>
        Login
      </button>
    </form>
  );
}
```

### Pattern 2 : Liste réactive

```typescript
function TodoList() {
  const container = (<div class="todo-list"></div>) as HTMLElement;

  Pulse.effect(() => {
    const todos = todosSignal();
    container.innerHTML = "";
    
    todos.forEach(todo => {
      const item = TodoItem({ 
        todo,
        onToggle: () => toggleTodo(todo.id),
        onDelete: () => deleteTodo(todo.id)
      });
      container.appendChild(item);
    });
  });

  return container;
}
```

### Pattern 3 : Classes CSS conditionnelles

```typescript
function Button() {
  const isLoading = Pulse.signal(false);
  
  const buttonClass = Pulse.computed(() => {
    const base = "btn";
    const loading = isLoading() ? " btn-loading" : "";
    return base + loading;
  });

  return <button class={buttonClass}>Click me</button>;
}
```

### Pattern 4 : Modal réactif

```typescript
function Modal() {
  const isOpen = Pulse.signal(false);
  
  const displayStyle = Pulse.computed(() => 
    isOpen() ? "block" : "none"
  );

  return (
    <div class="modal" style={{ display: displayStyle }}>
      <button onclick={() => isOpen(false)}>Close</button>
      {/* Contenu du modal */}
    </div>
  );
}
```

### Pattern 5 : Tabs dynamiques

```typescript
function Tabs() {
  const activeTab = Pulse.signal("tab1");

  const isActive = (tabId: string) => 
    Pulse.computed(() => activeTab() === tabId);

  return (
    <div>
      <button 
        class={isActive("tab1")}
        onclick={() => activeTab("tab1")}
      >
        Tab 1
      </button>
      <button 
        class={isActive("tab2")}
        onclick={() => activeTab("tab2")}
      >
        Tab 2
      </button>
    </div>
  );
}
```

---

## ⚠️ Pièges à éviter

### Piège 1 : Créer des signals dans des boucles

```typescript
// ❌ FAUX - Fuite mémoire
items().map(item => {
  const selected = Pulse.signal(false); // Nouveau signal à chaque render !
  return <div>{item.name}</div>;
});

// ✅ CORRECT - État géré au niveau parent
const selectedItems = Pulse.signal<Set<string>>(new Set());
```

### Piège 2 : Appeler des fonctions au lieu de passer des références

```typescript
// ❌ FAUX - Exécute la fonction une seule fois
<div class={getClassName()}>

// ✅ CORRECT - Passe un computed
const className = Pulse.computed(() => getClassName());
<div class={className}>
```

### Piège 3 : Oublier d'appeler les signals

```typescript
// ❌ FAUX - Compare les fonctions, pas les valeurs
if (signal1 === signal2) { ... }

// ✅ CORRECT - Compare les valeurs
if (signal1() === signal2()) { ... }
```

### Piège 4 : Mutation directe de tableaux/objets

```typescript
// ❌ FAUX - Mute l'objet, pas de réactivité
const user = userSignal();
user.name = "New name";

// ✅ CORRECT - Créer un nouvel objet
userSignal({ ...userSignal(), name: "New name" });

// ❌ FAUX - Mute le tableau
const items = itemsSignal();
items.push(newItem);

// ✅ CORRECT - Créer un nouveau tableau
itemsSignal([...itemsSignal(), newItem]);
```

---

## 🔍 Debugging

### Afficher la valeur d'un signal

```typescript
// Dans la console
console.log("Current value:", mySignal());

// Effect pour logger les changements
Pulse.effect(() => {
  console.log("Signal changed:", mySignal());
});
```

### Vérifier si un signal est utilisé

```typescript
// Les signals Pulse n'ont pas de méthode .peek()
// Toujours appeler avec () pour lire
const value = mySignal(); // Crée une dépendance
```

### Debug des effects

```typescript
Pulse.effect(() => {
  console.log("Effect triggered");
  const value = mySignal();
  console.log("Value:", value);
  // Votre logique ici
});
```



---

## 📚 Ressources

- [Documentation officielle Pulse Framework](https://pulse-framework.com)
- [FIXES_APPLIED.md](./FIXES_APPLIED.md) - Guide détaillé des correctifs
- [README.md](./README.md) - Documentation du projet

---

## ✅ Checklist avant commit

- [ ] Tous les signals sont appelés avec `()` pour lire
- [ ] Pas de `.value` dans le code
- [ ] Les valeurs dérivées utilisent `Pulse.computed()`
- [ ] Les listes dynamiques utilisent `Pulse.effect()`
- [ ] Les classes CSS conditionnelles utilisent `computed()`
- [ ] Pas de signals créés dans des boucles
- [ ] Les tableaux/objets sont immuables (pas de mutations)
- [ ] Import correct : `import Pulse from "pulse-framework"`

---

**Version** : 1.0.0  
**Dernière mise à jour** : Janvier 2025
```

### Pulse - Components

TOUJOUR UTILISER `Pulse.Fn`

```md
export function Inspector(): HTMLElement {
  const container = (<div class="inspector-container"></div>) as HTMLElement;

  // Render inspector content based on selection state
  Pulse.effect(() => {
    const hasNode = hasSelection();
    const node = selectedNode();
    const type = nodeType();
    const currentTab = activeTab();
    const canHaveChildren = isContainerLike();

    // Clear container
    container.innerHTML = "";

    if (!hasNode || !node) {
      // No selection - show empty state
      const emptyState = document.createElement("div");
      emptyState.className = "inspector-empty";

      const icon = document.createElement("div");
      icon.className = "inspector-empty-icon";
      icon.textContent = "📋";

      const text = document.createElement("div");
      text.className = "inspector-empty-text";
      text.textContent = "Select an element to view its properties";

      emptyState.appendChild(icon);
      emptyState.appendChild(text);
      container.appendChild(emptyState);
      return;
    }

    // Has selection - show header + tabs + content
    const header = document.createElement("div");
    header.className = "inspector-header";

    const titleDiv = document.createElement("div");
    titleDiv.className = "inspector-title";

    const typeSpan = document.createElement("span");
    typeSpan.className = "inspector-node-type";
    typeSpan.textContent = type || "";
    titleDiv.appendChild(typeSpan);

    if (node.metadata?.label) {
      const labelSpan = document.createElement("span");
      labelSpan.className = "inspector-node-label";
      labelSpan.textContent = " - " + node.metadata.label;
      titleDiv.appendChild(labelSpan);
    }

    header.appendChild(titleDiv);

    const idDiv = document.createElement("div");
    idDiv.className = "inspector-node-id";
    idDiv.textContent = node.id;
    header.appendChild(idDiv);

    container.appendChild(header);

    // Tabs (only show Children tab if node can have children)
    if (canHaveChildren) {
      const tabs = document.createElement("div");
      tabs.className = "inspector-tabs";

      const propsButton = document.createElement("button");
      propsButton.className =
        "inspector-tab" + (currentTab === "properties" ? " active" : "");
      propsButton.textContent = "Properties";
      propsButton.onclick = () => setActiveTab("properties");

      const childrenButton = document.createElement("button");
      childrenButton.className =
        "inspector-tab" + (currentTab === "children" ? " active" : "");
      childrenButton.textContent = "Children";
      childrenButton.onclick = () => setActiveTab("children");

      tabs.appendChild(propsButton);
      tabs.appendChild(childrenButton);
      container.appendChild(tabs);
    }

    // Tab content
    const content = document.createElement("div");
    content.className = "inspector-content";

    if (currentTab === "properties") {
      content.appendChild(PropertiesForm());
    } else if (currentTab === "children" && canHaveChildren) {
      content.appendChild(ChildrenManager());
    }

    container.appendChild(content);
  });

  return container;
}
```
