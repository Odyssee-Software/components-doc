# @odyssee/components

Une bibliothèque de composants UI moderne construite avec [Pulse Framework](https://github.com/Odyssee-Software/pulse-framework) et stylisée avec Tailwind CSS.

> **Note**: Projet interne Odyssee Software - Bibliothèque de composants pour nos applications

## 🎯 À propos

`@odyssee/components` est une collection de composants UI réactifs et accessibles, conçus pour être utilisés dans les projets Odyssee Software. Elle exploite la puissance de Pulse Framework pour offrir une réactivité fine et performante.

### Caractéristiques

- ⚡ **Réactivité native** avec Pulse Framework signals
- 🎨 **Stylisé avec Tailwind CSS** et Preline
- ♿ **Accessible** (ARIA, navigation clavier)
- 🌙 **Dark mode** intégré
- 📦 **Tree-shakeable** - Import uniquement ce dont vous avez besoin
- 💪 **TypeScript** - Typage complet
- 🎭 **Variants multiples** - Solid, Outline, Soft, Ghost, Link
- 🎨 **8 couleurs de thème** - Primary, Secondary, Success, Danger, Warning, Info, Light, Dark

## 📦 Installation

```bash
npm install @odyssee/components
```

### Dépendances

```bash
npm install pulse-framework
npm install tailwindcss @tailwindcss/forms preline
```

## 🚀 Quick Start

### 1. Configuration Tailwind

Ajoutez à votre `tailwind.config.js` :

```js
export default {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@odyssee/components/**/*.js",
    "./node_modules/preline/preline.js",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('preline/plugin'),
  ],
}
```

### 2. Configuration TypeScript

Dans votre `tsconfig.json` :

```json
{
  "compilerOptions": {
    "jsx": "preserve",
    "jsxFactory": "Pulse.jsx",
    "jsxFragmentFactory": "Pulse.render.fragment"
  }
}
```

### 3. Configuration Vite

Dans votre `vite.config.ts` :

```ts
export default defineConfig({
  esbuild: {
    jsx: "transform",
    jsxFactory: "Pulse.jsx",
    jsxFragment: "Pulse.render.fragment"
  }
});
```

### 4. Import des styles

```tsx
import '@odyssee/components/styles';
```

### 5. Utiliser les composants

```tsx
import Pulse from 'pulse-framework';
import { Button, Badge, Input } from '@odyssee/components';

const app = (
  <div>
    <Button variant="solid" color="primary">
      Click me
    </Button>
    <Badge color="success">New</Badge>
    <Input label="Email" type="email" />
  </div>
) as Pulse.JSX.Element;

document.getElementById('app')?.appendChild(app);
```

## 📚 Composants disponibles

### Composants de base

- **Button** - Boutons avec variants, couleurs, tailles, loading state
- **Badge** - Badges et labels avec dots, icônes, dismissible
- **Alert** - Messages d'alerte et notifications

### Composants de formulaire

- **Input** - Champs de texte avec validation, icônes, hints
- **Textarea** - Champ multi-lignes avec auto-resize
- **Select** - Dropdown avec options et groupes
- **Checkbox** - Cases à cocher avec description
- **Radio** - Boutons radio individuels
- **RadioGroup** - Groupes de boutons radio
- **Toggle** - Interrupteurs on/off
- **FileInput** - Upload de fichiers avec validation
- **RangeSlider** - Slider de valeurs numériques
- **ColorPicker** - Sélecteur de couleurs
- **FormGroup** - Conteneur pour grouper des champs

### Composants overlay

- **Modal** - Dialogues modaux

## 💡 Exemples

### Button avec état de chargement

```tsx
import Pulse from 'pulse-framework';
import { Button } from '@odyssee/components';

const isLoading = Pulse.signal(false);

const handleSubmit = async () => {
  isLoading(true);
  await someAsyncOperation();
  isLoading(false);
};

const btn = (
  <Button loading={isLoading} onClick={handleSubmit}>
    Submit
  </Button>
) as Pulse.JSX.Element;
```

### Input avec validation réactive

```tsx
import Pulse from 'pulse-framework';
import { Input } from '@odyssee/components';

const email = Pulse.signal('');

const isValid = Pulse.computed(() => 
  email().includes('@') && email().includes('.')
);

const errorMsg = Pulse.computed(() => 
  email().length > 0 && !isValid() 
    ? 'Please enter a valid email' 
    : ''
);

const input = (
  <Input
    label="Email"
    type="email"
    value={email}
    onChange={(val) => email(val)}
    error={errorMsg}
  />
) as Pulse.JSX.Element;
```

### Badge dismissible

```tsx
import { Badge } from '@odyssee/components';

const badge = (
  <Badge
    variant="soft"
    color="primary"
    dismissible={true}
    onDismiss={() => console.log('Dismissed')}
  >
    Removable
  </Badge>
) as Pulse.JSX.Element;
```

## 🛠️ Développement

### Structure du projet

```
odyssee-components/
├── src/
│   ├── components/      # Composants sources
│   │   ├── base/        # Button, Badge, Alert
│   │   ├── forms/       # Input, Select, etc.
│   │   └── overlay/     # Modal
│   ├── types/           # Types TypeScript
│   ├── utils/           # Utilitaires
│   ├── styles.css       # Styles globaux
│   └── index.ts         # Point d'entrée
├── test/                # Playground de test
├── dist/                # Build de production
└── package.json
```

### Scripts disponibles

```bash
# Build de la bibliothèque
npm run build

# Playground de test visuel
npm run test:dev

# Type checking
npm run type-check

# Linting
npm run lint

# Formatage
npm run format
```

### Test playground

Pour tester visuellement les composants pendant le développement :

```bash
npm run test:dev
```

Ouvre http://localhost:3001 avec tous les composants en live-reload.

Voir [test/README.md](./test/README.md) pour plus d'informations.

## 📖 Documentation

La documentation complète est disponible sur :

🌐 **https://odyssee-software.github.io/components-doc/**

## 🔧 Configuration avancée

### Personnaliser les couleurs

Modifiez votre `tailwind.config.js` pour personnaliser la palette :

```js
theme: {
  extend: {
    colors: {
      primary: {
        // Votre palette personnalisée
      },
    },
  },
}
```

### Dark mode

Le dark mode est géré automatiquement via la classe `dark` sur l'élément HTML :

```tsx
// Toggle dark mode
document.documentElement.classList.toggle('dark');
```

## 🤝 Contribution (Équipe interne)

### Workflow

1. Créer une branche feature : `git checkout -b feature/nouveau-composant`
2. Développer avec le test playground : `npm run test:dev`
3. Builder : `npm run build`
4. Créer une PR vers `main`

### Guidelines

- ✅ Utiliser Pulse signals pour la réactivité
- ✅ Typage TypeScript complet
- ✅ Suivre les conventions de nommage existantes
- ✅ Documenter avec JSDoc
- ✅ Tester dans le playground
- ✅ S'assurer que les styles Tailwind sont appliqués
- ✅ Vérifier l'accessibilité (ARIA)

### Ajouter un nouveau composant

1. Créer le fichier dans `src/components/`
2. Définir le type dans `src/types/`
3. Exporter dans `src/index.ts`
4. Ajouter des tests visuels dans `test/main.tsx`
5. Builder et tester
6. Documenter dans `components-doc`

## 📝 Versioning

Nous suivons le [Semantic Versioning](https://semver.org/) :

- **MAJOR** : Breaking changes
- **MINOR** : Nouvelles fonctionnalités (backward compatible)
- **PATCH** : Bug fixes

Voir [CHANGELOG.md](./CHANGELOG.md) pour l'historique des versions.

## 🐛 Issues & Support

Pour les bugs ou demandes de fonctionnalités :

1. Vérifier la [documentation](https://odyssee-software.github.io/components-doc/)
2. Consulter les [issues existantes](https://github.com/Odyssee-Software/odyssee-components/issues)
3. Créer une nouvelle issue avec un exemple reproductible

## 📄 Licence

MIT © Odyssee Software

---

## 🔗 Liens utiles

- [Documentation](https://odyssee-software.github.io/components-doc/)
- [Pulse Framework](https://github.com/Odyssee-Software/pulse-framework)
- [Tailwind CSS](https://tailwindcss.com)
- [Preline UI](https://preline.co)

## 👥 Équipe

Développé par l'équipe Odyssee Software.

---

**Version actuelle** : 1.0.0  
**Dernière mise à jour** : Janvier 2025

Pour toute question interne, contactez l'équipe dev Odyssee Software.