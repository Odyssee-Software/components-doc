/**
 * Checkbox Component
 * A customizable checkbox with label, description, and validation states
 *
 * @example
 * ```tsx
 * import { Checkbox } from '@odyssee/components';
 *
 * // Basic checkbox
 * <Checkbox label="Accept terms" onChange={(checked) => console.log(checked)} />
 *
 * // With description
 * <Checkbox
 *   label="Notifications"
 *   description="Notify me when this action happens"
 *   onChange={(checked) => console.log(checked)}
 * />
 *
 * // With reactive value
 * const isChecked = Pulse.signal(false);
 * <Checkbox
 *   label="Subscribe"
 *   checked={isChecked}
 *   onChange={(checked) => isChecked(checked)}
 * />
 *
 * // With error state
 * <Checkbox
 *   label="Accept terms"
 *   error="You must accept the terms"
 *   required={true}
 * />
 *
 * // Indeterminate state
 * <Checkbox
 *   label="Select all"
 *   indeterminate={true}
 *   onChange={(checked) => console.log(checked)}
 * />
 *
 * // Disabled
 * <Checkbox label="Disabled option" disabled={true} checked={true} />
 * ```
 */

import Pulse from "pulse-framework";
import type { CheckboxProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Checkbox: Pulse.Fn<CheckboxProps> = (props) => {
  const {
    checked = false,
    indeterminate = false,
    disabled = false,
    required = false,
    label,
    description,
    error,
    success,
    size = "md",
    labelPosition = "right",
    onChange,
    className,
    id = generateId("checkbox"),
    name,
    value,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5",
    xl: "w-6 h-6",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  // Base checkbox classes
  const baseClasses =
    "rounded border-gray-300 text-primary-600 focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-600 dark:bg-gray-700 dark:checked:bg-primary-500 dark:checked:border-primary-500 dark:focus:ring-primary-600 dark:focus:ring-offset-gray-800 transition-colors duration-200";

  // State classes
  let stateClasses = "";
  if (error) {
    stateClasses =
      "border-red-300 text-red-600 focus:ring-red-500 dark:border-red-600";
  } else if (success) {
    stateClasses =
      "border-green-300 text-green-600 focus:ring-green-500 dark:border-green-600";
  }

  // Combine classes
  const checkboxClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Get reactive values
  const isChecked = () => (isSignal(checked) ? (checked as any)() : checked);
  const isIndeterminate = () =>
    isSignal(indeterminate) ? (indeterminate as any)() : indeterminate;

  // Handle change event
  const handleChange = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.checked);
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      <div
        class={cn(
          "flex items-start gap-2",
          labelPosition === "left" ? "flex-row-reverse justify-end" : "",
        )}
      >
        <input
          type="checkbox"
          id={id}
          name={name}
          value={value ? String(value) : undefined}
          class={checkboxClasses}
          checked={isChecked()}
          indeterminate={isIndeterminate()}
          disabled={disabled}
          required={required}
          onChange={handleChange}
          {...rest}
        />

        {(label || description) && (
          <div class="flex flex-col gap-0.5">
            {label && (
              <label
                for={id}
                class={cn(
                  "font-medium cursor-pointer",
                  labelSizeClasses[size],
                  error
                    ? "text-red-700 dark:text-red-400"
                    : success
                      ? "text-green-700 dark:text-green-400"
                      : "text-gray-900 dark:text-gray-100",
                  disabled ? "opacity-50 cursor-not-allowed" : "",
                )}
              >
                {label}
                {required && <span class="text-red-500 ml-1">*</span>}
              </label>
            )}

            {description && (
              <p
                class={cn(
                  "text-xs",
                  error
                    ? "text-red-600 dark:text-red-400"
                    : success
                      ? "text-green-600 dark:text-green-400"
                      : "text-gray-500 dark:text-gray-400",
                  disabled ? "opacity-50" : "",
                )}
              >
                {description}
              </p>
            )}
          </div>
        )}
      </div>

      {error && typeof error === "string" && (
        <p class="text-xs text-red-600 dark:text-red-400 ml-6">{error}</p>
      )}

      {success && typeof success === "string" && (
        <p class="text-xs text-green-600 dark:text-green-400 ml-6">{success}</p>
      )}
    </div>
  ) as Pulse.JSX.Element;
};
