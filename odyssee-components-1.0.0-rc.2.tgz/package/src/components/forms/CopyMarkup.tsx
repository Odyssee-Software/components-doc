/**
 * CopyMarkup Component
 * A component for dynamically duplicating form fields and content
 *
 * @example
 * ```tsx
 * import { CopyMarkup } from '@odyssee/components';
 *
 * // Basic usage with Input
 * <CopyMarkup
 *   template={
 *     <Input placeholder="Enter name" />
 *   }
 *   buttonText="Add Name"
 *   limit={3}
 * />
 *
 * // With custom button
 * <CopyMarkup
 *   template={
 *     <Input type="email" placeholder="Enter email" />
 *   }
 *   buttonText="Add Email"
 *   buttonVariant="solid"
 *   limit={5}
 * />
 *
 * // With Select component
 * <CopyMarkup
 *   template={
 *     <Select
 *       options={[
 *         { value: 'name', label: 'Name' },
 *         { value: 'email', label: 'Email' },
 *       ]}
 *       placeholder="Select option..."
 *     />
 *   }
 *   buttonText="Add Option"
 *   limit={3}
 * />
 *
 * // With remove button on each item
 * <CopyMarkup
 *   template={
 *     <Input placeholder="Enter address" />
 *   }
 *   buttonText="Add Address"
 *   showRemoveButton={true}
 *   limit={5}
 * />
 *
 * // With onChange callback
 * <CopyMarkup
 *   template={
 *     <Input placeholder="Phone number" />
 *   }
 *   buttonText="Add Phone"
 *   onChange={(count) => console.log('Total items:', count)}
 * />
 *
 * // Custom spacing
 * <CopyMarkup
 *   template={
 *     <Textarea placeholder="Enter comment" />
 *   }
 *   buttonText="Add Comment"
 *   spacing="lg"
 * />
 *
 * // Custom button position
 * <CopyMarkup
 *   template={
 *     <Input placeholder="Enter skill" />
 *   }
 *   buttonText="Add Skill"
 *   buttonPosition="left"
 * />
 *
 * // With initial count
 * <CopyMarkup
 *   template={
 *     <Input placeholder="Enter language" />
 *   }
 *   buttonText="Add Language"
 *   initialCount={2}
 *   limit={5}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { CopyMarkupProps } from "../../types";
import { cn, generateId } from "../../utils";

export const CopyMarkup: Pulse.Fn<CopyMarkupProps> = (props) => {
  const {
    template,
    buttonText = "Add Item",
    buttonIcon,
    buttonVariant = "outline",
    buttonPosition = "right",
    limit = 10,
    initialCount = 0,
    showRemoveButton = true,
    removeButtonText,
    spacing = "md",
    onChange,
    onAdd,
    onRemove,
    className,
    buttonClassName,
    wrapperClassName,
    id = generateId("copy-markup"),
    disabled = false,
    ...rest
  } = props;

  // State for items count
  const itemCount = Pulse.signal(initialCount);
  const items = Pulse.signal<number[]>(
    Array.from({ length: initialCount }, (_, i) => i),
  );

  // Check if limit is reached
  const isLimitReached = Pulse.computed(() => itemCount() >= limit);

  // Spacing classes
  const spacingClasses = {
    sm: "space-y-2",
    md: "space-y-3",
    lg: "space-y-4",
    xl: "space-y-5",
  };

  // Button alignment
  const buttonAlignmentClass =
    buttonPosition === "left"
      ? "text-start"
      : buttonPosition === "center"
        ? "text-center"
        : "text-end";

  // Handle add item
  const handleAdd = (e: Event) => {
    e.preventDefault();
    if (itemCount() < limit) {
      const currentItems = items();
      const newId = currentItems.length > 0 ? Math.max(...currentItems) + 1 : 0;
      items([...currentItems, newId]);
      itemCount(itemCount() + 1);

      if (onAdd) onAdd(itemCount() + 1);
      if (onChange) onChange(itemCount() + 1);
    }
  };

  // Handle remove item
  const handleRemove = (itemId: number) => (e: Event) => {
    e.preventDefault();
    const currentItems = items();
    const filteredItems = currentItems.filter((id) => id !== itemId);
    items(filteredItems);
    itemCount(itemCount() - 1);

    if (onRemove) onRemove(itemCount() - 1);
    if (onChange) onChange(itemCount() - 1);
  };

  // Default icon for add button
  const defaultAddIcon = (
    <svg
      class="shrink-0 size-3.5"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M5 12h14"></path>
      <path d="M12 5v14"></path>
    </svg>
  );

  // Default icon for remove button
  const defaultRemoveIcon = (
    <svg
      class="shrink-0 size-3.5"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  );

  // Button variant classes
  const getButtonClasses = (variant: string) => {
    const baseClasses =
      "py-1.5 px-2 inline-flex items-center gap-x-1 text-xs font-medium rounded-full focus:outline-hidden transition-colors duration-200 disabled:opacity-50 disabled:pointer-events-none";

    const variantClasses = {
      outline:
        "border border-dashed border-gray-200 bg-white text-gray-800 hover:bg-gray-50 focus:bg-gray-50 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-700 dark:focus:bg-neutral-700",
      solid:
        "border border-transparent bg-blue-600 text-white hover:bg-blue-700 focus:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 dark:focus:bg-blue-600",
      ghost:
        "border border-transparent text-blue-600 hover:bg-blue-50 focus:bg-blue-50 dark:text-blue-500 dark:hover:bg-blue-900/20 dark:focus:bg-blue-900/20",
      danger:
        "border border-transparent bg-red-100 text-red-800 hover:bg-red-200 focus:bg-red-200 dark:bg-red-900/20 dark:text-red-400 dark:hover:bg-red-900/30 dark:focus:bg-red-900/30",
    };

    return cn(baseClasses, variantClasses[variant as keyof typeof variantClasses] || variantClasses.outline);
  };

  return (
    <div class={cn("w-full", className)} id={id} {...rest}>
      {/* Items wrapper */}
      <div class={cn(spacingClasses[spacing], wrapperClassName)}>
        {items().map((itemId) => (
          <div key={itemId} class="relative group">
            {/* Render template */}
            <div class={showRemoveButton && itemCount() > 0 ? "pr-10" : ""}>
              {template}
            </div>

            {/* Remove button */}
            {showRemoveButton && itemCount() > 0 && (
              <button
                type="button"
                class={cn(
                  "absolute top-1/2 -translate-y-1/2 right-2",
                  getButtonClasses("danger"),
                  "opacity-0 group-hover:opacity-100",
                )}
                onClick={handleRemove(itemId)}
                aria-label={removeButtonText || "Remove item"}
                title={removeButtonText || "Remove item"}
              >
                {defaultRemoveIcon}
                {removeButtonText && <span class="sr-only">{removeButtonText}</span>}
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Add button */}
      <div class={cn("mt-3", buttonAlignmentClass)}>
        <button
          type="button"
          class={cn(getButtonClasses(buttonVariant), buttonClassName)}
          onClick={handleAdd}
          disabled={disabled || isLimitReached()}
          aria-label={buttonText}
        >
          {buttonIcon || defaultAddIcon}
          {buttonText}
        </button>

        {/* Limit indicator */}
        {isLimitReached() && (
          <p class="mt-2 text-xs text-gray-500 dark:text-gray-400">
            Maximum limit of {limit} items reached
          </p>
        )}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
