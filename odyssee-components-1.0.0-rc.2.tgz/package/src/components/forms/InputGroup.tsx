/**
 * InputGroup Component
 * A flexible input component with support for add-ons, inline elements, and multiple combinations
 *
 * @example
 * ```tsx
 * import { InputGroup } from '@odyssee/components';
 *
 * // Basic text addon
 * <InputGroup leadingAddon="$" placeholder="0.00" />
 *
 * // Multiple addons
 * <InputGroup
 *   leadingAddons={["$", "0.00"]}
 *   placeholder="Amount"
 * />
 *
 * // Button addon
 * <InputGroup
 *   placeholder="Search..."
 *   trailingAddon={{
 *     type: "button",
 *     content: "Search",
 *     buttonProps: { variant: "solid", color: "primary" },
 *     onClick: () => handleSearch()
 *   }}
 * />
 *
 * // Inline icons (absolute positioned)
 * <InputGroup
 *   leadingIcon={<EmailIcon />}
 *   placeholder="you@site.com"
 * />
 *
 * // Inline select
 * <InputGroup
 *   leadingSelect={{
 *     options: [
 *       { value: "us", label: "US" },
 *       { value: "ca", label: "CA" }
 *     ],
 *     value: "us",
 *     label: "Country"
 *   }}
 *   placeholder="+1 (000) 000-0000"
 * />
 *
 * // Checkbox addon
 * <InputGroup
 *   leadingAddon={{
 *     type: "checkbox",
 *     checked: agreed,
 *     onChange: (checked) => agreed(checked)
 *   }}
 *   placeholder="I agree to terms"
 * />
 *
 * // Loading state
 * <InputGroup
 *   placeholder="Searching..."
 *   loading={isLoading}
 *   loadingPosition="trailing"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { InputGroupProps, InputGroupAddon } from "../../types";
import { cn, isSignal, generateId } from "../../utils";
import { Button } from "../base/Button";
import { Checkbox } from "./Checkbox";
import { Radio } from "./Radio";
import { Spinner } from "../base/Spinner";

export const InputGroup: Pulse.Fn<InputGroupProps> = (props) => {
  const {
    // Add-ons
    leadingAddon,
    trailingAddon,
    leadingAddons,
    trailingAddons,

    // Inline elements
    leadingIcon,
    trailingIcon,
    leadingSelect,
    trailingSelect,

    // Loading
    loading = false,
    loadingPosition = "trailing",

    // Input props
    type = "text",
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    onChange,
    onFocus,
    onBlur,

    // Container props
    containerClassName,
    containerStyle,
    className,
    id = generateId("input-group"),
    style,
    ...rest
  } = props;

  // Get reactive values
  const isLoading = () => (isSignal(loading) ? (loading as any)() : loading);

  // Type assertion for size to ensure it's the correct type
  const inputSize = size as "xs" | "sm" | "md" | "lg" | "xl";

  // Combine all leading/trailing addons
  const allLeadingAddons = [
    ...(leadingAddons || []),
    ...(leadingAddon ? [leadingAddon] : []),
  ];
  const allTrailingAddons = [
    ...(trailingAddon ? [trailingAddon] : []),
    ...(trailingAddons || []),
  ];

  const hasLeadingAddons = allLeadingAddons.length > 0;
  const hasTrailingAddons = allTrailingAddons.length > 0;

  // Check if we have inline elements (icons, selects, loading spinner)
  const hasLeadingInline = !!(
    leadingIcon ||
    leadingSelect ||
    (isLoading() && loadingPosition === "leading")
  );
  const hasTrailingInline = !!(
    trailingIcon ||
    trailingSelect ||
    (isLoading() && loadingPosition === "trailing")
  );

  // Size classes for input
  const sizeClasses: Record<"xs" | "sm" | "md" | "lg" | "xl", string> = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Inline padding classes (for icons, selects, spinner)
  const inlinePaddingClasses: Record<
    "leading" | "trailing",
    Record<"xs" | "sm" | "md" | "lg" | "xl", string>
  > = {
    leading: {
      xs: "ps-8",
      sm: "ps-9",
      md: "ps-11",
      lg: "ps-12",
      xl: "ps-14",
    },
    trailing: {
      xs: "pe-8",
      sm: "pe-9",
      md: "pe-11",
      lg: "pe-12",
      xl: "pe-14",
    },
  };

  // Select inline width classes
  const selectWidthClasses: Record<"xs" | "sm" | "md" | "lg" | "xl", string> = {
    xs: "w-16",
    sm: "w-20",
    md: "w-24",
    lg: "w-28",
    xl: "w-32",
  };

  // Select inline padding (to make room for the select)
  const selectPaddingClasses: Record<
    "leading" | "trailing",
    Record<"xs" | "sm" | "md" | "lg" | "xl", string>
  > = {
    leading: {
      xs: "ps-16",
      sm: "ps-20",
      md: "ps-24",
      lg: "ps-28",
      xl: "ps-32",
    },
    trailing: {
      xs: "pe-16",
      sm: "pe-20",
      md: "pe-24",
      lg: "pe-28",
      xl: "pe-32",
    },
  };

  // Base input classes
  const baseInputClasses =
    "w-full border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-500";

  // Z-index for focus (to appear above addons)
  const focusZIndex = "focus:z-10 focus:relative";

  // Rounded classes based on addon position
  let roundedClasses = "rounded-lg";
  if (hasLeadingAddons && hasTrailingAddons) {
    roundedClasses = "rounded-none";
  } else if (hasLeadingAddons) {
    roundedClasses = "rounded-e-lg rounded-s-none";
  } else if (hasTrailingAddons) {
    roundedClasses = "rounded-s-lg rounded-e-none";
  }

  // Inline padding (for icons, selects, loading)
  let inlinePadding = "";
  if (hasLeadingInline && hasTrailingInline) {
    inlinePadding = cn(
      leadingSelect
        ? selectPaddingClasses.leading[inputSize]
        : inlinePaddingClasses.leading[inputSize],
      trailingSelect
        ? selectPaddingClasses.trailing[inputSize]
        : inlinePaddingClasses.trailing[inputSize],
    );
  } else if (hasLeadingInline) {
    inlinePadding = leadingSelect
      ? selectPaddingClasses.leading[inputSize]
      : inlinePaddingClasses.leading[inputSize];
  } else if (hasTrailingInline) {
    inlinePadding = trailingSelect
      ? selectPaddingClasses.trailing[inputSize]
      : inlinePaddingClasses.trailing[inputSize];
  }

  // Combine input classes
  const inputClasses = cn(
    baseInputClasses,
    sizeClasses[inputSize],
    stateClasses,
    roundedClasses,
    focusZIndex,
    inlinePadding,
    className,
  );

  // Get reactive input value
  const inputValue = () => (isSignal(value) ? (value as any)() : value || "");

  // Handle input event
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  // Render a single addon
  const renderAddon = (
    addon: InputGroupAddon | string | Pulse.JSX.Element,
    position: "leading" | "trailing",
    index: number,
  ): Pulse.JSX.Element => {
    // Simple string or JSX addon
    if (typeof addon === "string") {
      const isFirst = position === "leading" && index === 0;
      const isLast =
        position === "trailing" && index === allTrailingAddons.length - 1;

      return (
        <span
          class={cn(
            "px-4 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 text-sm text-gray-500 dark:bg-neutral-700 dark:border-neutral-700 dark:text-neutral-400",
            isFirst && "rounded-s-lg border-e-0",
            isLast && "rounded-e-lg border-s-0",
            !isFirst && !isLast && "border-e-0",
          )}
        >
          {addon}
        </span>
      ) as Pulse.JSX.Element;
    }

    // If it's a JSX element but not an object addon
    if (typeof addon === "object" && !("type" in addon)) {
      const isFirst = position === "leading" && index === 0;
      const isLast =
        position === "trailing" && index === allTrailingAddons.length - 1;

      return (
        <span
          class={cn(
            "px-4 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 text-sm text-gray-500 dark:bg-neutral-700 dark:border-neutral-700 dark:text-neutral-400",
            isFirst && "rounded-s-lg border-e-0",
            isLast && "rounded-e-lg border-s-0",
            !isFirst && !isLast && "border-e-0",
          )}
        >
          {addon}
        </span>
      ) as Pulse.JSX.Element;
    }

    // InputGroupAddon object
    const addonObj = addon as InputGroupAddon;
    const isFirst = position === "leading" && index === 0;
    const isLast =
      position === "trailing" && index === allTrailingAddons.length - 1;

    switch (addonObj.type) {
      case "text":
      case "icon":
        return (
          <span
            class={cn(
              "px-4 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 text-sm text-gray-500 dark:bg-neutral-700 dark:border-neutral-700 dark:text-neutral-400",
              isFirst && "rounded-s-lg border-e-0",
              isLast && "rounded-e-lg border-s-0",
              !isFirst && !isLast && "border-e-0",
              addonObj.className,
            )}
          >
            {addonObj.content}
          </span>
        ) as Pulse.JSX.Element;

      case "button":
        // Convert content to string if needed for Button children type compatibility
        const buttonContent =
          typeof addonObj.content === "string"
            ? addonObj.content
            : (addonObj.content as any);

        return (
          <Button
            {...(addonObj.buttonProps || {})}
            onClick={addonObj.onClick}
            class={cn(
              isFirst && "rounded-s-lg rounded-e-none",
              isLast && "rounded-e-lg rounded-s-none",
              !isFirst && !isLast && "rounded-none",
              addonObj.className,
            )}
          >
            {buttonContent}
          </Button>
        ) as Pulse.JSX.Element;

      case "checkbox":
        return (
          <span
            class={cn(
              "px-3 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 dark:bg-neutral-700 dark:border-neutral-700",
              isFirst && "rounded-s-lg border-e-0",
              isLast && "rounded-e-lg border-s-0",
              !isFirst && !isLast && "border-e-0",
              addonObj.className,
            )}
          >
            <Checkbox
              checked={addonObj.checked}
              onChange={addonObj.onChange}
              className="m-0"
            />
          </span>
        ) as Pulse.JSX.Element;

      case "radio":
        return (
          <span
            class={cn(
              "px-3 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 dark:bg-neutral-700 dark:border-neutral-700",
              isFirst && "rounded-s-lg border-e-0",
              isLast && "rounded-e-lg border-s-0",
              !isFirst && !isLast && "border-e-0",
              addonObj.className,
            )}
          >
            <Radio
              checked={addonObj.checked}
              onChange={
                addonObj.onChange ? () => addonObj.onChange?.(true) : undefined
              }
              className="m-0"
            />
          </span>
        ) as Pulse.JSX.Element;

      case "select":
        // For select addon, render a styled select
        const selectValue = () =>
          isSignal(addonObj.selectValue)
            ? (addonObj.selectValue as any)()
            : addonObj.selectValue || "";

        const handleSelectChange = (e: Event) => {
          const target = e.target as HTMLSelectElement;
          if (addonObj.onSelectChange) {
            addonObj.onSelectChange(target.value);
          }
        };

        return (
          <span
            class={cn(
              "inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 dark:bg-neutral-700 dark:border-neutral-700",
              isFirst && "rounded-s-lg border-e-0",
              isLast && "rounded-e-lg border-s-0",
              !isFirst && !isLast && "border-e-0",
              addonObj.className,
            )}
          >
            <select
              value={selectValue()}
              onChange={handleSelectChange}
              disabled={disabled}
              class="py-2 px-3 pe-9 block w-full bg-gray-50 border-transparent rounded-lg text-sm focus:border-primary-500 focus:ring-primary-500 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-700 dark:border-transparent dark:text-neutral-400 dark:focus:ring-neutral-600"
            >
              {addonObj.selectOptions?.map((option) => (
                <option value={option.value} disabled={option.disabled}>
                  {option.label}
                </option>
              ))}
            </select>
          </span>
        ) as Pulse.JSX.Element;

      default:
        return (
          <span class="px-4 inline-flex items-center min-w-fit border border-gray-200 bg-gray-50 text-sm text-gray-500 dark:bg-neutral-700 dark:border-neutral-700 dark:text-neutral-400">
            {addonObj.content}
          </span>
        ) as Pulse.JSX.Element;
    }
  };

  // Render inline select (absolute positioned)
  const renderInlineSelect = (
    selectConfig: NonNullable<
      InputGroupProps["leadingSelect"] | InputGroupProps["trailingSelect"]
    >,
    position: "leading" | "trailing",
  ): Pulse.JSX.Element => {
    const selectValue = () =>
      isSignal(selectConfig.value)
        ? (selectConfig.value as any)()
        : selectConfig.value || "";

    const handleSelectChange = (e: Event) => {
      const target = e.target as HTMLSelectElement;
      if (selectConfig.onChange) {
        selectConfig.onChange(target.value);
      }
    };

    return (
      <div
        class={cn(
          "absolute inset-y-0 flex items-center pointer-events-none",
          position === "leading" ? "start-0" : "end-0",
        )}
      >
        <label class="sr-only">{selectConfig.label || "Select"}</label>
        <select
          value={selectValue()}
          onChange={handleSelectChange}
          disabled={disabled}
          class={cn(
            "block h-full border-transparent bg-transparent py-0 text-gray-500 focus:ring-0 focus:border-transparent pointer-events-auto dark:text-neutral-400",
            selectWidthClasses[inputSize],
            position === "leading" ? "ps-2.5 pe-7" : "ps-7 pe-2.5",
          )}
        >
          {selectConfig.options.map((option) => (
            <option value={option.value} disabled={option.disabled}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    ) as Pulse.JSX.Element;
  };

  // Render inline icon or spinner
  const renderInlineElement = (
    element: Pulse.JSX.Element | undefined,
    position: "leading" | "trailing",
    isSpinner = false,
  ): Pulse.JSX.Element | null => {
    if (!element && !isSpinner) return null;

    return (
      <div
        class={cn(
          "absolute inset-y-0 flex items-center pointer-events-none",
          position === "leading" ? "start-0 ps-3" : "end-0 pe-3",
        )}
      >
        {isSpinner ? (
          <Spinner
            size={inputSize === "xs" || inputSize === "sm" ? "xs" : "sm"}
          />
        ) : (
          element
        )}
      </div>
    ) as Pulse.JSX.Element;
  };

  // Main render
  const inputElement = (
    <input
      type={type}
      id={id}
      class={inputClasses}
      placeholder={placeholder}
      disabled={disabled}
      readonly={readonly}
      required={required}
      value={inputValue()}
      style={style}
      onInput={handleInput}
      onFocus={onFocus}
      onBlur={onBlur}
      {...rest}
    />
  ) as Pulse.JSX.Element;

  // Wrapper for inline elements + input
  const inputWithInline = (
    <div class="relative w-full">
      {/* Leading inline select */}
      {leadingSelect && renderInlineSelect(leadingSelect, "leading")}

      {/* Leading inline icon */}
      {!leadingSelect &&
        renderInlineElement(
          leadingIcon,
          "leading",
          isLoading() && loadingPosition === "leading",
        )}

      {/* Input */}
      {inputElement}

      {/* Trailing inline select */}
      {trailingSelect && renderInlineSelect(trailingSelect, "trailing")}

      {/* Trailing inline icon */}
      {!trailingSelect &&
        renderInlineElement(
          trailingIcon,
          "trailing",
          isLoading() && loadingPosition === "trailing",
        )}
    </div>
  ) as Pulse.JSX.Element;

  // If we have addons, wrap in flex container
  const inputGroupElement =
    hasLeadingAddons || hasTrailingAddons ? (
      <div
        class={cn("flex rounded-lg shadow-sm", containerClassName)}
        style={containerStyle}
      >
        {/* Leading addons */}
        {allLeadingAddons.map((addon, index) =>
          renderAddon(addon, "leading", index),
        )}

        {/* Input with inline elements */}
        {inputWithInline}

        {/* Trailing addons */}
        {allTrailingAddons.map((addon, index) =>
          renderAddon(addon, "trailing", index),
        )}
      </div>
    ) : (
      <div class={containerClassName} style={containerStyle}>
        {inputWithInline}
      </div>
    );

  // Wrap with label, hint, error (like Input component)
  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      {inputGroupElement}

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
