/**
 * ColorPicker Component
 * A color picker component using HTML5 color input with reactive value support
 *
 * @example
 * ```tsx
 * import { ColorPicker } from '@odyssee/components';
 *
 * // Basic color picker
 * <ColorPicker label="Choose color" onChange={(color) => console.log(color)} />
 *
 * // With reactive value
 * const color = Pulse.signal('#3b82f6');
 * <ColorPicker
 *   label="Theme color"
 *   value={color}
 *   onChange={(val) => color(val)}
 * />
 *
 * // With hint
 * <ColorPicker
 *   label="Brand color"
 *   hint="Select your primary brand color"
 *   value="#10b981"
 * />
 *
 * // With error
 * <ColorPicker
 *   label="Color"
 *   error="Please select a valid color"
 *   required={true}
 * />
 *
 * // Disabled
 * <ColorPicker label="Color" value="#ef4444" disabled={true} />
 * ```
 */

import Pulse from "pulse-framework";
import type { ColorPickerProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const ColorPicker: Pulse.Fn<ColorPickerProps> = (props) => {
  const {
    value = "#000000",
    label,
    hint,
    error,
    disabled = false,
    required = false,
    size = "md",
    showValue = true,
    onChange,
    className,
    id = generateId("color-picker"),
    name,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "w-8 h-8",
    sm: "w-10 h-10",
    md: "w-12 h-12",
    lg: "w-14 h-14",
    xl: "w-16 h-16",
  };

  // Base color input classes
  const baseClasses =
    "rounded-md border-2 cursor-pointer transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 focus:ring-red-500 dark:border-red-600"
    : "border-gray-300 focus:ring-primary-500 dark:border-gray-600";

  // Combine classes
  const colorClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Get reactive value
  const currentValue = () =>
    (isSignal(value) ? (value as any)() : value) || "#000000";

  // Handle change event
  const handleChange = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="flex items-center gap-3">
        <input
          type="color"
          id={id}
          name={name}
          class={colorClasses}
          value={currentValue()}
          disabled={disabled}
          required={required}
          onChange={handleChange}
          {...rest}
        />

        {showValue && (
          <span class="text-sm font-mono text-gray-600 dark:text-gray-400">
            {currentValue()}
          </span>
        )}
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
