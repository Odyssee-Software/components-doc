/**
 * FormGroup Component
 * A container component for organizing and grouping form fields
 *
 * @example
 * ```tsx
 * import { FormGroup, Input, Select } from '@odyssee/components';
 *
 * // Basic form group
 * <FormGroup label="Personal Information">
 *   <Input label="First Name" name="firstName" />
 *   <Input label="Last Name" name="lastName" />
 * </FormGroup>
 *
 * // With description
 * <FormGroup
 *   label="Account Settings"
 *   description="Manage your account preferences"
 * >
 *   <Input label="Email" type="email" />
 *   <Input label="Password" type="password" />
 * </FormGroup>
 *
 * // Horizontal layout
 * <FormGroup label="Address" direction="horizontal" gap="lg">
 *   <Input label="City" name="city" />
 *   <Input label="ZIP" name="zip" />
 * </FormGroup>
 *
 * // With border
 * <FormGroup label="Billing" bordered={true}>
 *   <Input label="Card Number" />
 *   <Input label="CVV" />
 * </FormGroup>
 * ```
 */

import Pulse from "pulse-framework";
import type { FormGroupProps } from "../../types";
import { cn } from "../../utils";

export const FormGroup: Pulse.Fn<FormGroupProps> = (props) => {
  const {
    label,
    description,
    children,
    direction = "vertical",
    gap = "md",
    bordered = false,
    className,
    ...rest
  } = props;

  // Gap classes
  const gapClasses = {
    xs: "gap-1",
    sm: "gap-2",
    md: "gap-4",
    lg: "gap-6",
    xl: "gap-8",
  };

  return (
    <div
      class={cn(
        "form-group",
        bordered
          ? "border border-gray-200 dark:border-gray-700 rounded-lg p-4"
          : "",
        className,
      )}
      {...rest}
    >
      {(label || description) && (
        <div class="mb-4">
          {label && (
            <h3 class="text-base font-semibold text-gray-900 dark:text-gray-100">
              {label}
            </h3>
          )}
          {description && (
            <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">
              {description}
            </p>
          )}
        </div>
      )}

      <div
        class={cn(
          "flex",
          direction === "horizontal" ? "flex-row flex-wrap" : "flex-col",
          gapClasses[gap],
        )}
      >
        {children}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
