/**
 * FileInput Component
 * A file input component with label, validation, and multiple style variants
 *
 * @example
 * ```tsx
 * import { FileInput } from '@odyssee/components';
 *
 * // Basic file input
 * <FileInput label="Upload file" onChange={(files) => console.log(files)} />
 *
 * // With accept filter
 * <FileInput
 *   label="Upload image"
 *   accept="image/*"
 *   onChange={(files) => console.log(files)}
 * />
 *
 * // Multiple files
 * <FileInput
 *   label="Upload documents"
 *   multiple={true}
 *   accept=".pdf,.doc,.docx"
 *   onChange={(files) => console.log(files)}
 * />
 *
 * // With button style
 * <FileInput
 *   label="Choose profile photo"
 *   buttonText="Browse"
 *   variant="button"
 *   accept="image/*"
 * />
 *
 * // With error
 * <FileInput
 *   label="Upload"
 *   error="File size must be less than 5MB"
 *   required={true}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { FileInputProps } from "../../types";
import { cn, generateId } from "../../utils";

export const FileInput: Pulse.Fn<FileInputProps> = (props) => {
  const {
    label,
    hint,
    error,
    accept,
    multiple = false,
    required = false,
    disabled = false,
    size = "md",
    variant = "default",
    buttonText = "Choose file",
    placeholder = "No file chosen",
    maxSize,
    onChange,
    className,
    id = generateId("file-input"),
    name,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Create a signal for the file name display
  const fileName = Pulse.signal(placeholder);

  // Handle file change
  const handleFileChange = (e: Event) => {
    const target = e.target as HTMLInputElement;
    const files = target.files;

    if (files && files.length > 0) {
      // Validate file size if maxSize is specified
      if (maxSize) {
        const totalSize = Array.from(files).reduce(
          (acc, file) => acc + file.size,
          0,
        );
        if (totalSize > maxSize) {
          alert(`File size exceeds ${maxSize / 1024 / 1024}MB limit`);
          target.value = "";
          fileName(placeholder);
          return;
        }
      }

      // Update display
      if (files.length === 1) {
        fileName(files[0].name);
      } else {
        fileName(`${files.length} files selected`);
      }

      // Call onChange callback
      if (onChange) {
        onChange(files);
      }
    } else {
      fileName(placeholder);
    }
  };

  if (variant === "button") {
    // Button style file input
    return (
      <div class="flex flex-col gap-1.5">
        {label && (
          <label
            for={id}
            class="text-sm font-medium text-gray-700 dark:text-gray-300"
          >
            {label}
            {required && <span class="text-red-500 ml-1">*</span>}
          </label>
        )}

        <div class="flex items-center gap-3">
          <button
            type="button"
            class={cn(
              "inline-flex items-center justify-center gap-2 rounded-md border font-medium transition-all",
              sizeClasses[size],
              error
                ? "border-red-300 bg-red-50 text-red-700 hover:bg-red-100 dark:border-red-600 dark:bg-red-900/20 dark:text-red-400"
                : "border-gray-300 bg-white text-gray-700 hover:bg-gray-50 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-gray-700",
              disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
            )}
            disabled={disabled}
            onClick={() => document.getElementById(id)?.click()}
          >
            {buttonText}
          </button>

          <span class="text-sm text-gray-500 dark:text-gray-400">
            {fileName()}
          </span>

          <input
            type="file"
            id={id}
            name={name}
            class="hidden"
            accept={accept}
            multiple={multiple}
            required={required}
            disabled={disabled}
            onChange={handleFileChange}
            {...rest}
          />
        </div>

        {hint && !error && (
          <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
        )}

        {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Default style file input
  const baseClasses =
    "block w-full rounded-md border transition-colors duration-200 file:border-0 file:mr-4 file:py-2 file:px-4 file:text-sm file:font-medium focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  const stateClasses = error
    ? "border-red-300 text-red-900 file:bg-red-50 file:text-red-700 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400 dark:file:bg-red-900/20 dark:file:text-red-400"
    : "border-gray-300 text-gray-900 file:bg-gray-50 file:text-gray-700 hover:file:bg-gray-100 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:file:bg-gray-600 dark:file:text-gray-300 dark:hover:file:bg-gray-500";

  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <input
        type="file"
        id={id}
        name={name}
        class={inputClasses}
        accept={accept}
        multiple={multiple}
        required={required}
        disabled={disabled}
        onChange={handleFileChange}
        {...rest}
      />

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
