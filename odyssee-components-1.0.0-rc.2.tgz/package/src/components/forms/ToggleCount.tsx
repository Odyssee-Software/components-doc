/**
 * ToggleCount Component
 * A pricing toggle component that switches between two values (e.g., monthly/annual pricing)
 * with animated value transitions. Commonly used on pricing pages.
 *
 * @example
 * ```tsx
 * import { ToggleCount, ToggleCountValue } from '@odyssee/components';
 *
 * // Basic usage with radio buttons
 * <ToggleCount
 *   id="pricing-toggle"
 *   options={["Monthly", "Annual"]}
 *   defaultValue={0}
 * />
 * <ToggleCountValue
 *   target="pricing-toggle"
 *   min={19}
 *   max={29}
 *   prefix="$"
 * />
 *
 * // With switch instead of radio
 * <ToggleCount
 *   id="pricing-switch"
 *   type="switch"
 *   options={["Monthly", "Annual"]}
 * />
 * <ToggleCountValue
 *   target="pricing-switch"
 *   min={99}
 *   max={149}
 *   prefix="$"
 *   suffix="/mo"
 * />
 *
 * // Multiple values synced to same toggle
 * const pricingToggle = "my-pricing";
 * <ToggleCount
 *   id={pricingToggle}
 *   options={["Monthly", "Annual"]}
 * />
 * <ToggleCountValue target={pricingToggle} min={19} max={29} prefix="$" />
 * <ToggleCountValue target={pricingToggle} min={89} max={99} prefix="$" />
 * <ToggleCountValue target={pricingToggle} min={129} max={149} prefix="$" />
 *
 * // With reactive value
 * const selectedIndex = Pulse.signal(0);
 * <ToggleCount
 *   id="reactive-toggle"
 *   options={["Basic", "Pro"]}
 *   value={selectedIndex}
 *   onChange={(index) => selectedIndex(index)}
 * />
 *
 * // Custom formatting
 * <ToggleCountValue
 *   target="pricing-toggle"
 *   min={1900}
 *   max={2900}
 *   formatter={(value) => `€${(value / 100).toFixed(2)}`}
 * />
 *
 * // With decimals
 * <ToggleCountValue
 *   target="pricing-toggle"
 *   min={19.99}
 *   max={29.99}
 *   decimals={2}
 *   prefix="$"
 * />
 *
 * // Pills variant (radio buttons)
 * <ToggleCount
 *   id="pills-toggle"
 *   type="radio"
 *   variant="pills"
 *   options={["Starter", "Enterprise"]}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { ToggleCountProps, ToggleCountValueProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

// Global registry for toggle state management
const toggleRegistry = new Map<string, any>();

/**
 * Register a toggle signal in the global registry
 */
export const registerToggle = (id: string, signal: any) => {
  toggleRegistry.set(id, signal);
};

/**
 * Get a toggle signal from the global registry
 */
export const getToggleSignal = (id: string): any | undefined => {
  return toggleRegistry.get(id);
};

/**
 * Unregister a toggle signal
 */
export const unregisterToggle = (id: string) => {
  toggleRegistry.delete(id);
};

/**
 * ToggleCount - Main toggle component (radio or switch)
 */
export const ToggleCount: Pulse.Fn<ToggleCountProps> = (props) => {
  const {
    id = generateId("toggle-count"),
    type = "radio",
    variant = "default",
    options,
    value,
    defaultValue = 0,
    onChange,
    className,
    disabled = false,
    ...rest
  } = props;

  // Validate options
  if (!options || options.length !== 2) {
    console.error("ToggleCount requires exactly 2 options");
    return null as any;
  }

  // Create internal signal for toggle state
  const currentIndex = Pulse.signal(
    isSignal(value) ? (value as any)() : defaultValue
  );

  // Register toggle in global registry
  registerToggle(id, currentIndex);

  // Sync with external signal if provided
  Pulse.effect(() => {
    if (isSignal(value)) {
      const val = (value as any)();
      if (val !== currentIndex()) {
        currentIndex(val);
      }
    }
  });

  // Handle toggle change
  const handleToggle = (index: number) => {
    if (disabled) return;

    currentIndex(index);

    if (onChange) {
      onChange(index, options[index]);
    }

    if (isSignal(value)) {
      (value as any)(index);
    }
  };

  // Cleanup on unmount
  Pulse.effect(() => {
    return () => {
      unregisterToggle(id);
    };
  });

  // Render radio variant
  if (type === "radio") {
    const isDefault = variant === "default";
    const isPills = variant === "pills";

    return (
      <div
        id={id}
        class={cn(
          "inline-flex",
          isPills && "p-0.5 bg-gray-100 rounded-lg dark:bg-neutral-700",
          className
        )}
        {...rest}
      >
        {options.map((label, index) => {
          const inputId = `${id}-option-${index}`;
          const isChecked = () => currentIndex() === index;

          return (
            <label
              for={inputId}
              class={cn(
                "relative inline-block cursor-pointer",
                isPills && "py-2 px-3",
                isDefault && index === 0 && "mr-2",
                disabled && "opacity-50 cursor-not-allowed"
              )}
            >
              <span
                class={cn(
                  "inline-block relative z-10 text-sm font-medium transition-colors",
                  isChecked()
                    ? "text-gray-800 dark:text-neutral-200"
                    : "text-gray-600 dark:text-neutral-400",
                  isPills && "cursor-pointer"
                )}
              >
                {label}
              </span>
              <input
                type="radio"
                id={inputId}
                name={id}
                checked={isChecked()}
                disabled={disabled}
                onChange={() => handleToggle(index)}
                class={cn(
                  isPills &&
                    "absolute top-0 end-0 size-full border-transparent bg-transparent bg-none text-transparent rounded-lg cursor-pointer before:absolute before:inset-0 before:size-full before:rounded-lg focus:ring-offset-0 checked:before:bg-white checked:before:shadow-sm checked:bg-none focus:ring-2 focus:ring-blue-500 dark:checked:before:bg-neutral-800 dark:focus:ring-offset-transparent",
                  isDefault && "sr-only"
                )}
              />
              {isDefault && isChecked() && (
                <span class="absolute inset-0 border-2 border-blue-600 rounded-md dark:border-blue-500" />
              )}
            </label>
          );
        })}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render switch variant
  if (type === "switch") {
    const isChecked = () => currentIndex() === 1;

    return (
      <div
        class={cn("flex items-center gap-x-3", className)}
        id={id}
        {...rest}
      >
        <label
          for={`${id}-switch`}
          class={cn(
            "text-sm text-gray-800 dark:text-neutral-200",
            disabled && "opacity-50"
          )}
        >
          {options[0]}
        </label>

        <label
          for={`${id}-switch`}
          class={cn(
            "relative inline-block w-11 h-6",
            disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer"
          )}
        >
          <input
            type="checkbox"
            id={`${id}-switch`}
            checked={isChecked()}
            disabled={disabled}
            onChange={() => handleToggle(isChecked() ? 0 : 1)}
            class="peer sr-only"
          />
          <span class="absolute inset-0 bg-gray-200 rounded-full transition-colors duration-200 ease-in-out peer-checked:bg-blue-600 dark:bg-neutral-700 dark:peer-checked:bg-blue-500 peer-disabled:opacity-50 peer-disabled:pointer-events-none" />
          <span class="absolute top-1/2 start-0.5 -translate-y-1/2 size-5 bg-white rounded-full shadow-sm transition-transform duration-200 ease-in-out peer-checked:translate-x-full dark:bg-neutral-400 dark:peer-checked:bg-white" />
        </label>

        <label
          for={`${id}-switch`}
          class={cn(
            "text-sm text-gray-800 dark:text-neutral-200",
            disabled && "opacity-50"
          )}
        >
          {options[1]}
        </label>
      </div>
    ) as Pulse.JSX.Element;
  }

  return null as any;
};

/**
 * ToggleCountValue - Animated value display component
 */
export const ToggleCountValue: Pulse.Fn<ToggleCountValueProps> = (props) => {
  const {
    target,
    min,
    max,
    duration = 300,
    prefix = "",
    suffix = "",
    decimals = 0,
    formatter,
    className,
    ...rest
  } = props;

  // Current displayed value
  const displayValue = Pulse.signal(min);
  const isAnimating = Pulse.signal(false);

  // Get toggle signal from registry
  const toggleSignal = getToggleSignal(target);

  if (!toggleSignal) {
    console.error(`ToggleCount with id "${target}" not found`);
  }

  // Animation state
  let animationFrameId: number | null = null;

  // Animate value change
  const animateValue = (from: number, to: number) => {
    // Cancel any existing animation
    if (animationFrameId !== null) {
      cancelAnimationFrame(animationFrameId);
    }

    const startTime = performance.now();
    const diff = to - from;

    isAnimating(true);

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Easing function (ease-out cubic)
      const easeProgress = 1 - Math.pow(1 - progress, 3);

      const currentValue = from + diff * easeProgress;
      displayValue(currentValue);

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(animate);
      } else {
        isAnimating(false);
        animationFrameId = null;
      }
    };

    animationFrameId = requestAnimationFrame(animate);
  };

  // Watch toggle changes and animate
  Pulse.effect(() => {
    if (toggleSignal) {
      const index = toggleSignal();
      const targetValue = index === 0 ? min : max;
      const currentValue = displayValue();

      if (currentValue !== targetValue) {
        animateValue(currentValue, targetValue);
      }
    }
  });

  // Format display value
  const formattedValue = () => {
    const value = displayValue();

    if (formatter) {
      return formatter(value);
    }

    const fixedValue = value.toFixed(decimals);
    return `${prefix}${fixedValue}${suffix}`;
  };

  // Cleanup on unmount
  Pulse.effect(() => {
    return () => {
      if (animationFrameId !== null) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  });

  return (
    <span
      class={cn(
        "inline-block font-semibold tabular-nums",
        isAnimating() && "transition-opacity",
        className
      )}
      data-toggle-count-target={target}
      {...rest}
    >
      {formattedValue()}
    </span>
  ) as Pulse.JSX.Element;
};
