/**
 * Input Component
 * A flexible text input component with labels, hints, icons, and validation states
 *
 * @example
 * ```tsx
 * import { Input } from '@odyssee/components';
 *
 * // Basic input
 * <Input placeholder="Enter your name" onChange={(value) => console.log(value)} />
 *
 * // With label and hint
 * <Input
 *   label="Email"
 *   hint="We will never share your email"
 *   type="email"
 *   required={true}
 * />
 *
 * // With reactive value
 * const email = Pulse.signal('');
 * <Input
 *   label="Email"
 *   value={email}
 *   onChange={(val) => email(val)}
 * />
 *
 * // With error state
 * <Input
 *   label="Username"
 *   error="Username is already taken"
 *   value="john"
 * />
 *
 * // With icon
 * <Input
 *   label="Search"
 *   icon="🔍"
 *   iconPosition="left"
 *   placeholder="Search..."
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { InputProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Input: Pulse.Fn<InputProps> = (props) => {
  const {
    type = "text",
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    icon,
    iconPosition = "left",
    onChange,
    onFocus,
    onBlur,
    className,
    id = generateId("input"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Icon padding classes
  const iconPaddingClasses = {
    left: {
      xs: "pl-7",
      sm: "pl-8",
      md: "pl-9",
      lg: "pl-10",
      xl: "pl-12",
    },
    right: {
      xs: "pr-7",
      sm: "pr-8",
      md: "pr-9",
      lg: "pr-10",
      xl: "pr-12",
    },
  };

  // Icon size classes
  const iconSizes = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
    xl: "text-xl",
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-500";

  // Icon classes
  const iconClass =
    icon && iconPosition ? iconPaddingClasses[iconPosition][size] : "";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    iconClass,
    className,
  );

  // Get reactive value
  const inputValue = () => (isSignal(value) ? (value as any)() : value || "");

  // Handle input event
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative">
        {icon && (
          <span
            class={cn(
              "absolute top-1/2 -translate-y-1/2 pointer-events-none",
              iconPosition === "left" ? "left-2.5" : "right-2.5",
              error ? "text-red-400" : "text-gray-400 dark:text-gray-500",
              iconSizes[size],
            )}
          >
            {icon}
          </span>
        )}

        <input
          type={type}
          id={id}
          class={inputClasses}
          placeholder={placeholder}
          disabled={disabled}
          readonly={readonly}
          required={required}
          value={inputValue()}
          style={style}
          onInput={handleInput}
          onFocus={onFocus}
          onBlur={onBlur}
          {...rest}
        />
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
