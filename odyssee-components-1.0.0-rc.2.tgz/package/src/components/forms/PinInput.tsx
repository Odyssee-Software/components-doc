/**
 * PinInput Component
 * A component for entering PIN codes, OTP, verification codes with auto-focus management
 *
 * @example
 * ```tsx
 * import { PinInput } from '@odyssee/components';
 *
 * // Basic usage (4 digits)
 * <PinInput
 *   length={4}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With label and validation
 * <PinInput
 *   length={6}
 *   label="Enter verification code"
 *   hint="Check your email for the code"
 *   error="Invalid code"
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With reactive value
 * const code = Pulse.signal('');
 * <PinInput
 *   length={4}
 *   value={code}
 *   onChange={(val) => code(val)}
 * />
 *
 * // Numbers only
 * <PinInput
 *   length={4}
 *   type="numeric"
 *   placeholder="⚬"
 * />
 *
 * // Password/Masked
 * <PinInput
 *   length={4}
 *   masked={true}
 *   placeholder="⚬"
 * />
 *
 * // Gray variant
 * <PinInput
 *   length={4}
 *   variant="gray"
 *   placeholder="⚬"
 * />
 *
 * // Underline variant
 * <PinInput
 *   length={6}
 *   variant="underline"
 *   placeholder="⚬"
 * />
 *
 * // With focus effect
 * <PinInput
 *   length={4}
 *   focusEffect="scale"
 *   placeholder="⚬"
 * />
 *
 * // Different sizes
 * <PinInput length={4} size="sm" />
 * <PinInput length={4} size="md" />
 * <PinInput length={4} size="lg" />
 *
 * // Disabled state
 * <PinInput
 *   length={4}
 *   disabled={true}
 *   value="1234"
 * />
 *
 * // iOS one-time-code support
 * <PinInput
 *   length={6}
 *   autoComplete="one-time-code"
 * />
 *
 * // Custom regex validation
 * <PinInput
 *   length={4}
 *   pattern="^[0-3]+$"
 *   hint="Only numbers 0-3 allowed"
 * />
 *
 * // With onComplete callback
 * <PinInput
 *   length={6}
 *   onComplete={(value) => {
 *     console.log('PIN complete:', value);
 *     // Submit form or verify code
 *   }}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { PinInputProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const PinInput: Pulse.Fn<PinInputProps> = (props) => {
  const {
    length = 4,
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    masked = false,
    type = "alphanumeric",
    pattern,
    variant = "default",
    size = "md",
    focusEffect,
    error,
    label,
    hint,
    onChange,
    onComplete,
    onFocus,
    onBlur,
    className,
    id = generateId("pin-input"),
    autoComplete,
    ...rest
  } = props;

  // Create array of signals for each input
  const inputs = Array.from({ length }, () => Pulse.signal(""));
  const inputRefs: (HTMLInputElement | null)[] = Array(length).fill(null);

  // Initialize values from prop
  Pulse.effect(() => {
    const val = isSignal(value) ? (value as any)() : value || "";
    const chars = val.split("").slice(0, length);
    chars.forEach((char: string, i: number) => {
      if (inputs[i]) {
        inputs[i](char);
      }
    });
  });

  // Size classes
  const sizeClasses = {
    sm: "size-9.5 text-sm",
    md: "size-11 text-sm",
    lg: "size-15.5 text-lg",
  };

  // Variant classes
  const variantClasses = {
    default:
      "border-gray-200 bg-white focus:border-blue-500 focus:ring-blue-500 dark:bg-neutral-900 dark:border-neutral-700",
    gray: "bg-gray-200 border-transparent focus:border-blue-500 focus:ring-blue-500 dark:bg-neutral-700 dark:border-transparent",
    underline:
      "bg-transparent border-t-transparent border-b-2 border-x-transparent border-b-gray-200 focus:border-t-transparent focus:border-x-transparent focus:border-b-blue-500 focus:ring-0 dark:border-b-neutral-700 dark:focus:border-b-neutral-600",
  };

  // Focus effect classes
  const focusEffectClass = focusEffect === "scale" ? "focus:scale-110" : "";

  // Base input classes
  const baseClasses =
    "block text-center rounded-md transition-all duration-200 focus:outline-none [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none disabled:opacity-50 disabled:pointer-events-none";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : variantClasses[variant];

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    focusEffectClass,
    "dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600",
  );

  // Get validation regex based on type or custom pattern
  const getValidationRegex = () => {
    if (pattern) return new RegExp(pattern);
    if (type === "numeric") return /^[0-9]+$/;
    return /^[a-zA-Z0-9]+$/; // alphanumeric default
  };

  const validationRegex = getValidationRegex();

  // Get current full value
  const getCurrentValue = () => {
    return inputs.map((sig) => sig()).join("");
  };

  // Handle input change
  const handleInput = (index: number) => (e: Event) => {
    const target = e.target as HTMLInputElement;
    const val = target.value;

    // Only allow valid characters
    const lastChar = val.slice(-1);
    if (val && !validationRegex.test(lastChar)) {
      target.value = inputs[index]();
      return;
    }

    // Update signal
    inputs[index](lastChar);
    target.value = lastChar;

    // Move to next input if value entered
    if (lastChar && index < length - 1) {
      const nextInput = inputRefs[index + 1];
      if (nextInput) {
        nextInput.focus();
        nextInput.select();
      }
    }

    // Trigger callbacks
    const fullValue = getCurrentValue();
    if (onChange) {
      onChange(fullValue);
    }
    if (isSignal(value)) {
      (value as any)(fullValue);
    }

    // Check if complete
    if (fullValue.length === length && onComplete) {
      onComplete(fullValue);
    }
  };

  // Handle keydown for navigation
  const handleKeyDown = (index: number) => (e: KeyboardEvent) => {
    const target = e.target as HTMLInputElement;

    // Backspace: clear current and move to previous
    if (e.key === "Backspace") {
      e.preventDefault();
      if (inputs[index]()) {
        inputs[index]("");
        target.value = "";
        const fullValue = getCurrentValue();
        if (onChange) onChange(fullValue);
        if (isSignal(value)) (value as any)(fullValue);
      } else if (index > 0) {
        const prevInput = inputRefs[index - 1];
        if (prevInput) {
          inputs[index - 1]("");
          prevInput.value = "";
          prevInput.focus();
          prevInput.select();
          const fullValue = getCurrentValue();
          if (onChange) onChange(fullValue);
          if (isSignal(value)) (value as any)(fullValue);
        }
      }
    }

    // Delete: clear current
    if (e.key === "Delete") {
      e.preventDefault();
      inputs[index]("");
      target.value = "";
      const fullValue = getCurrentValue();
      if (onChange) onChange(fullValue);
      if (isSignal(value)) (value as any)(fullValue);
    }

    // Left arrow: move to previous
    if (e.key === "ArrowLeft" && index > 0) {
      e.preventDefault();
      const prevInput = inputRefs[index - 1];
      if (prevInput) {
        prevInput.focus();
        prevInput.select();
      }
    }

    // Right arrow: move to next
    if (e.key === "ArrowRight" && index < length - 1) {
      e.preventDefault();
      const nextInput = inputRefs[index + 1];
      if (nextInput) {
        nextInput.focus();
        nextInput.select();
      }
    }
  };

  // Handle paste
  const handlePaste = (index: number) => (e: ClipboardEvent) => {
    e.preventDefault();
    const pasteData = e.clipboardData?.getData("text") || "";
    const chars = pasteData
      .split("")
      .filter((char) => validationRegex.test(char));

    // Fill inputs starting from current index
    chars.forEach((char, offset) => {
      const targetIndex = index + offset;
      if (targetIndex < length) {
        inputs[targetIndex](char);
        if (inputRefs[targetIndex]) {
          inputRefs[targetIndex]!.value = char;
        }
      }
    });

    // Focus last filled input or next empty
    const lastFilledIndex = Math.min(index + chars.length - 1, length - 1);
    const nextEmptyIndex = inputs.findIndex(
      (sig, i) => i > lastFilledIndex && !sig(),
    );
    const focusIndex = nextEmptyIndex !== -1 ? nextEmptyIndex : lastFilledIndex;

    if (inputRefs[focusIndex]) {
      inputRefs[focusIndex]!.focus();
      inputRefs[focusIndex]!.select();
    }

    // Trigger callbacks
    const fullValue = getCurrentValue();
    if (onChange) onChange(fullValue);
    if (isSignal(value)) (value as any)(fullValue);
    if (fullValue.length === length && onComplete) {
      onComplete(fullValue);
    }
  };

  // Handle focus
  const handleFocus = (_index: number) => (e: Event) => {
    const target = e.target as HTMLInputElement;
    target.select();
    if (onFocus) onFocus(e);
  };

  // Handle blur
  const handleBlur = (e: Event) => {
    if (onBlur) onBlur(e);
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label class="text-sm font-medium text-gray-700 dark:text-gray-300">
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class={cn("flex gap-x-3", className)} data-hs-pin-input="" {...rest}>
        {Array.from({ length }).map((_, index) => (
          <input
            ref={(el: HTMLInputElement | null) => (inputRefs[index] = el)}
            type={
              masked
                ? "password"
                : autoComplete === "one-time-code"
                  ? "tel"
                  : "text"
            }
            class={inputClasses}
            placeholder={placeholder}
            disabled={disabled}
            readonly={readonly}
            required={required && index === 0}
            maxLength={1}
            value={inputs[index]()}
            autocomplete={index === 0 ? autoComplete : undefined}
            data-hs-pin-input-item=""
            id={`${id}-${index}`}
            onInput={handleInput(index)}
            onKeyDown={handleKeyDown(index)}
            onPaste={handlePaste(index)}
            onFocus={handleFocus(index)}
            onBlur={handleBlur}
            autofocus={index === 0}
          />
        ))}
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
