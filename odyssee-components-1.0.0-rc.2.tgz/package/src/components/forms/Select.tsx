/**
 * Select Component
 * A customizable select dropdown with support for groups, search, and multiple selection
 *
 * @example
 * ```tsx
 * import { Select } from '@odyssee/components';
 *
 * // Basic select
 * <Select
 *   options={[
 *     { value: '1', label: 'Option 1' },
 *     { value: '2', label: 'Option 2' },
 *     { value: '3', label: 'Option 3' }
 *   ]}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With label and placeholder
 * <Select
 *   label="Country"
 *   placeholder="Select a country"
 *   options={[
 *     { value: 'us', label: 'United States' },
 *     { value: 'uk', label: 'United Kingdom' },
 *     { value: 'fr', label: 'France' }
 *   ]}
 * />
 *
 * // With reactive value
 * const country = Pulse.signal('us');
 * <Select
 *   label="Country"
 *   value={country}
 *   options={[...]}
 *   onChange={(val) => country(val)}
 * />
 *
 * // With groups
 * <Select
 *   label="Fruit"
 *   options={[
 *     { value: 'apple', label: 'Apple', group: 'Common' },
 *     { value: 'banana', label: 'Banana', group: 'Common' },
 *     { value: 'mango', label: 'Mango', group: 'Exotic' },
 *     { value: 'papaya', label: 'Papaya', group: 'Exotic' }
 *   ]}
 * />
 *
 * // With error
 * <Select
 *   label="Status"
 *   error="Please select a status"
 *   options={[...]}
 * />
 *
 * // Multiple selection
 * <Select
 *   label="Tags"
 *   multiple={true}
 *   options={[...]}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { SelectProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Select: Pulse.Fn<SelectProps> = (props) => {
  const {
    value,
    options,
    placeholder = "Select an option",
    disabled = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    multiple = false,
    onChange,
    className,
    id = generateId("select"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base select classes
  const baseClasses =
    "w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed appearance-none bg-white dark:bg-gray-700";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:text-gray-100";

  // Combine classes
  const selectClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    "pr-10", // Space for dropdown arrow
    className,
  );

  // Get reactive value
  const selectValue = () => {
    const val = isSignal(value) ? (value as any)() : value;
    if (multiple && Array.isArray(val)) {
      return val;
    }
    return val || "";
  };

  // Group options by group property
  const groupedOptions: Record<string, typeof options> = {};
  const ungroupedOptions: typeof options = [];

  options.forEach((option) => {
    if (option.group) {
      if (!groupedOptions[option.group]) {
        groupedOptions[option.group] = [];
      }
      groupedOptions[option.group].push(option);
    } else {
      ungroupedOptions.push(option);
    }
  });

  // Handle change event
  const handleChange = (e: Event) => {
    const target = e.target as HTMLSelectElement;
    if (onChange) {
      if (multiple) {
        const selectedValues = Array.from(target.selectedOptions).map(
          (option) => option.value,
        );
        onChange(selectedValues);
      } else {
        onChange(target.value);
      }
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative">
        <select
          id={id}
          class={selectClasses}
          disabled={disabled}
          required={required}
          multiple={multiple}
          value={selectValue()}
          style={style}
          onChange={handleChange}
          {...rest}
        >
          {!multiple && placeholder && (
            <option value="" disabled selected={!value}>
              {placeholder}
            </option>
          )}

          {ungroupedOptions.map((option) => (
            <option
              value={String(option.value)}
              disabled={option.disabled || false}
            >
              {option.label}
            </option>
          ))}

          {Object.entries(groupedOptions).map(([groupName, groupOptions]) => (
            <optgroup label={groupName}>
              {groupOptions.map((option) => (
                <option
                  value={String(option.value)}
                  disabled={option.disabled || false}
                >
                  {option.label}
                </option>
              ))}
            </optgroup>
          ))}
        </select>

        <span
          class={cn(
            "absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none",
            error ? "text-red-400" : "text-gray-400 dark:text-gray-500",
          )}
        >
          <svg
            class="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M19 9l-7 7-7-7"
            />
          </svg>
        </span>
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
