/**
 * RadioGroup Component
 * A component for managing a group of radio buttons with a single value
 *
 * @example
 * ```tsx
 * import { RadioGroup } from '@odyssee/components';
 *
 * // Basic radio group
 * <RadioGroup
 *   name="color"
 *   options={[
 *     { value: 'red', label: 'Red' },
 *     { value: 'blue', label: 'Blue' },
 *     { value: 'green', label: 'Green' }
 *   ]}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With reactive value
 * const selectedColor = Pulse.signal('blue');
 * <RadioGroup
 *   name="color"
 *   label="Choose a color"
 *   value={selectedColor}
 *   options={[
 *     { value: 'red', label: 'Red' },
 *     { value: 'blue', label: 'Blue' },
 *     { value: 'green', label: 'Green' }
 *   ]}
 *   onChange={(value) => selectedColor(value)}
 * />
 *
 * // With descriptions
 * <RadioGroup
 *   name="plan"
 *   label="Select a plan"
 *   options={[
 *     { value: 'free', label: 'Free', description: 'Basic features' },
 *     { value: 'pro', label: 'Pro', description: '$29/month - All features' },
 *     { value: 'enterprise', label: 'Enterprise', description: 'Custom pricing' }
 *   ]}
 * />
 *
 * // Horizontal layout
 * <RadioGroup
 *   name="size"
 *   label="Size"
 *   direction="horizontal"
 *   options={[
 *     { value: 'sm', label: 'Small' },
 *     { value: 'md', label: 'Medium' },
 *     { value: 'lg', label: 'Large' }
 *   ]}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { RadioGroupProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const RadioGroup: Pulse.Fn<RadioGroupProps> = (props) => {
  const {
    name = generateId("radio-group"),
    value,
    options,
    label,
    hint,
    error,
    required = false,
    disabled = false,
    size = "md",
    direction = "vertical",
    onChange,
    className,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "w-3 h-3",
    sm: "w-3.5 h-3.5",
    md: "w-4 h-4",
    lg: "w-5 h-5",
    xl: "w-6 h-6",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  // Base radio classes
  const baseClasses =
    "border-gray-300 text-primary-600 focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed dark:border-gray-600 dark:bg-gray-700 dark:checked:bg-primary-500 dark:checked:border-primary-500 dark:focus:ring-primary-600 dark:focus:ring-offset-gray-800 transition-colors duration-200";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-600 focus:ring-red-500 dark:border-red-600"
    : "";

  // Get reactive value
  const currentValue = () => (isSignal(value) ? (value as any)() : value);

  // Handle change event
  const handleChange = (optionValue: any) => {
    if (onChange) {
      onChange(optionValue);
    }
  };

  return (
    <div class="flex flex-col gap-1.5" {...rest}>
      {label && (
        <label class="text-sm font-medium text-gray-700 dark:text-gray-300">
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div
        class={cn(
          "flex gap-4",
          direction === "horizontal" ? "flex-row flex-wrap" : "flex-col",
          className,
        )}
      >
        {options.map((option) => {
          const optionId = generateId("radio");
          const isDisabled = disabled || option.disabled || false;
          const isChecked = () => currentValue() === option.value;

          return (
            <div class="flex items-start gap-2">
              <input
                type="radio"
                id={optionId}
                name={name}
                value={String(option.value)}
                class={cn(baseClasses, sizeClasses[size], stateClasses)}
                checked={isChecked()}
                disabled={isDisabled}
                onChange={() => handleChange(option.value)}
              />

              {(option.label || option.description) && (
                <div class="flex flex-col gap-0.5">
                  {option.label && (
                    <label
                      for={optionId}
                      class={cn(
                        "font-medium cursor-pointer",
                        labelSizeClasses[size],
                        error
                          ? "text-red-700 dark:text-red-400"
                          : "text-gray-900 dark:text-gray-100",
                        isDisabled ? "opacity-50 cursor-not-allowed" : "",
                      )}
                    >
                      {option.label}
                    </label>
                  )}

                  {option.description && (
                    <p
                      class={cn(
                        "text-xs",
                        error
                          ? "text-red-600 dark:text-red-400"
                          : "text-gray-500 dark:text-gray-400",
                        isDisabled ? "opacity-50" : "",
                      )}
                    >
                      {option.description}
                    </p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
