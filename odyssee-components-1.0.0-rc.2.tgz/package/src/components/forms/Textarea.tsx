/**
 * Textarea Component
 * A flexible multiline text input with labels, hints, auto-resize, and character count
 *
 * @example
 * ```tsx
 * import { Textarea } from '@odyssee/components';
 *
 * // Basic textarea
 * <Textarea placeholder="Enter your message" onChange={(value) => console.log(value)} />
 *
 * // With label and hint
 * <Textarea
 *   label="Comment"
 *   hint="We will get back to you soon."
 *   rows={3}
 *   required={true}
 * />
 *
 * // With reactive value
 * const message = Pulse.signal('');
 * <Textarea
 *   label="Message"
 *   value={message}
 *   onChange={(val) => message(val)}
 * />
 *
 * // With error state
 * <Textarea
 *   label="Feedback"
 *   error="Your message should be at least 10 characters long"
 *   value="Short"
 * />
 *
 * // With character count
 * <Textarea
 *   label="Bio"
 *   maxLength={200}
 *   showCount={true}
 *   placeholder="Tell us about yourself"
 * />
 *
 * // Auto-resize
 * <Textarea
 *   label="Description"
 *   autoResize={true}
 *   minRows={2}
 *   maxRows={8}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { TextareaProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Textarea: Pulse.Fn<TextareaProps> = (props) => {
  const {
    value,
    placeholder = "",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    rows = 3,
    maxLength,
    showCount = false,
    autoResize = false,
    minRows = 2,
    maxRows = 10,
    onChange,
    onFocus,
    onBlur,
    className,
    id = generateId("textarea"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "px-3 py-2 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base textarea classes
  const baseClasses =
    "block w-full rounded-md border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed resize-y";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-300 text-gray-900 placeholder-gray-400 focus:border-primary-500 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder-gray-500";

  // Combine classes
  const textareaClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    autoResize ? "resize-none overflow-hidden" : "",
    className,
  );

  // Get reactive value
  const textareaValue = () =>
    isSignal(value) ? (value as any)() : value || "";

  // Character count
  const currentLength = () => {
    const val = textareaValue();
    return val ? String(val).length : 0;
  };

  // Handle input event
  const handleInput = (e: Event) => {
    const target = e.target as HTMLTextAreaElement;
    if (onChange) {
      onChange(target.value);
    }
    if (autoResize) {
      handleAutoResize(target);
    }
  };

  // Auto-resize function
  const handleAutoResize = (textarea: HTMLTextAreaElement) => {
    if (!autoResize) return;

    // Reset height to auto to get the correct scrollHeight
    textarea.style.height = "auto";

    // Calculate new height based on content
    const newHeight = textarea.scrollHeight;

    // Apply min/max constraints
    const lineHeight = parseInt(getComputedStyle(textarea).lineHeight) || 20;
    const minHeight = minRows * lineHeight;
    const maxHeight = maxRows * lineHeight;

    const constrainedHeight = Math.min(
      Math.max(newHeight, minHeight),
      maxHeight,
    );
    textarea.style.height = `${constrainedHeight}px`;

    // Show scrollbar if content exceeds maxHeight
    if (newHeight > maxHeight) {
      textarea.style.overflowY = "auto";
    } else {
      textarea.style.overflowY = "hidden";
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <div class="flex items-center justify-between">
          <label
            for={id}
            class="text-sm font-medium text-gray-700 dark:text-gray-300"
          >
            {label}
            {required && <span class="text-red-500 ml-1">*</span>}
          </label>

          {maxLength && showCount && (
            <span class="text-xs text-gray-500 dark:text-gray-400">
              {currentLength()} / {maxLength}
            </span>
          )}
        </div>
      )}

      <textarea
        id={id}
        class={textareaClasses}
        placeholder={placeholder}
        disabled={disabled}
        readonly={readonly}
        required={required}
        rows={autoResize ? minRows : rows}
        maxLength={maxLength}
        value={textareaValue()}
        style={style}
        onInput={handleInput}
        onFocus={onFocus}
        onBlur={onBlur}
        {...rest}
      />

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
