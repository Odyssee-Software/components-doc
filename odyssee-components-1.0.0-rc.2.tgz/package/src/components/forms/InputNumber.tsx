/**
 * InputNumber Component
 * A quantity selector component with increment/decrement buttons for numerical input
 *
 * @example
 * ```tsx
 * import { InputNumber } from '@odyssee/components';
 *
 * // Basic usage
 * <InputNumber
 *   value={1}
 *   onChange={(val) => console.log(val)}
 * />
 *
 * // With label and description
 * <InputNumber
 *   label="Quantity"
 *   description="Select quantity"
 *   value={0}
 *   onChange={(val) => console.log(val)}
 * />
 *
 * // With reactive value
 * const quantity = Pulse.signal(1);
 * <InputNumber
 *   value={quantity}
 *   onChange={(val) => quantity(val)}
 * />
 *
 * // With min, max, and step
 * <InputNumber
 *   min={0}
 *   max={10}
 *   step={2}
 *   value={0}
 * />
 *
 * // Vertical variant
 * <InputNumber
 *   variant="vertical"
 *   label="Additional seats"
 *   description="$39 monthly"
 * />
 *
 * // Horizontal variant
 * <InputNumber
 *   variant="horizontal"
 *   value={1}
 * />
 *
 * // Mini variant
 * <InputNumber
 *   variant="mini"
 *   value={0}
 * />
 *
 * // With validation error
 * <InputNumber
 *   value={10}
 *   error="Out of limit"
 *   max={5}
 * />
 *
 * // Disabled
 * <InputNumber
 *   value={5}
 *   disabled={true}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { InputNumberProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const InputNumber: Pulse.Fn<InputNumberProps> = (props) => {
  const {
    value,
    min,
    max,
    step = 1,
    disabled = false,
    label,
    description,
    error,
    hint,
    variant = "default",
    size = "md",
    buttonShape = "rounded",
    showButtons = true,
    onChange,
    className,
    id = generateId("input-number"),
    name,
    ...rest
  } = props;

  // Internal state for value
  const internalValue = Pulse.signal(
    isSignal(value) ? (value as any)() : (value ?? 0),
  );

  // Sync with external value
  Pulse.effect(() => {
    if (isSignal(value)) {
      internalValue((value as any)());
    } else if (value !== undefined) {
      internalValue(value);
    }
  });

  // Get current value
  const getValue = () => internalValue();

  // Check if decrement is disabled
  const isDecrementDisabled = () => {
    const val = getValue();
    return disabled || (min !== undefined && val <= min);
  };

  // Check if increment is disabled
  const isIncrementDisabled = () => {
    const val = getValue();
    return disabled || (max !== undefined && val >= max);
  };

  // Handle increment
  const handleIncrement = (e: Event) => {
    e.preventDefault();
    if (isIncrementDisabled()) return;

    let newValue = getValue() + step;
    if (max !== undefined && newValue > max) {
      newValue = max;
    }

    internalValue(newValue);
    if (onChange) onChange(newValue);
    if (isSignal(value)) (value as any)(newValue);
  };

  // Handle decrement
  const handleDecrement = (e: Event) => {
    e.preventDefault();
    if (isDecrementDisabled()) return;

    let newValue = getValue() - step;
    if (min !== undefined && newValue < min) {
      newValue = min;
    }

    internalValue(newValue);
    if (onChange) onChange(newValue);
    if (isSignal(value)) (value as any)(newValue);
  };

  // Handle manual input
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    let newValue = parseFloat(target.value);

    if (isNaN(newValue)) {
      newValue = min ?? 0;
    }

    if (min !== undefined && newValue < min) {
      newValue = min;
    }
    if (max !== undefined && newValue > max) {
      newValue = max;
    }

    internalValue(newValue);
    if (onChange) onChange(newValue);
    if (isSignal(value)) (value as any)(newValue);
  };

  // Size classes for wrapper
  const sizeClasses = {
    xs: "py-1 px-2",
    sm: "py-1.5 px-2.5",
    md: "py-2 px-3",
    lg: "py-2.5 px-4",
    xl: "py-3 px-5",
  };

  // Button size classes
  const buttonSizeClasses = {
    xs: "size-5",
    sm: "size-5",
    md: "size-6",
    lg: "size-7",
    xl: "size-8",
  };

  // Button shape classes
  const buttonShapeClass =
    buttonShape === "square" ? "rounded-full" : "rounded-md";

  // Base button classes
  const buttonBaseClasses =
    "inline-flex justify-center items-center gap-x-2 text-sm font-medium border border-gray-200 bg-white text-gray-800 shadow-2xs hover:bg-gray-50 focus:outline-none focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-800 dark:focus:bg-neutral-800";

  // Wrapper classes
  const wrapperClasses = cn(
    "bg-white border rounded-lg dark:bg-neutral-900",
    error ? "border-red-500" : "border-gray-200 dark:border-neutral-700",
    sizeClasses[size],
    className,
  );

  return (
    <div class="flex flex-col gap-1.5">
      <div class={wrapperClasses}>
        {/* Mini variant */}
        {variant === "mini" && (
          <div class="flex items-center gap-x-1.5">
            <button
              type="button"
              class={cn(
                buttonBaseClasses,
                buttonSizeClasses[size],
                buttonShapeClass,
              )}
              aria-label="Decrease"
              disabled={isDecrementDisabled()}
              onClick={handleDecrement}
              tabindex="-1"
            >
              <svg
                class="shrink-0 size-3.5"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="M5 12h14"></path>
              </svg>
            </button>
            <input
              type="number"
              id={id}
              name={name}
              class="p-0 w-6 bg-transparent border-0 text-gray-800 text-center focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
              style="-moz-appearance: textfield;"
              value={getValue()}
              disabled={disabled}
              min={min}
              max={max}
              step={step}
              onInput={handleInput}
              aria-roledescription="Number field"
              {...rest}
            />
            <button
              type="button"
              class={cn(
                buttonBaseClasses,
                buttonSizeClasses[size],
                buttonShapeClass,
              )}
              aria-label="Increase"
              disabled={isIncrementDisabled()}
              onClick={handleIncrement}
              tabindex="-1"
            >
              <svg
                class="shrink-0 size-3.5"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="M5 12h14"></path>
                <path d="M12 5v14"></path>
              </svg>
            </button>
          </div>
        )}

        {/* Vertical variant */}
        {variant === "vertical" && (
          <div class="w-full flex items-center gap-x-1">
            <div class="grow py-2 px-3">
              {(label || description) && (
                <div class="mb-1">
                  {description && (
                    <span class="block font-medium text-sm text-gray-800 dark:text-white">
                      {description}
                    </span>
                  )}
                  {label && (
                    <span class="block text-xs text-gray-500 dark:text-neutral-400">
                      {label}
                    </span>
                  )}
                </div>
              )}
              {error ? (
                <div class="relative w-full">
                  <input
                    type="number"
                    id={id}
                    name={name}
                    class="w-full p-0 pe-7 bg-transparent border-0 text-gray-800 focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
                    style="-moz-appearance: textfield;"
                    value={getValue()}
                    disabled={disabled}
                    min={min}
                    max={max}
                    step={step}
                    onInput={handleInput}
                    aria-roledescription="Number field"
                    {...rest}
                  />
                  <div class="absolute inset-y-0 end-0 flex items-center pointer-events-none">
                    <svg
                      class="shrink-0 size-4 text-red-500"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" x2="12" y1="8" y2="12"></line>
                      <line x1="12" x2="12.01" y1="16" y2="16"></line>
                    </svg>
                  </div>
                </div>
              ) : (
                <input
                  type="number"
                  id={id}
                  name={name}
                  class="w-full p-0 bg-transparent border-0 text-gray-800 focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
                  style="-moz-appearance: textfield;"
                  value={getValue()}
                  disabled={disabled}
                  min={min}
                  max={max}
                  step={step}
                  onInput={handleInput}
                  aria-roledescription="Number field"
                  {...rest}
                />
              )}
            </div>
            {showButtons && (
              <div class="flex flex-col -gap-y-px divide-y divide-gray-200 border-s border-gray-200 dark:divide-neutral-700 dark:border-neutral-700">
                <button
                  type="button"
                  class="size-7 inline-flex justify-center items-center gap-x-2 text-sm font-medium rounded-se-lg bg-gray-50 text-gray-800 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:text-white dark:hover:bg-neutral-700 dark:focus:bg-neutral-700"
                  aria-label="Decrease"
                  disabled={isDecrementDisabled()}
                  onClick={handleDecrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                  </svg>
                </button>
                <button
                  type="button"
                  class="size-7 inline-flex justify-center items-center gap-x-2 text-sm font-medium rounded-ee-lg bg-gray-50 text-gray-800 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:text-white dark:hover:bg-neutral-700 dark:focus:bg-neutral-700"
                  aria-label="Increase"
                  disabled={isIncrementDisabled()}
                  onClick={handleIncrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                    <path d="M12 5v14"></path>
                  </svg>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Horizontal variant */}
        {variant === "horizontal" && (
          <div class="w-full flex items-center gap-x-1">
            <div class="grow py-2 px-3">
              {(label || description) && (
                <div class="mb-1">
                  {description && (
                    <span class="block font-medium text-sm text-gray-800 dark:text-white">
                      {description}
                    </span>
                  )}
                  {label && (
                    <span class="block text-xs text-gray-500 dark:text-neutral-400">
                      {label}
                    </span>
                  )}
                </div>
              )}
              <input
                type="number"
                id={id}
                name={name}
                class="w-full p-0 bg-transparent border-0 text-gray-800 focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
                style="-moz-appearance: textfield;"
                value={getValue()}
                disabled={disabled}
                min={min}
                max={max}
                step={step}
                onInput={handleInput}
                aria-roledescription="Number field"
                {...rest}
              />
            </div>
            {showButtons && (
              <div class="flex items-center -gap-y-px divide-x divide-gray-200 border-s border-gray-200 dark:divide-neutral-700 dark:border-neutral-700">
                <button
                  type="button"
                  class="size-10 inline-flex justify-center items-center gap-x-2 text-sm font-medium last:rounded-e-lg bg-white text-gray-800 hover:bg-gray-50 focus:outline-none focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:text-white dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
                  aria-label="Decrease"
                  disabled={isDecrementDisabled()}
                  onClick={handleDecrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                  </svg>
                </button>
                <button
                  type="button"
                  class="size-10 inline-flex justify-center items-center gap-x-2 text-sm font-medium last:rounded-e-lg bg-white text-gray-800 hover:bg-gray-50 focus:outline-none focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:text-white dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
                  aria-label="Increase"
                  disabled={isIncrementDisabled()}
                  onClick={handleIncrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                    <path d="M12 5v14"></path>
                  </svg>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Default variant */}
        {variant === "default" && (
          <div class="w-full flex justify-between items-center gap-x-5">
            <div class="grow">
              {(label || description) && (
                <div class="mb-1">
                  {description && (
                    <span class="block font-medium text-sm text-gray-800 dark:text-white">
                      {description}
                    </span>
                  )}
                  {label && (
                    <span class="block text-xs text-gray-500 dark:text-neutral-400">
                      {label}
                    </span>
                  )}
                </div>
              )}
              {error ? (
                <div class="relative w-full">
                  <input
                    type="number"
                    id={id}
                    name={name}
                    class="w-full p-0 pe-7 bg-transparent border-0 text-gray-800 focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
                    style="-moz-appearance: textfield;"
                    value={getValue()}
                    disabled={disabled}
                    min={min}
                    max={max}
                    step={step}
                    onInput={handleInput}
                    aria-roledescription="Number field"
                    {...rest}
                  />
                  <div class="absolute inset-y-0 end-0 flex items-center pointer-events-none">
                    <svg
                      class="shrink-0 size-4 text-red-500"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <circle cx="12" cy="12" r="10"></circle>
                      <line x1="12" x2="12" y1="8" y2="12"></line>
                      <line x1="12" x2="12.01" y1="16" y2="16"></line>
                    </svg>
                  </div>
                </div>
              ) : (
                <input
                  type="number"
                  id={id}
                  name={name}
                  class="w-full p-0 bg-transparent border-0 text-gray-800 focus:ring-0 [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-white"
                  style="-moz-appearance: textfield;"
                  value={getValue()}
                  disabled={disabled}
                  min={min}
                  max={max}
                  step={step}
                  onInput={handleInput}
                  aria-roledescription="Number field"
                  {...rest}
                />
              )}
            </div>
            {showButtons && (
              <div class="flex justify-end items-center gap-x-1.5">
                <button
                  type="button"
                  class={cn(
                    buttonBaseClasses,
                    buttonSizeClasses[size],
                    buttonShapeClass,
                  )}
                  aria-label="Decrease"
                  disabled={isDecrementDisabled()}
                  onClick={handleDecrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                  </svg>
                </button>
                <button
                  type="button"
                  class={cn(
                    buttonBaseClasses,
                    buttonSizeClasses[size],
                    buttonShapeClass,
                  )}
                  aria-label="Increase"
                  disabled={isIncrementDisabled()}
                  onClick={handleIncrement}
                  tabindex="-1"
                >
                  <svg
                    class="shrink-0 size-3.5"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M5 12h14"></path>
                    <path d="M12 5v14"></path>
                  </svg>
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
