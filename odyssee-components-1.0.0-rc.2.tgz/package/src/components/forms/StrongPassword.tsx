/**
 * StrongPassword Component
 * A password input with strength indicator and validation rules
 *
 * @example
 * ```tsx
 * import { StrongPassword } from '@odyssee/components';
 *
 * // Basic usage
 * <StrongPassword
 *   placeholder="Enter password"
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With all rules displayed
 * <StrongPassword
 *   label="Password"
 *   showHints={true}
 *   minLength={8}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With reactive value
 * const password = Pulse.signal('');
 * <StrongPassword
 *   value={password}
 *   onChange={(val) => password(val)}
 *   showHints={true}
 * />
 *
 * // Custom strength levels
 * <StrongPassword
 *   strengthLevels={["Empty", "Weak", "Fair", "Good", "Strong", "Very Strong"]}
 *   showHints={true}
 * />
 *
 * // Custom rules
 * <StrongPassword
 *   minLength={10}
 *   requireLowercase={true}
 *   requireUppercase={true}
 *   requireNumbers={true}
 *   requireSpecialChars={true}
 *   specialCharsSet="!@#$%^&*"
 *   showHints={true}
 * />
 *
 * // With toggle password visibility
 * <StrongPassword
 *   showToggleButton={true}
 *   showHints={true}
 * />
 *
 * // Disabled state
 * <StrongPassword
 *   disabled={true}
 *   value="password123"
 * />
 *
 * // With popover mode (hints in popover)
 * <StrongPassword
 *   showHints={true}
 *   hintsMode="popover"
 * />
 *
 * // Without specific checks
 * <StrongPassword
 *   checksExclude={["lowercase", "special-characters"]}
 *   showHints={true}
 * />
 *
 * // With onChange and strength callback
 * <StrongPassword
 *   onChange={(value, strength) => {
 *     console.log('Password:', value);
 *     console.log('Strength:', strength);
 *   }}
 *   showHints={true}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { StrongPasswordProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const StrongPassword: Pulse.Fn<StrongPasswordProps> = (props) => {
  const {
    value,
    placeholder = "Enter password",
    disabled = false,
    readonly = false,
    required = false,
    label,
    hint,
    error,
    size = "md",
    minLength = 6,
    requireLowercase = true,
    requireUppercase = true,
    requireNumbers = true,
    requireSpecialChars = true,
    specialCharsSet = "!@#$%^&*()_+-=[]{}|;:,.<>?",
    strengthLevels = ["Empty", "Weak", "Medium", "Strong", "Very Strong", "Super Strong"],
    showHints = false,
    hintsMode = "inline",
    showToggleButton = true,
    checksExclude = [],
    stripCount = 4,
    onChange,
    onStrengthChange,
    onFocus,
    onBlur,
    className,
    id = generateId("strong-password"),
    name,
    ...rest
  } = props;

  // Internal state
  const isVisible = Pulse.signal(false);
  const inputValue = Pulse.signal("");
  const strength = Pulse.signal(0);
  const strengthLevel = Pulse.signal(strengthLevels[0]);
  const isFocused = Pulse.signal(false);

  // Initialize value
  Pulse.effect(() => {
    const val = isSignal(value) ? (value as any)() : value || "";
    inputValue(val);
    calculateStrength(val);
  });

  // Validation rules
  const rules = {
    "min-length": {
      test: (val: string) => val.length >= minLength,
      message: `Minimum number of characters is ${minLength}.`,
      excluded: checksExclude.includes("min-length"),
    },
    lowercase: {
      test: (val: string) => /[a-z]/.test(val),
      message: "Should contain lowercase.",
      excluded: !requireLowercase || checksExclude.includes("lowercase"),
    },
    uppercase: {
      test: (val: string) => /[A-Z]/.test(val),
      message: "Should contain uppercase.",
      excluded: !requireUppercase || checksExclude.includes("uppercase"),
    },
    numbers: {
      test: (val: string) => /[0-9]/.test(val),
      message: "Should contain numbers.",
      excluded: !requireNumbers || checksExclude.includes("numbers"),
    },
    "special-characters": {
      test: (val: string) => {
        const regex = new RegExp(`[${specialCharsSet.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}]`);
        return regex.test(val);
      },
      message: `Should contain special characters${specialCharsSet !== "!@#$%^&*()_+-=[]{}|;:,.<>?" ? ` (available chars: ${specialCharsSet})` : ""}.`,
      excluded: !requireSpecialChars || checksExclude.includes("special-characters"),
    },
  };

  // Calculate password strength
  const calculateStrength = (val: string) => {
    if (!val) {
      strength(0);
      strengthLevel(strengthLevels[0]);
      if (onStrengthChange) onStrengthChange(0, strengthLevels[0]);
      return;
    }

    const activeRules = Object.entries(rules).filter(([_, rule]) => !rule.excluded);
    const passedRules = activeRules.filter(([_, rule]) => rule.test(val)).length;
    const totalRules = activeRules.length;

    const strengthValue = totalRules > 0 ? Math.min(Math.floor((passedRules / totalRules) * (strengthLevels.length - 1)) + 1, strengthLevels.length - 1) : 0;

    strength(strengthValue);
    strengthLevel(strengthLevels[strengthValue]);
    if (onStrengthChange) onStrengthChange(strengthValue, strengthLevels[strengthValue]);
  };

  // Check if a rule is satisfied
  const isRuleSatisfied = (ruleKey: string) => {
    const val = inputValue();
    const rule = rules[ruleKey as keyof typeof rules];
    return rule && rule.test(val);
  };

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "py-2.5 sm:py-3 px-4 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-lg border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-200 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-700 dark:bg-neutral-900 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600";

  // Add padding for toggle button
  const paddingClass = showToggleButton ? "pe-10" : "";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    paddingClass,
    className,
  );

  // Get strip colors based on strength
  const getStripColor = (index: number) => {
    if (strength() === 0) return "bg-blue-500 opacity-50";
    if (index < strength()) {
      // All satisfied strips are teal
      return "bg-teal-500 opacity-100";
    }
    return "bg-blue-500 opacity-50";
  };

  // Handle input change
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    const val = target.value;
    inputValue(val);
    calculateStrength(val);

    if (onChange) {
      onChange(val, strength(), strengthLevel());
    }
    if (isSignal(value)) {
      (value as any)(val);
    }
  };

  // Handle toggle visibility
  const handleToggle = (e: Event) => {
    e.preventDefault();
    isVisible(!isVisible());
  };

  // Handle focus
  const handleFocus = (e: Event) => {
    isFocused(true);
    if (onFocus) onFocus(e);
  };

  // Handle blur
  const handleBlur = (e: Event) => {
    // Delay to allow popover interaction
    setTimeout(() => {
      isFocused(false);
    }, 200);
    if (onBlur) onBlur(e);
  };

  // Icons
  const eyeOffIcon = (
    <svg
      class="shrink-0 size-3.5"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path>
      <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path>
      <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path>
      <line x1="2" x2="22" y1="2" y2="22"></line>
    </svg>
  );

  const eyeIcon = (
    <svg
      class="shrink-0 size-3.5"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
      <circle cx="12" cy="12" r="3"></circle>
    </svg>
  );

  const checkIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );

  const crossIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  );

  // Render hints content
  const renderHints = () => (
    <>
      <div class="mb-3">
        <span class="text-sm text-gray-800 dark:text-neutral-200">Level: </span>
        <span class="text-sm font-semibold text-gray-800 dark:text-neutral-200">
          {strengthLevel()}
        </span>
      </div>

      <h4 class="my-2 text-sm font-semibold text-gray-800 dark:text-white">
        Your password must contain:
      </h4>

      <ul class="space-y-1 text-sm text-gray-500 dark:text-neutral-500">
        {Object.entries(rules)
          .filter(([_, rule]) => !rule.excluded)
          .map(([key, rule]) => {
            const satisfied = isRuleSatisfied(key);
            return (
              <li
                key={key}
                class={cn(
                  "flex items-center gap-x-2 transition-colors",
                  satisfied && "text-teal-500",
                )}
              >
                <span class={satisfied ? "block" : "hidden"}>{checkIcon}</span>
                <span class={satisfied ? "hidden" : "block"}>{crossIcon}</span>
                {rule.message}
              </li>
            );
          })}
      </ul>
    </>
  );

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative">
        <input
          type={isVisible() ? "text" : "password"}
          id={id}
          name={name}
          class={inputClasses}
          placeholder={placeholder}
          disabled={disabled}
          readonly={readonly}
          required={required}
          value={inputValue()}
          onInput={handleInput}
          onFocus={handleFocus}
          onBlur={handleBlur}
          {...rest}
        />

        {showToggleButton && (
          <button
            type="button"
            class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-blue-600 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-600 dark:focus:text-blue-500"
            onClick={handleToggle}
            disabled={disabled}
            aria-label={isVisible() ? "Hide password" : "Show password"}
            aria-pressed={isVisible()}
          >
            {isVisible() ? eyeIcon : eyeOffIcon}
          </button>
        )}

        {/* Popover hints */}
        {showHints && hintsMode === "popover" && (
          <div
            class={cn(
              "absolute z-10 w-full bg-white shadow-md rounded-lg p-4 mt-2 dark:bg-neutral-800 dark:border dark:border-neutral-700 transition-opacity",
              isFocused() ? "block" : "hidden",
            )}
          >
            {/* Strength strips */}
            <div class="flex mt-2 -mx-1">
              {Array.from({ length: stripCount }).map((_, index) => (
                <div
                  key={index}
                  class={cn(
                    "h-2 flex-auto rounded-full mx-1 transition-all duration-300",
                    getStripColor(index),
                  )}
                ></div>
              ))}
            </div>

            {renderHints()}
          </div>
        )}
      </div>

      {/* Inline strength strips */}
      {!error && (
        <div class="flex mt-2 -mx-1">
          {Array.from({ length: stripCount }).map((_, index) => (
            <div
              key={index}
              class={cn(
                "h-2 flex-auto rounded-full mx-1 transition-all duration-300",
                getStripColor(index),
              )}
            ></div>
          ))}
        </div>
      )}

      {/* Inline hints */}
      {showHints && hintsMode === "inline" && !error && renderHints()}

      {hint && !error && !showHints && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
