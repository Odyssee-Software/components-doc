/**
 * TogglePassword Component
 * An input component that allows users to toggle between showing and hiding password text
 *
 * @example
 * ```tsx
 * import { TogglePassword } from '@odyssee/components';
 *
 * // Basic usage
 * <TogglePassword
 *   placeholder="Enter password"
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With label and validation
 * <TogglePassword
 *   label="Password"
 *   hint="Must be at least 8 characters"
 *   error="Password is required"
 *   required={true}
 * />
 *
 * // With reactive value
 * const password = Pulse.signal('');
 * <TogglePassword
 *   label="Password"
 *   value={password}
 *   onChange={(val) => password(val)}
 * />
 *
 * // Default visible
 * <TogglePassword
 *   label="Password"
 *   defaultVisible={true}
 *   placeholder="Enter password"
 * />
 *
 * // Without toggle button
 * <TogglePassword
 *   label="Password"
 *   showToggleButton={false}
 * />
 *
 * // Different sizes
 * <TogglePassword label="Small" size="sm" />
 * <TogglePassword label="Medium" size="md" />
 * <TogglePassword label="Large" size="lg" />
 *
 * // Disabled state
 * <TogglePassword
 *   label="Password"
 *   disabled={true}
 *   value="locked"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { TogglePasswordProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const TogglePassword: Pulse.Fn<TogglePasswordProps> = (props) => {
  const {
    value,
    placeholder = "Enter password",
    disabled = false,
    readonly = false,
    required = false,
    error,
    label,
    hint,
    size = "md",
    defaultVisible = false,
    showToggleButton = true,
    onChange,
    onFocus,
    onBlur,
    className,
    id = generateId("toggle-password"),
    style,
    name,
    ...rest
  } = props;

  // Internal state for visibility
  const isVisible = Pulse.signal(defaultVisible);

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "py-2.5 sm:py-3 px-4 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-lg border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-200 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-700 dark:bg-neutral-900 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600";

  // Add padding right for toggle button
  const paddingClass = showToggleButton ? "pe-10" : "";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    paddingClass,
    className,
  );

  // Get reactive value
  const inputValue = () => (isSignal(value) ? (value as any)() : value || "");

  // Handle input event
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.value);
    }
  };

  // Handle toggle visibility
  const handleToggle = (e: Event) => {
    e.preventDefault();
    isVisible(!isVisible());
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative">
        <input
          type={isVisible() ? "text" : "password"}
          id={id}
          name={name}
          class={inputClasses}
          placeholder={placeholder}
          disabled={disabled}
          readonly={readonly}
          required={required}
          value={inputValue()}
          style={style}
          onInput={handleInput}
          onFocus={onFocus}
          onBlur={onBlur}
          {...rest}
        />

        {showToggleButton && (
          <button
            type="button"
            class="absolute inset-y-0 end-0 flex items-center z-20 px-3 cursor-pointer text-gray-400 rounded-e-md focus:outline-none focus:text-blue-600 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-600 dark:focus:text-blue-500"
            onClick={handleToggle}
            disabled={disabled}
            aria-label={isVisible() ? "Hide password" : "Show password"}
            aria-pressed={isVisible()}
          >
            <svg
              class="shrink-0 size-3.5"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              {!isVisible() ? (
                <>
                  {/* Eye off icon (password hidden) */}
                  <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"></path>
                  <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"></path>
                  <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"></path>
                  <line x1="2" x2="22" y1="2" y2="22"></line>
                </>
              ) : (
                <>
                  {/* Eye icon (password visible) */}
                  <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path>
                  <circle cx="12" cy="12" r="3"></circle>
                </>
              )}
            </svg>
          </button>
        )}
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
