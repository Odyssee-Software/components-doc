/**
 * Toggle/Switch Component
 * A customizable switch component with label, description, icons, and validation states
 *
 * @example
 * ```tsx
 * import { Toggle } from '@odyssee/components';
 *
 * // Basic toggle
 * <Toggle label="Enable notifications" onChange={(checked) => console.log(checked)} />
 *
 * // With description
 * <Toggle
 *   label="Auto-save"
 *   description="Automatically save your changes"
 *   onChange={(checked) => console.log(checked)}
 * />
 *
 * // With reactive value
 * const isEnabled = Pulse.signal(false);
 * <Toggle
 *   label="Dark mode"
 *   checked={isEnabled}
 *   onChange={(checked) => isEnabled(checked)}
 * />
 *
 * // With icons
 * <Toggle
 *   label="Power"
 *   showIcons={true}
 *   onChange={(checked) => console.log(checked)}
 * />
 *
 * // Different sizes
 * <Toggle label="Small toggle" size="sm" onChange={(checked) => console.log(checked)} />
 *
 * // Soft variant
 * <Toggle label="Soft toggle" variant="soft" onChange={(checked) => console.log(checked)} />
 *
 * // With error/success state
 * <Toggle label="Accept terms" error="You must accept the terms" required={true} />
 *
 * // Disabled
 * <Toggle label="Disabled option" disabled={true} checked={true} />
 * ```
 */

import Pulse from "pulse-framework";
import type { ToggleProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Toggle: Pulse.Fn<ToggleProps> = (props) => {
  const {
    checked = false,
    disabled = false,
    required = false,
    label,
    description,
    error,
    success,
    size = "md",
    variant = "default",
    showIcons = false,
    labelPosition = "right",
    onChange,
    className,
    id = generateId("toggle"),
    name,
    ...rest
  } = props;

  // Size classes for the toggle
  const sizeClasses = {
    xs: "w-8 h-4",
    sm: "w-9 h-5",
    md: "w-11 h-6",
    lg: "w-14 h-7",
  };

  // Size classes for the toggle thumb
  const thumbSizeClasses = {
    xs: "w-3 h-3",
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-6 h-6",
  };

  // Translation classes for checked state
  const translateClasses = {
    xs: "peer-checked:translate-x-4",
    sm: "peer-checked:translate-x-4",
    md: "peer-checked:translate-x-5",
    lg: "peer-checked:translate-x-7",
  };

  const labelSizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-sm",
    lg: "text-base",
  };

  // Get reactive checked value
  const isChecked = () => (isSignal(checked) ? (checked as any)() : checked);

  // Handle change event
  const handleChange = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(target.checked);
    }
  };

  // Variant classes
  let switchBgClasses = "";
  let thumbClasses = "";

  if (variant === "soft") {
    // Soft variant
    if (error) {
      switchBgClasses =
        "bg-red-100 peer-checked:bg-red-200 dark:bg-red-900 dark:peer-checked:bg-red-800";
      thumbClasses = "bg-red-500 dark:bg-red-400";
    } else if (success) {
      switchBgClasses =
        "bg-green-100 peer-checked:bg-green-200 dark:bg-green-900 dark:peer-checked:bg-green-800";
      thumbClasses = "bg-green-500 dark:bg-green-400";
    } else {
      switchBgClasses =
        "bg-gray-100 peer-checked:bg-primary-100 dark:bg-gray-700 dark:peer-checked:bg-primary-900";
      thumbClasses =
        "bg-gray-400 peer-checked:bg-primary-600 dark:bg-gray-500 dark:peer-checked:bg-primary-500";
    }
  } else {
    // Default variant
    if (error) {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-red-600 dark:bg-gray-700 dark:peer-checked:bg-red-600";
    } else if (success) {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-green-600 dark:bg-gray-700 dark:peer-checked:bg-green-600";
    } else {
      switchBgClasses =
        "bg-gray-200 peer-checked:bg-primary-600 dark:bg-gray-700 dark:peer-checked:bg-primary-600";
    }
    thumbClasses = "bg-white dark:bg-gray-300";
  }

  return (
    <div class="flex flex-col gap-1.5">
      <div
        class={cn(
          "flex items-start gap-2",
          labelPosition === "left" ? "flex-row-reverse justify-end" : "",
        )}
      >
        <input
          type="checkbox"
          id={id}
          name={name}
          class="sr-only peer"
          checked={isChecked()}
          disabled={disabled}
          required={required}
          onChange={handleChange}
          {...rest}
        />

        <label
          for={id}
          class={cn(
            "relative inline-flex items-center cursor-pointer",
            sizeClasses[size],
            switchBgClasses,
            "rounded-full transition-colors duration-200",
            "peer-focus:ring-2 peer-focus:ring-offset-2",
            error
              ? "peer-focus:ring-red-500"
              : success
                ? "peer-focus:ring-green-500"
                : "peer-focus:ring-primary-500",
            disabled ? "opacity-50 cursor-not-allowed" : "hover:brightness-95",
            className,
          )}
        >
          <span
            class={cn(
              "absolute left-0.5 top-0.5 rounded-full transition-transform duration-200",
              thumbSizeClasses[size],
              thumbClasses,
              translateClasses[size],
              "flex items-center justify-center",
            )}
          >
            {showIcons && (
              <>
                <svg
                  class="w-2.5 h-2.5 text-current opacity-0 peer-checked:opacity-100 absolute transition-opacity duration-200"
                  fill="currentColor"
                  viewBox="0 0 12 12"
                >
                  <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                </svg>
                <svg
                  class="w-2.5 h-2.5 text-current opacity-100 peer-checked:opacity-0 absolute transition-opacity duration-200"
                  fill="currentColor"
                  viewBox="0 0 12 12"
                >
                  <path d="M11.707 1.707A1 1 0 0010.293.293L6 4.586 1.707.293A1 1 0 00.293 1.707L4.586 6 .293 10.293a1 1 0 101.414 1.414L6 7.414l4.293 4.293a1 1 0 001.414-1.414L7.414 6l4.293-4.293z" />
                </svg>
              </>
            )}
          </span>
        </label>

        {(label || description) && (
          <div class="flex flex-col gap-0.5">
            {label && (
              <span
                class={cn(
                  "font-medium",
                  labelSizeClasses[size],
                  error
                    ? "text-red-700 dark:text-red-400"
                    : success
                      ? "text-green-700 dark:text-green-400"
                      : "text-gray-900 dark:text-gray-100",
                  disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
                )}
                onClick={() =>
                  !disabled && document.getElementById(id)?.click()
                }
              >
                {label}
                {required && <span class="text-red-500 ml-1">*</span>}
              </span>
            )}

            {description && (
              <p
                class={cn(
                  "text-xs",
                  error
                    ? "text-red-600 dark:text-red-400"
                    : success
                      ? "text-green-600 dark:text-green-400"
                      : "text-gray-500 dark:text-gray-400",
                  disabled ? "opacity-50" : "",
                )}
              >
                {description}
              </p>
            )}
          </div>
        )}
      </div>

      {error && typeof error === "string" && (
        <p class="text-xs text-red-600 dark:text-red-400 ml-6">{error}</p>
      )}

      {success && typeof success === "string" && (
        <p class="text-xs text-green-600 dark:text-green-400 ml-6">{success}</p>
      )}
    </div>
  ) as Pulse.JSX.Element;
};
