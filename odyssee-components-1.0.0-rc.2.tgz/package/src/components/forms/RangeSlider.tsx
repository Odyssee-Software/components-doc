/**
 * RangeSlider Component
 * A range slider component for selecting numeric values within a defined range
 *
 * @example
 * ```tsx
 * import { RangeSlider } from '@odyssee/components';
 *
 * // Basic range slider
 * <RangeSlider label="Volume" onChange={(value) => console.log(value)} />
 *
 * // With reactive value
 * const volume = Pulse.signal(50);
 * <RangeSlider
 *   label="Volume"
 *   value={volume}
 *   onChange={(val) => volume(val)}
 * />
 *
 * // With min, max, and step
 * <RangeSlider
 *   label="Price"
 *   min={0}
 *   max={1000}
 *   step={10}
 *   value={500}
 *   showValue={true}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // With custom format
 * <RangeSlider
 *   label="Temperature"
 *   min={-10}
 *   max={40}
 *   value={20}
 *   showValue={true}
 *   valueFormat={(val) => `${val}°C`}
 *   onChange={(value) => console.log(value)}
 * />
 *
 * // Disabled
 * <RangeSlider label="Brightness" value={75} disabled={true} />
 * ```
 */

import Pulse from "pulse-framework";
import type { RangeSliderProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const RangeSlider: Pulse.Fn<RangeSliderProps> = (props) => {
  const {
    value = 50,
    min = 0,
    max = 100,
    step = 1,
    label,
    hint,
    error,
    disabled = false,
    showValue = false,
    valueFormat,
    onChange,
    className,
    id = generateId("range-slider"),
    name,
    ...rest
  } = props;

  // Base range slider classes
  const baseClasses =
    "w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "focus:ring-red-500 dark:focus:ring-red-500"
    : "focus:ring-primary-500 dark:focus:ring-primary-500";

  // Combine classes
  const rangeClasses = cn(baseClasses, stateClasses, className);

  // Get reactive value
  const currentValue = () => (isSignal(value) ? (value as any)() : value);

  // Format value for display
  const displayValue = () => {
    const val = currentValue();
    return valueFormat ? valueFormat(val) : String(val);
  };

  // Handle input event
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    if (onChange) {
      onChange(Number(target.value));
    }
  };

  return (
    <div class="flex flex-col gap-1.5">
      {(label || showValue) && (
        <div class="flex items-center justify-between">
          {label && (
            <label
              for={id}
              class="text-sm font-medium text-gray-700 dark:text-gray-300"
            >
              {label}
            </label>
          )}

          {showValue && (
            <span class="text-sm text-gray-600 dark:text-gray-400">
              {displayValue()}
            </span>
          )}
        </div>
      )}

      <input
        type="range"
        id={id}
        name={name}
        class={rangeClasses}
        min={String(min)}
        max={String(max)}
        step={String(step)}
        value={String(currentValue())}
        disabled={disabled}
        onInput={handleInput}
        {...rest}
      />

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
