/**
 * SearchBox Component
 * A search-focused input with autocomplete, grouping, and filtering capabilities
 *
 * @example
 * ```tsx
 * import { SearchBox } from '@odyssee/components';
 *
 * // Basic usage with static options
 * <SearchBox
 *   options={[
 *     { id: 1, name: 'John Doe', category: 'People', status: 'online' },
 *     { id: 2, name: 'Compose email', category: 'Recent', app: 'Gmail' },
 *   ]}
 *   placeholder="Search..."
 *   onSelect={(item) => console.log(item)}
 * />
 *
 * // With grouping
 * <SearchBox
 *   options={searchData}
 *   groupBy="category"
 *   showGroupTitles={true}
 *   placeholder="Search or type a command"
 * />
 *
 * // With API search
 * <SearchBox
 *   apiUrl="https://api.example.com/search"
 *   groupBy="category"
 *   minSearchLength={2}
 *   placeholder="Type to search..."
 * />
 *
 * // Open on focus
 * <SearchBox
 *   options={recentActions}
 *   isOpenOnFocus={true}
 *   placeholder="Search..."
 * />
 *
 * // With custom item rendering
 * <SearchBox
 *   options={users}
 *   renderItem={(item) => (
 *     <div class="flex items-center gap-3">
 *       <img src={item.avatar} class="size-5 rounded-full" />
 *       <span>{item.name}</span>
 *       <span class="text-xs text-gray-400">{item.status}</span>
 *     </div>
 *   )}
 * />
 *
 * // With group title customization
 * <SearchBox
 *   options={data}
 *   groupBy="category"
 *   renderGroupTitle={(title) => (
 *     <div class="text-xs uppercase text-gray-500 m-3 mb-1">
 *       {title}
 *     </div>
 *   )}
 * />
 *
 * // Prevent selection (command palette style)
 * <SearchBox
 *   options={commands}
 *   preventSelection={true}
 *   onSelect={(item) => executeCommand(item.action)}
 * />
 *
 * // With loading state
 * const [loading, setLoading] = Pulse.signal(false);
 * <SearchBox
 *   options={results}
 *   loading={loading}
 *   placeholder="Search..."
 * />
 *
 * // Different sizes
 * <SearchBox options={data} size="sm" />
 * <SearchBox options={data} size="md" />
 * <SearchBox options={data} size="lg" />
 * ```
 */

import Pulse from "pulse-framework";
import type { SearchBoxProps, SearchBoxOption } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const SearchBox: Pulse.Fn<SearchBoxProps> = (props) => {
  const {
    options = [],
    value,
    placeholder = "Search...",
    disabled = false,
    readonly = false,
    required = false,
    label,
    hint,
    error,
    size = "md",
    displayField = "name",
    valueField = "id",
    searchFields = [displayField],
    groupBy,
    showGroupTitles = true,
    minSearchLength = 0,
    isOpenOnFocus = false,
    preventSelection = false,
    preserveSelectionOnEmpty = true,
    maxHeight = "max-h-72",
    apiUrl,
    apiSearchQuery = "search",
    loading: externalLoading,
    onSelect,
    onSearch,
    onFocus,
    onBlur,
    className,
    dropdownClassName,
    id = generateId("searchbox"),
    name,
    renderItem,
    renderGroupTitle,
    ...rest
  } = props;

  // Internal state
  const inputValue = Pulse.signal("");
  const isOpen = Pulse.signal(false);
  const selectedItem = Pulse.signal<SearchBoxOption | null>(null);
  const allOptions = Pulse.signal<SearchBoxOption[]>(options);
  const filteredOptions = Pulse.signal<SearchBoxOption[]>([]);
  const groupedOptions = Pulse.signal<Record<string, SearchBoxOption[]>>({});
  const focusedIndex = Pulse.signal(-1);
  const isLoading = Pulse.signal(false);

  // Get external loading state if provided
  const loading = externalLoading !== undefined
    ? (isSignal(externalLoading) ? externalLoading : Pulse.signal(externalLoading))
    : isLoading;

  // Initialize value
  Pulse.effect(() => {
    const val = isSignal(value) ? (value as any)() : value || "";
    if (val) {
      const item = allOptions().find(
        (opt) => getFieldValue(opt, valueField) === val || getFieldValue(opt, displayField) === val
      );
      if (item) {
        selectedItem(item);
        inputValue(getFieldValue(item, displayField));
      } else {
        inputValue(val);
      }
    }
  });

  // Get nested field value
  const getFieldValue = (obj: any, field: string): string => {
    if (!field || !obj) return "";
    const keys = field.split(".");
    let result = obj;
    for (const key of keys) {
      result = result?.[key];
      if (result === undefined) return "";
    }
    return String(result || "");
  };

  // Group options by field
  const groupOptions = (opts: SearchBoxOption[]) => {
    if (!groupBy) {
      return { "": opts };
    }

    const grouped: Record<string, SearchBoxOption[]> = {};
    opts.forEach((option) => {
      const groupValue = getFieldValue(option, groupBy) || "Other";
      if (!grouped[groupValue]) {
        grouped[groupValue] = [];
      }
      grouped[groupValue].push(option);
    });
    return grouped;
  };

  // Filter and group options
  const filterOptions = (searchTerm: string) => {
    if (minSearchLength > 0 && searchTerm.length < minSearchLength) {
      filteredOptions([]);
      groupedOptions({});
      return;
    }

    const search = searchTerm.toLowerCase();
    const filtered = allOptions().filter((option) => {
      return searchFields.some((field) => {
        const fieldValue = getFieldValue(option, field).toLowerCase();
        return fieldValue.includes(search);
      });
    });

    filteredOptions(filtered);
    groupedOptions(groupOptions(filtered));
    focusedIndex(-1);
  };

  // Fetch from API
  const fetchFromApi = async (searchTerm: string) => {
    if (!apiUrl) return;
    if (minSearchLength > 0 && searchTerm.length < minSearchLength) return;

    (loading as any)(true);
    try {
      const url = searchTerm
        ? `${apiUrl}?${apiSearchQuery}=${encodeURIComponent(searchTerm)}`
        : apiUrl;
      const response = await fetch(url);
      const data = await response.json();
      const results = Array.isArray(data) ? data : [];
      allOptions(results);
      filteredOptions(results);
      groupedOptions(groupOptions(results));
    } catch (err) {
      console.error("SearchBox API fetch error:", err);
      filteredOptions([]);
      groupedOptions({});
    } finally {
      (loading as any)(false);
    }
  };

  // Debounce API calls
  let debounceTimer: any;
  const debounceApiCall = (searchTerm: string, delay = 300) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      fetchFromApi(searchTerm);
    }, delay);
  };

  // Handle input change
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    const val = target.value;
    inputValue(val);

    // Clear selection if not preserving
    if (!preserveSelectionOnEmpty && !val) {
      selectedItem(null);
    }

    if (apiUrl) {
      debounceApiCall(val);
    } else {
      filterOptions(val);
    }

    if (!isOpen()) {
      isOpen(true);
    }

    if (onSearch) {
      onSearch(val);
    }
  };

  // Handle item selection
  const handleSelect = (option: SearchBoxOption) => (e: Event) => {
    e.preventDefault();
    e.stopPropagation();

    if (!preventSelection) {
      selectedItem(option);
      inputValue(getFieldValue(option, displayField));
    }

    isOpen(false);

    if (onSelect) {
      onSelect(option);
    }
    if (isSignal(value) && !preventSelection) {
      (value as any)(getFieldValue(option, valueField));
    }
  };

  // Handle focus
  const handleFocus = (e: Event) => {
    if (onFocus) onFocus(e);

    if (isOpenOnFocus) {
      if (!apiUrl && allOptions().length > 0) {
        filterOptions(inputValue());
        isOpen(true);
      } else if (apiUrl) {
        fetchFromApi(inputValue());
        isOpen(true);
      }
    }
  };

  // Handle blur
  const handleBlur = (e: Event) => {
    setTimeout(() => {
      isOpen(false);
      if (onBlur) onBlur(e);
    }, 200);
  };

  // Handle keyboard navigation
  const handleKeyDown = (e: KeyboardEvent) => {
    const items = filteredOptions();

    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (!isOpen()) {
        isOpen(true);
      } else {
        focusedIndex(Math.min(focusedIndex() + 1, items.length - 1));
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      focusedIndex(Math.max(focusedIndex() - 1, -1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (focusedIndex() >= 0 && items[focusedIndex()]) {
        const option = items[focusedIndex()];
        if (!preventSelection) {
          selectedItem(option);
          inputValue(getFieldValue(option, displayField));
        }
        isOpen(false);
        if (onSelect) onSelect(option);
        if (isSignal(value) && !preventSelection) {
          (value as any)(getFieldValue(option, valueField));
        }
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      isOpen(false);
    }
  };

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs ps-8",
    sm: "px-2.5 py-1.5 text-sm ps-9",
    md: "py-2.5 sm:py-3 ps-10 pe-4 text-sm",
    lg: "px-4 py-2.5 ps-11 text-base",
    xl: "px-5 py-3 ps-12 text-lg",
  };

  // Icon position classes
  const iconSizeClasses = {
    xs: "size-3",
    sm: "size-3.5",
    md: "size-4",
    lg: "size-4.5",
    xl: "size-5",
  };

  const iconPositionClasses = {
    xs: "ps-2",
    sm: "ps-2.5",
    md: "ps-3.5",
    lg: "ps-4",
    xl: "ps-5",
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-lg border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-200 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-700 dark:bg-neutral-900 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Search icon
  const searchIcon = (
    <svg
      class={cn("shrink-0 text-gray-400 dark:text-white/60", iconSizeClasses[size])}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <circle cx="11" cy="11" r="8"></circle>
      <path d="m21 21-4.3-4.3"></path>
    </svg>
  );

  const checkIcon = (
    <svg
      class="shrink-0 size-3.5 text-blue-600 dark:text-blue-500"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M20 6 9 17l-5-5"></path>
    </svg>
  );

  // Check if option is selected
  const isSelected = (option: SearchBoxOption) => {
    const selected = selectedItem();
    if (!selected) return false;
    return getFieldValue(selected, valueField) === getFieldValue(option, valueField);
  };

  // Default item renderer
  const defaultRenderItem = (option: SearchBoxOption) => (
    <div class="flex justify-between items-center w-full">
      <span>{getFieldValue(option, displayField)}</span>
      {!preventSelection && isSelected(option) && <span>{checkIcon}</span>}
    </div>
  );

  // Default group title renderer
  const defaultRenderGroupTitle = (title: string) => (
    <div class="text-xs uppercase text-gray-500 m-3 mb-1 dark:text-neutral-500">
      {title}
    </div>
  );

  // Render grouped items
  const renderGroupedItems = () => {
    const groups = groupedOptions();
    const groupKeys = Object.keys(groups);

    if (groupKeys.length === 0) {
      return null;
    }

    return groupKeys.map((groupKey) => {
      const groupItems = groups[groupKey];
      let currentIndex = 0;

      // Calculate the starting index for this group
      for (const key of groupKeys) {
        if (key === groupKey) break;
        currentIndex += groups[key].length;
      }

      return (
        <div key={groupKey}>
          {showGroupTitles && groupKey && groupKey !== "" && (
            <div>
              {renderGroupTitle ? renderGroupTitle(groupKey) : defaultRenderGroupTitle(groupKey)}
            </div>
          )}
          {groupItems.map((option, idx) => {
            const absoluteIndex = currentIndex + idx;
            return (
              <div
                key={getFieldValue(option, valueField)}
                class={cn(
                  "cursor-pointer py-2 px-4 w-full text-sm text-gray-800 hover:bg-gray-100 rounded-lg focus:outline-none focus:bg-gray-100",
                  "dark:bg-neutral-900 dark:hover:bg-neutral-800 dark:text-neutral-200 dark:focus:bg-neutral-800",
                  focusedIndex() === absoluteIndex && "bg-gray-100 dark:bg-neutral-800",
                  !preventSelection && isSelected(option) && "hs-combo-box-selected",
                )}
                role="option"
                tabindex={absoluteIndex}
                onClick={handleSelect(option)}
                data-hs-combo-box-output-item=""
              >
                {renderItem ? renderItem(option) : defaultRenderItem(option)}
              </div>
            );
          })}
        </div>
      );
    });
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative" data-hs-combo-box="" {...rest}>
        <div class="relative">
          {/* Search icon */}
          <div class={cn("absolute inset-y-0 start-0 flex items-center pointer-events-none z-20", iconPositionClasses[size])}>
            {searchIcon}
          </div>

          <input
            type="text"
            id={id}
            name={name}
            class={inputClasses}
            placeholder={placeholder}
            disabled={disabled}
            readonly={readonly}
            required={required}
            value={inputValue()}
            role="combobox"
            aria-expanded={isOpen()}
            aria-autocomplete="list"
            onInput={handleInput}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            data-hs-combo-box-input=""
          />
        </div>

        {/* Dropdown */}
        <div
          class={cn(
            "absolute z-50 w-full bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden",
            "dark:bg-neutral-800 dark:border-neutral-700 transition-opacity",
            isOpen() ? "block" : "hidden",
            dropdownClassName,
          )}
          role="listbox"
          data-hs-combo-box-output=""
        >
          <div
            class={cn(
              "p-2 overflow-y-auto overflow-hidden",
              "[&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-300",
              "dark:[&::-webkit-scrollbar-track]:bg-neutral-700 dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500",
              maxHeight,
            )}
            data-hs-combo-box-output-items-wrapper=""
          >
            {(loading as any)() ? (
              <div class="py-2 px-4 text-sm text-gray-500 dark:text-neutral-500">
                Loading...
              </div>
            ) : filteredOptions().length === 0 ? (
              <div class="py-2 px-4 text-sm text-gray-500 dark:text-neutral-500">
                {minSearchLength > 0 && inputValue().length < minSearchLength
                  ? `Type at least ${minSearchLength} characters to search`
                  : "No results found"}
              </div>
            ) : (
              renderGroupedItems()
            )}
          </div>
        </div>
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
