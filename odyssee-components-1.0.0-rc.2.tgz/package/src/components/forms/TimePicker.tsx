/**
 * TimePicker Component
 * A time picker with dropdown for easy time selection
 *
 * @example
 * ```tsx
 * import { TimePicker } from '@odyssee/components';
 *
 * // Basic time picker
 * <TimePicker placeholder="Select time" onChange={(time) => console.log(time)} />
 *
 * // 12-hour format
 * <TimePicker format="12h" onChange={(time) => console.log(time)} />
 *
 * // 24-hour format (default)
 * <TimePicker format="24h" onChange={(time) => console.log(time)} />
 *
 * // With reactive value
 * const time = Pulse.signal('14:30');
 * <TimePicker
 *   value={time}
 *   onChange={(val) => time(val)}
 * />
 *
 * // With label and validation
 * <TimePicker
 *   label="Appointment Time"
 *   required={true}
 *   error="Please select a time"
 * />
 *
 * // With minute step
 * <TimePicker
 *   minuteStep={15}
 *   onChange={(time) => console.log(time)}
 * />
 *
 * // Disabled state
 * <TimePicker disabled={true} value="09:00" />
 * ```
 */

import Pulse from "pulse-framework";
import type { TimePickerProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";
import { Radio } from "./Radio";

export const TimePicker: Pulse.Fn<TimePickerProps> = (props) => {
  const {
    value,
    format = "24h",
    label,
    hint,
    error,
    placeholder = format === "12h" ? "hh:mm aa" : "HH:mm",
    disabled = false,
    required = false,
    minuteStep = 1,
    showNowButton = true,
    onChange,
    className,
    id = generateId("timepicker"),
    size = "md",
    ...rest
  } = props;

  // Internal state for selected time
  const selectedHour = Pulse.signal<number | null>(null);
  const selectedMinute = Pulse.signal<number | null>(null);
  const selectedPeriod = Pulse.signal<"AM" | "PM">("AM");

  // Parse initial value
  const parseValue = (val: string) => {
    if (!val) return;

    if (format === "12h") {
      // Parse "hh:mm aa" format
      const match = val.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
      if (match) {
        let hour = parseInt(match[1], 10);
        const minute = parseInt(match[2], 10);
        const period = match[3].toUpperCase() as "AM" | "PM";

        selectedHour(hour);
        selectedMinute(minute);
        selectedPeriod(period);
      }
    } else {
      // Parse "HH:mm" format
      const match = val.match(/^(\d{1,2}):(\d{2})$/);
      if (match) {
        const hour = parseInt(match[1], 10);
        const minute = parseInt(match[2], 10);

        selectedHour(hour);
        selectedMinute(minute);
      }
    }
  };

  // Initialize from value prop
  Pulse.effect(() => {
    const val = isSignal(value) ? (value as any)() : value;
    if (val) {
      parseValue(val);
    }
  });

  // Format time string
  const formatTime = () => {
    const hour = selectedHour();
    const minute = selectedMinute();

    if (hour === null || minute === null) return "";

    const hourStr = hour.toString().padStart(2, "0");
    const minuteStr = minute.toString().padStart(2, "0");

    if (format === "12h") {
      return `${hourStr}:${minuteStr} ${selectedPeriod()}`;
    }

    return `${hourStr}:${minuteStr}`;
  };

  // Get display value
  const displayValue = () => {
    const formatted = formatTime();
    if (formatted) return formatted;

    const val = isSignal(value) ? (value as any)() : value;
    return val || "";
  };

  // Generate hours array
  const generateHours = () => {
    const hours: number[] = [];
    const max = format === "12h" ? 12 : 23;
    const start = format === "12h" ? 1 : 0;

    for (let i = start; i <= max; i++) {
      hours.push(i);
    }

    return hours;
  };

  // Generate minutes array
  const generateMinutes = () => {
    const minutes: number[] = [];
    for (let i = 0; i < 60; i += minuteStep) {
      minutes.push(i);
    }
    return minutes;
  };

  // Handle hour selection
  const handleHourSelect = (hour: number) => {
    selectedHour(hour);
    updateValue();
  };

  // Handle minute selection
  const handleMinuteSelect = (minute: number) => {
    selectedMinute(minute);
    updateValue();
  };

  // Handle period selection
  const handlePeriodSelect = (period: "AM" | "PM") => {
    selectedPeriod(period);
    updateValue();
  };

  // Update value and trigger onChange
  const updateValue = () => {
    const hour = selectedHour();
    const minute = selectedMinute();

    if (hour === null || minute === null) return;

    const formatted = formatTime();

    if (onChange) {
      onChange(formatted);
    }

    if (isSignal(value)) {
      (value as any)(formatted);
    }
  };

  // Handle "Now" button
  const handleNow = () => {
    const now = new Date();
    let hour = now.getHours();
    const minute = Math.floor(now.getMinutes() / minuteStep) * minuteStep;

    if (format === "12h") {
      const period = hour >= 12 ? "PM" : "AM";
      hour = hour % 12 || 12;
      selectedPeriod(period);
    }

    selectedHour(hour);
    selectedMinute(minute);
    updateValue();
  };

  // Handle "OK" button - closes dropdown
  const handleOk = (e: Event) => {
    const dropdown = (e.target as HTMLElement).closest(".hs-dropdown");
    if (dropdown) {
      const trigger = dropdown.querySelector(
        ".hs-dropdown-toggle",
      ) as HTMLElement;
      if (trigger) {
        trigger.click(); // Close dropdown
      }
    }
  };

  // Size classes
  const sizeClasses = {
    xs: "py-1 px-2 text-xs",
    sm: "py-1.5 px-2.5 text-sm",
    md: "py-2.5 sm:py-3 px-4 text-sm",
    lg: "py-2.5 px-4 text-base",
    xl: "py-3 px-5 text-lg",
  };

  // Radio button classes (reusable)
  // Wrapper label for custom styled radio in TimePicker
  const TimePickerRadioItem: Pulse.Fn<{
    name: string;
    value: number;
    checked: boolean;
    onChange: () => void;
  }> = (itemProps) => {
    return (
      <label
        class={cn(
          "group relative flex justify-center items-center p-1.5 w-10 text-center text-sm text-gray-800 cursor-pointer rounded-md",
          "hover:bg-gray-100 hover:text-gray-800",
          "dark:text-neutral-200 dark:hover:bg-neutral-700 dark:hover:text-neutral-200",
          "has-[:checked]:text-white dark:has-[:checked]:text-white",
          "has-[:checked]:bg-blue-600 dark:has-[:checked]:bg-blue-500",
        )}
      >
        <Radio
          name={itemProps.name}
          value={itemProps.value}
          checked={itemProps.checked}
          onChange={itemProps.onChange}
          className="hidden"
        />
        <span class="block">{itemProps.value.toString().padStart(2, "0")}</span>
      </label>
    ) as Pulse.JSX.Element;
  };

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class={cn("hs-dropdown relative inline-flex", className)}>
        <div class="relative w-full">
          <input
            type="text"
            id={id}
            class={cn(
              "w-full ps-4 pe-12 block border-gray-200 rounded-lg focus:border-blue-500 focus:ring-blue-500 disabled:opacity-50 disabled:pointer-events-none",
              "dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-200 dark:placeholder-neutral-400 dark:focus:ring-neutral-600",
              sizeClasses[size],
              error &&
                "border-red-300 text-red-900 focus:border-red-500 focus:ring-red-500",
            )}
            placeholder={placeholder}
            value={displayValue()}
            disabled={disabled}
            required={required}
            readonly
            {...rest}
          />

          <div class="absolute inset-y-0 end-0 flex items-center pe-3">
            <button
              id={`${id}-trigger`}
              type="button"
              class="hs-dropdown-toggle size-7 shrink-0 inline-flex justify-center items-center rounded-full bg-white text-gray-500 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
              aria-haspopup="menu"
              aria-expanded="false"
              aria-label="Select time"
              disabled={disabled}
            >
              <span class="sr-only">Select time</span>
              <svg
                class="shrink-0 size-4"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <polyline points="12 6 12 12 16 14"></polyline>
              </svg>
            </button>
          </div>
        </div>

        <div
          class="hs-dropdown-menu transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden min-w-30 bg-white border border-gray-200 shadow-xl rounded-lg mt-2 dark:bg-neutral-800 dark:border-neutral-700 dark:divide-neutral-700 after:h-4 after:absolute after:-bottom-4 after:start-0 after:w-full before:h-4 before:absolute before:-top-4 before:start-0 before:w-full"
          role="menu"
          aria-orientation="vertical"
          aria-labelledby={`${id}-trigger`}
        >
          <div class="flex flex-row divide-x divide-gray-200 dark:divide-neutral-700">
            {/* Hours */}
            <div class="p-1 max-h-56 overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-white [&::-webkit-scrollbar-thumb]:bg-transparent hover:[&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-800 dark:hover:[&::-webkit-scrollbar-thumb]:bg-neutral-500">
              {generateHours().map((hour) => {
                const isSelected = selectedHour() === hour;
                return (
                  <TimePickerRadioItem
                    name={`${id}-hour`}
                    value={hour}
                    checked={isSelected}
                    onChange={() => handleHourSelect(hour)}
                  />
                );
              })}
            </div>

            {/* Minutes */}
            <div class="p-1 max-h-56 overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-white [&::-webkit-scrollbar-thumb]:bg-transparent hover:[&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-800 dark:hover:[&::-webkit-scrollbar-thumb]:bg-neutral-500">
              {generateMinutes().map((minute) => {
                const isSelected = selectedMinute() === minute;
                return (
                  <TimePickerRadioItem
                    name={`${id}-minute`}
                    value={minute}
                    checked={isSelected}
                    onChange={() => handleMinuteSelect(minute)}
                  />
                );
              })}
            </div>

            {/* AM/PM (12-hour format only) */}
            {format === "12h" && (
              <div class="p-1 max-h-56 overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-white [&::-webkit-scrollbar-thumb]:bg-transparent hover:[&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-800 dark:hover:[&::-webkit-scrollbar-thumb]:bg-neutral-500">
                {["AM", "PM"].map((period) => {
                  const isSelected = selectedPeriod() === period;
                  return (
                    <label
                      class={cn(
                        "group relative flex justify-center items-center p-1.5 w-10 text-center text-sm text-gray-800 cursor-pointer rounded-md",
                        "hover:bg-gray-100 hover:text-gray-800",
                        "dark:text-neutral-200 dark:hover:bg-neutral-700 dark:hover:text-neutral-200",
                        "has-[:checked]:text-white dark:has-[:checked]:text-white",
                        "has-[:checked]:bg-blue-600 dark:has-[:checked]:bg-blue-500",
                      )}
                    >
                      <Radio
                        name={`${id}-period`}
                        value={period}
                        checked={isSelected}
                        onChange={() =>
                          handlePeriodSelect(period as "AM" | "PM")
                        }
                        className="hidden"
                      />
                      <span class="block">{period}</span>
                    </label>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer */}
          <div class="py-2 px-3 flex flex-wrap justify-between items-center gap-2 border-t border-gray-200 dark:border-neutral-700">
            {showNowButton && (
              <button
                type="button"
                class="text-[13px] font-medium rounded-md bg-white text-blue-600 hover:text-blue-700 disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:text-blue-700 dark:bg-neutral-800 dark:text-blue-500 dark:hover:text-blue-600 dark:focus:text-blue-600"
                onClick={handleNow}
              >
                Now
              </button>
            )}
            <button
              type="button"
              class="py-1 px-2.5 text-[13px] font-medium rounded-md bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              onClick={handleOk}
            >
              OK
            </button>
          </div>
        </div>
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
