/**
 * ComboBox Component
 * An autocomplete input with search and filtering capabilities
 *
 * @example
 * ```tsx
 * import { ComboBox } from '@odyssee/components';
 *
 * // Basic usage with static options
 * <ComboBox
 *   options={[
 *     { id: 1, name: 'Argentina' },
 *     { id: 2, name: 'Brazil' },
 *     { id: 3, name: 'China' },
 *   ]}
 *   placeholder="Select a country"
 *   onChange={(item) => console.log(item)}
 * />
 *
 * // With label and default value
 * <ComboBox
 *   label="Country"
 *   options={countries}
 *   value="Argentina"
 *   onChange={(item) => console.log(item)}
 * />
 *
 * // With reactive value
 * const selectedCountry = Pulse.signal('');
 * <ComboBox
 *   label="Country"
 *   options={countries}
 *   value={selectedCountry}
 *   onChange={(item) => selectedCountry(item.name)}
 * />
 *
 * // With custom display fields
 * <ComboBox
 *   options={users}
 *   displayField="email"
 *   valueField="id"
 *   searchFields={['name', 'email']}
 *   placeholder="Search users..."
 * />
 *
 * // With close button
 * <ComboBox
 *   options={countries}
 *   showCloseButton={true}
 *   placeholder="Select a country"
 * />
 *
 * // With minimum search length
 * <ComboBox
 *   options={countries}
 *   minSearchLength={3}
 *   placeholder="Type at least 3 characters"
 * />
 *
 * // Disabled state
 * <ComboBox
 *   options={countries}
 *   disabled={true}
 *   value="France"
 * />
 *
 * // With error state
 * <ComboBox
 *   label="Country"
 *   options={countries}
 *   error="Please select a country"
 *   required={true}
 * />
 *
 * // With API data (async loading)
 * <ComboBox
 *   apiUrl="https://api.example.com/countries"
 *   displayField="name"
 *   valueField="id"
 *   placeholder="Search countries..."
 * />
 *
 * // With custom item template
 * <ComboBox
 *   options={countries}
 *   renderItem={(item) => (
 *     <div class="flex items-center gap-2">
 *       <span>{item.flag}</span>
 *       <span>{item.name}</span>
 *     </div>
 *   )}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { ComboBoxProps, ComboBoxOption } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const ComboBox: Pulse.Fn<ComboBoxProps> = (props) => {
  const {
    options = [],
    value,
    placeholder = "Search...",
    disabled = false,
    readonly = false,
    required = false,
    label,
    hint,
    error,
    size = "md",
    displayField = "name",
    valueField = "id",
    searchFields = [displayField],
    minSearchLength = 0,
    showCloseButton = false,
    maxHeight = "max-h-72",
    apiUrl,
    apiSearchQuery = "search",
    onChange,
    onSearch,
    onFocus,
    onBlur,
    className,
    dropdownClassName,
    id = generateId("combobox"),
    name,
    renderItem,
    ...rest
  } = props;

  // Internal state
  const inputValue = Pulse.signal("");
  const isOpen = Pulse.signal(false);
  const selectedItem = Pulse.signal<ComboBoxOption | null>(null);
  const filteredOptions = Pulse.signal<ComboBoxOption[]>([]);
  const allOptions = Pulse.signal<ComboBoxOption[]>(options);
  const focusedIndex = Pulse.signal(-1);
  const isLoading = Pulse.signal(false);

  // Initialize value
  Pulse.effect(() => {
    const val = isSignal(value) ? (value as any)() : value || "";
    if (val) {
      const item = allOptions().find(
        (opt) => getFieldValue(opt, valueField) === val || getFieldValue(opt, displayField) === val
      );
      if (item) {
        selectedItem(item);
        inputValue(getFieldValue(item, displayField));
      } else {
        inputValue(val);
      }
    }
  });

  // Get nested field value
  const getFieldValue = (obj: any, field: string): string => {
    if (!field || !obj) return "";
    const keys = field.split(".");
    let result = obj;
    for (const key of keys) {
      result = result?.[key];
      if (result === undefined) return "";
    }
    return String(result || "");
  };

  // Filter options based on search
  const filterOptions = (searchTerm: string) => {
    if (minSearchLength > 0 && searchTerm.length < minSearchLength) {
      filteredOptions([]);
      return;
    }

    const search = searchTerm.toLowerCase();
    const filtered = allOptions().filter((option) => {
      return searchFields.some((field) => {
        const fieldValue = getFieldValue(option, field).toLowerCase();
        return fieldValue.includes(search);
      });
    });
    filteredOptions(filtered);
    focusedIndex(-1);
  };

  // Fetch from API
  const fetchFromApi = async (searchTerm: string) => {
    if (!apiUrl) return;
    if (minSearchLength > 0 && searchTerm.length < minSearchLength) return;

    isLoading(true);
    try {
      const url = searchTerm
        ? `${apiUrl}?${apiSearchQuery}=${encodeURIComponent(searchTerm)}`
        : apiUrl;
      const response = await fetch(url);
      const data = await response.json();
      allOptions(Array.isArray(data) ? data : []);
      filteredOptions(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("ComboBox API fetch error:", err);
      filteredOptions([]);
    } finally {
      isLoading(false);
    }
  };

  // Debounce API calls
  let debounceTimer: any;
  const debounceApiCall = (searchTerm: string, delay = 300) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      fetchFromApi(searchTerm);
    }, delay);
  };

  // Handle input change
  const handleInput = (e: Event) => {
    const target = e.target as HTMLInputElement;
    const val = target.value;
    inputValue(val);

    if (apiUrl) {
      debounceApiCall(val);
    } else {
      filterOptions(val);
    }

    if (!isOpen()) {
      isOpen(true);
    }

    if (onSearch) {
      onSearch(val);
    }
  };

  // Handle item selection
  const handleSelect = (option: ComboBoxOption) => (e: Event) => {
    e.preventDefault();
    e.stopPropagation();

    selectedItem(option);
    inputValue(getFieldValue(option, displayField));
    isOpen(false);

    if (onChange) {
      onChange(option);
    }
    if (isSignal(value)) {
      (value as any)(getFieldValue(option, valueField));
    }
  };

  // Handle toggle
  const handleToggle = (e: Event) => {
    e.preventDefault();
    if (disabled) return;

    if (!isOpen()) {
      if (!apiUrl) {
        filterOptions(inputValue());
      } else if (inputValue().length >= minSearchLength) {
        fetchFromApi(inputValue());
      }
    }
    isOpen(!isOpen());
  };

  // Handle close/clear
  const handleClose = (e: Event) => {
    e.preventDefault();
    e.stopPropagation();
    inputValue("");
    selectedItem(null);
    filteredOptions([]);
    isOpen(false);

    if (onChange) {
      onChange(null);
    }
    if (isSignal(value)) {
      (value as any)("");
    }
  };

  // Handle focus
  const handleFocus = (e: Event) => {
    if (onFocus) onFocus(e);
    if (!apiUrl && allOptions().length > 0) {
      filterOptions(inputValue());
      isOpen(true);
    }
  };

  // Handle blur
  const handleBlur = (e: Event) => {
    setTimeout(() => {
      isOpen(false);
      if (onBlur) onBlur(e);
    }, 200);
  };

  // Handle keyboard navigation
  const handleKeyDown = (e: KeyboardEvent) => {
    const items = filteredOptions();

    if (e.key === "ArrowDown") {
      e.preventDefault();
      if (!isOpen()) {
        isOpen(true);
      } else {
        focusedIndex(Math.min(focusedIndex() + 1, items.length - 1));
      }
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      focusedIndex(Math.max(focusedIndex() - 1, -1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (focusedIndex() >= 0 && items[focusedIndex()]) {
        const option = items[focusedIndex()];
        selectedItem(option);
        inputValue(getFieldValue(option, displayField));
        isOpen(false);
        if (onChange) onChange(option);
        if (isSignal(value)) (value as any)(getFieldValue(option, valueField));
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      isOpen(false);
    }
  };

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs",
    sm: "px-2.5 py-1.5 text-sm",
    md: "py-2.5 sm:py-3 ps-4 pe-9 text-sm",
    lg: "px-4 py-2.5 text-base",
    xl: "px-5 py-3 text-lg",
  };

  // Base input classes
  const baseClasses =
    "w-full rounded-lg border transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-0 disabled:opacity-50 disabled:cursor-not-allowed";

  // State classes
  const stateClasses = error
    ? "border-red-300 text-red-900 placeholder-red-300 focus:border-red-500 focus:ring-red-500 dark:border-red-600 dark:text-red-400"
    : "border-gray-200 text-gray-900 placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500 dark:border-gray-700 dark:bg-neutral-900 dark:text-neutral-400 dark:placeholder-neutral-500 dark:focus:ring-neutral-600";

  // Combine classes
  const inputClasses = cn(
    baseClasses,
    sizeClasses[size],
    stateClasses,
    className,
  );

  // Icons
  const toggleIcon = (
    <svg
      class="shrink-0 size-3.5 text-gray-500 dark:text-neutral-500"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m7 15 5 5 5-5"></path>
      <path d="m7 9 5-5 5 5"></path>
    </svg>
  );

  const closeIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <circle cx="12" cy="12" r="10"></circle>
      <path d="m15 9-6 6"></path>
      <path d="m9 9 6 6"></path>
    </svg>
  );

  const checkIcon = (
    <svg
      class="shrink-0 size-3.5 text-blue-600 dark:text-blue-500"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M20 6 9 17l-5-5"></path>
    </svg>
  );

  // Check if option is selected
  const isSelected = (option: ComboBoxOption) => {
    const selected = selectedItem();
    if (!selected) return false;
    return getFieldValue(selected, valueField) === getFieldValue(option, valueField);
  };

  // Default item renderer
  const defaultRenderItem = (option: ComboBoxOption) => (
    <div class="flex justify-between items-center w-full">
      <span>{getFieldValue(option, displayField)}</span>
      {isSelected(option) && <span>{checkIcon}</span>}
    </div>
  );

  return (
    <div class="flex flex-col gap-1.5">
      {label && (
        <label
          for={id}
          class="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          {label}
          {required && <span class="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div class="relative" data-hs-combo-box="" {...rest}>
        <div class="relative">
          <input
            type="text"
            id={id}
            name={name}
            class={inputClasses}
            placeholder={placeholder}
            disabled={disabled}
            readonly={readonly}
            required={required}
            value={inputValue()}
            role="combobox"
            aria-expanded={isOpen()}
            aria-autocomplete="list"
            onInput={handleInput}
            onFocus={handleFocus}
            onBlur={handleBlur}
            onKeyDown={handleKeyDown}
            data-hs-combo-box-input=""
          />

          {/* Close button */}
          {showCloseButton && inputValue() && (
            <div class="absolute inset-y-0 end-8 flex items-center z-20">
              <button
                type="button"
                class="inline-flex shrink-0 justify-center items-center size-6 rounded-full text-gray-500 hover:text-blue-600 focus:outline-none focus:text-blue-600 dark:text-neutral-500 dark:hover:text-blue-500 dark:focus:text-blue-500"
                onClick={handleClose}
                aria-label="Close"
                data-hs-combo-box-close=""
              >
                <span class="sr-only">Close</span>
                {closeIcon}
              </button>
            </div>
          )}

          {/* Toggle button */}
          <div
            class="absolute top-1/2 end-3 -translate-y-1/2 cursor-pointer"
            aria-expanded={isOpen()}
            role="button"
            onClick={handleToggle}
            data-hs-combo-box-toggle=""
          >
            {toggleIcon}
          </div>
        </div>

        {/* Dropdown */}
        <div
          class={cn(
            "absolute z-50 w-full p-1 bg-white border border-gray-200 rounded-lg overflow-hidden overflow-y-auto",
            "[&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-300",
            "dark:[&::-webkit-scrollbar-track]:bg-neutral-700 dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500",
            "dark:bg-neutral-900 dark:border-neutral-700 transition-opacity",
            maxHeight,
            isOpen() ? "block" : "hidden",
            dropdownClassName,
          )}
          role="listbox"
          data-hs-combo-box-output=""
        >
          {isLoading() ? (
            <div class="py-2 px-4 text-sm text-gray-500 dark:text-neutral-500">
              Loading...
            </div>
          ) : filteredOptions().length === 0 ? (
            <div class="py-2 px-4 text-sm text-gray-500 dark:text-neutral-500">
              {minSearchLength > 0 && inputValue().length < minSearchLength
                ? `Type at least ${minSearchLength} characters to search`
                : "No results found"}
            </div>
          ) : (
            filteredOptions().map((option, index) => (
              <div
                key={getFieldValue(option, valueField)}
                class={cn(
                  "cursor-pointer py-2 px-4 w-full text-sm text-gray-800 hover:bg-gray-100 rounded-lg focus:outline-none focus:bg-gray-100",
                  "dark:bg-neutral-900 dark:hover:bg-neutral-800 dark:text-neutral-200 dark:focus:bg-neutral-800",
                  focusedIndex() === index && "bg-gray-100 dark:bg-neutral-800",
                  isSelected(option) && "hs-combo-box-selected",
                )}
                role="option"
                tabindex={index}
                onClick={handleSelect(option)}
                data-hs-combo-box-output-item=""
              >
                {renderItem ? renderItem(option) : defaultRenderItem(option)}
              </div>
            ))
          )}
        </div>
      </div>

      {hint && !error && (
        <p class="text-xs text-gray-500 dark:text-gray-400">{hint}</p>
      )}

      {error && <p class="text-xs text-red-600 dark:text-red-400">{error}</p>}
    </div>
  ) as Pulse.JSX.Element;
};
