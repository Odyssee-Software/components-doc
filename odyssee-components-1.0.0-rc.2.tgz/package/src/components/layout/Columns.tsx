/**
 * Columns Component
 * A CSS multi-column layout component for flowing content into multiple columns (magazine/newspaper style)
 *
 * @example
 * ```tsx
 * import { Columns } from '@odyssee/components';
 *
 * // 3 columns layout
 * <Columns count={3}>
 *   <img src="..." />
 *   <img src="..." />
 *   <img src="..." />
 * </Columns>
 *
 * // Columns with specific width
 * <Columns width="xs">
 *   <p>Content flows naturally into columns...</p>
 * </Columns>
 *
 * // With gap between columns
 * <Columns count={3} gap={8}>
 *   <img src="..." />
 *   <img src="..." />
 * </Columns>
 *
 * // Responsive columns
 * <Columns count={{ base: 1, md: 2, lg: 3 }}>
 *   <div>Content...</div>
 * </Columns>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Responsive column count
 */
export interface ResponsiveColumns {
  base?: number;
  sm?: number;
  md?: number;
  lg?: number;
  xl?: number;
  "2xl"?: number;
}

/**
 * Columns props
 */
export interface ColumnsProps extends BaseComponentProps {
  /** Content to render inside columns */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Number of columns (can be responsive) */
  count?: number | ResponsiveColumns;

  /** Column width (t-shirt sizes) */
  width?:
    | "3xs"
    | "2xs"
    | "xs"
    | "sm"
    | "md"
    | "lg"
    | "xl"
    | "2xl"
    | "3xl"
    | "4xl"
    | "5xl"
    | "6xl"
    | "7xl";

  /** Gap between columns */
  gap?: number | string;

  /** Column rule (divider line between columns) */
  rule?: boolean;
  ruleWidth?: "thin" | "medium" | "thick" | number;
  ruleColor?: string;
  ruleStyle?: "solid" | "dashed" | "dotted" | "double";

  /** Auto-fill columns */
  auto?: boolean;
}

/**
 * Get responsive column count classes
 */
function getColumnCountClasses(
  count: number | ResponsiveColumns | undefined,
): string {
  if (!count) return "";

  if (typeof count === "number") {
    return `columns-${count}`;
  }

  const classes: string[] = [];
  if (count.base) classes.push(`columns-${count.base}`);
  if (count.sm) classes.push(`sm:columns-${count.sm}`);
  if (count.md) classes.push(`md:columns-${count.md}`);
  if (count.lg) classes.push(`lg:columns-${count.lg}`);
  if (count.xl) classes.push(`xl:columns-${count.xl}`);
  if (count["2xl"]) classes.push(`2xl:columns-${count["2xl"]}`);

  return classes.join(" ");
}

/**
 * Get column width class
 */
function getColumnWidthClass(width: string | undefined): string {
  if (!width) return "";
  return `columns-${width}`;
}

/**
 * Get gap class
 */
function getGapClass(gap: number | string | undefined): string {
  if (!gap) return "";

  if (typeof gap === "number") {
    return `gap-x-${gap}`;
  }

  return `gap-x-[${gap}]`;
}

/**
 * Columns Component
 * Uses CSS multi-column layout for magazine/newspaper style layouts
 *
 * @example
 * ```tsx
 * <Columns count={3} gap={8}>
 *   <img src="image1.jpg" />
 *   <img src="image2.jpg" />
 *   <img src="image3.jpg" />
 * </Columns>
 * ```
 */
export const Columns: Pulse.Fn<ColumnsProps> = (props) => {
  const {
    children,
    count,
    width,
    gap,
    rule = false,
    ruleWidth,
    ruleColor,
    ruleStyle = "solid",
    auto = false,
    className,
    id = generateId("columns"),
    style,
    ...rest
  } = props;

  // Build column rule style
  const columnRuleStyle = rule
    ? `column-rule: ${ruleWidth || "1px"} ${ruleStyle} ${ruleColor || "currentColor"}; ${style || ""}`
    : style;

  // Columns classes
  const columnsClasses = cn(
    // Column count or width
    count ? getColumnCountClasses(count) : undefined,
    width ? getColumnWidthClass(width) : undefined,
    auto && "columns-auto",

    // Gap
    gap ? getGapClass(gap) : undefined,

    className,
  );

  return (
    <div id={id} class={columnsClasses} style={columnRuleStyle} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * ColumnBreak - Force a column break
 *
 * @example
 * ```tsx
 * <Columns count={2}>
 *   <p>First column content...</p>
 *   <ColumnBreak />
 *   <p>Second column content...</p>
 * </Columns>
 * ```
 */
export const ColumnBreak: Pulse.Fn<BaseComponentProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <div class={cn("break-after-column", className)} {...rest} />
  ) as Pulse.JSX.Element;
};

/**
 * ColumnSpan - Make an element span across all columns
 *
 * @example
 * ```tsx
 * <Columns count={3}>
 *   <ColumnSpan>
 *     <h2>This heading spans all columns</h2>
 *   </ColumnSpan>
 *   <p>Column content...</p>
 * </Columns>
 * ```
 */
export interface ColumnSpanProps extends BaseComponentProps {
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;
  span?: "all" | number;
}

export const ColumnSpan: Pulse.Fn<ColumnSpanProps> = (props) => {
  const { children, span = "all", className, ...rest } = props;

  const spanClass = span === "all" ? "col-span-full" : `col-span-${span}`;

  return (
    <div class={cn(spanClass, className)} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * TwoColumns - Quick 2-column layout
 */
export const TwoColumns: Pulse.Fn<ColumnsProps> = (props) => {
  return <Columns {...props} count={2} />;
};

/**
 * ThreeColumns - Quick 3-column layout
 */
export const ThreeColumns: Pulse.Fn<ColumnsProps> = (props) => {
  return <Columns {...props} count={3} />;
};

/**
 * FourColumns - Quick 4-column layout
 */
export const FourColumns: Pulse.Fn<ColumnsProps> = (props) => {
  return <Columns {...props} count={4} />;
};

/**
 * ResponsiveColumns - Responsive column layout
 * 1 column on mobile, 2 on tablet, 3 on desktop
 */
export const ResponsiveColumns: Pulse.Fn<ColumnsProps> = (props) => {
  return (
    <Columns {...props} count={{ base: 1, md: 2, lg: 3 }} />
  ) as Pulse.JSX.Element;
};

export default Columns;
