/**
 * Typography Components
 * A collection of text and typography components with semantic HTML and consistent styling
 *
 * @example
 * ```tsx
 * import { H1, H2, Text, Lead, Muted, GradientText } from '@odyssee/components';
 *
 * // Headings
 * <H1>Main heading</H1>
 * <H2>Secondary heading</H2>
 *
 * // Text variants
 * <Text>Regular text</Text>
 * <Lead>Lead paragraph text</Lead>
 * <Muted>Muted secondary text</Muted>
 *
 * // Gradient text
 * <GradientText from="blue-500" to="violet-500">
 *   Gradient text
 * </GradientText>
 *
 * // Inline elements
 * <Text>You can use <Mark>highlight</Mark> text</Text>
 * <Text><Strong>Bold text</Strong> and <Em>italic text</Em></Text>
 * ```
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Common text props
 */
export interface TextProps extends BaseComponentProps {
  /** Content to render */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Text alignment */
  align?: "left" | "center" | "right" | "justify";

  /** Text color */
  color?: string;

  /** Font weight */
  weight?:
    | "thin"
    | "light"
    | "normal"
    | "medium"
    | "semibold"
    | "bold"
    | "extrabold"
    | "black";

  /** Font size */
  size?:
    | "xs"
    | "sm"
    | "base"
    | "lg"
    | "xl"
    | "2xl"
    | "3xl"
    | "4xl"
    | "5xl"
    | "6xl"
    | "7xl"
    | "8xl"
    | "9xl";

  /** Truncate text with ellipsis */
  truncate?: boolean;

  /** Make text uppercase */
  uppercase?: boolean;

  /** Make text lowercase */
  lowercase?: boolean;

  /** Capitalize first letter */
  capitalize?: boolean;

  /** Line clamp (max lines before truncating) */
  lineClamp?: number;

  /** Element tag to render */
  as?: keyof HTMLElementTagNameMap;
}

/**
 * Heading props
 */
export interface HeadingProps extends Omit<TextProps, "size" | "as"> {
  /** Heading level */
  level?: 1 | 2 | 3 | 4 | 5 | 6;
}

/**
 * H1 Component - Main heading
 */
export const H1: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const {
    children,
    align,
    color,
    weight = "bold",
    truncate = false,
    uppercase = false,
    lowercase = false,
    capitalize = false,
    lineClamp,
    className,
    id,
    style,
    ...rest
  } = props;

  const weightClasses: Record<string, string> = {
    thin: "font-thin",
    light: "font-light",
    normal: "font-normal",
    medium: "font-medium",
    semibold: "font-semibold",
    bold: "font-bold",
    extrabold: "font-extrabold",
    black: "font-black",
  };

  const alignClasses: Record<string, string> = {
    left: "text-left",
    center: "text-center",
    right: "text-right",
    justify: "text-justify",
  };

  const classes = cn(
    "text-4xl",
    color || "dark:text-white",
    weight ? weightClasses[weight] : undefined,
    align ? alignClasses[align] : undefined,
    truncate && "truncate",
    uppercase && "uppercase",
    lowercase && "lowercase",
    capitalize && "capitalize",
    lineClamp ? `line-clamp-${lineClamp}` : undefined,
    className,
  );

  return (
    <h1 id={id} class={classes} style={style} {...rest}>
      {children}
    </h1>
  ) as Pulse.JSX.Element;
};

/**
 * H2 Component - Secondary heading
 */
export const H2: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const { className, weight = "bold", ...rest } = props;

  return (
    <Text {...rest} as="h2" size="3xl" weight={weight} className={className} />
  ) as Pulse.JSX.Element;
};

/**
 * H3 Component - Tertiary heading
 */
export const H3: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const { className, weight = "semibold", ...rest } = props;

  return (
    <Text {...rest} as="h3" size="2xl" weight={weight} className={className} />
  ) as Pulse.JSX.Element;
};

/**
 * H4 Component
 */
export const H4: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const { className, weight = "semibold", ...rest } = props;

  return (
    <Text {...rest} as="h4" size="xl" weight={weight} className={className} />
  ) as Pulse.JSX.Element;
};

/**
 * H5 Component
 */
export const H5: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const { className, weight = "medium", ...rest } = props;

  return (
    <Text {...rest} as="h5" size="lg" weight={weight} className={className} />
  ) as Pulse.JSX.Element;
};

/**
 * H6 Component
 */
export const H6: Pulse.Fn<Omit<HeadingProps, "level">> = (props) => {
  const { className, weight = "medium", ...rest } = props;

  return (
    <Text {...rest} as="h6" size="base" weight={weight} className={className} />
  ) as Pulse.JSX.Element;
};

/**
 * Text Component - Generic text element
 */
export const Text: Pulse.Fn<TextProps> = (props) => {
  const {
    children,
    align,
    color,
    weight,
    size = "base",
    truncate = false,
    uppercase = false,
    lowercase = false,
    capitalize = false,
    lineClamp,
    as = "p",
    className,
    id,
    style,
    ...rest
  } = props;

  const sizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    base: "text-base",
    lg: "text-lg",
    xl: "text-xl",
    "2xl": "text-2xl",
    "3xl": "text-3xl",
    "4xl": "text-4xl",
    "5xl": "text-5xl",
    "6xl": "text-6xl",
    "7xl": "text-7xl",
    "8xl": "text-8xl",
    "9xl": "text-9xl",
  };

  const weightClasses = {
    thin: "font-thin",
    light: "font-light",
    normal: "font-normal",
    medium: "font-medium",
    semibold: "font-semibold",
    bold: "font-bold",
    extrabold: "font-extrabold",
    black: "font-black",
  };

  const alignClasses = {
    left: "text-left",
    center: "text-center",
    right: "text-right",
    justify: "text-justify",
  };

  const classes = cn(
    sizeClasses[size],
    color || "dark:text-white",
    weight ? weightClasses[weight] : undefined,
    align ? alignClasses[align] : undefined,
    truncate && "truncate",
    uppercase && "uppercase",
    lowercase && "lowercase",
    capitalize && "capitalize",
    lineClamp ? `line-clamp-${lineClamp}` : undefined,
    className,
  );

  const Tag = as;

  return (
    <Tag id={id} class={classes} style={style} {...rest}>
      {children}
    </Tag>
  ) as Pulse.JSX.Element;
};

/**
 * Lead - Large lead paragraph
 */
export const Lead: Pulse.Fn<TextProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <Text
      {...rest}
      size="xl"
      className={cn("text-gray-600 dark:text-neutral-400", className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * Muted - Secondary/muted text
 */
export const Muted: Pulse.Fn<TextProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <Text
      {...rest}
      size="sm"
      className={cn("text-gray-500 dark:text-neutral-400", className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * Small - Fine print text
 */
export const Small: Pulse.Fn<TextProps> = (props) => {
  const { className, as = "small", ...rest } = props;

  return (
    <Text
      {...rest}
      as={as}
      size="xs"
      className={cn("text-gray-600 dark:text-neutral-400", className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * Strong - Bold text
 */
export const Strong: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <strong id={id} class={cn("font-bold", className)} {...rest}>
      {children}
    </strong>
  ) as Pulse.JSX.Element;
};

/**
 * Em - Emphasized/italic text
 */
export const Em: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <em id={id} class={cn("italic", className)} {...rest}>
      {children}
    </em>
  ) as Pulse.JSX.Element;
};

/**
 * Mark - Highlighted text
 */
export const Mark: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <mark
      id={id}
      class={cn("bg-yellow-200 dark:bg-yellow-800", className)}
      {...rest}
    >
      {children}
    </mark>
  ) as Pulse.JSX.Element;
};

/**
 * Del - Deleted text
 */
export const Del: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <del id={id} class={cn("line-through", className)} {...rest}>
      {children}
    </del>
  ) as Pulse.JSX.Element;
};

/**
 * Ins - Inserted text
 */
export const Ins: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <ins id={id} class={cn("underline", className)} {...rest}>
      {children}
    </ins>
  ) as Pulse.JSX.Element;
};

/**
 * Underline - Underlined text
 */
export const Underline: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <u id={id} class={cn("underline", className)} {...rest}>
      {children}
    </u>
  ) as Pulse.JSX.Element;
};

/**
 * Strikethrough - Text with strikethrough
 */
export const Strikethrough: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <s id={id} class={cn("line-through", className)} {...rest}>
      {children}
    </s>
  ) as Pulse.JSX.Element;
};

/**
 * Code - Inline code
 */
export const Code: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, ...rest } = props;

  return (
    <code
      id={id}
      class={cn(
        "px-1.5 py-0.5 text-sm font-mono bg-gray-100 text-gray-800 rounded",
        "dark:bg-neutral-800 dark:text-neutral-200",
        className,
      )}
      {...rest}
    >
      {children}
    </code>
  ) as Pulse.JSX.Element;
};

/**
 * Pre - Preformatted text block
 */
export const Pre: Pulse.Fn<BaseComponentProps> = (props) => {
  const { children, className, id, style, ...rest } = props;

  return (
    <pre
      id={id}
      class={cn(
        "p-4 overflow-x-auto text-sm font-mono bg-gray-50 rounded-lg",
        "dark:bg-neutral-900",
        className,
      )}
      style={style}
      {...rest}
    >
      {children}
    </pre>
  ) as Pulse.JSX.Element;
};

/**
 * GradientText - Text with gradient overlay
 */
export interface GradientTextProps extends Omit<TextProps, "color"> {
  /** Gradient start color */
  from: string;
  /** Gradient end color */
  to: string;
  /** Gradient via color (optional middle) */
  via?: string;
  /** Gradient direction */
  direction?: "tl" | "tr" | "br" | "bl" | "t" | "r" | "b" | "l";
}

export const GradientText: Pulse.Fn<GradientTextProps> = (props) => {
  const {
    children,
    from,
    to,
    via,
    direction = "tl",
    className,
    ...rest
  } = props;

  const gradientClass = via
    ? `bg-gradient-to-${direction} from-${from} via-${via} to-${to}`
    : `bg-gradient-to-${direction} from-${from} to-${to}`;

  return (
    <Text
      {...rest}
      className={cn("bg-clip-text text-transparent", gradientClass, className)}
    >
      {children}
    </Text>
  ) as Pulse.JSX.Element;
};

/**
 * DescriptionList - Semantic description list
 */
export interface DescriptionListProps extends BaseComponentProps {
  /** List items */
  items: Array<{
    term: string | Pulse.JSX.Element;
    description: string | Pulse.JSX.Element;
  }>;

  /** Layout orientation */
  orientation?: "vertical" | "horizontal";

  /** Truncate terms */
  truncateTerms?: boolean;
}

export const DescriptionList: Pulse.Fn<DescriptionListProps> = (props) => {
  const {
    items = [],
    orientation = "horizontal",
    truncateTerms = false,
    className,
    id,
    ...rest
  } = props;

  const isHorizontal = orientation === "horizontal";

  return (
    <dl
      id={id}
      class={cn(
        isHorizontal && "grid sm:grid-cols-3 gap-1 sm:gap-3",
        className,
      )}
      {...rest}
    >
      {items.map((item, index) => (
        <>
          <dt
            class={cn(
              "font-semibold dark:text-white",
              isHorizontal && "sm:col-span-1",
              truncateTerms && "truncate",
            )}
            key={`term-${index}`}
          >
            {item.term}
          </dt>
          <dd
            class={cn(
              "mb-3 sm:mb-0 dark:text-white",
              isHorizontal && "sm:col-span-2",
            )}
            key={`desc-${index}`}
          >
            {item.description}
          </dd>
        </>
      ))}
    </dl>
  ) as Pulse.JSX.Element;
};

/**
 * Blockquote Component
 */
export interface BlockquoteProps extends BaseComponentProps {
  /** Quote content */
  children?: Pulse.JSX.Element | string;

  /** Citation/author */
  cite?: string;

  /** Variant style */
  variant?: "default" | "bordered" | "accent";
}

export const Blockquote: Pulse.Fn<BlockquoteProps> = (props) => {
  const { children, cite, variant = "default", className, id, ...rest } = props;

  const variantClasses = {
    default:
      "border-l-4 border-gray-300 pl-4 italic text-gray-700 dark:border-gray-600 dark:text-gray-300",
    bordered: "border-2 border-gray-200 p-4 rounded-lg dark:border-gray-700",
    accent:
      "border-l-4 border-blue-500 bg-blue-50 p-4 dark:bg-blue-900/10 dark:border-blue-400",
  };

  return (
    <blockquote
      id={id}
      class={cn(variantClasses[variant], className)}
      {...rest}
    >
      <p class="dark:text-white">{children}</p>
      {cite && (
        <footer class="mt-2 text-sm text-gray-600 dark:text-gray-400">
          — <cite>{cite}</cite>
        </footer>
      )}
    </blockquote>
  ) as Pulse.JSX.Element;
};

export default Text;
