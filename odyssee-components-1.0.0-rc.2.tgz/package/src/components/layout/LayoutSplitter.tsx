/**
 * LayoutSplitter Component
 * A resizable split pane layout component with drag handles
 *
 * @example
 * ```tsx
 * import { LayoutSplitter, SplitterPanel, SplitterHandle } from '@odyssee/components';
 *
 * // Horizontal splitter
 * <LayoutSplitter direction="horizontal">
 *   <SplitterPanel size={50}>Left panel</SplitterPanel>
 *   <SplitterPanel size={50}>Right panel</SplitterPanel>
 * </LayoutSplitter>
 *
 * // Vertical splitter
 * <LayoutSplitter direction="vertical">
 *   <SplitterPanel size={30}>Top panel</SplitterPanel>
 *   <SplitterPanel size={70}>Bottom panel</SplitterPanel>
 * </LayoutSplitter>
 *
 * // With min/max constraints
 * <LayoutSplitter direction="horizontal">
 *   <SplitterPanel size={40} minSize={20} maxSize={60}>
 *     Left with constraints
 *   </SplitterPanel>
 *   <SplitterPanel size={60}>Right panel</SplitterPanel>
 * </LayoutSplitter>
 *
 * // Nested splitters
 * <LayoutSplitter direction="vertical">
 *   <SplitterPanel size={30}>Top</SplitterPanel>
 *   <SplitterPanel size={50}>
 *     <LayoutSplitter direction="horizontal">
 *       <SplitterPanel size={50}>Left</SplitterPanel>
 *       <SplitterPanel size={50}>Right</SplitterPanel>
 *     </LayoutSplitter>
 *   </SplitterPanel>
 *   <SplitterPanel size={20}>Bottom</SplitterPanel>
 * </LayoutSplitter>
 *
 * // Manual handle placement
 * <LayoutSplitter direction="horizontal" manualHandles>
 *   <SplitterPanel size={50}>Left</SplitterPanel>
 *   <SplitterHandle />
 *   <SplitterPanel size={50}>Right</SplitterPanel>
 * </LayoutSplitter>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps, Signal } from "../../types";

/**
 * Splitter panel item configuration
 */
export interface SplitterPanelConfig {
  /** Initial size (percentage or flex value) */
  size: number;
  /** Minimum size (percentage) */
  minSize?: number;
  /** Maximum size (percentage) */
  maxSize?: number;
}

/**
 * LayoutSplitter props
 */
export interface LayoutSplitterProps extends BaseComponentProps {
  /** Content (SplitterPanel components) */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[];

  /** Split direction */
  direction?: "horizontal" | "vertical";

  /** Custom handle template */
  handleTemplate?: Pulse.JSX.Element | string;

  /** Custom handle classes */
  handleClasses?: string;

  /** Manual handle placement */
  manualHandles?: boolean;

  /** Callback when sizes change */
  onResize?: (sizes: number[]) => void;

  /** Enable/disable resizing */
  disabled?: boolean;
}

/**
 * SplitterPanel props
 */
export interface SplitterPanelProps extends BaseComponentProps {
  /** Content to render inside panel */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Initial size (percentage 0-100) */
  size: number | Signal<number>;

  /** Minimum size (percentage) */
  minSize?: number;

  /** Maximum size (percentage) */
  maxSize?: number;

  /** Custom class when min limit reached */
  limitReachedClass?: string;
}

/**
 * SplitterHandle props
 */
export interface SplitterHandleProps extends BaseComponentProps {
  /** Handle direction (inherited from parent if not specified) */
  direction?: "horizontal" | "vertical";

  /** Custom handle content */
  children?: Pulse.JSX.Element | string;
}

/**
 * Default horizontal handle icon
 */
const HorizontalHandleIcon: Pulse.Fn = () => (
  <svg
    class="shrink-0 size-3.5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <circle cx="9" cy="12" r="1" />
    <circle cx="9" cy="5" r="1" />
    <circle cx="9" cy="19" r="1" />
    <circle cx="15" cy="12" r="1" />
    <circle cx="15" cy="5" r="1" />
    <circle cx="15" cy="19" r="1" />
  </svg>
);

/**
 * Default vertical handle icon
 */
const VerticalHandleIcon: Pulse.Fn = () => (
  <svg
    class="shrink-0 size-3.5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <circle cx="12" cy="9" r="1" />
    <circle cx="19" cy="9" r="1" />
    <circle cx="5" cy="9" r="1" />
    <circle cx="12" cy="15" r="1" />
    <circle cx="19" cy="15" r="1" />
    <circle cx="5" cy="15" r="1" />
  </svg>
);

/**
 * SplitterHandle Component
 */
export const SplitterHandle: Pulse.Fn<SplitterHandleProps> = (props) => {
  const { direction = "horizontal", children, className, id, ...rest } = props;

  const isHorizontal = direction === "horizontal";

  const handleClasses = cn(
    "hs-layout-splitter-control relative flex",
    isHorizontal
      ? "border-s border-gray-200 dark:border-neutral-700"
      : "border-t border-gray-200 dark:border-neutral-700",
    className,
  );

  const buttonClasses = cn(
    "absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 flex justify-center items-center",
    "bg-white border border-gray-200 text-gray-400 rounded-md",
    "hover:bg-gray-100 dark:bg-neutral-800 dark:border-neutral-700",
    "dark:text-neutral-600 dark:hover:bg-neutral-900",
    isHorizontal ? "w-4 h-6 cursor-col-resize" : "w-6 h-4 cursor-row-resize",
  );

  return (
    <div class={handleClasses} data-hs-layout-splitter-handle="" {...rest}>
      <span class={buttonClasses}>
        {children ||
          (isHorizontal ? <HorizontalHandleIcon /> : <VerticalHandleIcon />)}
      </span>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * SplitterPanel Component
 */
export const SplitterPanel: Pulse.Fn<SplitterPanelProps> = (props) => {
  const {
    children,
    size,
    minSize,
    maxSize,
    limitReachedClass,
    className,
    id,
    style,
    ...rest
  } = props;

  // Get size value
  const sizeValue =
    typeof size === "object" && "value" in size ? (size as any).value : size;

  // Build data attribute
  const dataAttr =
    minSize !== undefined || maxSize !== undefined
      ? JSON.stringify({
          dynamicSize: sizeValue,
          ...(minSize !== undefined && { minSize }),
          ...(maxSize !== undefined && { maxSize }),
        })
      : sizeValue.toString();

  const panelClasses = cn(
    "overflow-hidden",
    limitReachedClass && "hs-prev-limit-reached:" + limitReachedClass,
    className,
  );

  const panelStyle = `flex: ${sizeValue} 1 0px; ${style || ""}`;

  return (
    <div
      id={id}
      class={panelClasses}
      style={panelStyle}
      data-hs-layout-splitter-item={dataAttr}
      {...rest}
    >
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * LayoutSplitter Component
 */
export const LayoutSplitter: Pulse.Fn<LayoutSplitterProps> = (props) => {
  const {
    children,
    direction = "horizontal",
    handleTemplate,
    handleClasses,
    manualHandles = false,
    onResize,
    disabled = false,
    className,
    id = generateId("layout-splitter"),
    style,
    ...rest
  } = props;

  const isHorizontal = direction === "horizontal";

  // Default handle template (as string for Preline JS)
  const getDefaultHandleTemplate = (dir: "horizontal" | "vertical") => {
    const icon =
      dir === "horizontal"
        ? '<svg class="shrink-0 size-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="12" r="1"/><circle cx="9" cy="5" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="19" r="1"/></svg>'
        : '<svg class="shrink-0 size-3.5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="9" r="1"/><circle cx="19" cy="9" r="1"/><circle cx="5" cy="9" r="1"/><circle cx="12" cy="15" r="1"/><circle cx="19" cy="15" r="1"/><circle cx="5" cy="15" r="1"/></svg>';

    const size = dir === "horizontal" ? "w-4 h-6" : "w-6 h-4";
    const cursor =
      dir === "horizontal" ? "cursor-col-resize" : "cursor-row-resize";

    return `<div><span class="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 block ${size} flex justify-center items-center bg-white border border-gray-200 text-gray-400 rounded-md ${cursor} hover:bg-gray-100 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-600 dark:hover:bg-neutral-900">${icon}</span></div>`;
  };

  // Build configuration object
  const config: any = {};

  if (manualHandles) {
    config.isSplittersAddedManually = true;
  } else {
    if (isHorizontal) {
      config.horizontalSplitterTemplate = handleTemplate
        ? typeof handleTemplate === "string"
          ? handleTemplate
          : getDefaultHandleTemplate("horizontal")
        : getDefaultHandleTemplate("horizontal");

      config.horizontalSplitterClasses =
        handleClasses ||
        "relative flex border-s border-gray-200 dark:border-neutral-700";
    } else {
      config.verticalSplitterTemplate = handleTemplate
        ? typeof handleTemplate === "string"
          ? handleTemplate
          : getDefaultHandleTemplate("vertical")
        : getDefaultHandleTemplate("vertical");

      config.verticalSplitterClasses =
        handleClasses ||
        "relative flex border-t border-gray-200 dark:border-neutral-700";
    }
  }

  // Container for the splitter
  const containerClasses = cn(className);

  // Group classes
  const groupClasses = cn(
    "flex",
    "border border-gray-200 rounded-lg",
    "dark:border-neutral-700",
    isHorizontal ? "" : "flex-col",
  );

  // Convert children array to ensure proper structure
  const childrenArray = Array.isArray(children)
    ? children
    : children
      ? [children]
      : [];

  // If not manual handles, insert handles between panels
  const childrenWithHandles = manualHandles
    ? childrenArray
    : childrenArray.reduce((acc: Pulse.JSX.Element[], child, index) => {
        if (child) {
          acc.push(child);
          if (index < childrenArray.length - 1) {
            acc.push(
              <SplitterHandle
                direction={direction}
                className={handleClasses}
              />,
            );
          }
        }
        return acc;
      }, []);

  // Effect to initialize the splitter (if using Preline JS)
  // Note: This requires Preline JS to be loaded in the page
  Pulse.effect(() => {
    if (typeof window !== "undefined" && (window as any).HSLayoutSplitter) {
      // Wait for next tick to ensure DOM is ready
      setTimeout(() => {
        const element = document.getElementById(id);
        if (element) {
          (window as any).HSLayoutSplitter.autoInit();
        }
      }, 0);
    }
  });

  return (
    <div
      id={id}
      class={containerClasses}
      style={style}
      data-hs-layout-splitter={JSON.stringify(config)}
      {...rest}
    >
      <div
        class={groupClasses}
        data-hs-layout-splitter-horizontal-group={isHorizontal ? "" : undefined}
        data-hs-layout-splitter-vertical-group={!isHorizontal ? "" : undefined}
      >
        {childrenWithHandles}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * HorizontalSplitter - Quick horizontal layout splitter
 */
export const HorizontalSplitter: Pulse.Fn<LayoutSplitterProps> = (props) => {
  return <LayoutSplitter {...props} direction="horizontal" />;
};

/**
 * VerticalSplitter - Quick vertical layout splitter
 */
export const VerticalSplitter: Pulse.Fn<LayoutSplitterProps> = (props) => {
  return <LayoutSplitter {...props} direction="vertical" />;
};

/**
 * CodeEditorLayout - Common code editor layout (sidebar + editor + preview)
 */
export interface CodeEditorLayoutProps extends Omit<
  LayoutSplitterProps,
  "children"
> {
  /** Sidebar content */
  sidebar?: Pulse.JSX.Element | string;
  /** Editor content */
  editor: Pulse.JSX.Element | string;
  /** Preview content */
  preview?: Pulse.JSX.Element | string;
  /** Initial sidebar size */
  sidebarSize?: number;
  /** Initial editor size */
  editorSize?: number;
}

export const CodeEditorLayout: Pulse.Fn<CodeEditorLayoutProps> = (props) => {
  const {
    sidebar,
    editor,
    preview,
    sidebarSize = 20,
    editorSize = 40,
    ...rest
  } = props;

  const previewSize = 100 - sidebarSize - editorSize;

  const panels: Pulse.JSX.Element[] = [];

  if (sidebar) {
    panels.push(
      <SplitterPanel size={sidebarSize} minSize={10} maxSize={40}>
        {sidebar}
      </SplitterPanel>,
    );
  }

  panels.push(
    <SplitterPanel size={editorSize} minSize={20}>
      {editor}
    </SplitterPanel>,
  );

  if (preview) {
    panels.push(
      <SplitterPanel size={previewSize} minSize={20}>
        {preview}
      </SplitterPanel>,
    );
  }

  return (
    <HorizontalSplitter {...rest}>{panels}</HorizontalSplitter>
  ) as Pulse.JSX.Element;
};

/**
 * ThreePanelLayout - Top, middle, bottom layout
 */
export interface ThreePanelLayoutProps extends Omit<
  LayoutSplitterProps,
  "children"
> {
  /** Top panel content */
  top: Pulse.JSX.Element | string;
  /** Middle panel content */
  middle: Pulse.JSX.Element | string;
  /** Bottom panel content */
  bottom: Pulse.JSX.Element | string;
  /** Initial sizes */
  topSize?: number;
  middleSize?: number;
  bottomSize?: number;
}

export const ThreePanelLayout: Pulse.Fn<ThreePanelLayoutProps> = (props) => {
  const {
    top,
    middle,
    bottom,
    topSize = 30,
    middleSize = 50,
    bottomSize = 20,
    ...rest
  } = props;

  return (
    <VerticalSplitter {...rest}>
      <SplitterPanel size={topSize} minSize={10}>
        {top}
      </SplitterPanel>
      <SplitterPanel size={middleSize} minSize={20}>
        {middle}
      </SplitterPanel>
      <SplitterPanel size={bottomSize} minSize={10}>
        {bottom}
      </SplitterPanel>
    </VerticalSplitter>
  ) as Pulse.JSX.Element;
};

export default LayoutSplitter;
