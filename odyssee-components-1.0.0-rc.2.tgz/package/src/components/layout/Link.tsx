/**
 * Link Component
 * A versatile link component with multiple styles, underline variants, and icon support
 *
 * @example
 * ```tsx
 * import { Link, ExternalLink, IconLink } from '@odyssee/components';
 *
 * // Basic link
 * <Link href="/about">About Us</Link>
 *
 * // Link with underline
 * <Link href="/contact" underline="hover">
 *   Contact
 * </Link>
 *
 * // Colored link
 * <Link href="#" color="primary" underline="always">
 *   Primary Link
 * </Link>
 *
 * // Link with custom underline color
 * <Link
 *   href="#"
 *   color="blue-600"
 *   underlineColor="red-500"
 *   underline="hover"
 * >
 *   Custom underline
 * </Link>
 *
 * // Link with opacity
 * <Link href="#" opacity={80}>
 *   80% opacity link
 * </Link>
 *
 * // Link with icon
 * <IconLink href="/learn" icon="→" iconPosition="right">
 *   Learn more
 * </IconLink>
 *
 * // External link (opens in new tab)
 * <ExternalLink href="https://example.com">
 *   External Site
 * </ExternalLink>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Link props
 */
export interface LinkProps extends BaseComponentProps {
  /** Link destination */
  href: string;

  /** Link content */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Text color */
  color?:
    | "primary"
    | "secondary"
    | "success"
    | "danger"
    | "warning"
    | "dark"
    | "light"
    | string;

  /** Underline style */
  underline?: "none" | "always" | "hover" | "focus";

  /** Underline color (independent from text color) */
  underlineColor?: string;

  /** Underline thickness */
  underlineThickness?: "1" | "2" | "4" | "8";

  /** Underline offset */
  underlineOffset?: "1" | "2" | "4" | "8" | "auto";

  /** Link opacity */
  opacity?: number;

  /** Hover opacity */
  hoverOpacity?: number;

  /** Font size */
  size?: "xs" | "sm" | "base" | "lg" | "xl";

  /** Font weight */
  weight?: "normal" | "medium" | "semibold" | "bold";

  /** Open in new tab */
  external?: boolean;

  /** Disabled state */
  disabled?: boolean;

  /** On click handler */
  onClick?: (e: Event) => void;
}

/**
 * Get color classes
 */
function getColorClass(color: string | undefined): string {
  if (!color) return "text-blue-600 dark:text-blue-500";

  const colorMap: Record<string, string> = {
    primary: "text-blue-600 dark:text-blue-500",
    secondary: "text-gray-500 dark:text-gray-400",
    success: "text-teal-500 dark:text-teal-400",
    danger: "text-red-500 dark:text-red-400",
    warning: "text-yellow-500 dark:text-yellow-400",
    dark: "text-gray-800 dark:text-white",
    light: "text-white dark:text-gray-200",
  };

  return colorMap[color] || `text-${color}`;
}

/**
 * Get underline color class
 */
function getUnderlineColorClass(color: string | undefined): string {
  if (!color) return "";
  return `decoration-${color}`;
}

/**
 * Link Component
 */
export const Link: Pulse.Fn<LinkProps> = (props) => {
  const {
    href,
    children,
    color,
    underline = "none",
    underlineColor,
    underlineThickness = "2",
    underlineOffset = "auto",
    opacity,
    hoverOpacity,
    size = "base",
    weight = "normal",
    external = false,
    disabled = false,
    onClick,
    className,
    id = generateId("link"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    base: "text-base",
    lg: "text-lg",
    xl: "text-xl",
  };

  // Weight classes
  const weightClasses = {
    normal: "font-normal",
    medium: "font-medium",
    semibold: "font-semibold",
    bold: "font-bold",
  };

  // Underline classes
  const underlineClasses = {
    none: "",
    always: "underline",
    hover: "hover:underline",
    focus: "focus:underline",
  };

  // Underline thickness classes
  const thicknessClasses = {
    "1": "decoration-1",
    "2": "decoration-2",
    "4": "decoration-4",
    "8": "decoration-8",
  };

  // Underline offset classes
  const offsetClasses = {
    "1": "underline-offset-1",
    "2": "underline-offset-2",
    "4": "underline-offset-4",
    "8": "underline-offset-8",
    auto: "underline-offset-auto",
  };

  // Opacity classes
  const getOpacityClass = () => {
    if (!opacity) return "";
    return `opacity-${opacity}`;
  };

  const getHoverOpacityClass = () => {
    if (!hoverOpacity) return "hover:opacity-80";
    return `hover:opacity-${hoverOpacity}`;
  };

  // Link classes
  const linkClasses = cn(
    // Base styles
    "transition-all duration-200",
    "focus:outline-hidden",

    // Color
    getColorClass(color),

    // Size and weight
    sizeClasses[size],
    weightClasses[weight],

    // Underline
    underlineClasses[underline],
    underline !== "none" && thicknessClasses[underlineThickness],
    underline !== "none" && offsetClasses[underlineOffset],
    underlineColor && getUnderlineColorClass(underlineColor),

    // Opacity
    getOpacityClass(),
    getHoverOpacityClass(),

    // Focus styles
    underline === "hover" && "focus:underline",
    underline === "always" && "focus:opacity-80",

    // Disabled
    disabled && "opacity-50 pointer-events-none cursor-not-allowed",

    className,
  );

  // Handle click
  const handleClick = (e: Event) => {
    if (disabled) {
      e.preventDefault();
      return;
    }
    if (onClick) {
      onClick(e);
    }
  };

  // External link attributes
  const externalAttrs = external
    ? {
        target: "_blank",
        rel: "noopener noreferrer",
      }
    : {};

  return (
    <a
      id={id}
      href={href}
      class={linkClasses}
      style={style}
      onClick={handleClick}
      {...externalAttrs}
      {...rest}
    >
      {children}
    </a>
  ) as Pulse.JSX.Element;
};

/**
 * IconLink props
 */
export interface IconLinkProps extends LinkProps {
  /** Icon element or string */
  icon: Pulse.JSX.Element | string;

  /** Icon position */
  iconPosition?: "left" | "right";

  /** Icon size */
  iconSize?: "3" | "4" | "5" | "6";
}

/**
 * IconLink - Link with icon
 */
export const IconLink: Pulse.Fn<IconLinkProps> = (props) => {
  const {
    icon,
    iconPosition = "left",
    iconSize = "4",
    children,
    className,
    ...rest
  } = props;

  const iconClasses = cn("shrink-0", `size-${iconSize}`);

  return (
    <Link
      {...rest}
      className={cn("inline-flex items-center gap-x-1", className)}
    >
      {iconPosition === "left" && <span class={iconClasses}>{icon}</span>}
      {children as any}
      {iconPosition === "right" && <span class={iconClasses}>{icon}</span>}
    </Link>
  ) as Pulse.JSX.Element;
};

/**
 * ExternalLink - Link that opens in new tab
 */
export const ExternalLink: Pulse.Fn<LinkProps> = (props) => {
  return <Link {...props} external={true} />;
};

/**
 * NavLink - Link for navigation menus
 */
export interface NavLinkProps extends LinkProps {
  /** Active state */
  active?: boolean;

  /** Active color */
  activeColor?: string;
}

export const NavLink: Pulse.Fn<NavLinkProps> = (props) => {
  const {
    active = false,
    activeColor = "blue-600",
    color = "gray-800",
    className,
    ...rest
  } = props;

  return (
    <Link
      {...rest}
      color={active ? activeColor : color}
      underline={active ? "always" : "hover"}
      className={cn(active && "font-semibold", className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * ButtonLink - Link styled as a button
 */
export interface ButtonLinkProps extends Omit<LinkProps, "underline"> {
  /** Button variant */
  variant?: "solid" | "outline" | "ghost" | "soft";

  /** Size */
  size?: "sm" | "md" | "lg";

  /** Full width */
  fullWidth?: boolean;
}

export const ButtonLink: Pulse.Fn<ButtonLinkProps> = (props) => {
  const {
    variant = "solid",
    size = "md",
    color = "primary",
    fullWidth = false,
    className,
    children,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    sm: "py-1.5 px-2 text-xs",
    md: "py-2 px-3 text-sm",
    lg: "py-2.5 px-4 text-base",
  };

  // Variant classes
  const variantClasses = {
    solid: {
      primary: "bg-blue-600 text-white hover:bg-blue-700 focus:bg-blue-700",
      secondary: "bg-gray-600 text-white hover:bg-gray-700 focus:bg-gray-700",
      success: "bg-teal-500 text-white hover:bg-teal-600 focus:bg-teal-600",
      danger: "bg-red-500 text-white hover:bg-red-600 focus:bg-red-600",
    },
    outline: {
      primary:
        "border-2 border-blue-600 text-blue-600 hover:bg-blue-50 focus:bg-blue-50",
      secondary:
        "border-2 border-gray-600 text-gray-600 hover:bg-gray-50 focus:bg-gray-50",
      success:
        "border-2 border-teal-500 text-teal-500 hover:bg-teal-50 focus:bg-teal-50",
      danger:
        "border-2 border-red-500 text-red-500 hover:bg-red-50 focus:bg-red-50",
    },
    ghost: {
      primary: "text-blue-600 hover:bg-blue-50 focus:bg-blue-50",
      secondary: "text-gray-600 hover:bg-gray-50 focus:bg-gray-50",
      success: "text-teal-500 hover:bg-teal-50 focus:bg-teal-50",
      danger: "text-red-500 hover:bg-red-50 focus:bg-red-50",
    },
    soft: {
      primary: "bg-blue-100 text-blue-700 hover:bg-blue-200 focus:bg-blue-200",
      secondary:
        "bg-gray-100 text-gray-700 hover:bg-gray-200 focus:bg-gray-200",
      success: "bg-teal-100 text-teal-700 hover:bg-teal-200 focus:bg-teal-200",
      danger: "bg-red-100 text-red-700 hover:bg-red-200 focus:bg-red-200",
    },
  };

  type ColorKey = "primary" | "secondary" | "success" | "danger";
  const colorKey: ColorKey =
    color === "primary" ||
    color === "secondary" ||
    color === "success" ||
    color === "danger"
      ? color
      : "primary";

  return (
    <Link
      {...rest}
      href={rest.href || "#"}
      underline="none"
      className={cn(
        "inline-flex items-center justify-center font-medium rounded-md",
        "transition-colors duration-200",
        "focus:outline-hidden focus:ring-2 focus:ring-offset-2",
        "disabled:opacity-50 disabled:pointer-events-none",
        sizeClasses[size],
        variantClasses[variant][colorKey],
        fullWidth ? "w-full" : undefined,
        className,
      )}
    >
      {children}
    </Link>
  ) as Pulse.JSX.Element;
};

/**
 * BackLink - Link with back arrow
 */
export const BackLink: Pulse.Fn<Omit<LinkProps, "children">> = (props) => {
  const { children = "Back", ...rest } = props;

  const backIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  );

  return (
    <IconLink
      {...rest}
      href={rest.href || "#"}
      icon={backIcon}
      iconPosition="left"
      color="gray-800"
      underline="hover"
    >
      {children}
    </IconLink>
  ) as Pulse.JSX.Element;
};

/**
 * NextLink - Link with next arrow
 */
export const NextLink: Pulse.Fn<Omit<LinkProps, "children">> = (props) => {
  const { children = "Next", ...rest } = props;

  const nextIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  );

  return (
    <IconLink
      {...rest}
      href={rest.href || "#"}
      icon={nextIcon}
      iconPosition="right"
      color="primary"
      underline="hover"
    >
      {children}
    </IconLink>
  ) as Pulse.JSX.Element;
};

export default Link;
