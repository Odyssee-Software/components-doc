/**
 * Grid Component
 * A flexible grid layout component based on CSS Grid with responsive breakpoints
 *
 * @example
 * ```tsx
 * import { Grid, GridItem } from '@odyssee/components';
 *
 * // Basic grid with 3 columns
 * <Grid cols={3} gap={4}>
 *   <div>Item 1</div>
 *   <div>Item 2</div>
 *   <div>Item 3</div>
 * </Grid>
 *
 * // Responsive grid
 * <Grid cols={{ base: 1, sm: 2, md: 3, lg: 4 }} gap={4}>
 *   <div>Item 1</div>
 *   <div>Item 2</div>
 *   <div>Item 3</div>
 *   <div>Item 4</div>
 * </Grid>
 *
 * // Grid with spanning items
 * <Grid cols={3} gap={4}>
 *   <GridItem colSpan={2}>Spans 2 columns</GridItem>
 *   <div>Item 2</div>
 *   <div>Item 3</div>
 *   <GridItem colSpan={2}>Spans 2 columns</GridItem>
 * </Grid>
 *
 * // Grid with rows
 * <Grid cols={3} rows={3} gap={4}>
 *   <GridItem rowSpan={2}>Spans 2 rows</GridItem>
 *   <div>Item 2</div>
 *   <div>Item 3</div>
 * </Grid>
 *
 * // Grid with auto flow
 * <Grid cols={3} autoFlow="dense" gap={4}>
 *   <GridItem colSpan={2}>Wide item</GridItem>
 *   <div>Item 2</div>
 *   <div>Item 3</div>
 * </Grid>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Responsive breakpoint value
 */
export interface ResponsiveValue<T> {
  base?: T;
  sm?: T;
  md?: T;
  lg?: T;
  xl?: T;
  "2xl"?: T;
}

/**
 * Grid props
 */
export interface GridProps extends BaseComponentProps {
  /** Content to render inside grid */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Number of columns (responsive) */
  cols?: number | ResponsiveValue<number>;

  /** Number of rows (responsive) */
  rows?: number | ResponsiveValue<number>;

  /** Gap between grid items */
  gap?: number | string;

  /** Gap between columns */
  gapX?: number | string;

  /** Gap between rows */
  gapY?: number | string;

  /** Grid auto flow direction */
  autoFlow?: "row" | "col" | "dense" | "row-dense" | "col-dense";

  /** Align items */
  alignItems?: "start" | "center" | "end" | "stretch" | "baseline";

  /** Justify items */
  justifyItems?: "start" | "center" | "end" | "stretch";

  /** Align content */
  alignContent?: "start" | "center" | "end" | "between" | "around" | "evenly";

  /** Justify content */
  justifyContent?: "start" | "center" | "end" | "between" | "around" | "evenly";

  /** Auto columns sizing */
  autoColumns?: "auto" | "min" | "max" | "fr";

  /** Auto rows sizing */
  autoRows?: "auto" | "min" | "max" | "fr";
}

/**
 * Convert number to grid class
 */
function getGridColsClass(
  cols: number | ResponsiveValue<number> | undefined,
): string {
  if (!cols) return "";

  if (typeof cols === "number") {
    return `grid-cols-${cols}`;
  }

  const classes: string[] = [];
  if (cols.base) classes.push(`grid-cols-${cols.base}`);
  if (cols.sm) classes.push(`sm:grid-cols-${cols.sm}`);
  if (cols.md) classes.push(`md:grid-cols-${cols.md}`);
  if (cols.lg) classes.push(`lg:grid-cols-${cols.lg}`);
  if (cols.xl) classes.push(`xl:grid-cols-${cols.xl}`);
  if (cols["2xl"]) classes.push(`2xl:grid-cols-${cols["2xl"]}`);

  return classes.join(" ");
}

/**
 * Convert number to grid rows class
 */
function getGridRowsClass(
  rows: number | ResponsiveValue<number> | undefined,
): string {
  if (!rows) return "";

  if (typeof rows === "number") {
    return `grid-rows-${rows}`;
  }

  const classes: string[] = [];
  if (rows.base) classes.push(`grid-rows-${rows.base}`);
  if (rows.sm) classes.push(`sm:grid-rows-${rows.sm}`);
  if (rows.md) classes.push(`md:grid-rows-${rows.md}`);
  if (rows.lg) classes.push(`lg:grid-rows-${rows.lg}`);
  if (rows.xl) classes.push(`xl:grid-rows-${rows.xl}`);
  if (rows["2xl"]) classes.push(`2xl:grid-rows-${rows["2xl"]}`);

  return classes.join(" ");
}

/**
 * Get gap class
 */
function getGapClass(
  gap: number | string | undefined,
  prefix: "" | "x" | "y" = "",
): string {
  if (!gap) return "";

  const gapPrefix = prefix ? `gap-${prefix}-` : "gap-";

  if (typeof gap === "number") {
    return `${gapPrefix}${gap}`;
  }

  return `${gapPrefix}[${gap}]`;
}

/**
 * Grid Component
 *
 * @example
 * ```tsx
 * <Grid cols={4} gap={4}>
 *   <div>1</div>
 *   <div>2</div>
 *   <div>3</div>
 *   <div>4</div>
 * </Grid>
 * ```
 */
export const Grid: Pulse.Fn<GridProps> = (props) => {
  const {
    children,
    cols,
    rows,
    gap,
    gapX,
    gapY,
    autoFlow,
    alignItems,
    justifyItems,
    alignContent,
    justifyContent,
    autoColumns,
    autoRows,
    className,
    id = generateId("grid"),
    style,
    ...rest
  } = props;

  // Auto flow classes
  const autoFlowClasses = {
    row: "grid-flow-row",
    col: "grid-flow-col",
    dense: "grid-flow-dense",
    "row-dense": "grid-flow-row-dense",
    "col-dense": "grid-flow-col-dense",
  };

  // Align items classes
  const alignItemsClasses = {
    start: "items-start",
    center: "items-center",
    end: "items-end",
    stretch: "items-stretch",
    baseline: "items-baseline",
  };

  // Justify items classes
  const justifyItemsClasses = {
    start: "justify-items-start",
    center: "justify-items-center",
    end: "justify-items-end",
    stretch: "justify-items-stretch",
  };

  // Align content classes
  const alignContentClasses = {
    start: "content-start",
    center: "content-center",
    end: "content-end",
    between: "content-between",
    around: "content-around",
    evenly: "content-evenly",
  };

  // Justify content classes
  const justifyContentClasses = {
    start: "justify-start",
    center: "justify-center",
    end: "justify-end",
    between: "justify-between",
    around: "justify-around",
    evenly: "justify-evenly",
  };

  // Auto columns classes
  const autoColumnsClasses = {
    auto: "auto-cols-auto",
    min: "auto-cols-min",
    max: "auto-cols-max",
    fr: "auto-cols-fr",
  };

  // Auto rows classes
  const autoRowsClasses = {
    auto: "auto-rows-auto",
    min: "auto-rows-min",
    max: "auto-rows-max",
    fr: "auto-rows-fr",
  };

  // Grid classes
  const gridClasses = cn(
    "grid",
    getGridColsClass(cols),
    getGridRowsClass(rows),
    gap ? getGapClass(gap) : undefined,
    gapX ? getGapClass(gapX, "x") : undefined,
    gapY ? getGapClass(gapY, "y") : undefined,
    autoFlow ? autoFlowClasses[autoFlow] : undefined,
    alignItems ? alignItemsClasses[alignItems] : undefined,
    justifyItems ? justifyItemsClasses[justifyItems] : undefined,
    alignContent ? alignContentClasses[alignContent] : undefined,
    justifyContent ? justifyContentClasses[justifyContent] : undefined,
    autoColumns ? autoColumnsClasses[autoColumns] : undefined,
    autoRows ? autoRowsClasses[autoRows] : undefined,
    className,
  );

  return (
    <div id={id} class={gridClasses} style={style} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * GridItem props
 */
export interface GridItemProps extends BaseComponentProps {
  /** Content to render inside grid item */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Column span */
  colSpan?: number | "full" | "auto";

  /** Row span */
  rowSpan?: number | "full" | "auto";

  /** Column start */
  colStart?: number | "auto";

  /** Column end */
  colEnd?: number | "auto";

  /** Row start */
  rowStart?: number | "auto";

  /** Row end */
  rowEnd?: number | "auto";

  /** Align self */
  alignSelf?: "auto" | "start" | "center" | "end" | "stretch";

  /** Justify self */
  justifySelf?: "auto" | "start" | "center" | "end" | "stretch";

  /** Place self (shorthand for align-self and justify-self) */
  placeSelf?: "auto" | "start" | "center" | "end" | "stretch";
}

/**
 * GridItem Component
 *
 * @example
 * ```tsx
 * <Grid cols={3}>
 *   <GridItem colSpan={2}>Spans 2 columns</GridItem>
 *   <GridItem>Regular item</GridItem>
 * </Grid>
 * ```
 */
export const GridItem: Pulse.Fn<GridItemProps> = (props) => {
  const {
    children,
    colSpan,
    rowSpan,
    colStart,
    colEnd,
    rowStart,
    rowEnd,
    alignSelf,
    justifySelf,
    placeSelf,
    className,
    id,
    style,
    ...rest
  } = props;

  // Column span classes
  const getColSpanClass = () => {
    if (!colSpan) return "";
    if (colSpan === "full") return "col-span-full";
    if (colSpan === "auto") return "col-auto";
    return `col-span-${colSpan}`;
  };

  // Row span classes
  const getRowSpanClass = () => {
    if (!rowSpan) return "";
    if (rowSpan === "full") return "row-span-full";
    if (rowSpan === "auto") return "row-auto";
    return `row-span-${rowSpan}`;
  };

  // Column start classes
  const getColStartClass = () => {
    if (!colStart) return "";
    if (colStart === "auto") return "col-start-auto";
    return `col-start-${colStart}`;
  };

  // Column end classes
  const getColEndClass = () => {
    if (!colEnd) return "";
    if (colEnd === "auto") return "col-end-auto";
    return `col-end-${colEnd}`;
  };

  // Row start classes
  const getRowStartClass = () => {
    if (!rowStart) return "";
    if (rowStart === "auto") return "row-start-auto";
    return `row-start-${rowStart}`;
  };

  // Row end classes
  const getRowEndClass = () => {
    if (!rowEnd) return "";
    if (rowEnd === "auto") return "row-end-auto";
    return `row-end-${rowEnd}`;
  };

  // Align self classes
  const alignSelfClasses = {
    auto: "self-auto",
    start: "self-start",
    center: "self-center",
    end: "self-end",
    stretch: "self-stretch",
  };

  // Justify self classes
  const justifySelfClasses = {
    auto: "justify-self-auto",
    start: "justify-self-start",
    center: "justify-self-center",
    end: "justify-self-end",
    stretch: "justify-self-stretch",
  };

  // Place self classes
  const placeSelfClasses = {
    auto: "place-self-auto",
    start: "place-self-start",
    center: "place-self-center",
    end: "place-self-end",
    stretch: "place-self-stretch",
  };

  // Grid item classes
  const gridItemClasses = cn(
    getColSpanClass(),
    getRowSpanClass(),
    getColStartClass(),
    getColEndClass(),
    getRowStartClass(),
    getRowEndClass(),
    alignSelf && alignSelfClasses[alignSelf],
    justifySelf && justifySelfClasses[justifySelf],
    placeSelf && placeSelfClasses[placeSelf],
    className,
  );

  return (
    <div id={id} class={gridItemClasses} style={style} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * SimpleGrid - Grid with equal columns
 */
export interface SimpleGridProps extends Omit<GridProps, "cols"> {
  /** Number of columns */
  columns?: number;

  /** Minimum column width (will auto-fit) */
  minChildWidth?: string;
}

export const SimpleGrid: Pulse.Fn<SimpleGridProps> = (props) => {
  const { columns = 1, minChildWidth, style, ...rest } = props;

  const gridStyle = minChildWidth
    ? `grid-template-columns: repeat(auto-fit, minmax(${minChildWidth}, 1fr)); ${style || ""}`
    : style;

  return (
    <Grid
      {...rest}
      cols={!minChildWidth ? columns : undefined}
      style={gridStyle}
    />
  ) as Pulse.JSX.Element;
};

/**
 * ResponsiveGrid - Grid with predefined responsive breakpoints
 */
export const ResponsiveGrid: Pulse.Fn<GridProps> = (props) => {
  const { cols, ...rest } = props;

  return (
    <Grid {...rest} cols={cols || { base: 1, sm: 2, md: 3, lg: 4 }} />
  ) as Pulse.JSX.Element;
};

export default Grid;
