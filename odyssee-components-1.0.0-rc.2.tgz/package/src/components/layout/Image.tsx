/**
 * Image Component
 * A versatile image component with responsive features, lazy loading, and styling utilities
 *
 * @example
 * ```tsx
 * import { Image, ImageOverlay, ImageZoom } from '@odyssee/components';
 *
 * // Basic image
 * <Image src="https://example.com/image.jpg" alt="Description" />
 *
 * // Responsive image with fixed size
 * <Image
 *   src="https://example.com/image.jpg"
 *   alt="Description"
 *   width="56"
 *   height="auto"
 * />
 *
 * // Image with object fit
 * <Image
 *   src="https://example.com/image.jpg"
 *   alt="Description"
 *   objectFit="cover"
 *   className="h-48 w-96"
 * />
 *
 * // Image with zoom on hover
 * <ImageZoom src="https://example.com/image.jpg" alt="Description" />
 *
 * // Image with overlay content
 * <ImageOverlay src="https://example.com/image.jpg" alt="Description">
 *   <h3>Overlay Title</h3>
 *   <p>Overlay content</p>
 * </ImageOverlay>
 *
 * // Lazy loaded image
 * <Image
 *   src="https://example.com/image.jpg"
 *   alt="Description"
 *   loading="lazy"
 * />
 *
 * // Rounded image
 * <Image
 *   src="https://example.com/image.jpg"
 *   alt="Description"
 *   rounded="xl"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Image props
 */
export interface ImageProps extends BaseComponentProps {
  /** Image source URL */
  src: string;

  /** Alt text for accessibility */
  alt: string;

  /** Image width */
  width?: string | number;

  /** Image height */
  height?: string | number;

  /** Object fit behavior */
  objectFit?: "contain" | "cover" | "fill" | "none" | "scale-down";

  /** Object position */
  objectPosition?:
    | "center"
    | "top"
    | "right"
    | "bottom"
    | "left"
    | "left-top"
    | "left-bottom"
    | "right-top"
    | "right-bottom";

  /** Border radius */
  rounded?: "none" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "full";

  /** Loading strategy */
  loading?: "eager" | "lazy";

  /** Image will be block or inline */
  display?: "block" | "inline" | "inline-block";

  /** Aspect ratio */
  aspectRatio?: "square" | "video" | "4/3" | "16/9" | "21/9" | "auto";

  /** On load callback */
  onLoad?: () => void;

  /** On error callback */
  onError?: () => void;

  /** Fallback image source on error */
  fallbackSrc?: string;
}

/**
 * Image Component
 */
export const Image: Pulse.Fn<ImageProps> = (props) => {
  const {
    src,
    alt,
    width,
    height,
    objectFit,
    objectPosition,
    rounded = "none",
    loading = "lazy",
    display = "block",
    aspectRatio,
    onLoad,
    onError,
    fallbackSrc,
    className,
    id = generateId("image"),
    style,
    ...rest
  } = props;

  // Object fit classes
  const objectFitClasses = {
    contain: "object-contain",
    cover: "object-cover",
    fill: "object-fill",
    none: "object-none",
    "scale-down": "object-scale-down",
  };

  // Object position classes
  const objectPositionClasses = {
    center: "object-center",
    top: "object-top",
    right: "object-right",
    bottom: "object-bottom",
    left: "object-left",
    "left-top": "object-left-top",
    "left-bottom": "object-left-bottom",
    "right-top": "object-right-top",
    "right-bottom": "object-right-bottom",
  };

  // Rounded classes
  const roundedClasses = {
    none: "",
    sm: "rounded-sm",
    md: "rounded-md",
    lg: "rounded-lg",
    xl: "rounded-xl",
    "2xl": "rounded-2xl",
    "3xl": "rounded-3xl",
    full: "rounded-full",
  };

  // Display classes
  const displayClasses = {
    block: "block",
    inline: "inline",
    "inline-block": "inline-block",
  };

  // Aspect ratio classes
  const aspectRatioClasses = {
    square: "aspect-square",
    video: "aspect-video",
    "4/3": "aspect-[4/3]",
    "16/9": "aspect-[16/9]",
    "21/9": "aspect-[21/9]",
    auto: "aspect-auto",
  };

  // Width/height classes
  const getWidthClass = () => {
    if (!width) return "";
    if (typeof width === "number") return `w-${width}`;
    if (width === "auto") return "w-auto";
    if (width === "full") return "w-full";
    return `w-${width}`;
  };

  const getHeightClass = () => {
    if (!height) return "";
    if (typeof height === "number") return `h-${height}`;
    if (height === "auto") return "h-auto";
    if (height === "full") return "h-full";
    return `h-${height}`;
  };

  // Image classes
  const imageClasses = cn(
    displayClasses[display],
    objectFit && objectFitClasses[objectFit],
    objectPosition && objectPositionClasses[objectPosition],
    roundedClasses[rounded],
    aspectRatio && aspectRatioClasses[aspectRatio],
    getWidthClass(),
    getHeightClass(),
    className,
  );

  // Handle error with fallback
  const handleError = (e: Event) => {
    if (fallbackSrc) {
      const img = e.target as HTMLImageElement;
      img.src = fallbackSrc;
    }
    if (onError) {
      onError();
    }
  };

  return (
    <img
      id={id}
      src={src}
      alt={alt}
      class={imageClasses}
      style={style}
      loading={loading}
      onLoad={onLoad}
      onError={handleError}
      {...rest}
    />
  ) as Pulse.JSX.Element;
};

/**
 * ImageZoom - Image with zoom effect on hover
 */
export interface ImageZoomProps extends ImageProps {
  /** Zoom scale on hover */
  zoomScale?: number;

  /** Transition duration in ms */
  duration?: number;
}

export const ImageZoom: Pulse.Fn<ImageZoomProps> = (props) => {
  const {
    zoomScale = 105,
    duration = 500,
    className,
    rounded = "xl",
    ...rest
  } = props;

  return (
    <div
      class={cn(
        "group shrink-0 relative overflow-hidden",
        rest.width ? `w-${rest.width}` : "w-56 sm:w-96",
        rest.height ? `h-${rest.height}` : "h-44",
        rounded && `rounded-${rounded}`,
      )}
    >
      <Image
        {...rest}
        rounded={rounded}
        className={cn(
          "transition-transform ease-in-out size-full absolute top-0 start-0",
          `duration-[${duration}ms]`,
          `group-hover:scale-${zoomScale}`,
          className,
        )}
        objectFit="cover"
      />
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * ImageOverlay - Image with content overlay
 */
export interface ImageOverlayProps extends Omit<ImageProps, "children"> {
  /** Overlay content */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Overlay position */
  overlayPosition?: "top" | "bottom" | "center" | "full";

  /** Enable hover shadow */
  hoverShadow?: boolean;

  /** Link href */
  href?: string;
}

export const ImageOverlay: Pulse.Fn<ImageOverlayProps> = (props) => {
  const {
    children,
    overlayPosition = "bottom",
    hoverShadow = true,
    href,
    className,
    rounded = "xl",
    ...imageProps
  } = props;

  // Overlay position classes
  const overlayPositionClasses = {
    top: "top-0 start-0 end-0",
    bottom: "bottom-0 start-0 end-0",
    center: "top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2",
    full: "inset-0",
  };

  const containerClasses = cn(
    "group relative block overflow-hidden",
    rounded && `rounded-${rounded}`,
    hoverShadow && "hover:shadow-lg focus:outline-hidden focus:shadow-lg",
    "transition",
    className,
  );

  const Container = href ? "a" : "div";

  return (
    <Container href={href} class={containerClasses}>
      <div
        class={cn(
          "aspect-w-12 aspect-h-7 sm:aspect-none overflow-hidden",
          rounded && `rounded-${rounded}`,
        )}
      >
        <Image
          src={imageProps.src}
          alt={imageProps.alt}
          {...imageProps}
          rounded={rounded}
          className="group-hover:scale-105 group-focus:scale-105 transition-transform duration-500 ease-in-out w-full"
          objectFit="cover"
        />
      </div>
      {children && (
        <div
          class={cn("absolute", overlayPositionClasses[overlayPosition], "p-2")}
        >
          {typeof children === "string" ? (
            <div class="font-semibold text-gray-800 rounded-lg bg-white p-3 dark:bg-neutral-800 dark:text-neutral-200">
              {children}
            </div>
          ) : (
            children
          )}
        </div>
      )}
    </Container>
  ) as Pulse.JSX.Element;
};

/**
 * BackgroundImage - Div with background image
 */
export interface BackgroundImageProps extends BaseComponentProps {
  /** Background image URL */
  src: string;

  /** Background size */
  size?: "auto" | "cover" | "contain";

  /** Background position */
  position?:
    | "center"
    | "top"
    | "right"
    | "bottom"
    | "left"
    | "left-top"
    | "left-bottom"
    | "right-top"
    | "right-bottom";

  /** Background repeat */
  repeat?: "repeat" | "no-repeat" | "repeat-x" | "repeat-y";

  /** Background attachment */
  attachment?: "fixed" | "local" | "scroll";

  /** Content to overlay */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Min height */
  minHeight?: string;

  /** Border radius */
  rounded?: "none" | "sm" | "md" | "lg" | "xl" | "2xl" | "3xl" | "full";
}

export const BackgroundImage: Pulse.Fn<BackgroundImageProps> = (props) => {
  const {
    src,
    size = "cover",
    position = "center",
    repeat = "no-repeat",
    attachment = "scroll",
    children,
    minHeight = "min-h-60",
    rounded = "none",
    className,
    id,
    style,
    ...rest
  } = props;

  // Background size classes
  const sizeClasses = {
    auto: "bg-auto",
    cover: "bg-cover",
    contain: "bg-contain",
  };

  // Background position classes
  const positionClasses = {
    center: "bg-center",
    top: "bg-top",
    right: "bg-right",
    bottom: "bg-bottom",
    left: "bg-left",
    "left-top": "bg-left-top",
    "left-bottom": "bg-left-bottom",
    "right-top": "bg-right-top",
    "right-bottom": "bg-right-bottom",
  };

  // Background repeat classes
  const repeatClasses = {
    repeat: "bg-repeat",
    "no-repeat": "bg-no-repeat",
    "repeat-x": "bg-repeat-x",
    "repeat-y": "bg-repeat-y",
  };

  // Background attachment classes
  const attachmentClasses = {
    fixed: "bg-fixed",
    local: "bg-local",
    scroll: "bg-scroll",
  };

  // Rounded classes
  const roundedClasses = {
    none: "",
    sm: "rounded-sm",
    md: "rounded-md",
    lg: "rounded-lg",
    xl: "rounded-xl",
    "2xl": "rounded-2xl",
    "3xl": "rounded-3xl",
    full: "rounded-full",
  };

  const bgClasses = cn(
    sizeClasses[size],
    positionClasses[position],
    repeatClasses[repeat],
    attachmentClasses[attachment],
    roundedClasses[rounded],
    minHeight,
    className,
  );

  const bgStyle = `background-image: url('${src}'); ${style || ""}`;

  return (
    <div id={id} class={bgClasses} style={bgStyle} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * Avatar Image - Circular image for avatars
 */
export interface AvatarImageProps extends Omit<ImageProps, "rounded"> {
  /** Avatar size */
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl";
}

export const AvatarImage: Pulse.Fn<AvatarImageProps> = (props) => {
  const { size = "md", className, ...rest } = props;

  const sizeClasses = {
    xs: "w-6 h-6",
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12",
    xl: "w-16 h-16",
    "2xl": "w-20 h-20",
  };

  return (
    <Image
      src={rest.src}
      alt={rest.alt}
      {...rest}
      rounded="full"
      objectFit="cover"
      className={cn(sizeClasses[size], className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * Thumbnail - Fixed size image thumbnail
 */
export const Thumbnail: Pulse.Fn<ImageProps> = (props) => {
  const { className, width = "56", height = "auto", ...rest } = props;

  return (
    <Image
      {...rest}
      width={width}
      height={height}
      rounded="lg"
      className={className}
    />
  ) as Pulse.JSX.Element;
};

/**
 * FullscreenImage - Full screen background image
 */
export const FullscreenImage: Pulse.Fn<BackgroundImageProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <BackgroundImage
      {...rest}
      size="cover"
      position="center"
      minHeight="h-screen"
      className={className}
    />
  ) as Pulse.JSX.Element;
};

export default Image;
