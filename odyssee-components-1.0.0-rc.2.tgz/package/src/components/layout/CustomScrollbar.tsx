/**
 * CustomScrollbar Component
 * A wrapper component that applies custom scrollbar styling to its content
 *
 * @example
 * ```tsx
 * import { CustomScrollbar, ScrollArea } from '@odyssee/components';
 *
 * // Basic custom scrollbar
 * <CustomScrollbar maxHeight="100">
 *   <p>Long content that will scroll...</p>
 * </CustomScrollbar>
 *
 * // Thin scrollbar with rounded corners
 * <CustomScrollbar
 *   maxHeight="96"
 *   width="thin"
 *   rounded={true}
 *   trackColor="gray-100"
 *   thumbColor="gray-300"
 * >
 *   <p>Content...</p>
 * </CustomScrollbar>
 *
 * // Custom colors
 * <CustomScrollbar
 *   maxHeight="80"
 *   trackColor="blue-50"
 *   thumbColor="blue-400"
 *   thumbHoverColor="blue-500"
 * >
 *   <p>Content...</p>
 * </CustomScrollbar>
 *
 * // Auto-hide scrollbar
 * <CustomScrollbar maxHeight="100" autoHide={true}>
 *   <p>Content...</p>
 * </CustomScrollbar>
 *
 * // Horizontal scrollbar
 * <CustomScrollbar orientation="horizontal" maxWidth="full">
 *   <div class="flex gap-4">
 *     <div>Item 1</div>
 *     <div>Item 2</div>
 *     <div>Item 3</div>
 *   </div>
 * </CustomScrollbar>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * CustomScrollbar props
 */
export interface CustomScrollbarProps extends BaseComponentProps {
  /** Content to render with custom scrollbar */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Maximum height */
  maxHeight?: string;

  /** Maximum width (for horizontal scrollbars) */
  maxWidth?: string;

  /** Scrollbar width */
  width?: "thin" | "normal" | "thick" | string;

  /** Scrollbar orientation */
  orientation?: "vertical" | "horizontal" | "both";

  /** Track background color */
  trackColor?: string;

  /** Thumb (handle) color */
  thumbColor?: string;

  /** Thumb hover color */
  thumbHoverColor?: string;

  /** Rounded scrollbar */
  rounded?: boolean;

  /** Auto-hide scrollbar when not hovering */
  autoHide?: boolean;

  /** Custom scrollbar styles */
  scrollbarStyles?: Record<string, string>;
}

/**
 * Get scrollbar width class
 */
function getScrollbarWidthClass(width: string): string {
  const widthMap: Record<string, string> = {
    thin: "2",
    normal: "3",
    thick: "4",
  };

  const w = widthMap[width] || width;
  return `[&::-webkit-scrollbar]:w-${w}`;
}

/**
 * CustomScrollbar Component
 */
export const CustomScrollbar: Pulse.Fn<CustomScrollbarProps> = (props) => {
  const {
    children,
    maxHeight = "100",
    maxWidth,
    width = "thin",
    orientation = "vertical",
    trackColor = "gray-100",
    thumbColor = "gray-300",
    thumbHoverColor,
    rounded = false,
    autoHide = false,
    scrollbarStyles,
    className,
    id = generateId("scrollbar"),
    style,
    ...rest
  } = props;

  // Build scrollbar classes
  const scrollbarClasses = cn(
    // Overflow
    orientation === "vertical" && "overflow-y-auto",
    orientation === "horizontal" && "overflow-x-auto",
    orientation === "both" && "overflow-auto",

    // Max dimensions
    maxHeight && `max-h-${maxHeight}`,
    maxWidth && `max-w-${maxWidth}`,

    // Scrollbar width
    getScrollbarWidthClass(width),

    // Track styling
    `[&::-webkit-scrollbar-track]:bg-${trackColor}`,
    `dark:[&::-webkit-scrollbar-track]:bg-neutral-700`,

    // Thumb styling
    `[&::-webkit-scrollbar-thumb]:bg-${thumbColor}`,
    `dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500`,

    // Thumb hover
    thumbHoverColor && `[&::-webkit-scrollbar-thumb:hover]:bg-${thumbHoverColor}`,

    // Rounded corners
    rounded && "[&::-webkit-scrollbar-track]:rounded-full",
    rounded && "[&::-webkit-scrollbar-thumb]:rounded-full",

    // Auto-hide
    autoHide && "[&::-webkit-scrollbar]:opacity-0",
    autoHide && "hover:[&::-webkit-scrollbar]:opacity-100",
    autoHide && "[&::-webkit-scrollbar]:transition-opacity",

    className,
  );

  return (
    <div id={id} class={scrollbarClasses} style={style} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * ScrollArea - Preset scroll area with custom scrollbar
 */
export interface ScrollAreaProps extends Omit<CustomScrollbarProps, "rounded" | "width"> {
  /** Variant style */
  variant?: "default" | "minimal" | "accent";
}

export const ScrollArea: Pulse.Fn<ScrollAreaProps> = (props) => {
  const { variant = "default", ...rest } = props;

  const variantProps = {
    default: {
      width: "thin" as const,
      rounded: false,
      trackColor: "gray-100",
      thumbColor: "gray-300",
    },
    minimal: {
      width: "thin" as const,
      rounded: true,
      trackColor: "transparent",
      thumbColor: "gray-400",
      autoHide: true,
    },
    accent: {
      width: "thin" as const,
      rounded: true,
      trackColor: "blue-50",
      thumbColor: "blue-400",
      thumbHoverColor: "blue-500",
    },
  };

  return (
    <CustomScrollbar {...variantProps[variant]} {...rest} />
  ) as Pulse.JSX.Element;
};

/**
 * ThinScrollbar - Quick preset for thin scrollbar
 */
export const ThinScrollbar: Pulse.Fn<CustomScrollbarProps> = (props) => {
  return (
    <CustomScrollbar {...props} width="thin" rounded={true} />
  ) as Pulse.JSX.Element;
};

/**
 * CodeScrollbar - Scrollbar preset for code blocks
 */
export const CodeScrollbar: Pulse.Fn<CustomScrollbarProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <CustomScrollbar
      {...rest}
      width="thin"
      rounded={true}
      trackColor="gray-800"
      thumbColor="gray-600"
      thumbHoverColor="gray-500"
      className={cn("font-mono text-sm", className)}
    />
  ) as Pulse.JSX.Element;
};

/**
 * ChatScrollbar - Scrollbar preset for chat interfaces
 */
export const ChatScrollbar: Pulse.Fn<CustomScrollbarProps> = (props) => {
  return (
    <CustomScrollbar
      {...props}
      width="thin"
      rounded={true}
      autoHide={true}
      trackColor="transparent"
      thumbColor="gray-300"
    />
  ) as Pulse.JSX.Element;
};

/**
 * TableScrollbar - Scrollbar for tables (horizontal + vertical)
 */
export const TableScrollbar: Pulse.Fn<CustomScrollbarProps> = (props) => {
  return (
    <CustomScrollbar
      {...props}
      orientation="both"
      width="thin"
      rounded={false}
      trackColor="gray-50"
      thumbColor="gray-300"
    />
  ) as Pulse.JSX.Element;
};

export default CustomScrollbar;
