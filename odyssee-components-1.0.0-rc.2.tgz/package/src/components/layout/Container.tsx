/**
 * Container Component
 * A responsive container component that matches Tailwind's container utility
 * Sets max-width at each breakpoint without automatic centering or padding
 *
 * @example
 * ```tsx
 * import { Container } from '@odyssee/components';
 *
 * // Basic container (needs mx-auto to center)
 * <Container>
 *   <p>Content</p>
 * </Container>
 *
 * // Centered container
 * <Container centered>
 *   <p>Centered content</p>
 * </Container>
 *
 * // With padding
 * <Container centered padding="md">
 *   <p>Centered with padding</p>
 * </Container>
 *
 * // Responsive container (only container at md breakpoint and up)
 * <Container breakpoint="md">
 *   <p>Fluid until md, then container</p>
 * </Container>
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Container props
 */
export interface ContainerProps extends BaseComponentProps {
  /** Content to render inside container */
  children?: Pulse.JSX.Element | Pulse.JSX.Element[] | string;

  /** Center the container (applies mx-auto) */
  centered?: boolean;

  /** Add horizontal padding */
  padding?: "none" | "sm" | "md" | "lg" | "xl" | "2xl";

  /** Apply container only at specific breakpoint and up */
  breakpoint?: "sm" | "md" | "lg" | "xl" | "2xl";

  /** Use fluid container (no max-width constraints) */
  fluid?: boolean;
}

/**
 * Container Component
 * Follows Tailwind's container utility pattern
 *
 * Breakpoints:
 * - sm (640px): max-width: 640px (40rem)
 * - md (768px): max-width: 768px (48rem)
 * - lg (1024px): max-width: 1024px (64rem)
 * - xl (1280px): max-width: 1280px (80rem)
 * - 2xl (1536px): max-width: 1536px (96rem)
 *
 * @example
 * ```tsx
 * <Container centered padding="md">
 *   <h1>Welcome</h1>
 *   <p>This content is centered and has padding</p>
 * </Container>
 * ```
 */
export const Container: Pulse.Fn<ContainerProps> = (props) => {
  const {
    children,
    centered = false,
    padding = "none",
    breakpoint,
    fluid = false,
    className,
    id = generateId("container"),
    style,
    ...rest
  } = props;

  // Padding classes
  const paddingClasses = {
    none: "",
    sm: "px-4",
    md: "px-6",
    lg: "px-8",
    xl: "px-12",
    "2xl": "px-16",
  };

  // Breakpoint-specific container classes
  const breakpointClasses = {
    sm: "sm:container",
    md: "md:container",
    lg: "lg:container",
    xl: "xl:container",
    "2xl": "2xl:container",
  };

  // Container classes
  const containerClasses = cn(
    // Base container class (unless breakpoint-specific or fluid)
    !breakpoint && !fluid && "container",

    // Breakpoint-specific container
    breakpoint && breakpointClasses[breakpoint],

    // Fluid container (full width)
    fluid && "w-full",

    // Centering
    centered && "mx-auto",

    // Padding
    paddingClasses[padding],

    className,
  );

  return (
    <div id={id} class={containerClasses} style={style} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * CenteredContainer - Container with automatic centering
 */
export const CenteredContainer: Pulse.Fn<ContainerProps> = (props) => {
  return <Container {...props} centered={true} />;
};

/**
 * FluidContainer - Full width container
 */
export const FluidContainer: Pulse.Fn<ContainerProps> = (props) => {
  return <Container {...props} fluid={true} />;
};

export default Container;
