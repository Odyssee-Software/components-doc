/**
 * DatePicker Component
 * A comprehensive date picker with single/range selection, time picker, and localization
 *
 * Features:
 * - Single date selection
 * - Date range selection
 * - Optional time picker (12h/24h format)
 * - Min/max date constraints
 * - Disabled dates
 * - Localization support
 * - Keyboard navigation
 *
 * @example
 * ```tsx
 * import { DatePicker } from '@odyssee/components';
 *
 * // Basic single date picker
 * <DatePicker value={dateSignal} onChange={handleDateChange} />
 *
 * // Range picker
 * <DatePicker mode="range" rangeStart={startSignal} rangeEnd={endSignal} onRangeChange={handleRangeChange} />
 *
 * // With time picker
 * <DatePicker showTime timeFormat="12h" onChange={handleDateTimeChange} />
 *
 * // With constraints
 * <DatePicker minDate={new Date()} maxDate={futureDate} disabledDates={holidays} />
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId, isSignal } from "../../utils";
import type { DatePickerProps } from "../../types";

/**
 * Default month names (English)
 */
const DEFAULT_MONTH_NAMES = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

/**
 * Default day names (English, Monday first)
 */
const DEFAULT_DAY_NAMES = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];

/**
 * Default day names (English, Sunday first)
 */
const DEFAULT_DAY_NAMES_SUNDAY_FIRST = [
  "Su",
  "Mo",
  "Tu",
  "We",
  "Th",
  "Fr",
  "Sa",
];

/**
 * Date utility functions
 */
const DateUtils = {
  /**
   * Get days in month
   */
  getDaysInMonth(year: number, month: number): number {
    return new Date(year, month + 1, 0).getDate();
  },

  /**
   * Get first day of month (0 = Sunday, 1 = Monday, ...)
   */
  getFirstDayOfMonth(
    year: number,
    month: number,
    firstDayOfWeek: 0 | 1 = 1,
  ): number {
    let day = new Date(year, month, 1).getDay();
    // Adjust for Monday first (1) vs Sunday first (0)
    if (firstDayOfWeek === 1) {
      day = day === 0 ? 6 : day - 1;
    }
    return day;
  },

  /**
   * Check if two dates are the same day
   */
  isSameDay(date1: Date | null, date2: Date | null): boolean {
    if (!date1 || !date2) return false;
    return (
      date1.getFullYear() === date2.getFullYear() &&
      date1.getMonth() === date2.getMonth() &&
      date1.getDate() === date2.getDate()
    );
  },

  /**
   * Check if date is between two dates (inclusive)
   */
  isBetween(date: Date, start: Date | null, end: Date | null): boolean {
    if (!start || !end) return false;
    const time = date.getTime();
    return time >= start.getTime() && time <= end.getTime();
  },

  /**
   * Check if date is disabled
   */
  isDisabled(
    date: Date,
    minDate?: Date,
    maxDate?: Date,
    disabledDates?: Date[] | ((date: Date) => boolean),
  ): boolean {
    if (minDate && date < minDate) return true;
    if (maxDate && date > maxDate) return true;

    if (disabledDates) {
      if (typeof disabledDates === "function") {
        return disabledDates(date);
      }
      return disabledDates.some((d) => DateUtils.isSameDay(d, date));
    }

    return false;
  },

  /**
   * Format date to ISO string (YYYY-MM-DD)
   */
  toISODate(date: Date): string {
    return date.toISOString().split("T")[0];
  },

  /**
   * Clone date
   */
  clone(date: Date): Date {
    return new Date(date.getTime());
  },
};

/**
 * Chevron Left Icon
 */
const ChevronLeftIcon: Pulse.Fn = () =>
  (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * Chevron Right Icon
 */
const ChevronRightIcon: Pulse.Fn = () =>
  (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * DatePicker component
 */
export const DatePicker: Pulse.Fn<DatePickerProps> = (props) => {
  const {
    value,
    defaultValue,
    mode = "single",
    rangeStart,
    rangeEnd,
    showTime = false,
    timeFormat = "12h",
    minDate,
    maxDate,
    disabledDates,
    showFooter = mode === "range",
    showWeekNumbers = false,
    firstDayOfWeek = 1,
    locale = "en-US",
    monthNames = DEFAULT_MONTH_NAMES,
    dayNames = firstDayOfWeek === 1
      ? DEFAULT_DAY_NAMES
      : DEFAULT_DAY_NAMES_SUNDAY_FIRST,
    onChange,
    onRangeChange,
    onCancel,
    onApply,
    className,
    id = generateId("datepicker"),
    style,
    ...rest
  } = props;

  // Initialize dates
  const now = new Date();
  const initialDate = defaultValue || now;

  // Internal state for single mode
  const internalValue = Pulse.signal<Date | null>(initialDate);
  const selectedDate = value
    ? isSignal(value)
      ? (value as any)
      : Pulse.signal(value)
    : internalValue;

  // Internal state for range mode
  const internalRangeStart = Pulse.signal<Date | null>(null);
  const internalRangeEnd = Pulse.signal<Date | null>(null);

  const rangeStartDate = rangeStart
    ? isSignal(rangeStart)
      ? (rangeStart as any)
      : Pulse.signal(rangeStart)
    : internalRangeStart;

  const rangeEndDate = rangeEnd
    ? isSignal(rangeEnd)
      ? (rangeEnd as any)
      : Pulse.signal(rangeEnd)
    : internalRangeEnd;

  // Current viewing month/year
  const currentMonth = Pulse.signal(initialDate.getMonth());
  const currentYear = Pulse.signal(initialDate.getFullYear());

  // Time state (for time picker)
  const currentHour = Pulse.signal(
    initialDate.getHours() % (timeFormat === "12h" ? 12 : 24) ||
      (timeFormat === "12h" ? 12 : 0),
  );
  const currentMinute = Pulse.signal(initialDate.getMinutes());
  const currentPeriod = Pulse.signal<"AM" | "PM">(
    initialDate.getHours() >= 12 ? "PM" : "AM",
  );

  // Range selection state
  const isSelectingRange = Pulse.signal(false);

  /**
   * Get current date or null
   */
  const getCurrentDate = (): Date | null => {
    if (mode === "single") {
      return isSignal(selectedDate) ? (selectedDate as any)() : selectedDate;
    }
    return null;
  };

  /**
   * Get current range dates
   */
  const getCurrentRange = (): { start: Date | null; end: Date | null } => {
    if (mode === "range") {
      return {
        start: isSignal(rangeStartDate)
          ? (rangeStartDate as any)()
          : rangeStartDate,
        end: isSignal(rangeEndDate) ? (rangeEndDate as any)() : rangeEndDate,
      };
    }
    return { start: null, end: null };
  };

  /**
   * Navigate to previous month
   */
  const handlePrevMonth = () => {
    const month = currentMonth();
    const year = currentYear();

    if (month === 0) {
      currentMonth(11);
      currentYear(year - 1);
    } else {
      currentMonth(month - 1);
    }
  };

  /**
   * Navigate to next month
   */
  const handleNextMonth = () => {
    const month = currentMonth();
    const year = currentYear();

    if (month === 11) {
      currentMonth(0);
      currentYear(year + 1);
    } else {
      currentMonth(month + 1);
    }
  };

  /**
   * Handle month change
   */
  const handleMonthChange = (value: string | number) => {
    currentMonth(Number(value));
  };

  /**
   * Handle year change
   */
  const handleYearChange = (value: string | number) => {
    currentYear(Number(value));
  };

  /**
   * Handle day click
   */
  const handleDayClick = (date: Date) => {
    if (DateUtils.isDisabled(date, minDate, maxDate, disabledDates)) {
      return;
    }

    if (mode === "single") {
      // Single mode: set the date with time
      if (showTime) {
        const hour =
          timeFormat === "12h"
            ? (currentHour() % 12) + (currentPeriod() === "PM" ? 12 : 0)
            : currentHour();
        date.setHours(hour, currentMinute(), 0, 0);
      }

      if (isSignal(selectedDate)) {
        (selectedDate as any)(date);
      }

      if (onChange) {
        onChange(date);
      }
    } else {
      // Range mode
      const range = getCurrentRange();

      if (!range.start || (range.start && range.end)) {
        // Start new range
        if (isSignal(rangeStartDate)) {
          (rangeStartDate as any)(date);
        }
        if (isSignal(rangeEndDate)) {
          (rangeEndDate as any)(null);
        }
        isSelectingRange(true);
      } else if (range.start && !range.end) {
        // Complete range
        if (date < range.start) {
          // Swap if end is before start
          if (isSignal(rangeEndDate)) {
            (rangeEndDate as any)(range.start);
          }
          if (isSignal(rangeStartDate)) {
            (rangeStartDate as any)(date);
          }
        } else {
          if (isSignal(rangeEndDate)) {
            (rangeEndDate as any)(date);
          }
        }
        isSelectingRange(false);
      }
    }
  };

  /**
   * Handle cancel (range mode)
   */
  const handleCancel = () => {
    if (isSignal(rangeStartDate)) {
      (rangeStartDate as any)(null);
    }
    if (isSignal(rangeEndDate)) {
      (rangeEndDate as any)(null);
    }
    isSelectingRange(false);

    if (onCancel) {
      onCancel();
    }
  };

  /**
   * Handle apply (range mode)
   */
  const handleApply = () => {
    const range = getCurrentRange();

    if (onRangeChange && range.start && range.end) {
      onRangeChange(range.start, range.end);
    }

    if (onApply) {
      onApply();
    }
  };

  /**
   * Render calendar days
   */
  const renderCalendarDays = () => {
    const month = currentMonth();
    const year = currentYear();
    const daysInMonth = DateUtils.getDaysInMonth(year, month);
    const firstDay = DateUtils.getFirstDayOfMonth(year, month, firstDayOfWeek);
    const prevMonthDays = DateUtils.getDaysInMonth(year, month - 1);

    const currentDate = getCurrentDate();
    const range = getCurrentRange();

    const weeks: Pulse.JSX.Element[] = [];
    let days: Pulse.JSX.Element[] = [];

    // Previous month days (disabled)
    for (let i = firstDay - 1; i >= 0; i--) {
      const day = prevMonthDays - i;

      days.push(
        <div>
          <button
            type="button"
            class="m-px size-10 flex justify-center items-center border-[1.5px] border-transparent text-sm text-gray-800 rounded-full hover:border-blue-600 hover:text-blue-600 disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:border-blue-600 focus:text-blue-600 dark:text-neutral-200 dark:hover:border-blue-500 dark:hover:text-blue-500 dark:focus:border-blue-500 dark:focus:text-blue-500"
            disabled
          >
            {day}
          </button>
        </div>,
      );
    }

    // Current month days
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const isSelected =
        mode === "single" && DateUtils.isSameDay(date, currentDate);
      const isRangeStart =
        mode === "range" && DateUtils.isSameDay(date, range.start);
      const isRangeEnd =
        mode === "range" && DateUtils.isSameDay(date, range.end);
      const isInRange =
        mode === "range" && DateUtils.isBetween(date, range.start, range.end);
      const isDisabled = DateUtils.isDisabled(
        date,
        minDate,
        maxDate,
        disabledDates,
      );

      // Wrapper classes for range styling
      let wrapperClasses = "";
      if (mode === "range" && isInRange && !isRangeStart && !isRangeEnd) {
        wrapperClasses =
          "bg-gray-100 first:rounded-s-full last:rounded-e-full dark:bg-neutral-800";
      } else if (isRangeStart && range.end) {
        wrapperClasses = "bg-gray-100 rounded-s-full dark:bg-neutral-800";
      } else if (isRangeEnd) {
        wrapperClasses = "bg-gray-100 rounded-e-full dark:bg-neutral-800";
      }

      const buttonClasses = cn(
        "m-px size-10 flex justify-center items-center text-sm rounded-full",
        "disabled:opacity-50 disabled:pointer-events-none",
        "focus:outline-hidden",
        isSelected || isRangeStart || isRangeEnd
          ? "bg-blue-600 border-[1.5px] border-transparent font-medium text-white hover:border-blue-600 dark:bg-blue-500"
          : "border-[1.5px] border-transparent text-gray-800 hover:border-blue-600 hover:text-blue-600 focus:border-blue-600 focus:text-blue-600 dark:text-neutral-200 dark:hover:border-blue-500 dark:hover:text-blue-500 dark:focus:border-blue-500 dark:focus:text-blue-500",
      );

      days.push(
        <div class={wrapperClasses}>
          <button
            type="button"
            class={buttonClasses}
            disabled={isDisabled}
            onClick={() => handleDayClick(date)}
          >
            {day}
          </button>
        </div>,
      );

      // Create new week row
      if (days.length === 7) {
        weeks.push(<div class="flex">{days}</div>);
        days = [];
      }
    }

    // Next month days (disabled) to fill the last week
    if (days.length > 0) {
      const remainingDays = 7 - days.length;
      for (let i = 1; i <= remainingDays; i++) {
        days.push(
          <div>
            <button
              type="button"
              class="m-px size-10 flex justify-center items-center border-[1.5px] border-transparent text-sm text-gray-800 hover:border-blue-600 hover:text-blue-600 rounded-full disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:bg-gray-100 dark:text-neutral-200 dark:hover:border-neutral-500 dark:focus:bg-neutral-700"
              disabled
            >
              {i}
            </button>
          </div>,
        );
      }
      weeks.push(<div class="flex">{days}</div>);
    }

    return weeks;
  };

  /**
   * Render time picker
   */
  const renderTimePicker = () => {
    if (!showTime) return null;

    // Generate hour options
    const hours = Array.from(
      { length: timeFormat === "12h" ? 12 : 24 },
      (_, i) => (timeFormat === "12h" ? i + 1 : i),
    );

    // Generate minute options
    const minutes = Array.from({ length: 60 }, (_, i) => i);

    return (
      <div class="pt-3 flex justify-center items-center gap-x-2">
        {/* Hour select */}
        <div class="relative">
          <select
            class="py-1 px-2 pe-6 block w-full cursor-pointer bg-white border border-gray-200 rounded-lg text-start text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400"
            value={currentHour()}
            onChange={(e: Event) => {
              const target = e.target as HTMLSelectElement;
              currentHour(Number(target.value));
            }}
          >
            {hours.map((h) => (
              <option value={h}>
                {timeFormat === "12h" ? h : String(h).padStart(2, "0")}
              </option>
            ))}
          </select>
          <div class="absolute top-1/2 end-2 -translate-y-1/2 pointer-events-none">
            <svg
              class="shrink-0 size-3 text-gray-500 dark:text-neutral-500"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="m7 15 5 5 5-5" />
              <path d="m7 9 5-5 5 5" />
            </svg>
          </div>
        </div>

        <span class="text-gray-800 dark:text-white">:</span>

        {/* Minute select */}
        <div class="relative">
          <select
            class="py-1 px-2 pe-6 block w-full cursor-pointer bg-white border border-gray-200 rounded-lg text-start text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400"
            value={currentMinute()}
            onChange={(e: Event) => {
              const target = e.target as HTMLSelectElement;
              currentMinute(Number(target.value));
            }}
          >
            {minutes.map((m) => (
              <option value={m}>{String(m).padStart(2, "0")}</option>
            ))}
          </select>
          <div class="absolute top-1/2 end-2 -translate-y-1/2 pointer-events-none">
            <svg
              class="shrink-0 size-3 text-gray-500 dark:text-neutral-500"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2.5"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="m7 15 5 5 5-5" />
              <path d="m7 9 5-5 5 5" />
            </svg>
          </div>
        </div>

        {/* AM/PM select (12h format only) */}
        {timeFormat === "12h" && (
          <div class="relative">
            <select
              class="py-1 px-2 pe-6 block w-full cursor-pointer bg-white border border-gray-200 rounded-lg text-start text-sm focus:border-blue-500 focus:ring-blue-500 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-400"
              value={currentPeriod()}
              onChange={(e: Event) => {
                const target = e.target as HTMLSelectElement;
                currentPeriod(target.value as "AM" | "PM");
              }}
            >
              <option value="AM">AM</option>
              <option value="PM">PM</option>
            </select>
            <div class="absolute top-1/2 end-2 -translate-y-1/2 pointer-events-none">
              <svg
                class="shrink-0 size-3 text-gray-500 dark:text-neutral-500"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2.5"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="m7 15 5 5 5-5" />
                <path d="m7 9 5-5 5 5" />
              </svg>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Generate year options (current year ± 10 years)
  const currentYearValue = currentYear();
  const yearOptions = Array.from({ length: 21 }, (_, i) => ({
    value: currentYearValue - 10 + i,
    label: String(currentYearValue - 10 + i),
  }));

  // Generate month options
  const monthOptions = monthNames.map((name, index) => ({
    value: index,
    label: name,
  }));

  // Container classes
  const containerClasses = cn(
    "w-80 flex flex-col bg-white border border-gray-200 shadow-lg rounded-xl overflow-hidden",
    "dark:bg-neutral-900 dark:border-neutral-700",
    className,
  );

  return (
    <div id={id} class={containerClasses} style={style} {...rest}>
      {/* Calendar */}
      <div class="p-3 space-y-0.5">
        {/* Header: Month/Year navigation */}
        <div class="grid grid-cols-5 items-center gap-x-3 mx-1.5 pb-3">
          {/* Prev Button */}
          <div class="col-span-1">
            <button
              type="button"
              class="size-8 flex justify-center items-center text-gray-800 hover:bg-gray-100 rounded-full disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
              aria-label="Previous"
              onClick={handlePrevMonth}
            >
              <ChevronLeftIcon />
            </button>
          </div>

          {/* Month / Year */}
          <div class="col-span-3 flex justify-center items-center gap-x-1">
            {/* Month select */}
            <div class="relative">
              <select
                class="py-1 px-2 pe-6 block w-full cursor-pointer font-medium text-gray-800 hover:text-blue-600 focus:outline-hidden focus:text-blue-600 dark:text-neutral-200 dark:hover:text-blue-500 dark:focus:text-blue-500 bg-transparent border-none"
                value={currentMonth()}
                onChange={(e: Event) => {
                  const target = e.target as HTMLSelectElement;
                  handleMonthChange(target.value);
                }}
              >
                {monthOptions.map((option) => (
                  <option value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>

            <span class="text-gray-800 dark:text-neutral-200">/</span>

            {/* Year select */}
            <div class="relative">
              <select
                class="py-1 px-2 pe-6 block w-full cursor-pointer font-medium text-gray-800 hover:text-blue-600 focus:outline-hidden focus:text-blue-600 dark:text-neutral-200 dark:hover:text-blue-500 dark:focus:text-blue-500 bg-transparent border-none"
                value={currentYear()}
                onChange={(e: Event) => {
                  const target = e.target as HTMLSelectElement;
                  handleYearChange(target.value);
                }}
              >
                {yearOptions.map((option) => (
                  <option value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Next Button */}
          <div class="col-span-1 flex justify-end">
            <button
              type="button"
              class="size-8 flex justify-center items-center text-gray-800 hover:bg-gray-100 rounded-full disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
              aria-label="Next"
              onClick={handleNextMonth}
            >
              <ChevronRightIcon />
            </button>
          </div>
        </div>

        {/* Day names */}
        <div class="flex pb-1.5">
          {dayNames.map((day) => (
            <span class="m-px w-10 block text-center text-sm text-gray-500 dark:text-neutral-500">
              {day}
            </span>
          ))}
        </div>

        {/* Calendar days */}
        {renderCalendarDays()}

        {/* Time picker */}
        {renderTimePicker()}
      </div>

      {/* Footer (for range picker) */}
      {showFooter && (
        <div class="py-3 px-4 flex items-center justify-end gap-x-2 border-t border-gray-200 dark:border-neutral-700">
          <button
            type="button"
            class="py-2 px-3 inline-flex items-center gap-x-2 text-xs font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-sm hover:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:bg-gray-50 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300 dark:hover:bg-neutral-700 dark:focus:bg-neutral-700"
            onClick={handleCancel}
          >
            Cancel
          </button>
          <button
            type="button"
            class="py-2 px-3 inline-flex justify-center items-center gap-x-2 text-xs font-medium rounded-lg border-[1.5px] border-transparent bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 disabled:pointer-events-none focus:outline-hidden focus:ring-2 focus:ring-blue-500"
            onClick={handleApply}
          >
            Apply
          </button>
        </div>
      )}
    </div>
  ) as Pulse.JSX.Element;
};
