/**
 * Alert Component
 * A notification component for displaying important messages with multiple variants and colors
 *
 * @example
 * ```tsx
 * import { Alert } from '@odyssee/components';
 *
 * // Basic alert
 * <Alert variant="solid" color="info">This is an info alert!</Alert>
 *
 * // With title and description
 * <Alert variant="soft" color="success" title="Successfully updated">
 *   You have successfully updated your email preferences.
 * </Alert>
 *
 * // With icon
 * <Alert variant="bordered" color="danger" icon="⚠️" title="Error!">
 *   Your purchase has been declined.
 * </Alert>
 *
 * // With list
 * <Alert variant="soft" color="danger" title="A problem has occurred">
 *   <ul>
 *     <li>This username is already in use</li>
 *     <li>Email field can't be empty</li>
 *     <li>Please enter a valid phone number</li>
 *   </ul>
 * </Alert>
 *
 * // Dismissible alert
 * const isVisible = Pulse.signal(true);
 * <Alert
 *   variant="solid"
 *   color="success"
 *   dismissible={true}
 *   isVisible={isVisible}
 *   onDismiss={() => isVisible(false)}
 * >
 *   File has been successfully uploaded.
 * </Alert>
 *
 * // With actions
 * <Alert
 *   variant="soft"
 *   color="primary"
 *   title="YouTube would like to send notifications"
 *   actions={
 *     <>
 *       <button>Don't allow</button>
 *       <button>Allow</button>
 *     </>
 *   }
 * >
 *   Notifications may include alerts, sounds and icon badges.
 * </Alert>
 * ```
 */

import Pulse from "pulse-framework";
import type { AlertProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Alert: Pulse.Fn<AlertProps> = (props) => {
  const {
    variant = "soft",
    color = "primary",
    title,
    children,
    icon,
    dismissible = false,
    isVisible = true,
    actions,
    onDismiss,
    className,
    id = generateId("alert"),
    ...rest
  } = props;

  // Variant color classes
  const variantColorClasses = {
    solid: {
      primary: "bg-primary-600 text-white border-primary-600",
      secondary: "bg-gray-600 text-white border-gray-600",
      info: "bg-blue-600 text-white border-blue-600",
      success: "bg-green-600 text-white border-green-600",
      danger: "bg-red-600 text-white border-red-600",
      warning: "bg-yellow-500 text-white border-yellow-500",
      light: "bg-gray-100 text-gray-800 border-gray-100",
      dark: "bg-gray-900 text-white border-gray-900",
    },
    soft: {
      primary:
        "bg-primary-50 text-primary-800 border-primary-200 dark:bg-primary-900/10 dark:text-primary-500 dark:border-primary-900",
      secondary:
        "bg-gray-50 text-gray-800 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      info: "bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-900/10 dark:text-blue-500 dark:border-blue-900",
      success:
        "bg-green-50 text-green-800 border-green-200 dark:bg-green-900/10 dark:text-green-500 dark:border-green-900",
      danger:
        "bg-red-50 text-red-800 border-red-200 dark:bg-red-900/10 dark:text-red-500 dark:border-red-900",
      warning:
        "bg-yellow-50 text-yellow-800 border-yellow-200 dark:bg-yellow-900/10 dark:text-yellow-500 dark:border-yellow-900",
      light:
        "bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      dark: "bg-gray-800 text-gray-200 border-gray-700 dark:bg-gray-900 dark:text-gray-300 dark:border-gray-800",
    },
    bordered: {
      primary:
        "bg-white text-primary-800 border-primary-300 dark:bg-gray-800 dark:text-primary-400 dark:border-primary-800",
      secondary:
        "bg-white text-gray-800 border-gray-300 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      info: "bg-white text-blue-800 border-blue-300 dark:bg-gray-800 dark:text-blue-400 dark:border-blue-800",
      success:
        "bg-white text-green-800 border-green-300 dark:bg-gray-800 dark:text-green-400 dark:border-green-800",
      danger:
        "bg-white text-red-800 border-red-300 dark:bg-gray-800 dark:text-red-400 dark:border-red-800",
      warning:
        "bg-white text-yellow-800 border-yellow-300 dark:bg-gray-800 dark:text-yellow-400 dark:border-yellow-800",
      light:
        "bg-white text-gray-600 border-gray-200 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700",
      dark: "bg-white text-gray-800 border-gray-800 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600",
    },
  };

  // Icon color classes (for soft variant)
  const iconColorClasses = {
    primary: "text-primary-600 dark:text-primary-400",
    secondary: "text-gray-600 dark:text-gray-400",
    info: "text-blue-600 dark:text-blue-400",
    success: "text-green-600 dark:text-green-400",
    danger: "text-red-600 dark:text-red-400",
    warning: "text-yellow-600 dark:text-yellow-400",
    light: "text-gray-500 dark:text-gray-400",
    dark: "text-gray-700 dark:text-gray-300",
  };

  // Get reactive visibility value
  const visible = () =>
    isSignal(isVisible) ? (isVisible as any)() : isVisible;

  return (
    <div
      id={id}
      role="alert"
      class={cn(
        "flex p-4 border rounded-lg transition-all duration-200",
        variantColorClasses[variant][color],
        !visible() && "hidden",
        className,
      )}
      {...rest}
    >
      {icon && (
        <div class="flex-shrink-0">
          <span
            class={cn(
              "inline-flex items-center justify-center text-lg",
              variant === "soft" ? iconColorClasses[color] : "",
            )}
          >
            {icon}
          </span>
        </div>
      )}

      <div class="flex-1 ms-3">
        {title && <h3 class="text-sm font-semibold mb-1">{title}</h3>}

        {children && <div class="text-sm">{children}</div>}

        {actions && <div class="flex items-center gap-2 mt-3">{actions}</div>}
      </div>

      {dismissible && (
        <button
          type="button"
          class={cn(
            "inline-flex flex-shrink-0 justify-center items-center w-5 h-5 rounded-lg opacity-50 hover:opacity-100 focus:outline-none focus:opacity-100 transition",
            variant === "solid" ? "text-white" : "",
          )}
          aria-label="Close"
          onClick={onDismiss}
        >
          <svg class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 20 20">
            <path
              fill-rule="evenodd"
              d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
              clip-rule="evenodd"
            />
          </svg>
        </button>
      )}
    </div>
  ) as Pulse.JSX.Element;
};
