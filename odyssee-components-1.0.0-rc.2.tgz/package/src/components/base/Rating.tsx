/**
 * Rating Component
 * A versatile rating component with stars, hearts, emojis, and custom symbols
 * Supports both interactive and read-only modes
 *
 * @example
 * ```tsx
 * import { Rating } from '@odyssee/components';
 *
 * // Basic interactive rating (stars)
 * <Rating value={3} max={5} onChange={(val) => console.log(val)} />
 *
 * // Read-only display
 * <Rating value={4} max={5} mode="readonly" />
 *
 * // Different sizes
 * <Rating value={3} size="sm" />
 * <Rating value={3} size="md" /> // default
 * <Rating value={3} size="lg" />
 *
 * // Hearts
 * <Rating value={3} max={5} symbol="heart" color="red" />
 *
 * // Emoji rating (different emoji per value)
 * <Rating
 *   value={2}
 *   max={3}
 *   symbol="emoji"
 *   customSymbol={["😔", "😐️", "🤩"]}
 * />
 *
 * // Custom SVG symbol
 * <Rating
 *   value={3}
 *   max={5}
 *   symbol="custom"
 *   customSymbol={<MyCustomIcon />}
 * />
 *
 * // With label
 * <Rating
 *   value={3}
 *   max={5}
 *   showLabel
 *   label="Rate this product"
 * />
 *
 * // Reactive with Pulse Signal
 * const rating = Pulse.signal(0);
 * <Rating value={rating} max={5} onChange={(val) => rating(val)} />
 *
 * // Disabled
 * <Rating value={3} max={5} disabled />
 *
 * // Thumbs (Yes/No feedback)
 * <Rating value={1} max={2} symbol="thumbs" />
 * ```
 */

import Pulse from "pulse-framework";
import type { RatingProps } from "../../types";
import { cn, generateId, isSignal } from "../../utils";

export const Rating: Pulse.Fn<RatingProps> = (props) => {
  const {
    value: valueProp = 0,
    max = 5,
    mode = "interactive",
    onChange,
    symbol = "star",
    customSymbol,
    size = "md",
    color,
    inactiveColor,
    showLabel = false,
    label,
    name,
    disabled = false,
    required = false,
    className,
    id = generateId("rating"),
    style,
    ...rest
  } = props;

  // Internal state for hover effect
  const hoveredIndex = Pulse.signal(0);

  // Get current value (support both Signal and number)
  const getCurrentValue = () => {
    return isSignal(valueProp) ? (valueProp as any)() : valueProp;
  };

  // Handle click
  const handleClick = (newValue: number) => {
    if (mode === "readonly" || disabled) return;

    if (onChange) {
      onChange(newValue);
    }
  };

  // Handle mouse enter
  const handleMouseEnter = (index: number) => {
    if (mode === "readonly" || disabled) return;
    hoveredIndex(index);
  };

  // Handle mouse leave
  const handleMouseLeave = () => {
    if (mode === "readonly" || disabled) return;
    hoveredIndex(0);
  };

  // Size classes
  const sizeClasses = {
    sm: "size-4",
    md: "size-5",
    lg: "size-6",
  };

  // Get default colors based on symbol
  const getDefaultColor = () => {
    if (color) return color;

    switch (symbol) {
      case "heart":
        return "red-500";
      case "star":
      default:
        return "yellow-400";
    }
  };

  const getDefaultInactiveColor = () => {
    if (inactiveColor) return inactiveColor;
    return "gray-300";
  };

  // Get color classes for an item
  const getColorClasses = (isActive: boolean) => {
    const activeColor = getDefaultColor();
    const inactive = getDefaultInactiveColor();

    if (isActive) {
      return `text-${activeColor} dark:text-${activeColor.replace("400", "600")}`;
    }
    return `text-${inactive} dark:text-neutral-600`;
  };

  // Star SVG
  const StarIcon = () => (
    <svg
      class={cn("shrink-0", sizeClasses[size])}
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
    </svg>
  );

  // Heart SVG
  const HeartIcon = () => (
    <svg
      class={cn("shrink-0", sizeClasses[size])}
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path
        fill-rule="evenodd"
        d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z"
      ></path>
    </svg>
  );

  // Thumbs Up SVG
  const ThumbsUpIcon = () => (
    <svg
      class={cn("shrink-0", sizeClasses[size])}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M7 10v12"></path>
      <path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2h0a3.13 3.13 0 0 1 3 3.88Z"></path>
    </svg>
  );

  // Thumbs Down SVG
  const ThumbsDownIcon = () => (
    <svg
      class={cn("shrink-0", sizeClasses[size])}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M17 14V2"></path>
      <path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22h0a3.13 3.13 0 0 1-3-3.88Z"></path>
    </svg>
  );

  // Render symbol based on type
  const renderSymbol = (index: number) => {
    switch (symbol) {
      case "star":
        return <StarIcon />;
      case "heart":
        return <HeartIcon />;
      case "emoji":
        if (Array.isArray(customSymbol)) {
          return <span class="text-2xl">{customSymbol[index] || "⭐"}</span>;
        }
        return <span class="text-2xl">⭐</span>;
      case "thumbs":
        return index === 0 ? <ThumbsUpIcon /> : <ThumbsDownIcon />;
      case "custom":
        if (Array.isArray(customSymbol)) {
          return customSymbol[index];
        }
        return customSymbol;
      default:
        return <StarIcon />;
    }
  };

  // Render interactive rating
  if (mode === "interactive") {
    return (
      <div
        id={id}
        class={cn("flex items-center", className)}
        style={style}
        role="radiogroup"
        aria-label={label || "Rating"}
        aria-required={required}
        {...rest}
      >
        {showLabel && label && (
          <span class="mr-2 text-sm font-medium text-gray-800 dark:text-white">
            {label}
          </span>
        )}
        <div class="flex items-center gap-x-1">
          {Array.from({ length: max }).map((_, index) => {
            const itemValue = index + 1;
            const currentValue = getCurrentValue();
            const hovered = hoveredIndex();
            const isActive = itemValue <= currentValue;
            const isHovered = hovered > 0 && itemValue <= hovered;
            const shouldHighlight = isActive || isHovered;

            return (
              <button
                key={index}
                type="button"
                disabled={disabled}
                onMouseEnter={() => handleMouseEnter(itemValue)}
                onMouseLeave={handleMouseLeave}
                onClick={() => handleClick(itemValue)}
                class={cn(
                  "inline-flex justify-center items-center rounded-full transition-colors",
                  "focus:outline-none",
                  sizeClasses[size],
                  getColorClasses(shouldHighlight),
                  !shouldHighlight &&
                    !disabled &&
                    mode === "interactive" &&
                    `dark:hover:text-${getDefaultColor()}`,
                  disabled &&
                    "opacity-50 cursor-not-allowed pointer-events-none",
                )}
                aria-label={`Rate ${itemValue} out of ${max}`}
                aria-checked={itemValue === currentValue}
                role="radio"
              >
                {renderSymbol(index)}
              </button>
            );
          })}
        </div>
        {name && (
          <input
            type="hidden"
            name={name}
            value={getCurrentValue()}
            required={required}
          />
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render readonly rating
  return (
    <div
      id={id}
      class={cn("flex items-center", className)}
      style={style}
      role="img"
      aria-label={`Rating: ${getCurrentValue()} out of ${max}`}
      {...rest}
    >
      {showLabel && label && (
        <span class="mr-2 text-sm font-medium text-gray-800 dark:text-white">
          {label}
        </span>
      )}
      <div class="flex items-center gap-x-1">
        {Array.from({ length: max }).map((_, index) => {
          const itemValue = index + 1;
          const isActive = itemValue <= getCurrentValue();

          return (
            <div
              key={index}
              class={cn(
                "inline-flex justify-center items-center",
                sizeClasses[size],
                getColorClasses(isActive),
              )}
            >
              {renderSymbol(index)}
            </div>
          );
        })}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

export default Rating;
