/**
 * Device Component
 * A component for displaying mobile and browser device mockups with screenshots
 *
 * Features:
 * - Mobile device frame with rounded corners and shadows
 * - Browser frame with navigation bar and macOS-style controls
 * - Support for images or custom content
 * - Dark mode support
 * - Customizable alignment and sizing
 */

import Pulse from "pulse-framework";
import type { DeviceProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Device: Pulse.Fn<DeviceProps> = (props) => {
  const {
    variant,
    src,
    alt = "Device screenshot",
    children,
    url = "www.preline.com",
    showControls = true,
    maxWidth,
    align = "center",
    className,
    imageClassName,
    frameClassName,
    id = generateId("device"),
    style,
    ...rest
  } = props;

  // Alignment classes
  const alignmentClasses = {
    left: "mr-auto",
    center: "mx-auto",
    right: "ml-auto",
  };

  // Mobile device mockup
  if (variant === "mobile") {
    const mobileMaxWidth = maxWidth || "w-60";

    return (
      <figure
        id={id}
        class={cn(
          "max-w-full h-auto",
          mobileMaxWidth,
          alignmentClasses[align],
          className,
        )}
        style={style}
        {...rest}
      >
        <div
          class={cn(
            "p-1.5 bg-gray-800 rounded-3xl",
            "shadow-[0_2.75rem_5.5rem_-3.5rem_rgb(45_55_75_/_20%),_0_2rem_4rem_-2rem_rgb(45_55_75_/_30%),_inset_0_-0.1875rem_0.3125rem_0_rgb(45_55_75_/_20%)]",
            "dark:bg-neutral-600",
            "dark:shadow-[0_2.75rem_5.5rem_-3.5rem_rgb(0_0_0_/_20%),_0_2rem_4rem_-2rem_rgb(0_0_0_/_30%),_inset_0_-0.1875rem_0.3125rem_0_rgb(0_0_0_/_20%)]",
            frameClassName,
          )}
        >
          {src ? (
            <img
              class={cn(
                "max-w-full h-auto rounded-[1.25rem]",
                imageClassName,
              )}
              src={src}
              alt={alt}
            />
          ) : (
            <div class={cn("rounded-[1.25rem] overflow-hidden")}>
              {children}
            </div>
          )}
        </div>
      </figure>
    ) as Pulse.JSX.Element;
  }

  // Browser device mockup
  if (variant === "browser") {
    const browserMaxWidth = maxWidth || "max-w-3xl";

    return (
      <figure
        id={id}
        class={cn(
          "relative z-1 w-full h-auto",
          browserMaxWidth,
          alignmentClasses[align],
          "shadow-[0_2.75rem_3.5rem_-2rem_rgb(45_55_75_/_20%),_0_0_5rem_-2rem_rgb(45_55_75_/_15%)]",
          "dark:shadow-[0_2.75rem_3.5rem_-2rem_rgb(0_0_0_/_20%),_0_0_5rem_-2rem_rgb(0_0_0_/_15%)]",
          "rounded-b-lg",
          className,
        )}
        style={style}
        {...rest}
      >
        {/* Browser Navigation Bar */}
        <div
          class={cn(
            "relative flex items-center bg-gray-800 rounded-t-lg py-2 px-24",
            "dark:bg-neutral-700",
            frameClassName,
          )}
        >
          {/* macOS Controls */}
          {showControls && (
            <div class="flex gap-x-1 absolute top-2/4 start-4 -translate-y-1">
              <span class="size-2 bg-gray-600 rounded-full dark:bg-neutral-600"></span>
              <span class="size-2 bg-gray-600 rounded-full dark:bg-neutral-600"></span>
              <span class="size-2 bg-gray-600 rounded-full dark:bg-neutral-600"></span>
            </div>
          )}

          {/* URL Bar */}
          <div class="flex justify-center items-center size-full bg-gray-700 text-[.25rem] text-gray-400 rounded-sm sm:text-[.5rem] dark:bg-neutral-600 dark:text-neutral-400">
            {url}
          </div>
        </div>

        {/* Browser Content */}
        <div class="bg-gray-800 rounded-b-lg">
          {src ? (
            <img
              class={cn("max-w-full h-auto rounded-b-lg", imageClassName)}
              src={src}
              alt={alt}
            />
          ) : (
            <div class={cn("rounded-b-lg overflow-hidden")}>{children}</div>
          )}
        </div>
      </figure>
    ) as Pulse.JSX.Element;
  }

  // Fallback (should not happen with proper TypeScript)
  return null as any;
};

// Named exports for convenience
export const MobileDevice: Pulse.Fn<Omit<DeviceProps, "variant">> = (
  props,
) => {
  return <Device {...props} variant="mobile" /> as Pulse.JSX.Element;
};

export const BrowserDevice: Pulse.Fn<Omit<DeviceProps, "variant">> = (
  props,
) => {
  return <Device {...props} variant="browser" /> as Pulse.JSX.Element;
};
