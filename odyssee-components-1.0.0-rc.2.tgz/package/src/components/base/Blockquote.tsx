/**
 * Blockquote Component
 * A component for displaying quoted text with various styles and layouts
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps } from "../../types";
import { Avatar } from "./Avatar";

/**
 * Quote icon SVG component
 */
const QuoteIcon: Pulse.Fn = (): Pulse.JSX.Element => (
  <svg
    class="absolute -top-6 -start-8 size-16 text-gray-100 dark:text-neutral-700"
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M7.39762 10.3C7.39762 11.0733 7.14888 11.7 6.6514 12.18C6.15392 12.6333 5.52552 12.86 4.76621 12.86C3.84979 12.86 3.09047 12.5533 2.48825 11.94C1.91222 11.3266 1.62421 10.4467 1.62421 9.29999C1.62421 8.07332 1.96459 6.87332 2.64535 5.69999C3.35231 4.49999 4.33418 3.55332 5.59098 2.85999L6.4943 4.25999C5.81354 4.73999 5.26369 5.27332 4.84476 5.85999C4.45201 6.44666 4.19017 7.12666 4.05926 7.89999C4.29491 7.79332 4.56983 7.73999 4.88403 7.73999C5.61716 7.73999 6.21938 7.97999 6.69067 8.45999C7.16197 8.93999 7.39762 9.55333 7.39762 10.3ZM14.6242 10.3C14.6242 11.0733 14.3755 11.7 13.878 12.18C13.3805 12.6333 12.7521 12.86 11.9928 12.86C11.0764 12.86 10.3171 12.5533 9.71484 11.94C9.13881 11.3266 8.85079 10.4467 8.85079 9.29999C8.85079 8.07332 9.19117 6.87332 9.87194 5.69999C10.5789 4.49999 11.5608 3.55332 12.8176 2.85999L13.7209 4.25999C13.0401 4.73999 12.4903 5.27332 12.0713 5.85999C11.6786 6.44666 11.4168 7.12666 11.2858 7.89999C11.5215 7.79332 11.7964 7.73999 12.1106 7.73999C12.8437 7.73999 13.446 7.97999 13.9173 8.45999C14.3886 8.93999 14.6242 9.55333 14.6242 10.3Z"
      fill="currentColor"
    />
  </svg>
);

/**
 * Blockquote author info
 */
export interface BlockquoteAuthor {
  name: string;
  title?: string;
  avatar?: string;
  avatarAlt?: string;
}

/**
 * Blockquote props
 */
export interface BlockquoteProps extends BaseComponentProps {
  // Content
  quote: string | HTMLElement;
  children?: string | HTMLElement;

  // Author/Source
  author?: BlockquoteAuthor | string;

  // Size
  size?: "sm" | "md" | "lg";

  // Alignment
  align?: "left" | "center" | "right";

  // Variant
  variant?: "default" | "bordered" | "minimal";

  // Show quote icon
  showIcon?: boolean;

  // Border color (for bordered variant)
  borderColor?: string;
}

/**
 * Blockquote Component
 *
 * @example
 * ```tsx
 * // Basic blockquote
 * <Blockquote quote="I just wanted to say that I'm very happy..." />
 *
 * // With author
 * <Blockquote
 *   quote="I just wanted to say that I'm very happy..."
 *   author={{ name: "Josh Grazioso", title: "CEO" }}
 * />
 *
 * // With avatar
 * <Blockquote
 *   quote="I just wanted to say..."
 *   author={{
 *     name: "Josh Grazioso",
 *     title: "Source title",
 *     avatar: "https://..."
 *   }}
 * />
 *
 * // Bordered variant
 * <Blockquote
 *   quote="I just wanted to say..."
 *   variant="bordered"
 *   author={{ name: "Josh Grazioso" }}
 * />
 *
 * // Different sizes
 * <Blockquote quote="..." size="lg" />
 *
 * // Center aligned
 * <Blockquote quote="..." align="center" />
 * ```
 */
export const Blockquote: Pulse.Fn<BlockquoteProps> = (
  props: BlockquoteProps,
): Pulse.JSX.Element => {
  const {
    quote,
    children,
    author,
    size = "md",
    align = "left",
    variant = "default",
    showIcon = true,
    borderColor,
    className,
    id,
    style,
  } = props;

  // Size classes for text
  const sizeClasses: Record<string, string> = {
    sm: "text-base sm:text-lg",
    md: "text-gray-800 sm:text-xl dark:text-white",
    lg: "text-xl text-gray-800 md:text-3xl md:leading-normal dark:text-white",
  };

  // Alignment classes
  const alignClasses: Record<string, string> = {
    left: "text-start",
    center: "text-center max-w-lg mx-auto",
    right: "text-end",
  };

  // Container classes
  const containerClasses = cn(
    "relative",
    variant === "bordered" && "border-s-4 ps-4 sm:ps-6 dark:border-neutral-700",
    variant === "bordered" &&
      (borderColor || "border-gray-200 dark:border-neutral-700"),
    alignClasses[align],
    className,
  );

  // Render quote content
  const renderQuote = () => {
    const content = quote || children;
    const quoteText =
      typeof content === "string" ? <em>{content}</em> : <em>{content}</em>;

    if (variant === "bordered") {
      return <p class={sizeClasses[size]}>{quoteText}</p>;
    }

    if (align === "center" || align === "right") {
      return (
        <p class={sizeClasses[size]}>
          <em class="relative">
            {showIcon && (
              <svg
                class="absolute -top-8 -start-8 size-16 text-gray-100 sm:h-24 sm:w-24 dark:text-neutral-700"
                width="16"
                height="16"
                viewBox="0 0 16 16"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
              >
                <path
                  d="M7.39762 10.3C7.39762 11.0733 7.14888 11.7 6.6514 12.18C6.15392 12.6333 5.52552 12.86 4.76621 12.86C3.84979 12.86 3.09047 12.5533 2.48825 11.94C1.91222 11.3266 1.62421 10.4467 1.62421 9.29999C1.62421 8.07332 1.96459 6.87332 2.64535 5.69999C3.35231 4.49999 4.33418 3.55332 5.59098 2.85999L6.4943 4.25999C5.81354 4.73999 5.26369 5.27332 4.84476 5.85999C4.45201 6.44666 4.19017 7.12666 4.05926 7.89999C4.29491 7.79332 4.56983 7.73999 4.88403 7.73999C5.61716 7.73999 6.21938 7.97999 6.69067 8.45999C7.16197 8.93999 7.39762 9.55333 7.39762 10.3ZM14.6242 10.3C14.6242 11.0733 14.3755 11.7 13.878 12.18C13.3805 12.6333 12.7521 12.86 11.9928 12.86C11.0764 12.86 10.3171 12.5533 9.71484 11.94C9.13881 11.3266 8.85079 10.4467 8.85079 9.29999C8.85079 8.07332 9.19117 6.87332 9.87194 5.69999C10.5789 4.49999 11.5608 3.55332 12.8176 2.85999L13.7209 4.25999C13.0401 4.73999 12.4903 5.27332 12.0713 5.85999C11.6786 6.44666 11.4168 7.12666 11.2858 7.89999C11.5215 7.79332 11.7964 7.73999 12.1106 7.73999C12.8437 7.73999 13.446 7.97999 13.9173 8.45999C14.3886 8.93999 14.6242 9.55333 14.6242 10.3Z"
                  fill="currentColor"
                />
              </svg>
            )}
            <span class="relative z-10 dark:text-white">{content}</span>
          </em>
        </p>
      );
    }

    return <p class={sizeClasses[size]}>{quoteText}</p>;
  };

  // Render author/source
  const renderAuthor = () => {
    if (!author) return null;

    if (typeof author === "string") {
      return (
        <footer class="mt-6">
          <div class="text-base font-semibold text-gray-800 dark:text-neutral-400">
            {author}
          </div>
        </footer>
      );
    }

    if (author.avatar) {
      return (
        <footer class={cn("mt-6", variant === "bordered" && "mt-4")}>
          <div class="flex items-center">
            <div class="shrink-0">
              <Avatar
                src={author.avatar}
                alt={author.avatarAlt || author.name}
                name={author.name}
                size="md"
                rounded="full"
              />
            </div>
            <div class="ms-4">
              <div class="text-base font-semibold text-gray-800 dark:text-neutral-400">
                {author.name}
              </div>
              {author.title && (
                <div class="text-xs text-gray-500 dark:text-neutral-500">
                  {author.title}
                </div>
              )}
            </div>
          </div>
        </footer>
      );
    }

    return (
      <footer class="mt-6">
        <div class="text-base font-semibold text-gray-800 dark:text-neutral-400">
          {author.name}
        </div>
        {author.title && (
          <div class="text-xs text-gray-500 dark:text-neutral-500">
            {author.title}
          </div>
        )}
      </footer>
    );
  };

  return (
    <blockquote id={id} class={containerClasses} style={style}>
      {showIcon && variant === "default" && align === "left" && <QuoteIcon />}

      <div class={variant === "default" ? "relative z-10" : ""}>
        {renderQuote()}
      </div>

      {renderAuthor()}
    </blockquote>
  );
};

/**
 * Bordered Blockquote - Left border variant
 */
export const BorderedBlockquote: Pulse.Fn<BlockquoteProps> = (
  props: BlockquoteProps,
): Pulse.JSX.Element => {
  return <Blockquote {...props} variant="bordered" showIcon={false} />;
};

/**
 * Minimal Blockquote - No icon or border
 */
export const MinimalBlockquote: Pulse.Fn<BlockquoteProps> = (
  props: BlockquoteProps,
): Pulse.JSX.Element => {
  return <Blockquote {...props} variant="minimal" showIcon={false} />;
};

export default Blockquote;
