/**
 * Button Component
 * A versatile button component with multiple variants, sizes, and states
 *
 * @example
 * ```tsx
 * import { Button } from '@odyssee/components';
 *
 * // Basic button
 * <Button>Click me</Button>
 *
 * // With variant and color
 * <Button variant="solid" color="primary">Primary Button</Button>
 *
 * // With loading state
 * const isLoading = Pulse.signal(false);
 * <Button loading={isLoading}>Submit</Button>
 *
 * // With icon
 * <Button icon="🚀" iconPosition="left">Launch</Button>
 *
 * // Full width
 * <Button fullWidth variant="outline" color="secondary">Full Width</Button>
 * ```
 */

import Pulse from "pulse-framework";
import type { ButtonProps } from "../../types";
import { cn, isSignal } from "../../utils";
import { ButtonSpinner } from "./Spinner";

export const Button: Pulse.Fn<ButtonProps> = (props) => {
  const {
    type = "button",
    variant = "solid",
    color = "primary",
    size = "md",
    disabled = false,
    loading = false,
    icon,
    iconPosition = "left",
    fullWidth = false,
    onClick,
    children,
    className,
    id,
    style,
    spinnerProps,
    ...rest
  } = props;

  // Base classes
  const baseClasses =
    "inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";

  // Size classes
  const sizeClasses = {
    xs: "px-2 py-1 text-xs rounded gap-1",
    sm: "px-3 py-1.5 text-sm rounded gap-1.5",
    md: "px-4 py-2 text-sm rounded-md gap-2",
    lg: "px-5 py-2.5 text-base rounded-md gap-2",
    xl: "px-6 py-3 text-lg rounded-lg gap-2.5",
  };

  // Variant + Color classes
  const variantColorClasses = {
    solid: {
      primary:
        "bg-primary-600 text-white hover:bg-primary-700 focus:ring-primary-500 active:bg-primary-800",
      secondary:
        "bg-gray-600 text-white hover:bg-gray-700 focus:ring-gray-500 active:bg-gray-800",
      success:
        "bg-green-600 text-white hover:bg-green-700 focus:ring-green-500 active:bg-green-800",
      danger:
        "bg-red-600 text-white hover:bg-red-700 focus:ring-red-500 active:bg-red-800",
      warning:
        "bg-yellow-500 text-white hover:bg-yellow-600 focus:ring-yellow-400 active:bg-yellow-700",
      info: "bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500 active:bg-blue-800",
      light:
        "bg-gray-100 text-gray-900 hover:bg-gray-200 focus:ring-gray-300 active:bg-gray-300",
      dark: "bg-gray-900 text-white hover:bg-gray-800 focus:ring-gray-700 active:bg-gray-950",
    },
    outline: {
      primary:
        "border-2 border-primary-600 text-primary-600 hover:bg-primary-50 focus:ring-primary-500 active:bg-primary-100",
      secondary:
        "border-2 border-gray-600 text-gray-600 hover:bg-gray-50 focus:ring-gray-500 active:bg-gray-100",
      success:
        "border-2 border-green-600 text-green-600 hover:bg-green-50 focus:ring-green-500 active:bg-green-100",
      danger:
        "border-2 border-red-600 text-red-600 hover:bg-red-50 focus:ring-red-500 active:bg-red-100",
      warning:
        "border-2 border-yellow-500 text-yellow-600 hover:bg-yellow-50 focus:ring-yellow-400 active:bg-yellow-100",
      info: "border-2 border-blue-600 text-blue-600 hover:bg-blue-50 focus:ring-blue-500 active:bg-blue-100",
      light:
        "border-2 border-gray-300 text-gray-700 hover:bg-gray-50 focus:ring-gray-300 active:bg-gray-100",
      dark: "border-2 border-gray-900 text-gray-900 hover:bg-gray-50 focus:ring-gray-700 active:bg-gray-100",
    },
    ghost: {
      primary:
        "text-primary-600 hover:bg-primary-50 focus:ring-primary-500 active:bg-primary-100",
      secondary:
        "text-gray-600 hover:bg-gray-50 focus:ring-gray-500 active:bg-gray-100",
      success:
        "text-green-600 hover:bg-green-50 focus:ring-green-500 active:bg-green-100",
      danger:
        "text-red-600 hover:bg-red-50 focus:ring-red-500 active:bg-red-100",
      warning:
        "text-yellow-600 hover:bg-yellow-50 focus:ring-yellow-400 active:bg-yellow-100",
      info: "text-blue-600 hover:bg-blue-50 focus:ring-blue-500 active:bg-blue-100",
      light:
        "text-gray-700 hover:bg-gray-100 focus:ring-gray-300 active:bg-gray-200",
      dark: "text-gray-900 hover:bg-gray-100 focus:ring-gray-700 active:bg-gray-200",
    },
    soft: {
      primary:
        "bg-primary-100 text-primary-700 hover:bg-primary-200 focus:ring-primary-500 active:bg-primary-300",
      secondary:
        "bg-gray-100 text-gray-700 hover:bg-gray-200 focus:ring-gray-500 active:bg-gray-300",
      success:
        "bg-green-100 text-green-700 hover:bg-green-200 focus:ring-green-500 active:bg-green-300",
      danger:
        "bg-red-100 text-red-700 hover:bg-red-200 focus:ring-red-500 active:bg-red-300",
      warning:
        "bg-yellow-100 text-yellow-700 hover:bg-yellow-200 focus:ring-yellow-400 active:bg-yellow-300",
      info: "bg-blue-100 text-blue-700 hover:bg-blue-200 focus:ring-blue-500 active:bg-blue-300",
      light:
        "bg-gray-50 text-gray-600 hover:bg-gray-100 focus:ring-gray-300 active:bg-gray-200",
      dark: "bg-gray-800 text-gray-100 hover:bg-gray-700 focus:ring-gray-700 active:bg-gray-900",
    },
    link: {
      primary:
        "text-primary-600 hover:text-primary-700 underline-offset-4 hover:underline focus:ring-primary-500",
      secondary:
        "text-gray-600 hover:text-gray-700 underline-offset-4 hover:underline focus:ring-gray-500",
      success:
        "text-green-600 hover:text-green-700 underline-offset-4 hover:underline focus:ring-green-500",
      danger:
        "text-red-600 hover:text-red-700 underline-offset-4 hover:underline focus:ring-red-500",
      warning:
        "text-yellow-600 hover:text-yellow-700 underline-offset-4 hover:underline focus:ring-yellow-400",
      info: "text-blue-600 hover:text-blue-700 underline-offset-4 hover:underline focus:ring-blue-500",
      light:
        "text-gray-500 hover:text-gray-600 underline-offset-4 hover:underline focus:ring-gray-300",
      dark: "text-gray-900 hover:text-gray-800 underline-offset-4 hover:underline focus:ring-gray-700",
    },
  };

  // Full width class
  const widthClass = fullWidth ? "w-full" : "";

  // Map button color to spinner color based on variant
  const getSpinnerColor = (): any => {
    // If custom spinner color is provided, use it
    if (spinnerProps?.color) {
      return spinnerProps.color;
    }

    // For solid variant: spinner should be white (contrasts with colored background)
    if (variant === "solid") {
      return color === "light" ? "dark" : "white";
    }

    // For outline/ghost/soft/link variants: spinner should match the button color
    // Map Color to SpinnerProps color
    const colorMap: Record<string, any> = {
      primary: "primary",
      secondary: "secondary",
      success: "success",
      danger: "danger",
      warning: "warning",
      info: "info",
      light: "gray",
      dark: "gray",
    };

    return colorMap[color] || "primary";
  };

  // Get reactive values
  const isDisabled = () =>
    isSignal(disabled) ? (disabled as any)() : disabled;
  const isLoading = () => (isSignal(loading) ? (loading as any)() : loading);

  // Combine all classes
  const buttonClasses = cn(
    baseClasses,
    sizeClasses[size],
    variantColorClasses[variant][color],
    widthClass,
    className,
  );

  // Handle click
  const handleClick = (e: Event) => {
    if (!isDisabled() && !isLoading() && onClick) {
      onClick(e);
    }
  };

  return (
    <button
      type={type}
      id={id}
      class={buttonClasses}
      disabled={isDisabled() || isLoading()}
      style={style}
      onClick={handleClick}
      {...rest}
    >
      {isLoading() && (
        <ButtonSpinner
          color={getSpinnerColor()}
          label="Loading"
          {...spinnerProps}
        />
      )}
      {!isLoading() && icon && iconPosition === "left" && (
        <span class="inline-flex items-center">{icon}</span>
      )}
      {children}
      {!isLoading() && icon && iconPosition === "right" && (
        <span class="inline-flex items-center">{icon}</span>
      )}
    </button>
  ) as Pulse.JSX.Element;
};
