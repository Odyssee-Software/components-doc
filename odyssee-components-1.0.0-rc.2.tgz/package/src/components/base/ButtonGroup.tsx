/**
 * ButtonGroup Component
 * A component for grouping buttons together with various layouts and styles
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps } from "../../types";

/**
 * Button item in group
 */
export interface ButtonGroupItem {
  label: string | HTMLElement;
  value?: string | number;
  icon?: HTMLElement;
  disabled?: boolean;
  active?: boolean;
  onClick?: () => void;
  type?: "button" | "submit" | "reset";
  className?: string;
}

/**
 * ButtonGroup props
 */
export interface ButtonGroupProps extends BaseComponentProps {
  // Button items
  buttons: ButtonGroupItem[];

  // Layout
  orientation?: "horizontal" | "vertical";

  // Size
  size?: "sm" | "md" | "lg";

  // Variant
  variant?: "default" | "toolbar";

  // Allow responsive break (vertical on mobile, horizontal on desktop)
  responsive?: boolean;

  // Allow multiple selection (for toolbar mode)
  allowMultiple?: boolean;

  // Selected value(s)
  selected?: string | number | (string | number)[];

  // Full width
  fullWidth?: boolean;

  // Callback when a button is clicked
  onChange?: (value: string | number | (string | number)[]) => void;
}

/**
 * ButtonGroup Component
 *
 * @example
 * ```tsx
 * // Basic horizontal button group
 * <ButtonGroup
 *   buttons={[
 *     { label: "Years", value: "years" },
 *     { label: "Month", value: "month" },
 *     { label: "Date", value: "date" }
 *   ]}
 * />
 *
 * // Vertical button group
 * <ButtonGroup
 *   buttons={[
 *     { label: "Item 1", value: 1 },
 *     { label: "Item 2", value: 2 },
 *     { label: "Item 3", value: 3 }
 *   ]}
 *   orientation="vertical"
 * />
 *
 * // Toolbar variant
 * <ButtonGroup
 *   buttons={toolbarButtons}
 *   variant="toolbar"
 *   allowMultiple={true}
 * />
 *
 * // Responsive (vertical on mobile, horizontal on desktop)
 * <ButtonGroup
 *   buttons={items}
 *   responsive={true}
 * />
 * ```
 */
export const ButtonGroup: Pulse.Fn<ButtonGroupProps> = (
  props: ButtonGroupProps,
): Pulse.JSX.Element => {
  const {
    buttons = [],
    orientation = "horizontal",
    size = "md",
    variant = "default",
    responsive = false,
    allowMultiple = false,
    selected,
    fullWidth = false,
    onChange,
    className,
    id,
    style,
  } = props;

  // Size classes
  const sizeClasses: Record<string, string> = {
    sm: "py-2 px-3 text-sm",
    md: "py-3 px-4 text-sm",
    lg: "py-3 px-4 sm:p-5 text-sm",
  };

  // Container classes
  const containerClasses = cn(
    variant === "toolbar" ? "flex align-middle gap-x-0.5 p-2" : "inline-flex",
    variant === "default" &&
      orientation === "horizontal" &&
      "rounded-lg shadow-2xs",
    variant === "default" &&
      orientation === "vertical" &&
      "flex-col rounded-lg shadow-2xs",
    variant === "default" &&
      responsive &&
      "flex-col sm:inline-flex sm:flex-row rounded-lg shadow-2xs",
    fullWidth && "w-full",
    orientation === "vertical" && !responsive && "max-w-xs flex-col",
    className,
  );

  // Button base classes for default variant
  const defaultButtonClasses = cn(
    "inline-flex items-center gap-x-2 font-medium focus:z-10",
    "border border-gray-200 bg-white text-gray-800 shadow-2xs",
    "hover:bg-gray-50 focus:outline-hidden focus:bg-gray-50",
    "disabled:opacity-50 disabled:pointer-events-none",
    "dark:bg-neutral-900 dark:border-neutral-700 dark:text-white",
    "dark:hover:bg-neutral-800 dark:focus:bg-neutral-800",
  );

  // Toolbar button classes
  const toolbarButtonClasses = cn(
    "size-8 inline-flex justify-center items-center gap-x-2",
    "text-sm font-semibold rounded-full border border-transparent",
    "text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100",
    "disabled:opacity-50 disabled:pointer-events-none",
    "dark:text-white dark:hover:bg-neutral-700 dark:focus:bg-neutral-700",
  );

  // Position classes for horizontal layout
  const horizontalPositionClasses = cn(
    "-ms-px first:rounded-s-lg first:ms-0 last:rounded-e-lg",
  );

  // Position classes for vertical layout
  const verticalPositionClasses = cn(
    "-mt-px first:rounded-t-md last:rounded-b-md",
  );

  // Responsive position classes
  const responsivePositionClasses = cn(
    "-mt-px -ms-px",
    "first:rounded-t-md last:rounded-b-md",
    "sm:first:rounded-s-md sm:mt-0 sm:first:ms-0",
    "sm:first:rounded-se-none sm:last:rounded-es-none sm:last:rounded-e-md",
  );

  // Check if a button is selected
  const isSelected = (value?: string | number): boolean => {
    if (!selected || !value) return false;
    if (Array.isArray(selected)) {
      return selected.includes(value);
    }
    return selected === value;
  };

  // Handle button click
  const handleButtonClick = (button: ButtonGroupItem) => {
    if (button.disabled) return;

    if (button.onClick) {
      button.onClick();
    }

    if (onChange && button.value !== undefined) {
      if (allowMultiple && Array.isArray(selected)) {
        const newSelected = isSelected(button.value)
          ? selected.filter((v) => v !== button.value)
          : [...selected, button.value];
        onChange(newSelected);
      } else {
        onChange(button.value);
      }
    }
  };

  // Render button content
  const renderButtonContent = (button: ButtonGroupItem) => {
    if (variant === "toolbar" && button.icon) {
      return button.icon;
    }

    return (
      <>
        {button.icon && variant !== "toolbar" && button.icon}
        {typeof button.label === "string" ? button.label : button.label}
      </>
    );
  };

  // Get button classes based on variant and orientation
  const getButtonClasses = (button: ButtonGroupItem, index: number) => {
    if (variant === "toolbar") {
      return cn(
        toolbarButtonClasses,
        button.active && "bg-gray-100 dark:bg-neutral-700",
        isSelected(button.value) && "bg-gray-100 dark:bg-neutral-700",
        button.className,
      );
    }

    // Default variant
    let positionClasses = "";
    if (responsive) {
      positionClasses = responsivePositionClasses;
    } else if (orientation === "vertical") {
      positionClasses = verticalPositionClasses;
      // Add top rounding only for first item
      if (index === 0) {
        positionClasses = cn(positionClasses, "rounded-t-md");
      }
      // Add bottom rounding only for last item
      if (index === buttons.length - 1) {
        positionClasses = cn(positionClasses, "rounded-b-md");
      }
    } else {
      positionClasses = horizontalPositionClasses;
    }

    return cn(
      defaultButtonClasses,
      sizeClasses[size],
      positionClasses,
      isSelected(button.value) && "bg-gray-100 dark:bg-neutral-800",
      fullWidth && "justify-center",
      button.className,
    );
  };

  return (
    <div id={id} class={containerClasses} style={style}>
      {buttons.map((button, index) => (
        <button
          type={button.type || "button"}
          class={getButtonClasses(button, index)}
          disabled={button.disabled}
          onClick={() => handleButtonClick(button)}
          key={index}
        >
          {renderButtonContent(button)}
        </button>
      ))}
    </div>
  );
};

/**
 * Horizontal ButtonGroup
 */
export const HorizontalButtonGroup: Pulse.Fn<ButtonGroupProps> = (
  props: ButtonGroupProps,
): Pulse.JSX.Element => {
  return <ButtonGroup {...props} orientation="horizontal" />;
};

/**
 * Vertical ButtonGroup
 */
export const VerticalButtonGroup: Pulse.Fn<ButtonGroupProps> = (
  props: ButtonGroupProps,
): Pulse.JSX.Element => {
  return <ButtonGroup {...props} orientation="vertical" />;
};

/**
 * Toolbar ButtonGroup
 */
export const ToolbarButtonGroup: Pulse.Fn<ButtonGroupProps> = (
  props: ButtonGroupProps,
): Pulse.JSX.Element => {
  return <ButtonGroup {...props} variant="toolbar" allowMultiple={true} />;
};

/**
 * Responsive ButtonGroup - vertical on mobile, horizontal on desktop
 */
export const ResponsiveButtonGroup: Pulse.Fn<ButtonGroupProps> = (
  props: ButtonGroupProps,
): Pulse.JSX.Element => {
  return <ButtonGroup {...props} responsive={true} />;
};

export default ButtonGroup;
