/**
 * ToastContainer Component
 * A container for managing toast positioning and stacking
 *
 * @example
 * ```tsx
 * import { ToastContainer, Toast } from '@odyssee/components';
 *
 * // Basic container with position
 * <ToastContainer position="top-right">
 *   <Toast type="success" message="File saved!" />
 *   <Toast type="info" message="New notification" />
 * </ToastContainer>
 *
 * // Center positioned
 * <ToastContainer position="center">
 *   <Toast type="error" message="An error occurred" />
 * </ToastContainer>
 *
 * // Bottom right with custom offset and gap
 * <ToastContainer
 *   position="bottom-right"
 *   offset={20}
 *   gap={12}
 * >
 *   <Toast type="success" message="Upload complete" />
 * </ToastContainer>
 *
 * // With max toasts limit
 * <ToastContainer
 *   position="top-center"
 *   maxToasts={3}
 * >
 *   {toasts.map(toast => (
 *     <Toast key={toast.id} {...toast} />
 *   ))}
 * </ToastContainer>
 * ```
 */

import Pulse from "pulse-framework";
import type { ToastContainerProps } from "../../types";
import { cn, generateId } from "../../utils";

export const ToastContainer: Pulse.Fn<ToastContainerProps> = (props) => {
  const {
    position = "top-right",
    maxToasts = 5,
    offset = 16,
    gap = 12,
    children,
    className,
    id = generateId("toast-container"),
    style,
    ...rest
  } = props;

  // Get position style based on position prop
  const getPositionStyle = (): Record<string, any> => {
    const baseStyle: Record<string, any> = (style as any) || {};

    switch (position) {
      case "top-left":
        return { ...baseStyle, top: `${offset}px`, left: `${offset}px` };
      case "top-center":
        return {
          ...baseStyle,
          top: `${offset}px`,
          left: "50%",
          transform: "translateX(-50%)",
        };
      case "top-right":
        return { ...baseStyle, top: `${offset}px`, right: `${offset}px` };
      case "center":
        return {
          ...baseStyle,
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
        };
      case "bottom-left":
        return { ...baseStyle, bottom: `${offset}px`, left: `${offset}px` };
      case "bottom-center":
        return {
          ...baseStyle,
          bottom: `${offset}px`,
          left: "50%",
          transform: "translateX(-50%)",
        };
      case "bottom-right":
        return {
          ...baseStyle,
          bottom: `${offset}px`,
          right: `${offset}px`,
        };
      default:
        return baseStyle;
    }
  };

  // Container classes
  const containerClasses = cn(
    "fixed z-50 flex flex-col pointer-events-none",
    className,
  );

  // Gap style
  const gapStyle = {
    gap: `${gap}px`,
  };

  // Limit children to maxToasts
  const limitedChildren = Array.isArray(children)
    ? children.slice(0, maxToasts)
    : children;

  return (
    <div
      id={id}
      class={containerClasses}
      style={{ ...getPositionStyle(), ...gapStyle }}
      {...rest}
    >
      {/* Make toasts clickable again */}
      <div class="pointer-events-auto space-y-3">{limitedChildren}</div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * TopRightToastContainer - Convenience component
 */
export const TopRightToastContainer: Pulse.Fn<
  Omit<ToastContainerProps, "position">
> = (props) => {
  return <ToastContainer {...props} position="top-right" />;
};

/**
 * TopCenterToastContainer - Convenience component
 */
export const TopCenterToastContainer: Pulse.Fn<
  Omit<ToastContainerProps, "position">
> = (props) => {
  return <ToastContainer {...props} position="top-center" />;
};

/**
 * BottomRightToastContainer - Convenience component
 */
export const BottomRightToastContainer: Pulse.Fn<
  Omit<ToastContainerProps, "position">
> = (props) => {
  return <ToastContainer {...props} position="bottom-right" />;
};

/**
 * BottomCenterToastContainer - Convenience component
 */
export const BottomCenterToastContainer: Pulse.Fn<
  Omit<ToastContainerProps, "position">
> = (props) => {
  return <ToastContainer {...props} position="bottom-center" />;
};

export default ToastContainer;
