/**
 * Toast Component
 * A notification component for displaying temporary messages with auto-dismiss
 * Reuses Alert structure with positioning and animations
 *
 * @example
 * ```tsx
 * import { Toast } from '@odyssee/components';
 *
 * // Basic toast
 * <Toast type="success" message="File saved successfully!" />
 *
 * // With title and dismissible
 * <Toast
 *   type="error"
 *   title="Error"
 *   message="Failed to save file"
 *   dismissible
 *   onClose={() => console.log('Closed')}
 * />
 *
 * // With auto-dismiss
 * <Toast
 *   type="info"
 *   message="New notification"
 *   duration={3000}
 * />
 *
 * // With actions
 * <Toast
 *   type="success"
 *   message="Your email has been sent"
 *   actions={[
 *     { label: "Undo", onClick: handleUndo }
 *   ]}
 * />
 *
 * // With avatar
 * <Toast
 *   type="default"
 *   title="James mentioned you"
 *   message="Nice work! Keep it up!"
 *   avatar="https://example.com/avatar.jpg"
 *   actions={[
 *     { label: "Mark as read", onClick: handleMarkRead }
 *   ]}
 * />
 *
 * // With progress
 * <Toast
 *   type="default"
 *   title="Uploading 3 files"
 *   progress={57}
 *   progressLabel="57% · 5 seconds left"
 * />
 *
 * // With loading
 * <Toast
 *   type="default"
 *   message="Action in progress"
 *   loading
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { ToastProps } from "../../types";
import { cn, generateId, isSignal } from "../../utils";
import { Avatar } from "./Avatar";
import { Progress } from "./Progress";
import { Spinner } from "./Spinner";

export const Toast: Pulse.Fn<ToastProps> = (props) => {
  const {
    type = "default",
    variant = "default",
    title,
    message,
    icon,
    avatar,
    duration = 0,
    dismissible = false,
    actions = [],
    progress,
    progressLabel,
    loading = false,
    visible: visibleProp = true,
    onClose,
    animated = true,
    className,
    id = generateId("toast"),
    style,
    ...rest
  } = props;

  // Get visible state
  const isVisible = () =>
    isSignal(visibleProp) ? (visibleProp as any)() : visibleProp;

  // Auto-dismiss timer
  if (duration > 0 && onClose) {
    setTimeout(() => {
      onClose();
    }, duration);
  }

  // Type icons
  const InfoIcon = () => (
    <svg
      class="shrink-0 size-4 mt-0.5"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"></path>
    </svg>
  );

  const SuccessIcon = () => (
    <svg
      class="shrink-0 size-4 mt-0.5"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"></path>
    </svg>
  );

  const ErrorIcon = () => (
    <svg
      class="shrink-0 size-4 mt-0.5"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"></path>
    </svg>
  );

  const WarningIcon = () => (
    <svg
      class="shrink-0 size-4 mt-0.5"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      fill="currentColor"
      viewBox="0 0 16 16"
    >
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8 4a.905.905 0 0 0-.9.995l.35 3.507a.552.552 0 0 0 1.1 0l.35-3.507A.905.905 0 0 0 8 4zm.002 6a1 1 0 1 0 0 2 1 1 0 0 0 0-2z"></path>
    </svg>
  );

  // Close icon
  const CloseIcon = () => (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  );

  // Get type icon
  const getTypeIcon = () => {
    if (icon) return icon;

    switch (type) {
      case "info":
        return <InfoIcon />;
      case "success":
        return <SuccessIcon />;
      case "error":
        return <ErrorIcon />;
      case "warning":
        return <WarningIcon />;
      default:
        return null;
    }
  };

  // Get icon color classes
  const getIconColorClass = () => {
    switch (type) {
      case "info":
        return "text-blue-500";
      case "success":
        return "text-teal-500";
      case "error":
        return "text-red-500";
      case "warning":
        return "text-yellow-500";
      default:
        return "text-gray-600 dark:text-neutral-400";
    }
  };

  // Variant classes
  const variantClasses = {
    default: {
      container:
        "bg-white border border-gray-200 dark:bg-neutral-800 dark:border-neutral-700",
      text: "text-gray-700 dark:text-neutral-400",
      titleText: "text-gray-800 dark:text-white",
    },
    solid: {
      info: {
        container: "bg-blue-500 border-blue-500",
        text: "text-white",
        titleText: "text-white",
      },
      success: {
        container: "bg-teal-500 border-teal-500",
        text: "text-white",
        titleText: "text-white",
      },
      error: {
        container: "bg-red-500 border-red-500",
        text: "text-white",
        titleText: "text-white",
      },
      warning: {
        container: "bg-yellow-500 border-yellow-500",
        text: "text-white",
        titleText: "text-white",
      },
      default: {
        container: "bg-gray-800 border-gray-800 dark:bg-neutral-900",
        text: "text-white",
        titleText: "text-white",
      },
    },
    soft: {
      info: {
        container:
          "bg-blue-100 border border-blue-200 dark:bg-blue-800/10 dark:border-blue-900",
        text: "text-blue-800 dark:text-blue-500",
        titleText: "text-blue-800 dark:text-blue-500",
      },
      success: {
        container:
          "bg-teal-100 border border-teal-200 dark:bg-teal-800/10 dark:border-teal-900",
        text: "text-teal-800 dark:text-teal-500",
        titleText: "text-teal-800 dark:text-teal-500",
      },
      error: {
        container:
          "bg-red-100 border border-red-200 dark:bg-red-800/10 dark:border-red-900",
        text: "text-red-800 dark:text-red-500",
        titleText: "text-red-800 dark:text-red-500",
      },
      warning: {
        container:
          "bg-yellow-100 border border-yellow-200 dark:bg-yellow-800/10 dark:border-yellow-900",
        text: "text-yellow-800 dark:text-yellow-500",
        titleText: "text-yellow-800 dark:text-yellow-500",
      },
      default: {
        container:
          "bg-gray-100 border border-gray-200 dark:bg-white/10 dark:border-white/20",
        text: "text-gray-800 dark:text-white",
        titleText: "text-gray-800 dark:text-white",
      },
    },
  };

  // Get variant classes
  const getVariantClasses = () => {
    if (variant === "default") {
      return variantClasses.default;
    }
    // Type assertion to handle the indexing
    const variantClass = variantClasses[variant] as Record<string, any>;
    return variantClass[type] || variantClass.default;
  };

  const classes = getVariantClasses();

  // Container classes
  const containerClasses = cn(
    "max-w-xs rounded-xl shadow-lg transition-all duration-300",
    classes.container,
    animated && "hs-removing:translate-x-5 hs-removing:opacity-0",
    !isVisible() && "hidden",
    className,
  );

  // Handle close
  const handleClose = () => {
    if (onClose) {
      onClose();
    }
  };

  // Render avatar
  const renderAvatar = () => {
    if (!avatar) return null;
    return (
      <div class="shrink-0">
        <Avatar src={avatar} size="sm" alt="Avatar" />
      </div>
    );
  };

  // Render icon
  const renderIcon = () => {
    if (avatar) return null;
    if (loading) {
      return (
        <div class="shrink-0">
          <Spinner size="sm" color="primary" />
        </div>
      );
    }

    const typeIcon = getTypeIcon();
    if (!typeIcon) return null;

    return (
      <div class="shrink-0">
        <span class={getIconColorClass()}>{typeIcon}</span>
      </div>
    );
  };

  // Render progress
  const renderProgress = () => {
    if (progress === undefined) return null;

    return (
      <div class="mt-2 flex flex-col gap-x-3">
        {progressLabel && (
          <span class="block mb-1.5 text-xs text-gray-500 dark:text-neutral-400">
            {progressLabel}
          </span>
        )}
        <Progress value={progress} color="primary" size="sm" />
      </div>
    );
  };

  // Render actions
  const renderActions = () => {
    if (actions.length === 0) return null;

    return (
      <div class="mt-3 flex gap-x-3">
        {actions.map((action, index) => (
          <button
            key={index}
            type="button"
            class="text-blue-600 decoration-2 hover:underline font-medium text-sm focus:outline-hidden focus:underline dark:text-blue-500"
            onClick={action.onClick}
          >
            {action.label}
          </button>
        ))}
      </div>
    );
  };

  // Render close button
  const renderCloseButton = () => {
    if (!dismissible) return null;

    const closeButtonPosition = avatar || title || actions.length > 0;

    return (
      <button
        type="button"
        class={cn(
          "inline-flex shrink-0 justify-center items-center size-5 rounded-lg opacity-50 hover:opacity-100 focus:outline-hidden focus:opacity-100",
          variant === "solid" ? "text-white" : "text-gray-800 dark:text-white",
          closeButtonPosition ? "absolute top-3 end-3" : "ms-auto",
        )}
        aria-label="Close"
        onClick={handleClose}
      >
        <span class="sr-only">Close</span>
        <CloseIcon />
      </button>
    );
  };

  // Condensed layout (single line with inline actions)
  if (!title && !avatar && actions.length > 0 && !progress) {
    return (
      <div
        id={id}
        class={containerClasses}
        style={style}
        role="alert"
        tabindex="-1"
        {...rest}
      >
        <div class="flex p-4">
          <p class={cn("text-sm", classes.text)}>{message}</p>

          <div class="ms-auto flex items-center space-x-3">
            {actions.map((action, index) => (
              <button
                key={index}
                type="button"
                class="text-blue-600 decoration-2 hover:underline font-medium text-sm focus:outline-hidden focus:underline dark:text-blue-500"
                onClick={action.onClick}
              >
                {action.label}
              </button>
            ))}
            {dismissible && (
              <button
                type="button"
                class={cn(
                  "inline-flex shrink-0 justify-center items-center size-5 rounded-lg opacity-50 hover:opacity-100 focus:outline-hidden focus:opacity-100",
                  variant === "solid"
                    ? "text-white"
                    : "text-gray-800 dark:text-white",
                )}
                aria-label="Close"
                onClick={handleClose}
              >
                <span class="sr-only">Close</span>
                <CloseIcon />
              </button>
            )}
          </div>
        </div>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Standard layout
  return (
    <div
      id={id}
      class={cn(containerClasses, (avatar || dismissible) && "relative")}
      style={style}
      role="alert"
      tabindex="-1"
      {...rest}
    >
      <div class="flex p-4">
        {renderAvatar()}
        {renderIcon()}

        <div
          class={cn(
            avatar || renderIcon() ? "ms-3" : "",
            dismissible && avatar ? "me-5" : "flex-1",
          )}
        >
          {title && (
            <h3 class={cn("font-semibold text-sm mb-1", classes.titleText)}>
              {title}
            </h3>
          )}

          <div class={cn("text-sm", classes.text)}>
            {typeof message === "string" ? <p>{message}</p> : message}
          </div>

          {renderProgress()}
          {renderActions()}
        </div>

        {renderCloseButton()}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

export default Toast;
