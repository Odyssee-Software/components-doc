/**
 * Avatar Component
 * A versatile avatar component with images, initials, icons, status indicators, and badges
 *
 * @example
 * ```tsx
 * import { Avatar } from '@odyssee/components';
 *
 * // Basic image avatar
 * <Avatar src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5" alt="User" />
 *
 * // Avatar with initials
 * <Avatar initials="AC" name="Alice Cooper" />
 *
 * // Avatar with status indicator
 * <Avatar
 *   src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5"
 *   status="online"
 *   statusPosition="bottom"
 * />
 *
 * // Avatar with different sizes
 * <Avatar src="..." size="xs" />
 * <Avatar src="..." size="sm" />
 * <Avatar src="..." size="md" />
 * <Avatar src="..." size="lg" />
 * <Avatar src="..." size="xl" />
 *
 * // Avatar with initials and colors
 * <Avatar initials="AC" color="primary" colorVariant="solid" />
 * <Avatar initials="JD" color="success" colorVariant="soft" />
 * <Avatar initials="MW" color="danger" colorVariant="outline" />
 *
 * // Rounded variants
 * <Avatar src="..." rounded="full" />
 * <Avatar src="..." rounded="lg" />
 *
 * // Avatar with icon placeholder
 * <Avatar variant="icon" size="lg" />
 *
 * // Avatar with badge
 * <Avatar
 *   src="..."
 *   icon={<svg>...</svg>}
 *   iconBg={true}
 * />
 *
 * // Avatar with tooltip
 * <Avatar
 *   src="..."
 *   status="online"
 *   tooltip="Mark Wanner is online"
 * />
 *
 * // Clickable avatar
 * <Avatar
 *   src="..."
 *   href="/profile"
 *   onClick={() => console.log('clicked')}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { AvatarProps } from "../../types";
import { cn, generateId } from "../../utils";
import { signal } from "pulse-framework";

export const Avatar: Pulse.Fn<AvatarProps> = (props) => {
  const {
    // Image
    src,
    alt = "Avatar",

    // Text/Initials
    name,
    initials,

    // Variants
    variant = src ? "image" : initials || name ? "initials" : "icon",

    // Styling
    size = "md",
    rounded = "full",

    // Colors
    color = "gray",
    colorVariant = "solid",

    // Status
    status = "none",
    statusPosition = "bottom",
    statusColor,

    // Badge
    badge,
    badgePosition = "bottom",

    // Icon
    icon,
    iconBg = false,

    // Tooltip
    tooltip,

    // Interactions
    href,
    onClick,

    className,
    id = generateId("avatar"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "size-6",
    sm: "size-8",
    md: "size-9.5",
    lg: "size-11",
    xl: "size-15.5",
  };

  // Font size for initials
  const fontSizeClasses = {
    xs: "text-xs",
    sm: "text-xs",
    md: "text-sm",
    lg: "text-sm",
    xl: "text-lg",
  };

  // Rounded classes
  const roundedClasses = {
    true: "rounded-lg",
    false: "rounded",
    full: "rounded-full",
    lg: "rounded-lg",
  };

  // Status dot sizes
  const statusSizeClasses = {
    xs: "size-1.5",
    sm: "size-1.5",
    md: "size-2.5",
    lg: "size-3",
    xl: "size-3.5",
  };

  // Status colors
  const statusColorClasses = {
    online: "bg-teal-400",
    offline: "bg-gray-400",
    away: "bg-yellow-400",
    busy: "bg-red-400",
    none: "bg-gray-400",
  };

  // Color variants for initials
  const colorClasses = {
    solid: {
      gray: "bg-gray-500 text-white",
      primary: "bg-blue-600 text-white dark:bg-blue-500",
      secondary: "bg-gray-800 text-white dark:bg-white dark:text-neutral-800",
      success: "bg-green-500 text-white",
      danger: "bg-red-500 text-white",
      warning: "bg-yellow-500 text-white",
      info: "bg-blue-600 text-white",
      white: "bg-white text-gray-800",
    },
    soft: {
      gray: "bg-gray-100 text-gray-800 dark:bg-white/10 dark:text-white",
      primary:
        "bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-500",
      secondary: "bg-gray-50 text-gray-500 dark:bg-white/10 dark:text-white",
      success:
        "bg-teal-100 text-teal-800 dark:bg-teal-800/30 dark:text-teal-500",
      danger: "bg-red-100 text-red-800 dark:bg-red-800/30 dark:text-red-500",
      warning:
        "bg-yellow-100 text-yellow-800 dark:bg-yellow-800/30 dark:text-yellow-500",
      info: "bg-blue-100 text-blue-800 dark:bg-blue-800/30 dark:text-blue-500",
      white: "bg-white/10 text-white",
    },
    outline: {
      gray: "border border-gray-500 text-gray-500 dark:text-neutral-400",
      primary: "border border-blue-600 text-blue-600 dark:text-blue-500",
      secondary:
        "border border-gray-800 text-gray-800 dark:border-neutral-200 dark:text-white",
      success: "border border-teal-500 text-teal-500",
      danger: "border border-red-500 text-red-500",
      warning: "border border-yellow-500 text-yellow-500",
      info: "border border-blue-600 text-blue-600",
      white: "border border-white text-white",
    },
  };

  // Get initials from name
  const getInitials = () => {
    if (initials) return initials;
    if (name) {
      const parts = name.split(" ");
      if (parts.length >= 2) {
        return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
      }
      return parts[0].substring(0, 2).toUpperCase();
    }
    return "";
  };

  // Handle click
  const handleClick = (e: Event) => {
    if (onClick) {
      onClick(e);
    }
  };

  // Status indicator position classes
  const statusPositionClasses =
    statusPosition === "top"
      ? rounded === "full"
        ? "absolute top-0 end-0"
        : "absolute top-0 end-0 transform -translate-y-1/2 translate-x-1/2"
      : rounded === "full"
        ? "absolute bottom-0 end-0"
        : "absolute bottom-0 end-0 transform translate-y-1/2 translate-x-1/2";

  // Base avatar classes
  const baseClasses = cn(
    "inline-block",
    sizeClasses[size],
    roundedClasses[String(rounded) as keyof typeof roundedClasses],
    href && "cursor-pointer hover:opacity-80 transition-opacity",
  );

  // Container wrapper (for status/badge positioning)
  const Container = href ? "a" : "div";

  // Image error state
  const imageError = signal(false);

  // Handle image load error
  const handleImageError = () => {
    imageError(true);
  };

  // Render avatar content based on variant
  const renderAvatarContent = () => {
    if (variant === "image" && src && !imageError()) {
      return (
        <img
          class={cn(baseClasses, className)}
          src={src}
          alt={alt}
          style={style}
          loading="lazy"
          onError={handleImageError}
        />
      );
    }

    if (variant === "initials") {
      const displayInitials = getInitials();
      return (
        <span
          class={cn(
            baseClasses,
            "inline-flex items-center justify-center font-semibold",
            fontSizeClasses[size],
            colorClasses[colorVariant][color],
            className,
          )}
          style={style}
        >
          {displayInitials}
        </span>
      );
    }

    // Icon variant (placeholder)
    return (
      <span
        class={cn(baseClasses, "bg-gray-100 overflow-hidden", className)}
        style={style}
      >
        <svg
          class="size-full text-gray-300"
          width="16"
          height="16"
          viewBox="0 0 16 16"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <rect
            x="0.62854"
            y="0.359985"
            width="15"
            height="15"
            rx="7.5"
            fill="white"
          />
          <path
            d="M8.12421 7.20374C9.21151 7.20374 10.093 6.32229 10.093 5.23499C10.093 4.14767 9.21151 3.26624 8.12421 3.26624C7.0369 3.26624 6.15546 4.14767 6.15546 5.23499C6.15546 6.32229 7.0369 7.20374 8.12421 7.20374Z"
            fill="currentColor"
          />
          <path
            d="M11.818 10.5975C10.2992 12.6412 7.42106 13.0631 5.37731 11.5537C5.01171 11.2818 4.69296 10.9631 4.42107 10.5975C4.28982 10.4006 4.27107 10.1475 4.37419 9.94123L4.51482 9.65059C4.84296 8.95684 5.53671 8.51624 6.30546 8.51624H9.95231C10.7023 8.51624 11.3867 8.94749 11.7242 9.62249L11.8742 9.93184C11.968 10.1475 11.9586 10.4006 11.818 10.5975Z"
            fill="currentColor"
          />
        </svg>
      </span>
    );
  };

  // Render with tooltip if provided
  if (tooltip) {
    return (
      <div class="hs-tooltip inline-block">
        <Container
          id={id}
          href={href}
          class="hs-tooltip-toggle relative inline-block"
          onClick={handleClick}
          {...rest}
        >
          {renderAvatarContent()}

          {/* Status indicator */}
          {status !== "none" && (
            <span
              class={cn(
                statusPositionClasses,
                "block",
                statusSizeClasses[size],
                "rounded-full ring-2 ring-white dark:ring-neutral-900",
                statusColor || statusColorClasses[status],
              )}
            />
          )}

          {/* Icon/Badge */}
          {icon && (
            <span
              class={cn(
                "absolute",
                badgePosition === "top" ? "top-0" : "bottom-0",
                "end-0 block transform",
                badgePosition === "top"
                  ? "-translate-y-1/2 translate-x-1/2"
                  : "translate-y-1/2 translate-x-1/2",
                iconBg
                  ? "p-2 rounded-full bg-white dark:bg-neutral-900 dark:ring-neutral-900"
                  : "",
              )}
            >
              {icon}
            </span>
          )}

          {/* Tooltip content */}
          <div
            class="hs-tooltip-content hs-tooltip-shown:opacity-100 hs-tooltip-shown:visible opacity-0 transition-opacity inline-block absolute invisible z-10 py-1 px-2 bg-gray-900 text-xs font-medium text-white rounded-lg shadow-2xs dark:bg-neutral-700"
            role="tooltip"
          >
            {tooltip}
          </div>
        </Container>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Standard render without tooltip
  return (
    <Container
      id={id}
      href={href}
      class="relative inline-block"
      onClick={handleClick}
      {...rest}
    >
      {renderAvatarContent()}

      {/* Status indicator */}
      {status !== "none" && (
        <span
          class={cn(
            statusPositionClasses,
            "block",
            statusSizeClasses[size],
            "rounded-full ring-2 ring-white dark:ring-neutral-900",
            statusColor || statusColorClasses[status],
          )}
        />
      )}

      {/* Icon/Badge */}
      {icon && (
        <span
          class={cn(
            "absolute",
            badgePosition === "top" ? "top-0" : "bottom-0",
            "end-0 block transform",
            badgePosition === "top"
              ? "-translate-y-1/2 translate-x-1/2"
              : "translate-y-1/2 translate-x-1/2",
            iconBg
              ? "p-2 rounded-full bg-white dark:bg-neutral-900 dark:ring-neutral-900"
              : "",
          )}
        >
          {icon}
        </span>
      )}
    </Container>
  ) as Pulse.JSX.Element;
};
