/**
 * Timeline Components
 * A set of components to display chronological events in a vertical timeline
 * Includes Timeline (container), TimelineItem, and TimelineHeading
 *
 * @example
 * ```tsx
 * import { Timeline, TimelineItem, TimelineHeading } from '@odyssee/components';
 *
 * // Simple timeline with items array
 * <Timeline
 *   items={[
 *     {
 *       title: "Created task",
 *       description: "Find detailed instructions here",
 *       icon: "dot",
 *       user: { name: "James Collins", avatar: "url" }
 *     },
 *     {
 *       title: "Bug fixed",
 *       icon: "badge",
 *       initials: "A",
 *       user: { name: "Alex", initials: "A" }
 *     }
 *   ]}
 * />
 *
 * // With time display
 * <Timeline
 *   showTime
 *   timePosition="left"
 *   items={[
 *     { title: "Task created", time: "12:05PM" },
 *     { title: "Bug fixed", time: "1:30PM" }
 *   ]}
 * />
 *
 * // Grouped by date
 * <Timeline
 *   grouped
 *   groups={[
 *     {
 *       heading: "1 Aug, 2023",
 *       items: [{ title: "Task 1" }, { title: "Task 2" }]
 *     },
 *     {
 *       heading: "31 Jul, 2023",
 *       items: [{ title: "Task 3" }]
 *     }
 *   ]}
 * />
 *
 * // Hoverable + clickable
 * <Timeline
 *   hoverable
 *   items={[
 *     { title: "Task", href: "/task/123", onClick: () => {} }
 *   ]}
 * />
 *
 * // Collapsible
 * <Timeline
 *   collapsible
 *   collapsedItemsCount={3}
 *   collapseLabel="Show older"
 *   items={[...10 items]}
 * />
 *
 * // Manual composition
 * <Timeline>
 *   <TimelineHeading>1 Aug, 2023</TimelineHeading>
 *   <TimelineItem
 *     title="Created task"
 *     icon="avatar"
 *     avatar="url"
 *     user={{ name: "James", avatar: "url" }}
 *   />
 *   <TimelineItem
 *     title="Bug fixed"
 *     icon="badge"
 *     initials="A"
 *     isLast
 *   />
 * </Timeline>
 * ```
 */

import Pulse from "pulse-framework";
import type {
  TimelineProps,
  TimelineItemProps,
  TimelineHeadingProps,
} from "../../types";
import { cn, generateId } from "../../utils";
import { Avatar } from "./Avatar";

/**
 * TimelineHeading Component
 * A heading to group timeline items (e.g., by date)
 */
export const TimelineHeading: Pulse.Fn<TimelineHeadingProps> = (props) => {
  const { children, className, id, style, ...rest } = props;

  return (
    <div
      id={id}
      class={cn("ps-2 my-2 first:mt-0", className)}
      style={style}
      {...rest}
    >
      <h3 class="text-xs font-medium uppercase text-gray-500 dark:text-neutral-400">
        {children}
      </h3>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * TimelineItem Component
 * A single timeline event item
 */
export const TimelineItem: Pulse.Fn<TimelineItemProps> = (props) => {
  const {
    title,
    description,
    icon = "dot",
    iconContent,
    avatar,
    initials,
    user,
    time,
    showTime = false,
    timePosition = "left",
    href,
    onClick,
    hoverable = false,
    isLast = false,
    lineColor,
    dotColor,
    className,
    id = generateId("timeline-item"),
    style,
    ...rest
  } = props;

  // Line color
  const lineColorClass = lineColor || "bg-gray-200 dark:bg-neutral-700";
  const dotColorClass = dotColor || "bg-gray-400 dark:bg-neutral-600";

  // Icon rendering
  const renderIcon = () => {
    if (icon === "avatar" && avatar) {
      return <Avatar src={avatar} size="sm" alt="Timeline avatar" />;
    }

    if (icon === "badge" && initials) {
      return (
        <span class="flex shrink-0 justify-center items-center size-7 border border-gray-200 text-sm font-semibold uppercase text-gray-800 rounded-full dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-400">
          {initials}
        </span>
      );
    }

    if (icon === "icon" && iconContent) {
      return (
        <span class="flex shrink-0 justify-center items-center size-7 bg-white border border-gray-200 text-gray-600 rounded-full dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-400">
          {iconContent}
        </span>
      );
    }

    // Default dot
    return (
      <div class="relative z-10 size-7 flex justify-center items-center">
        <div class={cn("size-2 rounded-full", dotColorClass)}></div>
      </div>
    );
  };

  // User button rendering
  const renderUser = () => {
    if (!user) return null;

    const userContent = (
      <>
        {user.avatar ? (
          <Avatar src={user.avatar} size="xs" alt={user.name} />
        ) : user.initials ? (
          <span class="flex shrink-0 justify-center items-center size-4 bg-white border border-gray-200 text-[10px] font-semibold uppercase text-gray-600 rounded-full dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-400">
            {user.initials}
          </span>
        ) : null}
        {user.name}
      </>
    );

    if (user.onClick) {
      return (
        <button
          type="button"
          class={cn(
            "mt-1 -ms-1 p-1 inline-flex items-center gap-x-2 text-xs rounded-lg border border-transparent text-gray-500",
            hoverable
              ? "hover:bg-white hover:shadow-2xs dark:hover:bg-neutral-800"
              : "hover:bg-gray-100 dark:hover:bg-neutral-700",
            "focus:outline-none",
            hoverable ? "relative z-10" : "",
            "disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400",
          )}
          onClick={user.onClick}
        >
          {userContent}
        </button>
      );
    }

    return (
      <div class="mt-1 -ms-1 p-1 inline-flex items-center gap-x-2 text-xs text-gray-500 dark:text-neutral-400">
        {userContent}
      </div>
    );
  };

  // Title icon (if present in title as JSX)
  const renderTitle = () => {
    if (typeof title === "string") {
      return (
        <h3 class="font-semibold text-gray-800 dark:text-white">{title}</h3>
      );
    }
    return (
      <h3 class="flex gap-x-1.5 font-semibold text-gray-800 dark:text-white">
        {title}
      </h3>
    );
  };

  // Item wrapper (for hoverable/clickable)
  const ItemWrapper = ({
    children,
  }: {
    children: Pulse.JSX.Element | Pulse.JSX.Element[];
  }) => {
    if (hoverable && (href || onClick)) {
      return (
        <div
          class={cn(
            "flex gap-x-3 relative group rounded-lg hover:bg-gray-100 dark:hover:bg-white/10",
            className,
          )}
          {...rest}
        >
          {href && (
            <a class="absolute inset-0 z-0" href={href} onClick={onClick}></a>
          )}
          {!href && onClick && (
            <button
              type="button"
              class="absolute inset-0 z-0"
              onClick={onClick}
            ></button>
          )}
          {children}
        </div>
      );
    }

    return (
      <div class={cn("flex gap-x-3", className)} {...rest}>
        {children}
      </div>
    );
  };

  const iconClasses = cn(
    "relative",
    !isLast &&
      "after:absolute after:top-7 after:bottom-0 after:start-3.5 after:w-px after:-translate-x-[0.5px]",
    !isLast && `after:${lineColorClass}`,
    hoverable && !isLast && "dark:group-hover:after:bg-neutral-600",
  );

  const iconDotClasses = cn(
    "relative z-10 size-7 flex justify-center items-center",
    hoverable &&
      "size-2 rounded-full bg-white border-2 border-gray-300 group-hover:border-gray-600 dark:bg-neutral-800 dark:border-neutral-600 dark:group-hover:border-neutral-600",
  );

  const content = (
    <>
      {/* Time (left) */}
      {showTime && time && timePosition === "left" && (
        <div class="min-w-14 text-end">
          <span class="text-xs text-gray-500 dark:text-neutral-400">
            {time}
          </span>
        </div>
      )}

      {/* Icon */}
      <div class={iconClasses}>
        {hoverable && icon === "dot" ? (
          <div class={iconDotClasses}></div>
        ) : (
          renderIcon()
        )}
      </div>

      {/* Content */}
      <div class={cn("grow", hoverable ? "p-2 pb-8" : "pt-0.5 pb-8")}>
        {renderTitle()}

        {description && (
          <p class="mt-1 text-sm text-gray-600 dark:text-neutral-400">
            {description}
          </p>
        )}

        {renderUser()}
      </div>

      {/* Time (right) */}
      {showTime && time && timePosition === "right" && (
        <div class="text-end">
          <span class="text-xs text-gray-500 dark:text-neutral-400">
            {time}
          </span>
        </div>
      )}
    </>
  );

  return (<ItemWrapper>{content}</ItemWrapper>) as Pulse.JSX.Element;
};

/**
 * Timeline Component
 * Container for timeline items, supports both data-driven and composition patterns
 */
export const Timeline: Pulse.Fn<TimelineProps> = (props) => {
  const {
    items,
    grouped = false,
    groups,
    showTime = false,
    timePosition = "left",
    hoverable = false,
    collapsible = false,
    collapsedItemsCount = 3,
    collapseLabel = "Show older",
    lineColor,
    dotColor,
    children,
    className,
    id = generateId("timeline"),
    style,
    ...rest
  } = props;

  // Collapse state
  const isCollapsed = Pulse.signal(collapsible);

  const toggleCollapse = () => {
    isCollapsed(!isCollapsed());
  };

  // Render from items array
  if (items && items.length > 0) {
    const visibleItems =
      collapsible && isCollapsed()
        ? items.slice(0, collapsedItemsCount)
        : items;

    const collapsedItems = collapsible ? items.slice(collapsedItemsCount) : [];

    return (
      <div id={id} class={className} style={style} {...rest}>
        {visibleItems.map((item, index) => (
          <TimelineItem
            key={index}
            title={item.title}
            description={item.description}
            icon={item.icon}
            iconContent={item.iconContent}
            avatar={item.avatar}
            initials={item.initials}
            user={item.user}
            time={item.time}
            showTime={showTime || !!item.time}
            timePosition={timePosition}
            href={item.href}
            onClick={item.onClick}
            hoverable={hoverable || item.hoverable}
            isLast={
              index === items.length - 1 ||
              (collapsible &&
                isCollapsed() &&
                index === collapsedItemsCount - 1)
            }
            lineColor={lineColor}
            dotColor={dotColor}
          />
        ))}

        {/* Collapsed items */}
        {collapsible && collapsedItems.length > 0 && !isCollapsed() && (
          <div>
            {collapsedItems.map((item, index) => (
              <TimelineItem
                key={`collapsed-${index}`}
                title={item.title}
                description={item.description}
                icon={item.icon}
                iconContent={item.iconContent}
                avatar={item.avatar}
                initials={item.initials}
                user={item.user}
                time={item.time}
                showTime={showTime || !!item.time}
                timePosition={timePosition}
                href={item.href}
                onClick={item.onClick}
                hoverable={hoverable || item.hoverable}
                isLast={index === collapsedItems.length - 1}
                lineColor={lineColor}
                dotColor={dotColor}
              />
            ))}
          </div>
        )}

        {/* Show more button */}
        {collapsible && collapsedItems.length > 0 && isCollapsed() && (
          <div class="ps-2 -ms-px flex gap-x-3">
            <button
              type="button"
              class="text-start inline-flex items-center gap-x-1 text-sm text-blue-600 font-medium decoration-2 hover:underline focus:outline-none focus:underline dark:text-blue-500"
              onClick={toggleCollapse}
            >
              <svg
                class="shrink-0 size-3.5"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="m6 9 6 6 6-6"></path>
              </svg>
              {collapseLabel}
            </button>
          </div>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render from groups
  if (grouped && groups && groups.length > 0) {
    return (
      <div id={id} class={className} style={style} {...rest}>
        {groups.map((group, groupIndex) => (
          <div key={groupIndex}>
            <TimelineHeading>{group.heading}</TimelineHeading>
            {group.items.map((item, itemIndex) => (
              <TimelineItem
                key={`${groupIndex}-${itemIndex}`}
                title={item.title}
                description={item.description}
                icon={item.icon}
                iconContent={item.iconContent}
                avatar={item.avatar}
                initials={item.initials}
                user={item.user}
                time={item.time}
                showTime={showTime || !!item.time}
                timePosition={timePosition}
                href={item.href}
                onClick={item.onClick}
                hoverable={hoverable || item.hoverable}
                isLast={
                  groupIndex === groups.length - 1 &&
                  itemIndex === group.items.length - 1
                }
                lineColor={lineColor}
                dotColor={dotColor}
              />
            ))}
          </div>
        ))}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Manual composition with children
  return (
    <div id={id} class={className} style={style} {...rest}>
      {children}
    </div>
  ) as Pulse.JSX.Element;
};

export default Timeline;
