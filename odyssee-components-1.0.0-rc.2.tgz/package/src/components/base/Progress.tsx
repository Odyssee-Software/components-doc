/**
 * Progress Component
 * A versatile progress bar component with linear, circular, and gauge variants
 *
 * @example
 * ```tsx
 * import { Progress } from '@odyssee/components';
 *
 * // Basic progress bar
 * <Progress value={25} />
 *
 * // With label
 * <Progress value={50} label="Progress title" showValue={true} />
 *
 * // Different sizes
 * <Progress value={25} size="xs" />
 * <Progress value={50} size="sm" />
 * <Progress value={75} size="md" />
 * <Progress value={100} size="lg" />
 *
 * // With colors
 * <Progress value={50} color="primary" />
 * <Progress value={75} color="success" />
 * <Progress value={30} color="danger" />
 *
 * // Label positions
 * <Progress value={50} showValue={true} valuePosition="inside" />
 * <Progress value={50} showValue={true} valuePosition="end" />
 * <Progress value={50} showValue={true} valuePosition="top" />
 * <Progress value={50} showValue={true} valuePosition="floating" />
 *
 * // Reactive value with signal
 * const progress = Pulse.signal(0);
 * <Progress value={progress} showValue={true} />
 *
 * // Vertical progress
 * <Progress value={75} vertical={true} height="h-32" />
 *
 * // Segmented progress (steps)
 * <Progress value={50} segments={4} showValue={true} valuePosition="end" />
 *
 * // Circular progress
 * <Progress value={35} type="circular" showValue={true} circularSize={160} />
 *
 * // Gauge progress
 * <Progress value={50} type="gauge" label="Score" showValue={true} />
 *
 * // Half gauge
 * <Progress value={75} type="gauge-half" label="Score" showValue={true} />
 *
 * // With custom value format
 * <Progress
 *   value={50}
 *   showValue={true}
 *   valueFormat={(value, max) => `${value}/${max} MB`}
 * />
 *
 * // Animated
 * <Progress value={75} animated={true} transition={true} />
 * ```
 */

import Pulse from "pulse-framework";
import type { ProgressProps } from "../../types";
import { cn, isSignal } from "../../utils";

export const Progress: Pulse.Fn<ProgressProps> = (props) => {
  const {
    // Value
    value,
    max = 100,
    min = 0,

    // Display
    label,
    showValue = false,
    valuePosition = "inside",
    valueFormat,

    // Styling
    size = "md",
    color = "primary",
    variant = "default",

    // Shape
    rounded = true,
    vertical = false,
    height,

    // Multiple bars
    segments,
    segmentGap = "gap-x-1",

    // Circular/Gauge
    type = "linear",
    circularSize = 160,
    strokeWidth = 2,

    // Animation
    animated = false,
    transition = true,

    // Status
    showStatus = false,
    statusIcon,

    className,
    id,
    style,
    ...rest
  } = props;

  // Get reactive value
  const currentValue = () => {
    const val = isSignal(value) ? (value as any)() : value;
    return Math.min(Math.max(val, min), max);
  };

  // Calculate percentage
  const percentage = () => {
    return ((currentValue() - min) / (max - min)) * 100;
  };

  // Format value
  const formatValue = () => {
    if (valueFormat) {
      return valueFormat(currentValue(), max);
    }
    return `${Math.round(percentage())}%`;
  };

  // Size classes for linear progress
  const sizeClasses = {
    xs: "h-1",
    sm: "h-1.5",
    md: "h-2",
    lg: "h-4",
    xl: "h-6",
  };

  // Color classes
  const colorClasses = {
    primary: "bg-blue-600 dark:bg-blue-500",
    secondary: "bg-gray-800 dark:bg-white",
    success: "bg-teal-500",
    danger: "bg-red-500",
    warning: "bg-yellow-500",
    info: "bg-blue-600",
    light: "bg-gray-500",
    dark: "bg-gray-800",
  };

  // Render circular progress
  if (type === "circular") {
    const radius = 16;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = () => circumference - (percentage() / 100) * circumference;

    return (
      <div
        id={id}
        class={cn("relative", className)}
        style={`width: ${circularSize}px; height: ${circularSize}px; ${style || ""}`}
        {...rest}
      >
        <svg
          class="size-full -rotate-90"
          viewBox="0 0 36 36"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Background Circle */}
          <circle
            cx="18"
            cy="18"
            r={radius}
            fill="none"
            class="stroke-current text-gray-200 dark:text-neutral-700"
            stroke-width={strokeWidth}
          />
          {/* Progress Circle */}
          <circle
            cx="18"
            cy="18"
            r={radius}
            fill="none"
            class={cn("stroke-current", colorClasses[color])}
            stroke-width={strokeWidth}
            stroke-dasharray={circumference}
            stroke-dashoffset={strokeDashoffset()}
            stroke-linecap="round"
            style={transition ? "transition: stroke-dashoffset 0.5s ease" : ""}
          />
        </svg>

        {/* Center Text */}
        {showValue && (
          <div class="absolute top-1/2 start-1/2 transform -translate-y-1/2 -translate-x-1/2 text-center">
            <span class={cn("text-2xl font-bold", `text-${color}-600 dark:text-${color}-500`)}>
              {formatValue()}
            </span>
          </div>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render gauge progress
  if (type === "gauge" || type === "gauge-half") {
    const radius = 16;
    const maxDash = type === "gauge" ? 75 : 50;
    const dashValue = () => (percentage() / 100) * maxDash;
    const rotation = type === "gauge" ? "rotate-[135deg]" : "rotate-180";

    return (
      <div
        id={id}
        class={cn("relative", className)}
        style={`width: ${circularSize}px; height: ${circularSize}px; ${style || ""}`}
        {...rest}
      >
        <svg
          class={cn("size-full", rotation)}
          viewBox="0 0 36 36"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Background Circle (Gauge) */}
          <circle
            cx="18"
            cy="18"
            r={radius}
            fill="none"
            class="stroke-current text-gray-200 dark:text-neutral-700"
            stroke-width={strokeWidth}
            stroke-dasharray={`${maxDash} 100`}
            stroke-linecap="round"
          />
          {/* Gauge Progress */}
          <circle
            cx="18"
            cy="18"
            r={radius}
            fill="none"
            class={cn("stroke-current", colorClasses[color])}
            stroke-width={strokeWidth + 0.5}
            stroke-dasharray={`${dashValue()} 100`}
            stroke-linecap="round"
            style={transition ? "transition: stroke-dasharray 0.5s ease" : ""}
          />
        </svg>

        {/* Value Text */}
        {showValue && (
          <div class={cn(
            "absolute start-1/2 transform -translate-x-1/2 text-center",
            type === "gauge" ? "top-1/2 -translate-y-1/2" : "top-9"
          )}>
            <span class={cn("text-4xl font-bold", `text-${color}-600 dark:text-${color}-500`)}>
              {currentValue()}
            </span>
            {label && (
              <span class={cn("block", `text-${color}-600 dark:text-${color}-500`)}>
                {label}
              </span>
            )}
          </div>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render segmented progress (steps)
  if (segments) {
    const completedSegments = () => Math.ceil((percentage() / 100) * segments);

    return (
      <div id={id} class={cn("flex items-center", segmentGap, className)} style={style} {...rest}>
        {Array.from({ length: segments }).map((_, index) => (
          <div
            class={cn(
              "w-full h-2.5 flex flex-col justify-center overflow-hidden text-xs text-white text-center whitespace-nowrap",
              transition && "transition duration-500",
              index < completedSegments()
                ? colorClasses[color]
                : "bg-gray-300 dark:bg-neutral-600"
            )}
            role="progressbar"
            aria-valuenow={index < completedSegments() ? max / segments : 0}
            aria-valuemin={0}
            aria-valuemax={max}
          />
        ))}
        {showValue && valuePosition === "end" && (
          <div class="w-10 text-end">
            <span class="text-sm text-gray-800 dark:text-white">{formatValue()}</span>
          </div>
        )}
        {showStatus && statusIcon && (
          <div class="ms-1">
            <span class={cn(
              "shrink-0 ms-auto size-4 flex justify-center items-center rounded-full text-white",
              colorClasses[color]
            )}>
              {statusIcon}
            </span>
          </div>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render vertical progress
  if (vertical) {
    return (
      <div
        id={id}
        class={cn(
          "flex flex-col flex-nowrap justify-end w-2 bg-gray-200 rounded-full overflow-hidden dark:bg-neutral-700",
          height || "h-32",
          className
        )}
        role="progressbar"
        aria-valuenow={currentValue()}
        aria-valuemin={min}
        aria-valuemax={max}
        style={style}
        {...rest}
      >
        <div
          class={cn(
            "rounded-full overflow-hidden",
            colorClasses[color],
            transition && "transition-all duration-500"
          )}
          style={`height: ${percentage()}%`}
        />
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render linear progress (default)
  const containerClasses = cn(
    "flex w-full bg-gray-200 overflow-hidden dark:bg-neutral-700",
    rounded ? "rounded-full" : "",
    height || sizeClasses[size]
  );

  const barClasses = cn(
    "flex flex-col justify-center overflow-hidden text-xs text-white text-center whitespace-nowrap",
    rounded ? "rounded-full" : "",
    colorClasses[color],
    transition && "transition duration-500"
  );

  // Render with label and value on top
  if (label || (showValue && valuePosition === "top")) {
    return (
      <div id={id} class={className} style={style} {...rest}>
        {(label || showValue) && (
          <div class="mb-2 flex justify-between items-center">
            {label && (
              <h3 class="text-sm font-semibold text-gray-800 dark:text-white">
                {label}
              </h3>
            )}
            {showValue && valuePosition === "top" && (
              <span class="text-sm text-gray-800 dark:text-white">
                {formatValue()}
              </span>
            )}
          </div>
        )}
        <div
          class={containerClasses}
          role="progressbar"
          aria-valuenow={currentValue()}
          aria-valuemin={min}
          aria-valuemax={max}
        >
          <div class={barClasses} style={`width: ${percentage()}%`}>
            {showValue && valuePosition === "inside" && formatValue()}
          </div>
        </div>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render with floating label
  if (showValue && valuePosition === "floating") {
    return (
      <div id={id} class={className} style={style} {...rest}>
        <div
          class={cn(
            "inline-block mb-2 py-0.5 px-1.5 border text-xs font-medium rounded-lg",
            `bg-${color}-50 border-${color}-200 text-${color}-600`,
            `dark:bg-${color}-800/30 dark:border-${color}-800 dark:text-${color}-500`
          )}
          style={`margin-left: calc(${percentage()}% - 20px)`}
        >
          {formatValue()}
        </div>
        <div
          class={containerClasses}
          role="progressbar"
          aria-valuenow={currentValue()}
          aria-valuemin={min}
          aria-valuemax={max}
        >
          <div class={barClasses} style={`width: ${percentage()}%`} />
        </div>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render with value at the end
  if (showValue && valuePosition === "end") {
    return (
      <div id={id} class={cn("flex items-center gap-x-3 whitespace-nowrap", className)} style={style} {...rest}>
        <div
          class={containerClasses}
          role="progressbar"
          aria-valuenow={currentValue()}
          aria-valuemin={min}
          aria-valuemax={max}
        >
          <div class={barClasses} style={`width: ${percentage()}%`} />
        </div>
        {showStatus && statusIcon ? (
          <div class="w-10 text-end">
            <span class={cn(
              "shrink-0 ms-auto size-4 flex justify-center items-center rounded-full text-white",
              colorClasses[color]
            )}>
              {statusIcon}
            </span>
          </div>
        ) : (
          <div class="w-10 text-end">
            <span class="text-sm text-gray-800 dark:text-white">
              {formatValue()}
            </span>
          </div>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Default render (basic progress bar)
  return (
    <div
      id={id}
      class={cn(containerClasses, className)}
      role="progressbar"
      aria-valuenow={currentValue()}
      aria-valuemin={min}
      aria-valuemax={max}
      style={style}
      {...rest}
    >
      <div class={barClasses} style={`width: ${percentage()}%`}>
        {showValue && valuePosition === "inside" && formatValue()}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
