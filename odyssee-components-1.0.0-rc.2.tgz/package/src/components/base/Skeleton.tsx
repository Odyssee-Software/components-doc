/**
 * Skeleton Component
 * Loading placeholder component for enhancing the user experience during data loading
 *
 * @example
 * ```tsx
 * import { Skeleton, SkeletonAvatar, SkeletonCard } from '@odyssee/components';
 *
 * // Basic skeleton line
 * <Skeleton />
 *
 * // Multiple lines
 * <Skeleton lines={3} />
 *
 * // With animation
 * <Skeleton animate lines={4} />
 *
 * // Custom width
 * <Skeleton width="40%" />
 *
 * // Circular (for avatar)
 * <Skeleton variant="circular" width={48} height={48} />
 *
 * // Avatar skeleton
 * <SkeletonAvatar size="lg" animate />
 *
 * // Card skeleton (avatar + text)
 * <SkeletonCard avatar lines={4} animate />
 * ```
 */

import Pulse from "pulse-framework";
import type {
  SkeletonProps,
  SkeletonAvatarProps,
  SkeletonCardProps,
} from "../../types";
import { cn, generateId } from "../../utils";

export const Skeleton: Pulse.Fn<SkeletonProps> = (props) => {
  const {
    variant = "text",
    width,
    height,
    animate = false,
    lines = 1,
    gap = "md",
    className,
    id = generateId("skeleton"),
    style,
    ...rest
  } = props;

  // Gap classes
  const gapClasses = {
    sm: "space-y-2",
    md: "space-y-3",
    lg: "space-y-4",
  };

  // Base classes
  const baseClasses = cn(
    "bg-gray-200 dark:bg-neutral-700",
    animate && "animate-pulse",
  );

  // Variant classes
  const variantClasses = {
    text: "rounded-full h-4",
    circular: "rounded-full",
    rectangular: "rounded-lg",
  };

  // Build inline styles
  const buildStyle = (lineWidth?: string | number) => {
    const styles: any = {};

    if (lineWidth !== undefined) {
      if (typeof lineWidth === "string") {
        styles.width = lineWidth;
      } else {
        styles.width = `${lineWidth}px`;
      }
    }

    if (height !== undefined) {
      if (typeof height === "string") {
        styles.height = height;
      } else {
        styles.height = `${height}px`;
      }
    }

    // Merge with user provided style
    if (style) {
      if (typeof style === "string") {
        return style;
      }
      return { ...styles, ...style };
    }

    return styles;
  };

  // Single line
  if (lines === 1) {
    return (
      <span
        id={id}
        class={cn(baseClasses, variantClasses[variant], className)}
        style={buildStyle(width)}
        {...rest}
      />
    ) as Pulse.JSX.Element;
  }

  // Multiple lines
  return (
    <ul id={id} class={cn(gapClasses[gap], className)} {...rest}>
      {Array.from({ length: lines }).map((_, index) => {
        // Last line is often shorter
        const lineWidth =
          index === lines - 1 && !width && variant === "text"
            ? "80%"
            : width;

        return (
          <li
            key={index}
            class={cn(
              baseClasses,
              variantClasses[variant],
              variant === "text" && "w-full",
            )}
            style={buildStyle(lineWidth)}
          />
        );
      })}
    </ul>
  ) as Pulse.JSX.Element;
};

/**
 * SkeletonAvatar Component
 * A circular skeleton for avatar loading states
 *
 * @example
 * ```tsx
 * <SkeletonAvatar size="md" />
 * <SkeletonAvatar size="lg" animate />
 * ```
 */
export const SkeletonAvatar: Pulse.Fn<SkeletonAvatarProps> = (props) => {
  const {
    size = "md",
    animate = false,
    className,
    id = generateId("skeleton-avatar"),
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "size-8",
    sm: "size-10",
    md: "size-12",
    lg: "size-16",
    xl: "size-20",
  };

  return (
    <span
      id={id}
      class={cn(
        "block rounded-full bg-gray-200 dark:bg-neutral-700",
        animate && "animate-pulse",
        sizeClasses[size],
        className,
      )}
      {...rest}
    />
  ) as Pulse.JSX.Element;
};

/**
 * SkeletonCard Component
 * A complex skeleton combination with avatar and text lines
 *
 * @example
 * ```tsx
 * // Basic card skeleton
 * <SkeletonCard />
 *
 * // With avatar
 * <SkeletonCard avatar avatarSize="lg" />
 *
 * // With animation
 * <SkeletonCard avatar lines={4} animate />
 *
 * // Custom title width
 * <SkeletonCard avatar titleWidth="60%" lines={3} animate />
 * ```
 */
export const SkeletonCard: Pulse.Fn<SkeletonCardProps> = (props) => {
  const {
    avatar = true,
    avatarSize = "md",
    lines = 4,
    animate = false,
    titleWidth = "40%",
    className,
    id = generateId("skeleton-card"),
    ...rest
  } = props;

  return (
    <div
      id={id}
      class={cn("flex", animate && "animate-pulse", className)}
      {...rest}
    >
      {/* Avatar */}
      {avatar && (
        <div class="shrink-0">
          <SkeletonAvatar size={avatarSize} animate={false} />
        </div>
      )}

      {/* Content */}
      <div class={cn("w-full", avatar && "ms-4 mt-2")}>
        {/* Title */}
        <p
          class="h-4 bg-gray-200 rounded-full dark:bg-neutral-700"
          style={{ width: titleWidth }}
        />

        {/* Lines */}
        {lines > 0 && (
          <ul class="mt-5 space-y-3">
            {Array.from({ length: lines }).map((_, index) => (
              <li
                key={index}
                class="w-full h-4 bg-gray-200 rounded-full dark:bg-neutral-700"
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * SkeletonText Component
 * Convenience component for text skeleton (multiple lines)
 *
 * @example
 * ```tsx
 * <SkeletonText lines={3} />
 * <SkeletonText lines={5} animate />
 * ```
 */
export const SkeletonText: Pulse.Fn<
  Omit<SkeletonProps, "variant">
> = (props) => {
  return <Skeleton {...props} variant="text" />;
};

/**
 * SkeletonCircle Component
 * Convenience component for circular skeleton
 *
 * @example
 * ```tsx
 * <SkeletonCircle width={48} height={48} />
 * ```
 */
export const SkeletonCircle: Pulse.Fn<
  Omit<SkeletonProps, "variant">
> = (props) => {
  return <Skeleton {...props} variant="circular" />;
};

/**
 * SkeletonRectangle Component
 * Convenience component for rectangular skeleton
 *
 * @example
 * ```tsx
 * <SkeletonRectangle width="100%" height={200} />
 * ```
 */
export const SkeletonRectangle: Pulse.Fn<
  Omit<SkeletonProps, "variant">
> = (props) => {
  return <Skeleton {...props} variant="rectangular" />;
};

/**
 * SkeletonButton Component
 * Skeleton for button loading state
 *
 * @example
 * ```tsx
 * <SkeletonButton />
 * <SkeletonButton animate width={120} />
 * ```
 */
export const SkeletonButton: Pulse.Fn<Omit<SkeletonProps, "variant">> = (
  props,
) => {
  const { width = 100, height = 40, ...rest } = props;
  return (
    <Skeleton
      {...rest}
      variant="rectangular"
      width={width}
      height={height}
    />
  );
};

/**
 * SkeletonInput Component
 * Skeleton for input field loading state
 *
 * @example
 * ```tsx
 * <SkeletonInput />
 * <SkeletonInput animate width="100%" />
 * ```
 */
export const SkeletonInput: Pulse.Fn<Omit<SkeletonProps, "variant">> = (
  props,
) => {
  const { width = "100%", height = 40, ...rest } = props;
  return (
    <Skeleton
      {...rest}
      variant="rectangular"
      width={width}
      height={height}
    />
  );
};

/**
 * SkeletonImage Component
 * Skeleton for image loading state
 *
 * @example
 * ```tsx
 * <SkeletonImage width="100%" height={200} />
 * <SkeletonImage width={300} height={200} animate />
 * ```
 */
export const SkeletonImage: Pulse.Fn<Omit<SkeletonProps, "variant">> = (
  props,
) => {
  const { width = "100%", height = 200, ...rest } = props;
  return (
    <Skeleton
      {...rest}
      variant="rectangular"
      width={width}
      height={height}
    />
  );
};

/**
 * SkeletonTable Component
 * Skeleton for table loading state
 *
 * @example
 * ```tsx
 * <SkeletonTable rows={5} />
 * <SkeletonTable rows={3} animate />
 * ```
 */
export const SkeletonTable: Pulse.Fn<{
  rows?: number;
  animate?: boolean;
  className?: string;
}> = (props) => {
  const { rows = 5, animate = false, className } = props;

  return (
    <div class={cn("space-y-3", animate && "animate-pulse", className)}>
      {/* Header */}
      <div class="h-10 bg-gray-200 rounded-lg dark:bg-neutral-700" />

      {/* Rows */}
      {Array.from({ length: rows }).map((_, index) => (
        <div
          key={index}
          class="h-12 bg-gray-200 rounded-lg dark:bg-neutral-700"
        />
      ))}
    </div>
  ) as Pulse.JSX.Element;
};

export default Skeleton;
