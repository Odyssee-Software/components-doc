/**
 * Kbd Component
 * A keyboard key component for displaying keyboard shortcuts and commands
 *
 * @example
 * ```tsx
 * import { Kbd, KbdGroup } from '@odyssee/components';
 *
 * // Basic kbd
 * <Kbd>ctrl</Kbd>
 *
 * // Different variants
 * <Kbd variant="text">ctrl</Kbd>
 * <Kbd variant="text-dark">ctrl</Kbd>
 * <Kbd variant="solid">ctrl</Kbd>
 * <Kbd variant="bordered">ctrl</Kbd>
 * <Kbd variant="shadow">ctrl</Kbd>
 *
 * // Different sizes
 * <Kbd size="xs">ctrl</Kbd>
 * <Kbd size="sm">ctrl</Kbd>
 * <Kbd size="md">ctrl</Kbd>
 * <Kbd size="lg">ctrl</Kbd>
 *
 * // With icon
 * <Kbd icon={<svg>...</svg>} square />
 *
 * // Group of keys
 * <KbdGroup keys={['Ctrl', 'B']} separator="+" />
 *
 * // Group with custom separator
 * <KbdGroup keys={['shift', 'and', 'b']} />
 * ```
 */

import Pulse from "pulse-framework";
import type { KbdProps, KbdGroupProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Kbd: Pulse.Fn<KbdProps> = (props) => {
  const {
    children,
    variant = "solid",
    size = "sm",
    icon,
    square = false,
    className,
    id = generateId("kbd"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: square ? "min-h-4.5 min-w-4.5 px-1 text-xs" : "min-h-4.5 px-1 text-xs",
    sm: square
      ? "min-h-7.5 min-w-7.5 py-1 px-1.5 text-sm"
      : "min-h-7.5 py-1 px-1.5 text-sm",
    md: square
      ? "min-h-9 min-w-9 py-1.5 px-2 text-base"
      : "min-h-9 py-1.5 px-2 text-base",
    lg: square
      ? "min-h-10.5 min-w-10.5 py-1.5 px-2 text-lg"
      : "min-h-10.5 py-1.5 px-2 text-lg",
  };

  // Variant classes
  const variantClasses = {
    text: "text-gray-400 dark:text-neutral-600",
    "text-dark": "text-gray-800 dark:text-neutral-200",
    solid:
      "bg-gray-200 border border-transparent text-gray-800 dark:bg-neutral-700 dark:text-neutral-200",
    bordered:
      "bg-white border border-gray-200 text-gray-800 dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-200",
    shadow:
      "bg-white border border-gray-200 text-gray-800 shadow-[0px_2px_0px_0px_rgba(0,0,0,0.08)] dark:bg-neutral-900 dark:border-neutral-700 dark:text-neutral-200 dark:shadow-[0px_2px_0px_0px_rgba(255,255,255,0.1)]",
  };

  // Base classes
  const baseClasses = cn(
    "inline-flex justify-center items-center",
    "font-mono rounded-md",
    sizeClasses[size],
    variantClasses[variant],
    className,
  );

  return (
    <kbd id={id} class={baseClasses} style={style} {...rest}>
      {icon && <span class="shrink-0">{icon}</span>}
      {children}
    </kbd>
  ) as Pulse.JSX.Element;
};

/**
 * KbdGroup Component
 * Display multiple keyboard keys together with separators
 *
 * @example
 * ```tsx
 * // Basic group
 * <KbdGroup keys={['Ctrl', 'B']} separator="+" />
 *
 * // With custom variant
 * <KbdGroup keys={['Ctrl', 'Alt', 'Delete']} variant="bordered" separator="+" />
 *
 * // Mixed content
 * <KbdGroup
 *   keys={[
 *     'Ctrl',
 *     '+',
 *     { children: 'b', variant: 'shadow' }
 *   ]}
 * />
 * ```
 */
export const KbdGroup: Pulse.Fn<KbdGroupProps> = (props) => {
  const {
    keys = [],
    separator = "+",
    variant = "solid",
    size = "sm",
    className,
    id = generateId("kbd-group"),
    style,
    ...rest
  } = props;

  // Container classes
  const containerClasses = cn(
    "flex flex-wrap items-center gap-x-1",
    "text-sm text-gray-600 dark:text-neutral-400",
    className,
  );

  // Render a single key
  const renderKey = (key: string | HTMLElement | KbdProps, _index: number) => {
    // If it's a string, wrap it in Kbd
    if (typeof key === "string") {
      return (
        <Kbd variant={variant} size={size}>
          {key}
        </Kbd>
      );
    }

    // If it's an HTMLElement, return it directly
    if (key instanceof HTMLElement || (key as any).tagName) {
      return key as HTMLElement;
    }

    // If it's a KbdProps object, render a Kbd with those props
    const kbdProps = key as KbdProps;
    return (
      <Kbd
        variant={kbdProps.variant || variant}
        size={kbdProps.size || size}
        icon={kbdProps.icon}
        square={kbdProps.square}
        {...kbdProps}
      >
        {kbdProps.children}
      </Kbd>
    );
  };

  return (
    <span id={id} class={containerClasses} style={style} {...rest}>
      {keys.map((key, index) => (
        <>
          {renderKey(key, index)}
          {index < keys.length - 1 && separator && (
            <span class="text-gray-600 dark:text-neutral-400">{separator}</span>
          )}
        </>
      ))}
    </span>
  ) as Pulse.JSX.Element;
};

/**
 * Helper components for common keyboard keys
 */

// Command key (⌘)
export const CmdKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const cmdIcon = (
    <svg
      class="shrink-0 size-3"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3"></path>
    </svg>
  );
  return <Kbd {...props} icon={cmdIcon as any} square />;
};

// Option/Alt key
export const OptionKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const optionIcon = (
    <svg
      class="shrink-0 size-3"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M3 3h6l6 18h6"></path>
      <path d="M14 3h7"></path>
    </svg>
  );
  return <Kbd {...props} icon={optionIcon as any} square />;
};

// Shift key (up arrow)
export const ShiftKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const shiftIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M9 18v-6H5l7-7 7 7h-4v6H9z"></path>
    </svg>
  );
  return <Kbd {...props} icon={shiftIcon as any} square />;
};

// Arrow up key
export const ArrowUpKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const arrowUpIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m18 15-6-6-6 6"></path>
    </svg>
  );
  return <Kbd {...props} icon={arrowUpIcon as any} square />;
};

// Arrow down key
export const ArrowDownKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const arrowDownIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m6 9 6 6 6-6"></path>
    </svg>
  );
  return <Kbd {...props} icon={arrowDownIcon as any} square />;
};

// Arrow left key
export const ArrowLeftKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const arrowLeftIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m15 18-6-6 6-6"></path>
    </svg>
  );
  return <Kbd {...props} icon={arrowLeftIcon as any} square />;
};

// Arrow right key
export const ArrowRightKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  const arrowRightIcon = (
    <svg
      class="shrink-0 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m9 18 6-6-6-6"></path>
    </svg>
  );
  return <Kbd {...props} icon={arrowRightIcon as any} square />;
};

// Enter/Return key
export const EnterKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>↵</Kbd>;
};

// Escape key
export const EscKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>Esc</Kbd>;
};

// Tab key
export const TabKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>Tab</Kbd>;
};

// Space key
export const SpaceKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>Space</Kbd>;
};

// Delete key
export const DeleteKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>Del</Kbd>;
};

// Backspace key
export const BackspaceKey: Pulse.Fn<Omit<KbdProps, "children">> = (props) => {
  return <Kbd {...props}>⌫</Kbd>;
};

export default Kbd;
