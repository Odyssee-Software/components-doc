/**
 * Card Component
 * A versatile card component with multiple layouts, variants, and interactive features
 *
 * @example
 * ```tsx
 * import { Card } from '@odyssee/components';
 *
 * // Basic card
 * <Card title="Card title" subtitle="Card subtitle">
 *   Some quick example text to build on the card title.
 * </Card>
 *
 * // Card with image
 * <Card
 *   image="https://images.unsplash.com/photo-1680868543815-b8666dba60f7"
 *   imageAlt="Card Image"
 *   title="Card title"
 * >
 *   Some quick example text to build on the card title and make up the bulk of the card's content.
 * </Card>
 *
 * // Card with header and footer
 * <Card
 *   header={<p class="text-sm text-gray-500">Featured</p>}
 *   footer={<p class="text-xs text-gray-500">Last updated 5 mins ago</p>}
 *   title="Card title"
 * >
 *   With supporting text below as a natural lead-in to additional content.
 * </Card>
 *
 * // Clickable card with hover effect
 * <Card
 *   image="https://images.unsplash.com/photo-1680868543815-b8666dba60f7"
 *   title="Card title"
 *   clickable={true}
 *   href="#"
 *   hoverEffect="shadow"
 * >
 *   Some quick example text to build on the card title.
 * </Card>
 *
 * // Horizontal card
 * <Card
 *   image="https://images.unsplash.com/photo-1680868543815-b8666dba60f7"
 *   title="Card title"
 *   horizontal={true}
 * >
 *   Some quick example text to build on the card title and make up the bulk of the card's content.
 * </Card>
 *
 * // Centered content
 * <Card title="Card title" centered={true}>
 *   With supporting text below as a natural lead-in to additional content.
 * </Card>
 *
 * // Empty state
 * <Card
 *   emptyState={true}
 *   emptyStateIcon="📦"
 *   emptyStateText="No data to show"
 * />
 *
 * // Scrollable card
 * <Card
 *   title="Card title"
 *   scrollable={true}
 *   scrollHeight="h-80"
 * >
 *   Long content that will be scrollable...
 * </Card>
 *
 * // Image overlay
 * <Card
 *   image="https://images.unsplash.com/photo-1680868543815-b8666dba60f7"
 *   imageOverlay={true}
 *   title="Card title"
 * >
 *   Some quick example text to build on the card title.
 * </Card>
 * ```
 */

import Pulse from "pulse-framework";
import type { CardProps } from "../../types";
import { cn } from "../../utils";

export const Card: Pulse.Fn<CardProps> = (props) => {
  const {
    // Content
    title,
    subtitle,
    children,

    // Header & Footer
    header,
    headerBordered = false,
    footer,
    footerBordered = false,

    // Image
    image,
    imageAlt = "Card Image",
    imagePosition = "top",
    imageOverlay = false,
    imageRounded = true,

    // Variants & Styling
    variant = "default",
    size = "md",

    // Layout
    horizontal = false,
    centered = false,

    // States & Interactions
    clickable = false,
    href,
    onClick,

    // Special modes
    scrollable = false,
    scrollHeight = "h-80",
    emptyState = false,
    emptyStateIcon,
    emptyStateText = "No data to show",

    // Animations
    hoverEffect = "none",

    className,
    id,
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    sm: "p-4 md:p-5",
    md: "p-4 md:p-7",
    lg: "p-4 md:p-10",
  };

  // Base card classes
  const baseClasses =
    "flex flex-col bg-white border border-gray-200 rounded-xl dark:bg-neutral-900 dark:border-neutral-700";

  // Variant classes
  const variantClasses = {
    default: "shadow-2xs dark:shadow-neutral-700/70",
    bordered: "border-2",
    shadow: "shadow-lg dark:shadow-neutral-700/70",
  };

  // Hover effect classes
  const hoverEffectClasses = {
    none: "",
    shadow:
      "hover:shadow-lg focus:outline-hidden focus:shadow-lg transition dark:hover:shadow-neutral-700/70",
    scale:
      "hover:shadow-lg focus:outline-hidden focus:shadow-lg transition overflow-hidden",
  };

  // Clickable classes
  const clickableClasses = clickable || href
    ? "cursor-pointer " + hoverEffectClasses[hoverEffect]
    : "";

  // Handle click
  const handleClick = (e: Event) => {
    if (onClick) {
      onClick(e);
    }
  };

  // Container element (a or div)
  const ContainerTag = href ? "a" : "div";

  // Image classes
  const getImageClasses = () => {
    if (horizontal) {
      return "w-full h-auto object-cover";
    }

    const roundedClass = imageRounded
      ? imagePosition === "top"
        ? "rounded-t-xl"
        : imagePosition === "bottom"
          ? "rounded-b-xl"
          : "rounded-xl"
      : "";

    return cn("w-full h-auto", roundedClass);
  };

  // Image with scale animation
  const imageScaleClasses =
    hoverEffect === "scale"
      ? "group-hover:scale-105 group-focus:scale-105 transition-transform duration-500 ease-in-out"
      : "";

  // Render empty state
  if (emptyState) {
    return (
      <div
        id={id}
        class={cn(
          "min-h-60",
          baseClasses,
          variantClasses[variant],
          className,
        )}
        style={style}
        {...rest}
      >
        <div class="flex flex-auto flex-col justify-center items-center p-4 md:p-5">
          {emptyStateIcon && (
            <div class="text-5xl text-gray-500 dark:text-neutral-500 mb-2">
              {emptyStateIcon}
            </div>
          )}
          <p class="text-sm text-gray-800 dark:text-neutral-300">
            {emptyStateText}
          </p>
        </div>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Horizontal layout
  if (horizontal) {
    return (
      <ContainerTag
        id={id}
        href={href}
        class={cn(
          baseClasses,
          variantClasses[variant],
          clickableClasses,
          "sm:flex",
          className,
        )}
        style={style}
        onClick={handleClick}
        {...rest}
      >
        {image && (
          <div class="shrink-0 relative w-full rounded-t-xl overflow-hidden pt-[40%] sm:rounded-s-xl sm:max-w-60 md:rounded-se-none md:max-w-xs">
            <img
              class={cn(
                "size-full absolute top-0 start-0 object-cover",
                imageScaleClasses,
              )}
              src={image}
              alt={imageAlt}
            />
          </div>
        )}
        <div class="flex flex-wrap">
          <div class={cn("flex flex-col h-full", sizeClasses[size])}>
            {title && (
              <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                {title}
              </h3>
            )}
            {subtitle && (
              <p class="mt-1 text-xs font-medium uppercase text-gray-500 dark:text-neutral-500">
                {subtitle}
              </p>
            )}
            {children && (
              <div class="mt-1 text-gray-500 dark:text-neutral-400">
                {children}
              </div>
            )}
            {footer && (
              <div class="mt-5 sm:mt-auto">
                {typeof footer === "string" ? (
                  <p class="text-xs text-gray-500 dark:text-neutral-500">
                    {footer}
                  </p>
                ) : (
                  footer
                )}
              </div>
            )}
          </div>
        </div>
      </ContainerTag>
    ) as Pulse.JSX.Element;
  }

  // Image overlay layout
  if (imageOverlay && image) {
    return (
      <ContainerTag
        id={id}
        href={href}
        class={cn(
          "relative",
          baseClasses,
          variantClasses[variant],
          clickableClasses,
          className,
        )}
        style={style}
        onClick={handleClick}
        {...rest}
      >
        <img class="w-full h-auto rounded-xl" src={image} alt={imageAlt} />
        <div class="absolute top-0 start-0 end-0">
          <div class={sizeClasses[size]}>
            {title && (
              <h3 class="text-lg font-bold text-gray-800">{title}</h3>
            )}
            {subtitle && (
              <p class="mt-1 text-xs font-medium uppercase text-gray-800">
                {subtitle}
              </p>
            )}
            {children && <div class="mt-1 text-gray-800">{children}</div>}
            {footer && (
              <div class="mt-5">
                {typeof footer === "string" ? (
                  <p class="text-xs text-gray-500 dark:text-neutral-500">
                    {footer}
                  </p>
                ) : (
                  footer
                )}
              </div>
            )}
          </div>
        </div>
      </ContainerTag>
    ) as Pulse.JSX.Element;
  }

  // Standard vertical layout
  return (
    <ContainerTag
      id={id}
      href={href}
      class={cn(
        baseClasses,
        variantClasses[variant],
        clickableClasses,
        hoverEffect === "scale" && "group overflow-hidden",
        centered && "min-h-60",
        className,
      )}
      style={style}
      onClick={handleClick}
      {...rest}
    >
      {/* Image at top */}
      {image && imagePosition === "top" && !imageOverlay && (
        <div
          class={cn(
            hoverEffect === "scale" &&
              "relative pt-[50%] sm:pt-[60%] lg:pt-[80%] rounded-t-xl overflow-hidden",
          )}
        >
          <img
            class={cn(
              getImageClasses(),
              hoverEffect === "scale" &&
                "size-full absolute top-0 start-0 object-cover",
              imageScaleClasses,
            )}
            src={image}
            alt={imageAlt}
          />
        </div>
      )}

      {/* Header */}
      {header && (
        <div
          class={cn(
            "rounded-t-xl py-3 px-4 md:py-4 md:px-5",
            headerBordered &&
              "bg-gray-100 border-b border-gray-200 dark:bg-neutral-900 dark:border-neutral-700",
          )}
        >
          {typeof header === "string" ? (
            <p class="text-sm text-gray-500 dark:text-neutral-500">{header}</p>
          ) : (
            header
          )}
        </div>
      )}

      {/* Body */}
      <div
        class={cn(
          sizeClasses[size],
          centered && "flex flex-auto flex-col justify-center items-center",
          scrollable &&
            `${scrollHeight} overflow-y-auto [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-700 dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500`,
        )}
      >
        {title && (
          <h3 class="text-lg font-bold text-gray-800 dark:text-white">
            {title}
          </h3>
        )}
        {subtitle && (
          <p class="mt-1 text-xs font-medium uppercase text-gray-500 dark:text-neutral-500">
            {subtitle}
          </p>
        )}
        {children && (
          <div
            class={cn(
              "mt-2 text-gray-500 dark:text-neutral-400",
              !title && !subtitle && "mt-0",
            )}
          >
            {children}
          </div>
        )}
      </div>

      {/* Footer */}
      {footer && (
        <div
          class={cn(
            "rounded-b-xl py-3 px-4 md:py-4 md:px-5",
            footerBordered &&
              "bg-gray-100 border-t border-gray-200 dark:bg-neutral-900 dark:border-neutral-700",
          )}
        >
          {typeof footer === "string" ? (
            <p class="text-xs text-gray-500 dark:text-neutral-500">{footer}</p>
          ) : (
            footer
          )}
        </div>
      )}

      {/* Image at bottom */}
      {image && imagePosition === "bottom" && !imageOverlay && (
        <img class={getImageClasses()} src={image} alt={imageAlt} />
      )}
    </ContainerTag>
  ) as Pulse.JSX.Element;
};
