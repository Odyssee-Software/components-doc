/**
 * Spinner Component
 * A loading indicator component with various colors and sizes
 *
 * @example
 * ```tsx
 * import { Spinner } from '@odyssee/components';
 *
 * // Basic spinner
 * <Spinner />
 *
 * // With color
 * <Spinner color="primary" />
 *
 * // With size
 * <Spinner size="lg" />
 *
 * // With label
 * <Spinner label="Loading..." showLabel />
 *
 * // Centered
 * <Spinner centered />
 *
 * // Custom thickness
 * <Spinner thickness={4} />
 *
 * // In a card
 * <div class="min-h-60 flex items-center justify-center">
 *   <Spinner />
 * </div>
 * ```
 */

import Pulse from "pulse-framework";
import type { SpinnerProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Spinner: Pulse.Fn<SpinnerProps> = (props) => {
  const {
    size = "md",
    color = "primary",
    thickness = 3,
    label = "Loading...",
    showLabel = false,
    centered = false,
    className,
    id = generateId("spinner"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    xs: "size-4",
    sm: "size-5",
    md: "size-6",
    lg: "size-8",
    xl: "size-10",
  };

  // Color classes
  const colorClasses = {
    primary: "text-blue-600 dark:text-blue-500",
    secondary: "text-gray-600",
    success: "text-green-600",
    danger: "text-red-600",
    warning: "text-yellow-600",
    info: "text-blue-600 dark:text-blue-500",
    gray: "text-gray-400",
    white: "text-white",
    indigo: "text-indigo-600",
    purple: "text-purple-600",
    pink: "text-pink-600",
    orange: "text-orange-600",
  };

  // Thickness classes
  const thicknessClasses = {
    2: "border-2",
    3: "border-3",
    4: "border-4",
  };

  // Base spinner classes
  const spinnerClasses = cn(
    "animate-spin inline-block rounded-full",
    "border-current border-t-transparent",
    sizeClasses[size],
    colorClasses[color],
    thicknessClasses[thickness],
    className,
  );

  // Spinner element
  const spinnerElement = (
    <div
      id={id}
      class={spinnerClasses}
      style={style}
      role="status"
      aria-label={label}
      {...rest}
    >
      <span class="sr-only">{label}</span>
    </div>
  ) as Pulse.JSX.Element;

  // If centered, wrap in a flex container
  if (centered) {
    return (
      <div class="flex justify-center items-center">
        {spinnerElement}
        {showLabel && (
          <span class="ml-2 text-sm text-gray-600 dark:text-neutral-400">
            {label}
          </span>
        )}
      </div>
    ) as Pulse.JSX.Element;
  }

  // If showing label, wrap with label text
  if (showLabel) {
    return (
      <div class="inline-flex items-center gap-2">
        {spinnerElement}
        <span class="text-sm text-gray-600 dark:text-neutral-400">
          {label}
        </span>
      </div>
    ) as Pulse.JSX.Element;
  }

  return spinnerElement;
};

/**
 * SpinnerOverlay Component
 * A spinner with an overlay backdrop for blocking content
 *
 * @example
 * ```tsx
 * <SpinnerOverlay />
 *
 * // Custom color
 * <SpinnerOverlay color="success" />
 *
 * // With label
 * <SpinnerOverlay label="Processing..." showLabel />
 * ```
 */
export const SpinnerOverlay: Pulse.Fn<SpinnerProps> = (props) => {
  const {
    size = "lg",
    color = "primary",
    label = "Loading...",
    showLabel = false,
    className,
    ...rest
  } = props;

  return (
    <div class="absolute inset-0 bg-white/50 rounded-lg dark:bg-neutral-800/40">
      <div class="absolute top-1/2 start-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div class="flex flex-col items-center gap-3">
          <Spinner
            size={size}
            color={color}
            label={label}
            className={className}
            {...rest}
          />
          {showLabel && (
            <span class="text-sm font-medium text-gray-800 dark:text-neutral-200">
              {label}
            </span>
          )}
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * SpinnerCard Component
 * A spinner inside a card container
 *
 * @example
 * ```tsx
 * <SpinnerCard />
 *
 * // Custom height
 * <SpinnerCard className="min-h-80" />
 * ```
 */
export const SpinnerCard: Pulse.Fn<SpinnerProps> = (props) => {
  const {
    size = "md",
    color = "primary",
    label = "Loading...",
    className,
    ...rest
  } = props;

  return (
    <div
      class={cn(
        "min-h-60 flex flex-col bg-white border border-gray-200 shadow-2xs rounded-xl",
        "dark:bg-neutral-800 dark:border-neutral-700 dark:shadow-neutral-700/70",
        className,
      )}
    >
      <div class="flex flex-auto flex-col justify-center items-center p-4 md:p-5">
        <div class="flex justify-center">
          <Spinner size={size} color={color} label={label} {...rest} />
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * ButtonSpinner Component
 * A small spinner for use inside buttons
 *
 * @example
 * ```tsx
 * <button>
 *   <ButtonSpinner />
 *   Loading...
 * </button>
 * ```
 */
export const ButtonSpinner: Pulse.Fn<Omit<SpinnerProps, "size">> = (props) => {
  const { color = "white", ...rest } = props;

  return (
    <Spinner size="xs" color={color} thickness={2} {...rest} />
  ) as Pulse.JSX.Element;
};

/**
 * FullPageSpinner Component
 * A full page loading spinner with backdrop
 *
 * @example
 * ```tsx
 * const isLoading = Pulse.signal(true);
 *
 * {isLoading() && <FullPageSpinner />}
 * ```
 */
export const FullPageSpinner: Pulse.Fn<SpinnerProps> = (props) => {
  const {
    size = "xl",
    color = "primary",
    label = "Loading...",
    showLabel = true,
    ...rest
  } = props;

  return (
    <div class="fixed inset-0 z-50 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm">
      <div class="flex flex-col items-center justify-center min-h-screen gap-4">
        <Spinner size={size} color={color} label={label} {...rest} />
        {showLabel && (
          <p class="text-sm font-medium text-gray-800 dark:text-neutral-200">
            {label}
          </p>
        )}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

export default Spinner;
