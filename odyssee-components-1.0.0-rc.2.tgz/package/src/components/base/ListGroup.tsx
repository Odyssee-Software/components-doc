/**
 * ListGroup Component
 * A flexible list component for displaying grouped content with various interactive states
 *
 * @example
 * ```tsx
 * import { ListGroup } from '@odyssee/components';
 *
 * // Basic list group
 * <ListGroup items={['Profile', 'Settings', 'Newsletter']} />
 *
 * // With icons
 * <ListGroup
 *   items={[
 *     { content: 'Newsletter', icon: <svg>...</svg> },
 *     { content: 'Downloads', icon: <svg>...</svg> },
 *   ]}
 * />
 *
 * // As links
 * <ListGroup
 *   as="a"
 *   items={[
 *     { content: 'Active', href: '#', active: true, icon: <svg>...</svg> },
 *     { content: 'Link', href: '#', icon: <svg>...</svg> },
 *     { content: 'Disabled', href: '#', disabled: true, icon: <svg>...</svg> },
 *   ]}
 * />
 *
 * // As buttons
 * <ListGroup
 *   as="button"
 *   items={[
 *     { content: 'Active', active: true, icon: <svg>...</svg> },
 *     { content: 'Button', icon: <svg>...</svg> },
 *   ]}
 *   onItemClick={(item, index) => console.log(item, index)}
 * />
 *
 * // Striped
 * <ListGroup items={['Profile', 'Settings', 'Newsletter']} striped />
 *
 * // Flush (no borders)
 * <ListGroup items={['Profile', 'Settings', 'Newsletter']} variant="flush" />
 *
 * // Horizontal (responsive)
 * <ListGroup
 *   items={[
 *     { content: 'Newsletter', icon: <svg>...</svg> },
 *     { content: 'Downloads', icon: <svg>...</svg> },
 *   ]}
 *   variant="horizontal"
 * />
 *
 * // With badges
 * <ListGroup
 *   items={[
 *     { content: 'Profile', badge: 'New' },
 *     { content: 'Settings', badge: 2 },
 *     { content: 'Newsletter', badge: '99+' },
 *   ]}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { ListGroupProps, ListGroupItem } from "../../types";
import { cn, generateId, isSignal } from "../../utils";

export const ListGroup: Pulse.Fn<ListGroupProps> = (props) => {
  const {
    items = [],
    variant = "default",
    as = "li",
    striped = false,
    noGutters = false,
    size = "md",
    activeIndex,
    onItemClick,
    className,
    id = generateId("list-group"),
    style,
    ...rest
  } = props;

  // Size classes
  const sizeClasses = {
    sm: "py-2 px-3 text-xs",
    md: "py-3 px-4 text-sm",
    lg: "py-4 px-5 text-base",
  };

  // Container classes based on variant
  const containerClasses = {
    default: "flex flex-col",
    flush: "flex flex-col divide-y divide-gray-200 dark:divide-neutral-700",
    horizontal: "flex flex-col sm:flex-row",
  };

  // Base item classes
  const baseItemClasses = cn(
    "inline-flex items-center font-medium",
    noGutters ? "gap-x-2 py-3" : "gap-x-2",
    !noGutters && sizeClasses[size],
  );

  // Variant-specific item classes
  const itemVariantClasses = {
    default: cn(
      "bg-white border border-gray-200 text-gray-800",
      "-mt-px first:rounded-t-lg first:mt-0 last:rounded-b-lg",
      "dark:bg-neutral-900 dark:border-neutral-700 dark:text-white",
      striped && "odd:bg-gray-100 dark:odd:bg-neutral-800",
    ),
    flush: "text-gray-800 dark:text-white",
    horizontal: cn(
      "bg-white border border-gray-200 text-gray-800",
      "-mt-px first:rounded-t-lg first:mt-0 last:rounded-b-lg",
      "sm:-ms-px sm:mt-0 sm:first:rounded-se-none sm:first:rounded-es-lg",
      "sm:last:rounded-es-none sm:last:rounded-se-lg",
      "dark:bg-neutral-900 dark:border-neutral-700 dark:text-white",
    ),
  };

  // Get active index value
  const getActiveIndex = () => {
    if (activeIndex === undefined) return -1;
    return isSignal(activeIndex) ? (activeIndex as any)() : activeIndex;
  };

  // Render badge
  const renderBadge = (item: ListGroupItem) => {
    if (!item.badge) return null;

    const badgeColorClasses = {
      primary: "bg-blue-500 text-white",
      secondary: "bg-gray-500 text-white",
      success: "bg-green-500 text-white",
      danger: "bg-red-500 text-white",
      warning: "bg-yellow-500 text-white",
      info: "bg-blue-500 text-white",
      light: "bg-gray-100 text-gray-800",
      dark: "bg-gray-800 text-white",
    };

    const badgeColor = item.badgeColor || "primary";

    return (
      <span
        class={cn(
          "inline-flex items-center py-1 px-2 rounded-full text-xs font-medium",
          badgeColorClasses[badgeColor],
        )}
      >
        {item.badge}
      </span>
    );
  };

  // Render item icon
  const renderIcon = (icon: HTMLElement | string) => {
    if (typeof icon === "string") {
      return <span class="shrink-0 size-4">{icon}</span>;
    }
    return icon;
  };

  // Render item content
  const renderItemContent = (item: string | ListGroupItem, index: number) => {
    const listItem = typeof item === "string" ? { content: item } : item;
    const isActive =
      listItem.active !== undefined
        ? listItem.active
        : getActiveIndex() === index;

    // Content wrapper
    const content = (
      <>
        {listItem.icon && renderIcon(listItem.icon)}
        {listItem.badge ? (
          <div class="flex justify-between w-full">
            <span>
              {typeof listItem.content === "string" ? listItem.content : ""}
            </span>
            {renderBadge(listItem)}
          </div>
        ) : typeof listItem.content === "string" ? (
          listItem.content
        ) : (
          listItem.content
        )}
      </>
    );

    return { content, listItem, isActive };
  };

  // Handle item click
  const handleItemClick = (
    item: string | ListGroupItem,
    index: number,
    e: Event,
  ) => {
    const listItem = typeof item === "string" ? { content: item } : item;

    if (listItem.disabled) {
      e.preventDefault();
      return;
    }

    if (listItem.onClick) {
      listItem.onClick(e);
    }

    if (onItemClick) {
      onItemClick(item, index);
    }
  };

  // Render as link
  if (as === "a") {
    return (
      <div
        id={id}
        class={cn(
          containerClasses[variant],
          variant === "default" && "max-w-xs",
          className,
        )}
        style={style}
        {...rest}
      >
        {items.map((item, index) => {
          const { content, listItem, isActive } = renderItemContent(
            item,
            index,
          );

          return (
            <a
              key={index}
              href={listItem.href || "#"}
              class={cn(
                baseItemClasses,
                itemVariantClasses[variant],
                variant !== "flush" &&
                  !listItem.disabled &&
                  "hover:text-blue-600 dark:hover:text-blue-500",
                variant !== "flush" &&
                  "focus:z-10 focus:outline-hidden focus:ring-2 focus:ring-blue-600",
                isActive && "text-blue-600",
                listItem.disabled &&
                  "text-gray-400 cursor-not-allowed dark:text-neutral-700",
              )}
              onClick={(e: any) => handleItemClick(item, index, e)}
            >
              {content}
            </a>
          );
        })}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render as button
  if (as === "button") {
    return (
      <div
        id={id}
        class={cn(
          containerClasses[variant],
          variant === "default" && "max-w-xs",
          className,
        )}
        style={style}
        {...rest}
      >
        {items.map((item, index) => {
          const { content, listItem, isActive } = renderItemContent(
            item,
            index,
          );

          return (
            <button
              key={index}
              type="button"
              class={cn(
                baseItemClasses,
                "text-start",
                itemVariantClasses[variant],
                variant !== "flush" &&
                  !listItem.disabled &&
                  "hover:text-blue-600 dark:hover:text-blue-500",
                variant !== "flush" &&
                  "focus:z-10 focus:outline-hidden focus:ring-2 focus:ring-blue-600",
                isActive && "text-blue-600",
              )}
              disabled={listItem.disabled}
              onClick={(e: any) => handleItemClick(item, index, e)}
            >
              {content}
            </button>
          );
        })}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Render as list item (default)
  return (
    <ul
      id={id}
      class={cn(
        containerClasses[variant],
        variant === "default" && "max-w-xs",
        className,
      )}
      style={style}
      {...rest}
    >
      {items.map((item, index) => {
        const { content, listItem } = renderItemContent(item, index);

        return (
          <li
            key={index}
            class={cn(baseItemClasses, itemVariantClasses[variant])}
            onClick={
              listItem.onClick || onItemClick
                ? (e: any) => handleItemClick(item, index, e)
                : undefined
            }
          >
            {content}
          </li>
        );
      })}
    </ul>
  ) as Pulse.JSX.Element;
};

/**
 * ListGroupLink Component
 * Convenience component for link-based list groups
 *
 * @example
 * ```tsx
 * <ListGroupLink
 *   items={[
 *     { content: 'Active', href: '#', active: true },
 *     { content: 'Link', href: '#' },
 *   ]}
 * />
 * ```
 */
export const LinkListGroup: Pulse.Fn<Omit<ListGroupProps, "as">> = (props) => {
  return <ListGroup {...(props as any)} as="a" />;
};

/**
 * ListGroupButton Component
 * Convenience component for button-based list groups
 *
 * @example
 * ```tsx
 * <ListGroupButton
 *   items={['Item 1', 'Item 2']}
 *   onItemClick={(item, index) => console.log(item, index)}
 * />
 * ```
 */
export const ButtonListGroup: Pulse.Fn<Omit<ListGroupProps, "as">> = (
  props,
) => {
  return <ListGroup {...(props as any)} as="button" />;
};

/**
 * ListGroupFlush Component
 * Convenience component for flush list groups (no borders, uses dividers)
 *
 * @example
 * ```tsx
 * <ListGroupFlush items={['Profile', 'Settings', 'Newsletter']} />
 * ```
 */
export const FlushListGroup: Pulse.Fn<Omit<ListGroupProps, "variant">> = (
  props,
) => {
  return <ListGroup {...(props as any)} variant="flush" />;
};

/**
 * ListGroupHorizontal Component
 * Convenience component for horizontal list groups (responsive)
 *
 * @example
 * ```tsx
 * <ListGroupHorizontal
 *   items={[
 *     { content: 'Item 1', icon: <svg>...</svg> },
 *     { content: 'Item 2', icon: <svg>...</svg> },
 *   ]}
 * />
 * ```
 */
export const HorizontalListGroup: Pulse.Fn<Omit<ListGroupProps, "variant">> = (
  props,
) => {
  return <ListGroup {...(props as any)} variant="horizontal" />;
};

export default ListGroup;
