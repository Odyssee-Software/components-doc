/**
 * AvatarGroup Component
 * A component to display multiple avatars in a group with various layouts
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps, Size } from "../../types";
import { Avatar } from "./Avatar";

/**
 * Avatar item in group
 */
export interface AvatarGroupItem {
  src?: string;
  alt?: string;
  name?: string;
  initials?: string;
  tooltip?: string;
  href?: string;
  onClick?: () => void;
}

/**
 * AvatarGroup props
 */
export interface AvatarGroupProps extends BaseComponentProps {
  // Avatar items
  avatars: AvatarGroupItem[];

  // Layout
  layout?: "stack" | "grid";

  // Size
  size?: Size;

  // Maximum avatars to show
  max?: number;

  // Show counter for remaining avatars
  showCounter?: boolean;

  // Counter text (e.g., "9+")
  counterText?: string;

  // Spacing (only for grid layout)
  spacing?: "none" | "sm" | "md" | "lg";

  // Ring color
  ringColor?: "white" | "gray" | "transparent";

  // Rounded
  rounded?: boolean | "full" | "lg";

  // Enable tooltips
  enableTooltips?: boolean;

  // Dropdown for remaining avatars
  dropdownItems?: Array<{
    name: string;
    href?: string;
    onClick?: () => void;
  }>;

  // Hover effect
  hoverEffect?: boolean;
}

/**
 * AvatarGroup Component
 *
 * @example
 * ```tsx
 * // Stack layout
 * <AvatarGroup
 *   avatars={[
 *     { src: "...", alt: "User 1", tooltip: "John" },
 *     { src: "...", alt: "User 2", tooltip: "Jane" },
 *     { src: "...", alt: "User 3", tooltip: "Bob" }
 *   ]}
 *   layout="stack"
 *   size="md"
 * />
 *
 * // Grid layout with counter
 * <AvatarGroup
 *   avatars={avatarList}
 *   layout="grid"
 *   max={7}
 *   showCounter={true}
 * />
 *
 * // With dropdown
 * <AvatarGroup
 *   avatars={avatars}
 *   max={4}
 *   dropdownItems={[
 *     { name: "Chris Lynch" },
 *     { name: "Maria Guan" }
 *   ]}
 * />
 * ```
 */
export const AvatarGroup: Pulse.Fn<AvatarGroupProps> = (
  props: AvatarGroupProps,
): Pulse.JSX.Element => {
  const {
    avatars = [],
    layout = "stack",
    size = "md",
    max,
    showCounter = true,
    counterText,
    spacing = "none",
    ringColor = "white",
    rounded = "full",
    enableTooltips = false,
    dropdownItems,
    hoverEffect = false,
    className,
    id,
    style,
  } = props;

  // Determine visible avatars
  const visibleAvatars = max ? avatars.slice(0, max) : avatars;
  const remainingCount = max ? avatars.length - max : 0;

  // Size classes mapping
  const sizeClasses: Record<Size, string> = {
    xs: "size-8",
    sm: "size-9.5",
    md: "size-11",
    lg: "size-15.5",
    xl: "size-20",
  };

  // Ring color classes
  const ringColorClasses: Record<string, string> = {
    white: "ring-2 ring-white dark:ring-neutral-900",
    gray: "ring-2 ring-gray-200 dark:ring-neutral-700",
    transparent: "",
  };

  // Spacing classes for grid layout
  const spacingClasses: Record<string, string> = {
    none: "gap-0",
    sm: "gap-1",
    md: "gap-2",
    lg: "gap-3",
  };

  // Container classes
  const containerClasses = cn(
    "flex",
    layout === "stack" ? "-space-x-2" : spacingClasses[spacing],
    layout === "grid" && "flex-wrap",
    className,
  );

  // Avatar wrapper classes
  const avatarWrapperClasses = cn(enableTooltips && "hs-tooltip inline-block");

  // Counter/Remaining classes
  const counterClasses = cn(
    "inline-flex items-center justify-center",
    sizeClasses[size],
    rounded === "full"
      ? "rounded-full"
      : rounded === "lg"
        ? "rounded-lg"
        : "rounded",
    "bg-gray-100 border-2 border-gray-200",
    "dark:bg-neutral-600 dark:border-neutral-700",
    dropdownItems
      ? "hover:bg-gray-200 focus:outline-hidden focus:bg-gray-300 dark:hover:bg-neutral-600 dark:focus:bg-neutral-600 cursor-pointer"
      : "",
  );

  // Render tooltip
  const renderTooltip = (tooltip: string) => {
    if (!enableTooltips || !tooltip) return null;

    return (
      <span
        class="hs-tooltip-content hs-tooltip-shown:opacity-100 hs-tooltip-shown:visible opacity-0 inline-block absolute invisible z-20 py-1.5 px-2.5 bg-gray-900 text-xs text-white rounded-lg dark:bg-neutral-700"
        role="tooltip"
      >
        {tooltip}
      </span>
    );
  };

  // Render single avatar
  const renderAvatar = (avatar: AvatarGroupItem, index: number) => {
    const avatarElement = (
      <Avatar
        src={avatar.src}
        alt={avatar.alt || avatar.name || `Avatar ${index + 1}`}
        name={avatar.name}
        initials={avatar.initials}
        size={size}
        rounded={rounded === true ? "full" : rounded === "lg" ? "lg" : "full"}
        href={avatar.href}
        onClick={avatar.onClick}
        className={cn(
          ringColorClasses[ringColor],
          hoverEffect && "hover:z-10 relative",
        )}
      />
    );

    if (enableTooltips && avatar.tooltip) {
      return (
        <div class={avatarWrapperClasses} key={index}>
          {avatarElement}
          {renderTooltip(avatar.tooltip)}
        </div>
      );
    }

    return avatarElement;
  };

  // Render counter
  const renderCounter = () => {
    if (!showCounter || remainingCount <= 0) return null;

    const displayText = counterText || `${remainingCount}+`;

    if (dropdownItems && dropdownItems.length > 0) {
      // Render dropdown counter
      return (
        <div class="hs-dropdown [--placement:top-left] relative inline-flex">
          <button
            id="hs-avatar-group-dropdown"
            class={cn(counterClasses, "hs-dropdown-toggle")}
            aria-haspopup="menu"
            aria-expanded="false"
            aria-label="Dropdown"
          >
            <span class="font-medium text-gray-700 dark:text-white text-sm">
              {displayText}
            </span>
          </button>

          <div
            class="hs-dropdown-menu hs-dropdown-open:opacity-100 w-48 hidden z-10 transition-[margin,opacity] opacity-0 duration-300 mb-2 bg-white shadow-md rounded-lg p-2 dark:bg-neutral-800 dark:border dark:border-neutral-700 dark:divide-neutral-700"
            role="menu"
            aria-orientation="vertical"
            aria-labelledby="hs-avatar-group-dropdown"
          >
            {dropdownItems.map((item, index) => (
              <a
                key={index}
                class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-gray-800 hover:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-700 dark:hover:text-neutral-300"
                href={item.href || "#"}
                onClick={item.onClick}
              >
                {item.name}
              </a>
            ))}
          </div>
        </div>
      );
    }

    // Simple counter
    return (
      <span class={counterClasses}>
        <span class="font-medium text-gray-500 dark:text-neutral-400">
          {displayText}
        </span>
      </span>
    );
  };

  return (
    <div id={id} class={containerClasses} style={style}>
      {visibleAvatars.map((avatar, index) => renderAvatar(avatar, index))}
      {renderCounter()}
    </div>
  );
};

/**
 * Stack AvatarGroup - Avatars overlapping
 */
export const StackAvatarGroup: Pulse.Fn<AvatarGroupProps> = (
  props: AvatarGroupProps,
): Pulse.JSX.Element => {
  return <AvatarGroup {...props} layout="stack" />;
};

/**
 * Grid AvatarGroup - Avatars in a grid
 */
export const GridAvatarGroup: Pulse.Fn<AvatarGroupProps> = (
  props: AvatarGroupProps,
): Pulse.JSX.Element => {
  return <AvatarGroup {...props} layout="grid" />;
};

export default AvatarGroup;
