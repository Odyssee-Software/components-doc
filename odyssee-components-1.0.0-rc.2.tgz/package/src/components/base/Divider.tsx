/**
 * Divider Component
 * A flexible divider component for separating content with optional labels
 *
 * @example
 * ```tsx
 * import { Divider } from '@odyssee/components';
 *
 * // Basic horizontal divider
 * <Divider />
 *
 * // With color
 * <Divider color="blue" />
 *
 * // With thickness
 * <Divider thickness={4} />
 *
 * // With label (center)
 * <Divider label="OR" labelPosition="center" />
 *
 * // With label (left aligned)
 * <Divider label="Left aligned" labelPosition="left" />
 *
 * // With label (right aligned)
 * <Divider label="Right aligned" labelPosition="right" />
 *
 * // Vertical divider
 * <div class="flex gap-3">
 *   <button>Button 1</button>
 *   <Divider orientation="vertical" />
 *   <button>Button 2</button>
 * </div>
 *
 * // Responsive (horizontal on mobile, vertical on desktop)
 * <Divider responsiveOrientation={{ sm: "vertical" }} />
 * ```
 */

import Pulse from "pulse-framework";
import type { DividerProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Divider: Pulse.Fn<DividerProps> = (props) => {
  const {
    orientation = "horizontal",
    label,
    labelPosition = "center",
    color = "default",
    thickness = 1,
    spacing = "md",
    responsiveOrientation,
    className,
    id = generateId("divider"),
    style,
    ...rest
  } = props;

  // Color classes
  const colorClasses = {
    default: "border-gray-200 dark:border-neutral-600",
    gray: "border-gray-500 dark:border-neutral-500",
    teal: "border-teal-500",
    blue: "border-blue-500",
    red: "border-red-500",
    yellow: "border-yellow-500",
    white: "border-white",
  };

  // Thickness classes (border-width)
  const thicknessClasses = {
    1: "",
    2: "border-2",
    4: "border-4",
    8: "border-8",
  };

  // Spacing classes (padding)
  const spacingClasses = {
    xs: "py-1",
    sm: "py-2",
    md: "py-3",
    lg: "py-4",
    xl: "py-5",
  };

  // Text size classes based on spacing
  const textSizeClasses = {
    xs: "text-xs",
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
    xl: "text-lg",
  };

  // Responsive orientation classes
  const responsiveClasses = responsiveOrientation
    ? cn(
        // Default orientation class
        orientation === "vertical" ? "border-s" : "border-t",
        // Responsive overrides
        responsiveOrientation.sm === "vertical"
          ? "sm:border-t-0 sm:border-s"
          : responsiveOrientation.sm === "horizontal"
            ? "sm:border-s-0 sm:border-t"
            : "",
        responsiveOrientation.md === "vertical"
          ? "md:border-t-0 md:border-s"
          : responsiveOrientation.md === "horizontal"
            ? "md:border-s-0 md:border-t"
            : "",
        responsiveOrientation.lg === "vertical"
          ? "lg:border-t-0 lg:border-s"
          : responsiveOrientation.lg === "horizontal"
            ? "lg:border-s-0 lg:border-t"
            : "",
      )
    : "";

  // Simple divider without label
  if (!label) {
    // Vertical divider
    if (orientation === "vertical") {
      return (
        <div
          id={id}
          class={cn(
            "border-s",
            colorClasses[color],
            thicknessClasses[thickness],
            responsiveClasses,
            className,
          )}
          style={style}
          role="separator"
          aria-orientation="vertical"
          {...rest}
        />
      ) as Pulse.JSX.Element;
    }

    // Horizontal divider (default <hr>)
    return (
      <hr
        id={id}
        class={cn(
          colorClasses[color],
          thicknessClasses[thickness],
          responsiveClasses,
          className,
        )}
        style={style}
        {...rest}
      />
    ) as Pulse.JSX.Element;
  }

  // Divider with label
  const labelContent =
    typeof label === "string" ? (
      <span class="text-gray-800 dark:text-white">{label}</span>
    ) : (
      label
    );

  // Label position classes
  const labelContainerClasses = cn(
    spacingClasses[spacing],
    "flex items-center",
    textSizeClasses[spacing],
    "text-gray-800 dark:text-white",
  );

  // Left aligned label
  if (labelPosition === "left") {
    return (
      <div
        id={id}
        class={cn(
          labelContainerClasses,
          "after:flex-1 after:border-t after:ms-6",
          `after:${colorClasses[color]}`,
          `after:${thicknessClasses[thickness]}`,
          className,
        )}
        style={style}
        role="separator"
        {...rest}
      >
        {labelContent}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Right aligned label
  if (labelPosition === "right") {
    return (
      <div
        id={id}
        class={cn(
          labelContainerClasses,
          "before:flex-1 before:border-t before:me-6",
          `before:${colorClasses[color]}`,
          `before:${thicknessClasses[thickness]}`,
          className,
        )}
        style={style}
        role="separator"
        {...rest}
      >
        {labelContent}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Center aligned label (default)
  return (
    <div
      id={id}
      class={cn(
        labelContainerClasses,
        "before:flex-1 before:border-t before:me-6",
        "after:flex-1 after:border-t after:ms-6",
        `before:${colorClasses[color]}`,
        `after:${colorClasses[color]}`,
        `before:${thicknessClasses[thickness]}`,
        `after:${thicknessClasses[thickness]}`,
        className,
      )}
      style={style}
      role="separator"
      {...rest}
    >
      {labelContent}
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * VerticalDivider - Convenience component for vertical dividers
 */
export const VerticalDivider: Pulse.Fn<DividerProps> = (props) => {
  return <Divider {...props} orientation="vertical" />;
};

/**
 * DividerWithText - Convenience component for centered text divider
 */
export const DividerWithText: Pulse.Fn<
  Omit<DividerProps, "labelPosition">
> = (props) => {
  return <Divider {...props} labelPosition="center" />;
};

export default Divider;
