/**
 * LegendIndicator Component
 * A simple component to display a colored dot with a label, commonly used in chart legends
 *
 * @example
 * ```tsx
 * import { LegendIndicator } from '@odyssee/components';
 *
 * // Basic usage
 * <LegendIndicator label="Legend indicator" />
 *
 * // With colors
 * <LegendIndicator label="Red" color="red-500" />
 * <LegendIndicator label="Blue" color="blue-600" />
 * <LegendIndicator label="Green" color="green-500" />
 * <LegendIndicator label="Yellow" color="yellow-500" />
 *
 * // Different sizes
 * <LegendIndicator label="Extra small" size="xs" />
 * <LegendIndicator label="Small" size="sm" />
 * <LegendIndicator label="Medium" size="md" />
 * <LegendIndicator label="Large" size="lg" />
 *
 * // Square dot
 * <LegendIndicator label="Square" color="purple-500" shape="square" />
 *
 * // Custom classes
 * <LegendIndicator
 *   label="Custom"
 *   color="indigo-500"
 *   dotClassName="ring-2 ring-indigo-200"
 *   labelClassName="font-bold text-lg"
 * />
 *
 * // JSX label
 * <LegendIndicator
 *   label={<span>Custom <strong>Bold</strong> Label</span>}
 *   color="pink-500"
 * />
 *
 * // Chart legend example
 * <div class="flex gap-4">
 *   <LegendIndicator label="Revenue" color="blue-600" />
 *   <LegendIndicator label="Expenses" color="red-500" />
 *   <LegendIndicator label="Profit" color="green-500" />
 * </div>
 *
 * // Dashboard status indicators
 * <div class="flex flex-col gap-2">
 *   <LegendIndicator label="Active" color="green-500" />
 *   <LegendIndicator label="Pending" color="yellow-500" />
 *   <LegendIndicator label="Inactive" color="gray-500" />
 * </div>
 * ```
 */

import Pulse from "pulse-framework";
import type { LegendIndicatorProps } from "../../types";
import { cn, generateId } from "../../utils";

export const LegendIndicator: Pulse.Fn<LegendIndicatorProps> = (props) => {
  const {
    label,
    color = "gray-500",
    size = "sm",
    shape = "circle",
    dotClassName,
    labelClassName,
    className,
    id = generateId("legend-indicator"),
    style,
    ...rest
  } = props;

  // Size classes for the dot
  const sizeClasses = {
    xs: "size-1.5",
    sm: "size-2",
    md: "size-3",
    lg: "size-4",
  };

  // Shape classes
  const shapeClasses = {
    circle: "rounded-full",
    square: "rounded-sm",
  };

  // Dot classes
  const dotClasses = cn(
    "inline-block me-2",
    sizeClasses[size],
    `bg-${color}`,
    shapeClasses[shape],
    dotClassName
  );

  // Label classes
  const labelClasses = cn(
    "text-gray-600 dark:text-neutral-400",
    labelClassName
  );

  return (
    <div
      id={id}
      class={cn("inline-flex items-center", className)}
      style={style}
      {...rest}
    >
      <span class={dotClasses}></span>
      <span class={labelClasses}>{label}</span>
    </div>
  ) as Pulse.JSX.Element;
};

export default LegendIndicator;
