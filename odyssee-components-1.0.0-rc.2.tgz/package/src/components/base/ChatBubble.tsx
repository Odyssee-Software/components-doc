/**
 * ChatBubble Component
 * A component for displaying chat messages with various layouts and styles
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps } from "../../types";
import { Avatar } from "./Avatar";

/**
 * Chat message content item (for lists, links, etc.)
 */
export interface ChatContentItem {
  type: "text" | "link" | "list";
  content: string;
  href?: string;
}

/**
 * Chat message status
 */
export type ChatStatus = "sent" | "delivered" | "read" | "error" | "sending";

/**
 * ChatBubble props
 */
export interface ChatBubbleProps extends BaseComponentProps {
  // Message content
  message?: string;
  content?: HTMLElement | string | ChatContentItem[];

  // Title/Heading
  title?: string;

  // Sender type
  sender?: "user" | "bot" | "other";

  // Avatar
  avatar?: string;
  avatarAlt?: string;
  avatarInitials?: string;

  // Status
  status?: ChatStatus;
  statusText?: string;
  showStatus?: boolean;

  // Layout
  align?: "left" | "right";

  // Styling
  variant?: "default" | "primary";
  maxWidth?: string;

  // Timestamps
  timestamp?: string;
  showTimestamp?: boolean;
}

/**
 * Status Icon Component
 */
const StatusIcon: Pulse.Fn<{ status: ChatStatus }> = (
  props,
): Pulse.JSX.Element | null => {
  if (
    props.status === "sent" ||
    props.status === "delivered" ||
    props.status === "read"
  ) {
    return (
      <svg
        class="shrink-0 size-3"
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M18 6 7 17l-5-5"></path>
        <path d="m22 10-7.5 7.5L13 16"></path>
      </svg>
    );
  }

  if (props.status === "error") {
    return (
      <svg
        class="shrink-0 size-3"
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="12" x2="12" y1="8" y2="12"></line>
        <line x1="12" x2="12.01" y1="16" y2="16"></line>
      </svg>
    );
  }

  return null;
};

/**
 * ChatBubble Component
 *
 * @example
 * ```tsx
 * // Basic left-aligned message
 * <ChatBubble
 *   message="How can we help?"
 *   sender="bot"
 *   align="left"
 * />
 *
 * // User message (right-aligned)
 * <ChatBubble
 *   message="What's Preline UI?"
 *   sender="user"
 *   align="right"
 * />
 *
 * // With avatar
 * <ChatBubble
 *   message="Hello!"
 *   avatar="https://..."
 *   align="left"
 * />
 *
 * // With status
 * <ChatBubble
 *   message="Sent message"
 *   status="sent"
 *   showStatus={true}
 * />
 *
 * // With content items
 * <ChatBubble
 *   title="Getting Started"
 *   content={[
 *     { type: "text", content: "Here are some links:" },
 *     { type: "link", content: "Installation Guide", href: "/docs" }
 *   ]}
 * />
 * ```
 */
export const ChatBubble: Pulse.Fn<ChatBubbleProps> = (
  props: ChatBubbleProps,
): Pulse.JSX.Element => {
  const {
    message,
    content,
    title,
    sender = "bot",
    avatar,
    avatarAlt,
    avatarInitials,
    status,
    statusText,
    showStatus = false,
    align = "left",
    variant,
    maxWidth = "max-w-lg",
    timestamp,
    showTimestamp = false,
    className,
    id,
    style,
  } = props;

  // Determine variant based on sender if not explicitly set
  const bubbleVariant = variant || (sender === "user" ? "primary" : "default");

  // Container classes
  const containerClasses = cn(
    "flex gap-x-2 sm:gap-x-4",
    maxWidth,
    align === "right" && "ms-auto",
    align === "left" && avatar && "me-11",
    className,
  );

  // Content wrapper classes
  const contentWrapperClasses = cn(
    align === "right" && "grow text-end space-y-3",
    align === "left" && "grow space-y-3",
  );

  // Inner wrapper for right-aligned with status
  const innerWrapperClasses = cn(
    align === "right" && showStatus && "inline-flex flex-col justify-end",
  );

  // Bubble classes
  const bubbleClasses = cn(
    "rounded-2xl p-4 space-y-3",
    bubbleVariant === "primary"
      ? "inline-block bg-blue-600 shadow-2xs"
      : "bg-white border border-gray-200 dark:bg-neutral-900 dark:border-neutral-700",
    align === "right" && "inline-block",
  );

  // Text classes
  const textClasses = cn(
    "text-sm",
    bubbleVariant === "primary"
      ? "text-white"
      : "text-gray-800 dark:text-white",
  );

  // Status classes
  const statusClasses = cn(
    "mt-1.5 flex items-center gap-x-1 text-xs",
    status === "error" ? "text-red-500" : "text-gray-500 dark:text-neutral-500",
    align === "right" && "ms-auto",
  );

  // Render avatar
  const renderAvatar = () => {
    if (!avatar && !avatarInitials) return null;

    return (
      <Avatar
        src={avatar}
        alt={avatarAlt || "Avatar"}
        initials={avatarInitials}
        size="md"
        rounded="full"
      />
    );
  };

  // Render content
  const renderContent = () => {
    // If content is an array of items
    if (Array.isArray(content)) {
      return (
        <div class="space-y-1.5">
          {content.map((item, index) => {
            if (item.type === "text") {
              return (
                <p key={index} class={cn(textClasses, index === 0 && "mb-1.5")}>
                  {item.content}
                </p>
              );
            }

            if (item.type === "link") {
              return (
                <li key={index}>
                  <a
                    class="text-sm text-blue-600 decoration-2 hover:underline focus:outline-hidden focus:underline font-medium dark:text-blue-500 dark:hover:text-blue-400"
                    href={item.href || "#"}
                  >
                    {item.content}
                  </a>
                </li>
              );
            }

            if (item.type === "list") {
              return (
                <li key={index} class={textClasses}>
                  {item.content}
                </li>
              );
            }

            return null;
          })}
        </div>
      );
    }

    // If content is a string
    if (typeof content === "string") {
      return <p class={textClasses}>{content}</p>;
    }

    // If content is an HTMLElement
    if (content) {
      return content;
    }

    // Fallback to message
    if (message) {
      return <p class={textClasses}>{message}</p>;
    }

    return null;
  };

  // Render status
  const renderStatus = () => {
    if (!showStatus && !status) return null;

    const displayStatus = statusText || status || "sent";

    return (
      <span class={statusClasses}>
        {status && <StatusIcon status={status} />}
        {displayStatus}
      </span>
    );
  };

  // Render bubble content
  const renderBubble = () => {
    return (
      <div class={bubbleClasses}>
        {title && (
          <h2
            class={cn(
              "font-medium",
              bubbleVariant === "primary"
                ? "text-white"
                : "text-gray-800 dark:text-white",
            )}
          >
            {title}
          </h2>
        )}
        {renderContent()}
        {showTimestamp && timestamp && (
          <span class="text-xs text-gray-500 dark:text-neutral-500">
            {timestamp}
          </span>
        )}
      </div>
    );
  };

  return (
    <li id={id} class={containerClasses} style={style}>
      {/* Left avatar */}
      {align === "left" && (avatar || avatarInitials) && renderAvatar()}

      {/* Message content */}
      {align === "left" && !showStatus ? (
        <div>
          {renderBubble()}
          {renderStatus()}
        </div>
      ) : align === "left" && showStatus ? (
        <div>
          {renderBubble()}
          {renderStatus()}
        </div>
      ) : (
        <div class={contentWrapperClasses}>
          {showStatus ? (
            <div class={innerWrapperClasses}>
              {renderBubble()}
              {renderStatus()}
            </div>
          ) : (
            <>
              {renderBubble()}
              {renderStatus()}
            </>
          )}
        </div>
      )}

      {/* Right avatar */}
      {align === "right" && (avatar || avatarInitials) && renderAvatar()}
    </li>
  );
};

/**
 * ChatBubbleList Component - Container for multiple chat bubbles
 */
export interface ChatBubbleListProps extends BaseComponentProps {
  children?: HTMLElement | HTMLElement[];
  spacing?: "sm" | "md" | "lg";
}

export const ChatBubbleList: Pulse.Fn<ChatBubbleListProps> = (
  props: ChatBubbleListProps,
): Pulse.JSX.Element => {
  const { children, spacing = "md", className, id, style } = props;

  const spacingClasses: Record<string, string> = {
    sm: "space-y-3",
    md: "space-y-5",
    lg: "space-y-8",
  };

  return (
    <ul id={id} class={cn(spacingClasses[spacing], className)} style={style}>
      {children}
    </ul>
  );
};

/**
 * User ChatBubble - Right-aligned with primary color
 */
export const UserChatBubble: Pulse.Fn<ChatBubbleProps> = (
  props: ChatBubbleProps,
): Pulse.JSX.Element => {
  return (
    <ChatBubble {...props} sender="user" align="right" variant="primary" />
  );
};

/**
 * Bot ChatBubble - Left-aligned with default style
 */
export const BotChatBubble: Pulse.Fn<ChatBubbleProps> = (
  props: ChatBubbleProps,
): Pulse.JSX.Element => {
  return <ChatBubble {...props} sender="bot" align="left" variant="default" />;
};

export default ChatBubble;
