/**
 * Carousel Component
 * A slideshow component for cycling through elements with Pulse reactive state
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps, Signal } from "../../types";

/**
 * Carousel slide item
 */
export interface CarouselSlide {
  id?: string;
  content: HTMLElement | string;
  thumbnail?: HTMLElement | string;
}

/**
 * Carousel props
 */
export interface CarouselProps extends BaseComponentProps {
  // Slides
  slides: CarouselSlide[];

  // Current slide index (can be a signal)
  currentSlide?: number | Signal<number>;

  // Autoplay
  autoPlay?: boolean;
  interval?: number; // in milliseconds

  // Loop
  loop?: boolean;

  // Show controls
  showControls?: boolean;
  showPagination?: boolean;
  showInfo?: boolean;
  showThumbnails?: boolean;

  // Thumbnails layout
  thumbnailsPosition?: "bottom" | "right";

  // Height
  minHeight?: string;

  // Controls variant
  controlsVariant?: "default" | "overlay";

  // Draggable
  draggable?: boolean;

  // RTL
  rtl?: boolean;

  // Multiple slides per view
  slidesPerView?: number;

  // Callbacks
  onChange?: (index: number) => void;
  onSlideChange?: (index: number) => void;
}

/**
 * ChevronLeft Icon
 */
const ChevronLeftIcon: Pulse.Fn = (): Pulse.JSX.Element => (
  <svg
    class="shrink-0 size-5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m15 18-6-6 6-6"></path>
  </svg>
);

/**
 * ChevronRight Icon
 */
const ChevronRightIcon: Pulse.Fn = (): Pulse.JSX.Element => (
  <svg
    class="shrink-0 size-5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m9 18 6-6-6-6"></path>
  </svg>
);

/**
 * Carousel Component
 *
 * @example
 * ```tsx
 * // Basic carousel
 * <Carousel
 *   slides={[
 *     { content: "First slide" },
 *     { content: "Second slide" },
 *     { content: "Third slide" }
 *   ]}
 * />
 *
 * // With autoplay
 * <Carousel
 *   slides={slides}
 *   autoPlay={true}
 *   interval={5000}
 *   loop={true}
 * />
 *
 * // With thumbnails
 * <Carousel
 *   slides={slides}
 *   showThumbnails={true}
 *   thumbnailsPosition="bottom"
 * />
 * ```
 */
export const Carousel: Pulse.Fn<CarouselProps> = (
  props: CarouselProps,
): Pulse.JSX.Element => {
  const {
    slides = [],
    currentSlide: currentSlideProp,
    autoPlay = false,
    interval = 3000,
    loop = false,
    showControls = true,
    showPagination = true,
    showInfo = false,
    showThumbnails = false,
    thumbnailsPosition = "bottom",
    minHeight = "min-h-96",
    controlsVariant = "default",
    draggable = false,
    rtl = false,
    slidesPerView = 1,
    onChange,
    onSlideChange,
    className,
    id,
    style,
  } = props;

  // Create or use provided signal for current slide
  const currentSlideSignal: any =
    typeof currentSlideProp === "object" && "value" in currentSlideProp
      ? currentSlideProp
      : Pulse.signal(currentSlideProp || 0);

  // Auto-play effect
  if (autoPlay) {
    Pulse.effect(() => {
      const timer = setInterval(() => {
        const current = currentSlideSignal.value;
        const nextIndex = current + 1;

        if (nextIndex >= slides.length) {
          if (loop) {
            currentSlideSignal.value = 0;
          }
        } else {
          currentSlideSignal.value = nextIndex;
        }
      }, interval);

      return () => clearInterval(timer);
    });
  }

  // Watch for changes and call callbacks
  Pulse.effect(() => {
    const current = currentSlideSignal.value;
    if (onChange) onChange(current);
    if (onSlideChange) onSlideChange(current);
  });

  // Navigation handlers
  const goToSlide = (index: number) => {
    if (index >= 0 && index < slides.length) {
      currentSlideSignal.value = index;
    }
  };

  const goToPrevious = () => {
    const current = currentSlideSignal.value;
    if (current > 0) {
      currentSlideSignal.value = current - 1;
    } else if (loop) {
      currentSlideSignal.value = slides.length - 1;
    }
  };

  const goToNext = () => {
    const current = currentSlideSignal.value;
    if (current < slides.length - 1) {
      currentSlideSignal.value = current + 1;
    } else if (loop) {
      currentSlideSignal.value = 0;
    }
  };

  // Check if navigation is disabled
  const isPrevDisabled = () => {
    const current =
      typeof currentSlideSignal === "number"
        ? currentSlideSignal
        : currentSlideSignal.value;
    return !loop && current === 0;
  };

  const isNextDisabled = () => {
    const current =
      typeof currentSlideSignal === "number"
        ? currentSlideSignal
        : currentSlideSignal.value;
    return !loop && current === slides.length - 1;
  };

  // Container classes
  const containerClasses = cn("relative", className);

  // Carousel body classes
  const bodyClasses = cn(
    "hs-carousel-body absolute top-0 bottom-0 start-0 flex flex-nowrap transition-transform duration-700",
    draggable && "cursor-grab",
  );

  // Control button base classes
  const controlBaseClasses = cn(
    "inline-flex justify-center items-center",
    "text-gray-800 dark:text-white",
    "focus:outline-hidden disabled:opacity-50 disabled:pointer-events-none",
  );

  // Control button variant classes
  const controlVariantClasses =
    controlsVariant === "overlay"
      ? cn(
          "absolute inset-y-0 w-11.5 h-full",
          "hover:bg-gray-800/10 focus:bg-gray-800/10",
          "dark:hover:bg-white/10 dark:focus:bg-white/10",
        )
      : cn(
          "absolute top-1/2 -translate-y-1/2 size-10",
          "bg-white border border-gray-100 rounded-full shadow-2xs",
          "hover:bg-gray-100",
        );

  // Render slide content
  const renderSlideContent = (slide: CarouselSlide) => {
    if (typeof slide.content === "string") {
      return (
        <div
          class={cn(
            "flex justify-center h-full bg-gray-100 p-6 dark:bg-neutral-900",
          )}
        >
          <span class="self-center text-4xl text-gray-800 transition duration-700 dark:text-white">
            {slide.content}
          </span>
        </div>
      );
    }
    return slide.content;
  };

  // Render controls
  const renderControls = () => {
    if (!showControls) return null;

    const prevClasses = cn(
      controlBaseClasses,
      controlVariantClasses,
      controlsVariant === "overlay"
        ? rtl
          ? "end-0 rounded-e-lg"
          : "start-0 rounded-s-lg"
        : rtl
          ? "end-2"
          : "start-2",
    );

    const nextClasses = cn(
      controlBaseClasses,
      controlVariantClasses,
      controlsVariant === "overlay"
        ? rtl
          ? "start-0 rounded-s-lg"
          : "end-0 rounded-e-lg"
        : rtl
          ? "start-2"
          : "end-2",
    );

    return (
      <>
        <button
          type="button"
          class={prevClasses}
          onClick={goToPrevious}
          disabled={isPrevDisabled()}
          aria-label="Previous"
        >
          <span class="text-2xl" aria-hidden="true">
            <ChevronLeftIcon />
          </span>
          <span class="sr-only">Previous</span>
        </button>
        <button
          type="button"
          class={nextClasses}
          onClick={goToNext}
          disabled={isNextDisabled()}
          aria-label="Next"
        >
          <span class="sr-only">Next</span>
          <span class="text-2xl" aria-hidden="true">
            <ChevronRightIcon />
          </span>
        </button>
      </>
    );
  };

  // Render pagination dots
  const renderPagination = () => {
    if (!showPagination || showThumbnails) return null;

    return (
      <div class="hs-carousel-pagination flex justify-center absolute bottom-3 start-0 end-0 gap-x-2">
        {slides.map((_, index) => {
          const isActive = Pulse.computed(
            () => currentSlideSignal.value === index,
          );
          return (
            <button
              key={index}
              type="button"
              class={cn(
                "size-3 border rounded-full cursor-pointer transition-colors",
                isActive.value
                  ? "bg-blue-700 border-blue-700 dark:bg-blue-500 dark:border-blue-500"
                  : "border-gray-400 dark:border-neutral-600",
              )}
              onClick={() => goToSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          );
        })}
      </div>
    );
  };

  // Render info counter
  const renderInfo = () => {
    if (!showInfo) return null;

    const current =
      typeof currentSlideSignal === "number"
        ? currentSlideSignal
        : currentSlideSignal.value;
    return (
      <div class="hs-carousel-info inline-flex justify-center px-4 absolute bottom-3 start-[50%] -translate-x-[50%] bg-white rounded-lg dark:bg-neutral-800">
        <span class="hs-carousel-info-current me-1">{current + 1}</span>/
        <span class="hs-carousel-info-total ms-1">{slides.length}</span>
      </div>
    );
  };

  // Render thumbnails
  const renderThumbnails = () => {
    if (!showThumbnails) return null;

    const thumbnailContainerClasses =
      thumbnailsPosition === "right"
        ? "flex-none"
        : "absolute bottom-3 start-0 w-full overflow-x-auto";

    const thumbnailWrapperClasses =
      thumbnailsPosition === "right"
        ? "max-h-96 flex flex-col gap-2 overflow-y-auto"
        : "flex flex-row items-center gap-x-2 px-2";

    return (
      <div class={thumbnailContainerClasses}>
        <div class={thumbnailWrapperClasses}>
          {slides.map((slide, index) => {
            const isActive = Pulse.computed(
              () => currentSlideSignal.value === index,
            );
            const thumbnailClasses = cn(
              "shrink-0 border rounded-md overflow-hidden cursor-pointer",
              thumbnailsPosition === "right"
                ? "size-20 md:size-32"
                : "w-37.5 h-12.5",
              isActive.value
                ? "border-blue-400"
                : "border-gray-200 dark:border-neutral-700",
            );

            return (
              <div
                key={index}
                class={thumbnailClasses}
                onClick={() => goToSlide(index)}
              >
                {slide.thumbnail ? (
                  typeof slide.thumbnail === "string" ? (
                    <div class="flex justify-center items-center text-center size-full bg-gray-100 p-2 dark:bg-neutral-900">
                      <span class="text-xs text-gray-800 dark:text-white">
                        {slide.thumbnail}
                      </span>
                    </div>
                  ) : (
                    slide.thumbnail
                  )
                ) : (
                  <div class="flex justify-center items-center text-center size-full bg-gray-100 p-2 dark:bg-neutral-900">
                    <span class="text-xs text-gray-800 dark:text-white">
                      Slide {index + 1}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // Compute transform for slides
  const translateX = Pulse.computed(() => {
    const current =
      typeof currentSlideSignal === "number"
        ? currentSlideSignal
        : currentSlideSignal.value;
    const direction = rtl ? 1 : -1;
    return `translateX(${direction * current * (100 / slidesPerView)}%)`;
  });

  // Main carousel layout
  const carouselWrapperClasses = cn(
    showThumbnails && thumbnailsPosition === "right"
      ? "flex flex-col md:flex-row gap-2"
      : "",
  );

  const carouselInnerClasses = cn(
    showThumbnails && thumbnailsPosition === "right"
      ? "md:order-2 relative grow"
      : "relative",
    "overflow-hidden w-full bg-white rounded-lg dark:bg-neutral-900",
    minHeight,
  );

  return (
    <div
      id={id}
      class={containerClasses}
      style={style}
      dir={rtl ? "rtl" : "ltr"}
    >
      <div class={carouselWrapperClasses}>
        {showThumbnails && thumbnailsPosition === "right" && (
          <div class="md:order-1">{renderThumbnails()}</div>
        )}

        <div class={carouselInnerClasses}>
          <div class={bodyClasses} style={{ transform: translateX.value }}>
            {slides.map((slide, index) => (
              <div
                key={slide.id || index}
                class="hs-carousel-slide"
                style={{ minWidth: `${100 / slidesPerView}%` }}
              >
                {renderSlideContent(slide)}
              </div>
            ))}
          </div>

          {renderControls()}
          {renderPagination()}
          {renderInfo()}
          {showThumbnails &&
            thumbnailsPosition === "bottom" &&
            renderThumbnails()}
        </div>
      </div>
    </div>
  );
};

/**
 * AutoPlayCarousel - Carousel with autoplay enabled
 */
export const AutoPlayCarousel: Pulse.Fn<CarouselProps> = (
  props: CarouselProps,
): Pulse.JSX.Element => {
  return <Carousel {...props} autoPlay={true} loop={true} />;
};

/**
 * ThumbnailCarousel - Carousel with thumbnails
 */
export const ThumbnailCarousel: Pulse.Fn<CarouselProps> = (
  props: CarouselProps,
): Pulse.JSX.Element => {
  return <Carousel {...props} showThumbnails={true} showPagination={false} />;
};

export default Carousel;
