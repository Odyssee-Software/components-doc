/**
 * FileUploadProgress Component
 * Displays file upload progress with visual feedback for single or multiple files
 *
 * @example
 * ```tsx
 * import { FileUploadProgress } from '@odyssee/components';
 *
 * // Single file upload
 * const file = {
 *   id: '1',
 *   name: 'preline-ui.xls',
 *   size: '7 KB',
 *   progress: 25,
 *   status: 'uploading'
 * };
 * <FileUploadProgress file={file} onPause={(id) => console.log('pause', id)} />
 *
 * // Multiple files in card
 * const files = [
 *   { id: '1', name: 'file1.html', size: '7 KB', progress: 100, status: 'completed' },
 *   { id: '2', name: 'file2.mp4', size: '105.5 MB', progress: 25, status: 'uploading' },
 *   { id: '3', name: 'file3.jpg', size: '55 KB', progress: 100, status: 'completed' }
 * ];
 * <FileUploadProgress
 *   files={files}
 *   variant="card"
 *   onPauseAll={() => console.log('pause all')}
 * />
 *
 * // With reactive progress
 * const progress = Pulse.signal(0);
 * const file = {
 *   id: '1',
 *   name: 'upload.pdf',
 *   size: '2.5 MB',
 *   progress: progress,
 *   status: 'uploading'
 * };
 * <FileUploadProgress file={file} />
 * ```
 */

import Pulse from "pulse-framework";
import type { FileUploadProgressProps, FileUploadItem } from "../../types";
import { cn, generateId, isSignal } from "../../utils";
import { Progress } from "./Progress";

/**
 * FileUploadProgressItem - Single file upload item
 */
const FileUploadProgressItem: Pulse.Fn<{
  file: FileUploadItem;
  showPercentage?: boolean;
  showActions?: boolean;
  onPause?: (fileId: string) => void;
  onResume?: (fileId: string) => void;
  onDelete?: (fileId: string) => void;
}> = (props) => {
  const {
    file,
    showPercentage = true,
    showActions = true,
    onPause,
    onResume,
    onDelete,
  } = props;

  // Get progress value (handle signals)
  const getProgress = (): number => {
    return isSignal(file.progress)
      ? (file.progress as any)()
      : (file.progress as number);
  };

  const progress = getProgress();

  // Determine progress bar color based on status
  const getProgressColor = () => {
    switch (file.status) {
      case "completed":
        return "success";
      case "error":
        return "danger";
      default:
        return "primary";
    }
  };

  // Default file icon (upload icon)
  const defaultIcon = (
    <svg
      class="shrink-0 size-5"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
      <polyline points="17 8 12 3 7 8"></polyline>
      <line x1="12" x2="12" y1="3" y2="15"></line>
    </svg>
  );

  const fileIcon = file.icon || defaultIcon;

  return (
    <div>
      {/* File Content */}
      <div class="mb-2 flex justify-between items-center">
        <div class="flex items-center gap-x-3">
          <span class="size-8 flex justify-center items-center border border-gray-200 text-gray-500 rounded-lg dark:border-neutral-700 dark:text-neutral-500">
            {fileIcon}
          </span>
          <div>
            <p
              class={cn(
                "text-sm font-medium",
                file.status === "error"
                  ? "text-red-500"
                  : "text-gray-800 dark:text-white",
              )}
            >
              {file.name}
            </p>
            <p class="text-xs text-gray-500 dark:text-neutral-500">
              {file.size}
            </p>
          </div>
        </div>

        {showActions && (
          <div class="inline-flex items-center gap-x-2">
            {/* Status Icon (for completed/error) */}
            {file.status === "completed" && (
              <span class="relative">
                <svg
                  class="shrink-0 size-4 text-teal-500"
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  viewBox="0 0 16 16"
                >
                  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"></path>
                </svg>
                <span class="sr-only">Success</span>
              </span>
            )}

            {file.status === "error" && (
              <span class="relative">
                <svg
                  class="shrink-0 size-4 text-red-500"
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  viewBox="0 0 16 16"
                >
                  <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"></path>
                </svg>
                <span class="sr-only">Danger</span>
              </span>
            )}

            {/* Pause/Resume Button (only for uploading/paused) */}
            {(file.status === "uploading" || file.status === "paused") && (
              <button
                type="button"
                class="relative text-gray-500 hover:text-gray-800 focus:outline-hidden focus:text-gray-800 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200"
                onClick={() => {
                  if (file.status === "uploading" && onPause) {
                    onPause(file.id);
                  } else if (file.status === "paused" && onResume) {
                    onResume(file.id);
                  }
                }}
              >
                {file.status === "uploading" ? (
                  <>
                    <svg
                      class="shrink-0 size-4"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <rect width="4" height="16" x="6" y="4"></rect>
                      <rect width="4" height="16" x="14" y="4"></rect>
                    </svg>
                    <span class="sr-only">Pause</span>
                  </>
                ) : (
                  <>
                    <svg
                      class="shrink-0 size-4"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <polygon points="5 3 19 12 5 21 5 3"></polygon>
                    </svg>
                    <span class="sr-only">Resume</span>
                  </>
                )}
              </button>
            )}

            {/* Delete Button */}
            <button
              type="button"
              class="relative text-gray-500 hover:text-gray-800 focus:outline-hidden focus:text-gray-800 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-500 dark:hover:text-neutral-200 dark:focus:text-neutral-200"
              onClick={() => onDelete && onDelete(file.id)}
            >
              <svg
                class="shrink-0 size-4"
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <path d="M3 6h18"></path>
                <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                <line x1="10" x2="10" y1="11" y2="17"></line>
                <line x1="14" x2="14" y1="11" y2="17"></line>
              </svg>
              <span class="sr-only">Delete</span>
            </button>
          </div>
        )}
      </div>

      {/* Progress Bar */}
      <div class="flex items-center gap-x-3 whitespace-nowrap">
        <Progress
          value={file.progress}
          size="xs"
          color={getProgressColor()}
          className="flex-1"
          rounded={true}
          transition={true}
        />
        {showPercentage && (
          <div class="w-10 text-end">
            <span class="text-sm text-gray-800 dark:text-white">
              {Math.round(progress)}%
            </span>
          </div>
        )}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * FileUploadProgress - Main component
 */
export const FileUploadProgress: Pulse.Fn<FileUploadProgressProps> = (
  props,
) => {
  const {
    file,
    files,
    showPercentage = true,
    showActions = true,
    variant = "inline",
    onPause,
    onResume,
    onDelete,
    onPauseAll,
    onResumeAll,
    onDeleteAll,
    footerText,
    footerActions,
    className,
    id = generateId("file-upload-progress"),
    style,
    ...rest
  } = props;

  // Single file mode
  if (file) {
    return (
      <FileUploadProgressItem
        file={file}
        showPercentage={showPercentage}
        showActions={showActions}
        onPause={onPause}
        onResume={onResume}
        onDelete={onDelete}
      />
    ) as Pulse.JSX.Element;
  }

  // Multiple files mode
  if (!files || files.length === 0) {
    return (<div></div>) as Pulse.JSX.Element;
  }

  // Calculate stats
  const completedFiles = files.filter((f) => f.status === "completed").length;
  const failedFiles = files.filter((f) => f.status === "error").length;
  const uploadingFiles = files.filter(
    (f) => f.status === "uploading" || f.status === "paused",
  ).length;

  // Generate footer text
  const getFooterText = (): string => {
    if (footerText) return footerText;

    if (failedFiles > 0) {
      return `${completedFiles} success, ${failedFiles} failed`;
    }

    if (uploadingFiles > 0) {
      return `${uploadingFiles} left`;
    }

    return `${completedFiles} completed`;
  };

  // Inline variant (just list)
  if (variant === "inline") {
    return (
      <div id={id} class={cn("space-y-7", className)} style={style} {...rest}>
        {files.map((fileItem) => (
          <FileUploadProgressItem
            file={fileItem}
            showPercentage={showPercentage}
            showActions={showActions}
            onPause={onPause}
            onResume={onResume}
            onDelete={onDelete}
          />
        ))}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Card variant (with card wrapper and footer)
  return (
    <div
      id={id}
      class={cn(
        "flex flex-col bg-white border border-gray-200 shadow-sm rounded-xl dark:bg-neutral-800 dark:border-neutral-700",
        className,
      )}
      style={style}
      {...rest}
    >
      {/* Body */}
      <div class="p-4 md:p-5 space-y-7">
        {files.map((fileItem) => (
          <FileUploadProgressItem
            file={fileItem}
            showPercentage={showPercentage}
            showActions={showActions}
            onPause={onPause}
            onResume={onResume}
            onDelete={onDelete}
          />
        ))}
      </div>

      {/* Footer */}
      <div class="bg-gray-50 border-t border-gray-200 rounded-b-xl py-2 px-4 md:px-5 dark:bg-white/10 dark:border-neutral-700">
        <div class="flex flex-wrap justify-between items-center gap-x-3">
          <div>
            <span class="text-sm font-semibold text-gray-800 dark:text-white">
              {getFooterText()}
            </span>
          </div>

          {/* Footer Actions */}
          {(footerActions || onPauseAll || onResumeAll || onDeleteAll) && (
            <div class="-me-2.5">
              {footerActions ? (
                footerActions
              ) : (
                <>
                  {/* Pause All / Resume All */}
                  {uploadingFiles > 0 && (
                    <>
                      {files.some((f) => f.status === "uploading") &&
                        onPauseAll && (
                          <button
                            type="button"
                            class="py-2 px-3 inline-flex items-center gap-x-1.5 text-sm font-medium rounded-lg border border-transparent text-gray-500 hover:bg-gray-200 hover:text-gray-800 focus:outline-hidden focus:bg-gray-200 focus:text-gray-800 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-white dark:focus:bg-neutral-800 dark:focus:text-white"
                            onClick={onPauseAll}
                          >
                            <svg
                              class="shrink-0 size-4"
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            >
                              <rect width="4" height="16" x="6" y="4"></rect>
                              <rect width="4" height="16" x="14" y="4"></rect>
                            </svg>
                            Pause
                          </button>
                        )}

                      {files.some((f) => f.status === "paused") &&
                        onResumeAll && (
                          <button
                            type="button"
                            class="py-2 px-3 inline-flex items-center gap-x-1.5 text-sm font-medium rounded-lg border border-transparent text-gray-800 hover:bg-gray-200 focus:outline-hidden focus:bg-gray-200 disabled:opacity-50 disabled:pointer-events-none dark:text-white dark:hover:bg-neutral-800 dark:focus:bg-neutral-800"
                            onClick={onResumeAll}
                          >
                            <svg
                              class="shrink-0 size-4"
                              xmlns="http://www.w3.org/2000/svg"
                              width="24"
                              height="24"
                              viewBox="0 0 24 24"
                              fill="none"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"
                            >
                              <polygon points="5 3 19 12 5 21 5 3"></polygon>
                            </svg>
                            Start
                          </button>
                        )}
                    </>
                  )}

                  {/* Delete All */}
                  {onDeleteAll && (
                    <button
                      type="button"
                      class="py-2 px-3 inline-flex items-center gap-x-1.5 text-sm font-medium rounded-lg border border-transparent text-gray-500 hover:bg-gray-200 hover:text-gray-800 focus:outline-hidden focus:bg-gray-200 focus:text-gray-800 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:bg-neutral-800 dark:hover:text-white dark:focus:bg-neutral-800 dark:focus:text-white"
                      onClick={onDeleteAll}
                    >
                      <svg
                        class="shrink-0 size-4"
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                      >
                        <path d="M3 6h18"></path>
                        <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                        <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                        <line x1="10" x2="10" y1="11" y2="17"></line>
                        <line x1="14" x2="14" y1="11" y2="17"></line>
                      </svg>
                      Delete
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
