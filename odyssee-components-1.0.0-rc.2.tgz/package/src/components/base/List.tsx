/**
 * List Component
 * A versatile list component with multiple styles including bulleted, numbered, checked, and inline lists
 *
 * @example
 * ```tsx
 * import { List } from '@odyssee/components';
 *
 * // Basic disc list
 * <List items={['Item 1', 'Item 2', 'Item 3']} />
 *
 * // Numbered list
 * <List items={['Item 1', 'Item 2', 'Item 3']} type="decimal" />
 *
 * // Checked list
 * <List
 *   items={['FAQ', 'License', 'Terms & Conditions']}
 *   type="check"
 *   checkColor="primary"
 * />
 *
 * // Checked list with variant
 * <List
 *   items={['FAQ', 'License', 'Terms & Conditions']}
 *   type="check"
 *   checkColor="primary"
 *   checkVariant="solid"
 * />
 *
 * // Inline list with separator
 * <List
 *   items={['FAQ', 'License', 'Terms & Conditions']}
 *   type="inline"
 *   separator="dot"
 * />
 *
 * // Custom marker color
 * <List
 *   items={['FAQ', 'License', 'Terms & Conditions']}
 *   markerColor="text-blue-600"
 * />
 *
 * // Complex items with custom icons
 * <List
 *   items={[
 *     { content: 'Item 1', icon: <svg>...</svg>, iconColor: 'primary' },
 *     { content: 'Item 2', icon: <svg>...</svg>, iconColor: 'success' },
 *   ]}
 *   type="check"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { ListProps, ListItem } from "../../types";
import { cn, generateId } from "../../utils";

/**
 * Check icon SVG
 */
const CheckIcon: Pulse.Fn = () => (
  <svg
    class="shrink-0 size-3.5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <polyline points="20 6 9 17 4 12"></polyline>
  </svg>
);

export const List: Pulse.Fn<ListProps> = (props) => {
  const {
    items = [],
    type = "disc",
    spacing = "md",
    markerColor,
    checkColor = "primary",
    checkVariant = "simple",
    separator = "dot",
    size = "sm",
    start = 1,
    className,
    id = generateId("list"),
    style,
    ...rest
  } = props;

  // Spacing classes
  const spacingClasses = {
    sm: "space-y-2",
    md: "space-y-3",
    lg: "space-y-4",
  };

  // Text size classes
  const sizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
  };

  // Check icon color classes
  const checkColorClasses = {
    primary: "text-blue-600 dark:text-blue-500",
    secondary: "text-gray-600",
    success: "text-teal-500",
    danger: "text-red-500",
    warning: "text-yellow-500",
    info: "text-blue-600 dark:text-blue-500",
    light: "text-white",
    dark: "text-gray-800 dark:text-white",
    gray: "text-gray-500 dark:text-neutral-500",
    white: "text-white",
    teal: "text-teal-500",
    indigo: "text-indigo-600",
    purple: "text-purple-600",
    pink: "text-pink-600",
    orange: "text-orange-600",
  };

  // Check icon soft variant background classes
  const checkSoftColorClasses = {
    primary: "bg-blue-50 text-blue-600 dark:bg-blue-800/30 dark:text-blue-500",
    secondary:
      "bg-gray-50 text-gray-600 dark:bg-neutral-700 dark:text-neutral-400",
    success: "bg-teal-50 text-teal-500 dark:bg-teal-800/30 dark:text-teal-500",
    danger: "bg-red-50 text-red-500 dark:bg-red-800/30 dark:text-red-500",
    warning:
      "bg-yellow-50 text-yellow-500 dark:bg-yellow-800/30 dark:text-yellow-500",
    info: "bg-blue-50 text-blue-600 dark:bg-blue-800/30 dark:text-blue-500",
    light: "bg-white/10 text-white",
    dark: "bg-gray-50 text-gray-600 dark:bg-neutral-700 dark:text-neutral-200",
    gray: "bg-gray-50 text-gray-500 dark:bg-neutral-700 dark:text-neutral-400",
    white: "bg-white/10 text-white",
    teal: "bg-teal-50 text-teal-500 dark:bg-teal-800/30 dark:text-teal-500",
    indigo:
      "bg-indigo-50 text-indigo-600 dark:bg-indigo-800/30 dark:text-indigo-500",
    purple:
      "bg-purple-50 text-purple-600 dark:bg-purple-800/30 dark:text-purple-500",
    pink: "bg-pink-50 text-pink-600 dark:bg-pink-800/30 dark:text-pink-500",
    orange:
      "bg-orange-50 text-orange-600 dark:bg-orange-800/30 dark:text-orange-500",
  };

  // Check icon solid variant background classes
  const checkSolidColorClasses = {
    primary: "bg-blue-600 text-white dark:bg-blue-500",
    secondary: "bg-gray-500 text-white",
    success: "bg-teal-500 text-white",
    danger: "bg-red-500 text-white",
    warning: "bg-yellow-500 text-white",
    info: "bg-blue-600 text-white dark:bg-blue-500",
    light: "bg-white text-gray-800",
    dark: "bg-gray-800 text-gray-200 dark:bg-neutral-200 dark:text-neutral-800",
    gray: "bg-gray-500 text-white",
    white: "bg-white text-gray-800",
    teal: "bg-teal-500 text-white",
    indigo: "bg-indigo-600 text-white",
    purple: "bg-purple-600 text-white",
    pink: "bg-pink-600 text-white",
    orange: "bg-orange-600 text-white",
  };

  // Render check icon based on variant
  const renderCheckIcon = (item: ListItem) => {
    const itemCheckColor = item.iconColor || checkColor;
    const itemCheckVariant = item.iconVariant || checkVariant;

    if (itemCheckVariant === "simple") {
      // Simple check icon
      return (
        <svg
          class={cn(
            "shrink-0 size-4 mt-0.5",
            checkColorClasses[itemCheckColor as keyof typeof checkColorClasses],
          )}
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      );
    }

    if (itemCheckVariant === "soft") {
      // Soft check icon with background
      return (
        <span
          class={cn(
            "size-5 flex justify-center items-center rounded-full",
            checkSoftColorClasses[
              itemCheckColor as keyof typeof checkSoftColorClasses
            ],
          )}
        >
          <CheckIcon />
        </span>
      );
    }

    // Solid check icon with background
    return (
      <span
        class={cn(
          "size-5 flex justify-center items-center rounded-full",
          checkSolidColorClasses[
            itemCheckColor as keyof typeof checkSolidColorClasses
          ],
        )}
      >
        <CheckIcon />
      </span>
    );
  };

  // Render custom icon
  const renderCustomIcon = (icon: HTMLElement | string) => {
    if (typeof icon === "string") {
      return <span class="shrink-0 size-4 mt-0.5">{icon}</span>;
    }
    return icon;
  };

  // Render list item content
  const renderItemContent = (item: string | ListItem) => {
    if (typeof item === "string") {
      return <span class="text-gray-800 dark:text-neutral-400">{item}</span>;
    }

    if (typeof item.content === "string") {
      return (
        <span class="text-gray-800 dark:text-neutral-400">{item.content}</span>
      );
    }

    return item.content;
  };

  // Inline list with separator
  if (type === "inline") {
    const separatorClasses =
      separator === "dot"
        ? "before:absolute before:top-1/2 before:end-3 before:-translate-y-1/2 before:size-1 before:bg-gray-300 before:rounded-full dark:before:bg-neutral-600"
        : separator === "pipe"
          ? "before:absolute before:top-1/2 before:end-3 before:-translate-y-1/2 before:content-['|'] before:text-gray-300 dark:before:text-neutral-600"
          : separator === "slash"
            ? "before:absolute before:top-1/2 before:end-3 before:-translate-y-1/2 before:content-['/'] before:text-gray-300 dark:before:text-neutral-600"
            : "";

    return (
      <ul
        id={id}
        class={cn(sizeClasses[size], "text-gray-600", className)}
        style={style}
        {...rest}
      >
        {items.map((item, index) => (
          <li
            key={index}
            class={cn(
              "inline-block relative pe-8 last:pe-0",
              separator !== "none" && "last-of-type:before:hidden",
              separatorClasses,
            )}
          >
            {renderItemContent(item)}
          </li>
        ))}
      </ul>
    ) as Pulse.JSX.Element;
  }

  // Checked list
  if (type === "check") {
    return (
      <ul
        id={id}
        class={cn(spacingClasses[spacing], sizeClasses[size], className)}
        style={style}
        {...rest}
      >
        {items.map((item, index) => {
          const listItem = typeof item === "string" ? { content: item } : item;
          const hasCustomIcon = listItem.icon !== undefined;

          return (
            <li key={index} class="flex gap-x-3">
              {hasCustomIcon
                ? renderCustomIcon(listItem.icon!)
                : renderCheckIcon(listItem)}
              {renderItemContent(item)}
            </li>
          );
        })}
      </ul>
    ) as Pulse.JSX.Element;
  }

  // Standard list (disc, decimal, none)
  const ListTag = type === "decimal" ? "ol" : "ul";
  const listTypeClasses = {
    disc: "list-disc",
    decimal: "list-decimal",
    none: "list-none",
  };

  return (
    <ListTag
      id={id}
      class={cn(
        listTypeClasses[type as keyof typeof listTypeClasses],
        "list-inside",
        sizeClasses[size],
        "text-gray-800 dark:text-white",
        markerColor && markerColor,
        markerColor &&
          markerColor.startsWith("marker:") === false &&
          `marker:${markerColor}`,
        className,
      )}
      style={style}
      start={type === "decimal" ? start : undefined}
      {...rest}
    >
      {items.map((item, index) => (
        <li key={index}>{renderItemContent(item)}</li>
      ))}
    </ListTag>
  ) as Pulse.JSX.Element;
};

/**
 * CheckList Component
 * Convenience component for checked lists
 *
 * @example
 * ```tsx
 * <CheckList
 *   items={['FAQ', 'License', 'Terms']}
 *   color="primary"
 *   variant="solid"
 * />
 * ```
 */
export const CheckList: Pulse.Fn<
  Omit<ListProps, "type"> & {
    color?: ListProps["checkColor"];
    variant?: ListProps["checkVariant"];
  }
> = (props) => {
  const { color, variant, ...rest } = props;
  return (
    <List
      {...(rest as any)}
      type="check"
      checkColor={color}
      checkVariant={variant}
    />
  );
};

/**
 * InlineList Component
 * Convenience component for inline lists
 *
 * @example
 * ```tsx
 * <InlineList items={['Home', 'About', 'Contact']} separator="pipe" />
 * ```
 */
export const InlineList: Pulse.Fn<Omit<ListProps, "type">> = (props) => {
  return <List {...(props as any)} type="inline" />;
};

/**
 * OrderedList Component
 * Convenience component for numbered lists
 *
 * @example
 * ```tsx
 * <OrderedList items={['First', 'Second', 'Third']} start={1} />
 * ```
 */
export const OrderedList: Pulse.Fn<Omit<ListProps, "type">> = (props) => {
  return <List {...(props as any)} type="decimal" />;
};

/**
 * UnorderedList Component
 * Convenience component for bulleted lists
 *
 * @example
 * ```tsx
 * <UnorderedList items={['Item 1', 'Item 2', 'Item 3']} />
 * ```
 */
export const UnorderedList: Pulse.Fn<Omit<ListProps, "type">> = (props) => {
  return <List {...(props as any)} type="disc" />;
};

export default List;
