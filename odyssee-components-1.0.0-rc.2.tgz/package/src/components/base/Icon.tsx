/**
 * Icon Component
 * A versatile icon component with SVG support, multiple variants, sizes, colors, and shapes
 *
 * @example
 * ```tsx
 * import { Icon } from '@odyssee/components';
 *
 * // Basic icon (standalone SVG)
 * <Icon>
 *   <svg>...</svg>
 * </Icon>
 *
 * // With variant and color (wrapped)
 * <Icon variant="solid" color="primary" shape="circular">
 *   <svg>...</svg>
 * </Icon>
 *
 * // Different sizes
 * <Icon size="xs" variant="soft" color="success">
 *   <svg>...</svg>
 * </Icon>
 *
 * // Ghost variant (no background)
 * <Icon variant="ghost" color="danger" shape="rounded">
 *   <svg>...</svg>
 * </Icon>
 *
 * // Outline variant
 * <Icon variant="outline" color="warning" shape="circular">
 *   <svg>...</svg>
 * </Icon>
 *
 * // Soft-outline variant
 * <Icon variant="soft-outline" color="info" shape="rounded">
 *   <svg>...</svg>
 * </Icon>
 * ```
 */

import Pulse from "pulse-framework";
import type { IconProps } from "../../types";
import { cn, generateId } from "../../utils";

export const Icon: Pulse.Fn<IconProps> = (props) => {
  const {
    children,
    size = "md",
    width,
    height,
    color = "primary",
    variant,
    shape = "rounded",
    strokeWidth,
    fill = false,
    containerClassName,
    className,
    id = generateId("icon"),
    style,
    ...rest
  } = props;

  // Container sizes (wrapper span)
  const containerSizes = {
    xs: "size-6", // 24px
    sm: "size-8", // 32px
    md: "size-10", // 40px
    lg: "size-12", // 48px
    xl: "size-14", // 56px
    "2xl": "size-16", // 64px
  };

  // Icon sizes (SVG inside)
  const iconSizes = {
    xs: "size-3", // 12px
    sm: "size-4", // 16px
    md: "size-5", // 20px
    lg: "size-6", // 24px
    xl: "size-8", // 32px
    "2xl": "size-10", // 40px
  };

  // Shape classes
  const shapeClasses = {
    square: "rounded-none",
    rounded: "rounded-lg",
    circular: "rounded-full",
  };

  // Variant + Color classes
  const variantColorClasses = {
    solid: {
      primary:
        "bg-blue-600 text-white dark:bg-blue-500",
      secondary:
        "bg-gray-500 text-white dark:bg-neutral-700",
      success: "bg-teal-500 text-white",
      danger: "bg-red-500 text-white",
      warning: "bg-yellow-500 text-white",
      info: "bg-cyan-500 text-white",
      light:
        "bg-white text-gray-600 dark:bg-neutral-100 dark:text-neutral-700",
      dark:
        "bg-gray-800 text-white dark:bg-white dark:text-neutral-800",
    },
    outline: {
      primary:
        "border border-blue-600 text-blue-600 dark:border-blue-500 dark:text-blue-500",
      secondary:
        "border border-gray-500 text-gray-500 dark:border-neutral-500 dark:text-neutral-500",
      success: "border border-teal-500 text-teal-500",
      danger: "border border-red-500 text-red-500",
      warning: "border border-yellow-500 text-yellow-500",
      info: "border border-cyan-500 text-cyan-500",
      light:
        "border border-white text-white dark:border-neutral-200 dark:text-neutral-200",
      dark:
        "border border-gray-700 text-gray-700 dark:border-neutral-200 dark:text-neutral-200",
    },
    ghost: {
      primary: "text-blue-600 dark:text-blue-500",
      secondary: "text-gray-500 dark:text-neutral-500",
      success: "text-teal-500",
      danger: "text-red-500",
      warning: "text-yellow-500",
      info: "text-cyan-500",
      light: "text-white",
      dark: "text-gray-700 dark:text-neutral-400",
    },
    soft: {
      primary:
        "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-400",
      secondary:
        "bg-gray-50 text-gray-800 dark:bg-neutral-700 dark:text-neutral-400",
      success:
        "bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-400",
      danger: "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-400",
      warning:
        "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-400",
      info: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-400",
      light:
        "bg-white/10 text-white dark:bg-neutral-800 dark:text-neutral-200",
      dark:
        "bg-gray-100 text-gray-800 dark:bg-neutral-700 dark:text-neutral-200",
    },
    "soft-outline": {
      primary:
        "border-4 border-blue-100 bg-blue-200 text-blue-800 dark:border-blue-900 dark:bg-blue-800 dark:text-blue-400",
      secondary:
        "border-4 border-gray-50 bg-gray-200 text-gray-800 dark:border-neutral-600 dark:bg-neutral-700 dark:text-neutral-200",
      success:
        "border-4 border-teal-100 bg-teal-200 text-teal-800 dark:border-teal-900 dark:bg-teal-800 dark:text-teal-400",
      danger:
        "border-4 border-red-100 bg-red-200 text-red-800 dark:border-red-900 dark:bg-red-800 dark:text-red-400",
      warning:
        "border-4 border-yellow-100 bg-yellow-200 text-yellow-800 dark:border-yellow-900 dark:bg-yellow-800 dark:text-yellow-400",
      info:
        "border-4 border-cyan-100 bg-cyan-200 text-cyan-800 dark:border-cyan-900 dark:bg-cyan-800 dark:text-cyan-400",
      light:
        "border-4 border-white/10 bg-white/10 text-white dark:border-neutral-700 dark:bg-neutral-800 dark:text-neutral-200",
      dark:
        "border-4 border-gray-100 bg-gray-200 text-gray-800 dark:border-neutral-600 dark:bg-neutral-700 dark:text-neutral-200",
    },
  };

  // Process children to add icon classes and attributes
  const processIconSvg = (child: any): any => {
    if (!child) return null;

    // If it's an SVG element
    if (
      child.type === "svg" ||
      (typeof child.type === "string" && child.type.toLowerCase() === "svg")
    ) {
      const svgClasses = cn(
        "shrink-0",
        !width && !height ? iconSizes[size] : "",
        className,
      );

      // Build SVG attributes
      const svgAttrs: any = {
        class: svgClasses,
        xmlns: child.props?.xmlns || "http://www.w3.org/2000/svg",
        viewBox: child.props?.viewBox || "0 0 24 24",
        fill: fill ? "currentColor" : child.props?.fill || "none",
        stroke: !fill ? "currentColor" : child.props?.stroke || "none",
      };

      // Add custom width/height if provided
      if (width) svgAttrs.width = width;
      if (height) svgAttrs.height = height;

      // Add stroke attributes if not filled
      if (!fill) {
        svgAttrs["stroke-width"] = strokeWidth || child.props?.["stroke-width"] || "2";
        svgAttrs["stroke-linecap"] = child.props?.["stroke-linecap"] || "round";
        svgAttrs["stroke-linejoin"] = child.props?.["stroke-linejoin"] || "round";
      }

      // Clone the SVG with new attributes
      return (
        <svg {...svgAttrs}>
          {child.props?.children || child.children}
        </svg>
      );
    }

    // If children is an array, process first SVG found
    if (Array.isArray(child)) {
      for (const item of child) {
        const processed = processIconSvg(item);
        if (processed) return processed;
      }
    }

    // If it's a raw SVG element (HTMLElement)
    if (child instanceof HTMLElement && child.tagName?.toLowerCase() === "svg") {
      const svgClasses = cn(
        "shrink-0",
        !width && !height ? iconSizes[size] : "",
        className,
      );

      child.setAttribute("class", svgClasses);

      if (!child.hasAttribute("xmlns")) {
        child.setAttribute("xmlns", "http://www.w3.org/2000/svg");
      }
      if (!child.hasAttribute("viewBox")) {
        child.setAttribute("viewBox", "0 0 24 24");
      }

      if (fill) {
        child.setAttribute("fill", "currentColor");
        child.setAttribute("stroke", "none");
      } else {
        child.setAttribute("fill", "none");
        child.setAttribute("stroke", "currentColor");
        child.setAttribute("stroke-width", strokeWidth?.toString() || "2");
        child.setAttribute("stroke-linecap", "round");
        child.setAttribute("stroke-linejoin", "round");
      }

      if (width) child.setAttribute("width", width.toString());
      if (height) child.setAttribute("height", height.toString());

      return child;
    }

    return child;
  };

  // Process the SVG
  const iconSvg = processIconSvg(children);

  // Standalone mode: no variant/shape, just return the SVG with minimal styling
  if (!variant) {
    return iconSvg as Pulse.JSX.Element;
  }

  // Wrapped mode: with variant and shape
  const containerClasses = cn(
    "inline-flex justify-center items-center",
    containerSizes[size],
    shapeClasses[shape],
    variantColorClasses[variant][color],
    containerClassName,
  );

  return (
    <span
      id={id}
      class={containerClasses}
      style={style}
      aria-hidden="true"
      {...rest}
    >
      {iconSvg}
    </span>
  ) as Pulse.JSX.Element;
};
