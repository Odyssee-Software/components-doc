/**
 * Collapse Component
 * A component for showing/hiding content with smooth transitions
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { BaseComponentProps, Signal } from "../../types";

/**
 * Collapse props
 */
export interface CollapseProps extends BaseComponentProps {
  // Control open/closed state
  isOpen?: boolean | Signal<boolean>;

  // Trigger element (button/link)
  trigger?: HTMLElement | string;

  // Content to show/hide
  children?: HTMLElement | HTMLElement[] | string;

  // Show different text when open/closed
  openText?: string;
  closedText?: string;

  // Show icon
  showIcon?: boolean;

  // Trigger styling
  triggerClassName?: string;
  triggerVariant?: "button" | "link";

  // Transition duration
  duration?: number;

  // Callbacks
  onToggle?: (isOpen: boolean) => void;
  onOpen?: () => void;
  onClose?: () => void;
}

/**
 * ChevronDown Icon
 */
const ChevronDownIcon: Pulse.Fn = (): Pulse.JSX.Element => (
  <svg
    class="hs-collapse-open:rotate-180 shrink-0 size-4 transition-transform"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m6 9 6 6 6-6"></path>
  </svg>
);

/**
 * Collapse Component
 *
 * @example
 * ```tsx
 * // Basic collapse
 * <Collapse
 *   trigger="Toggle Content"
 *   isOpen={false}
 * >
 *   <p>This content can be collapsed</p>
 * </Collapse>
 *
 * // With reactive signal
 * const isOpen = Pulse.signal(false);
 * <Collapse
 *   trigger="Toggle"
 *   isOpen={isOpen}
 * >
 *   <p>Content here</p>
 * </Collapse>
 *
 * // Read more/less pattern
 * <Collapse
 *   openText="Read less"
 *   closedText="Read more"
 *   triggerVariant="link"
 * >
 *   <p>Hidden content...</p>
 * </Collapse>
 * ```
 */
export const Collapse: Pulse.Fn<CollapseProps> = (
  props: CollapseProps,
): Pulse.JSX.Element => {
  const {
    isOpen: isOpenProp,
    trigger,
    children,
    openText,
    closedText,
    showIcon = true,
    triggerClassName,
    triggerVariant = "button",
    duration = 300,
    onToggle,
    onOpen,
    onClose,
    className,
    id,
    style,
  } = props;

  // Create or use provided signal for open state
  const isOpenSignal: any =
    typeof isOpenProp === "object" && "value" in isOpenProp
      ? isOpenProp
      : Pulse.signal(isOpenProp || false);

  // Generate unique ID
  const collapseId =
    id || `collapse-${Math.random().toString(36).substr(2, 9)}`;
  const triggerId = `${collapseId}-trigger`;

  // Toggle handler
  const handleToggle = () => {
    const currentState =
      typeof isOpenSignal === "boolean" ? isOpenSignal : isOpenSignal.value;
    const newState = !currentState;

    if (typeof isOpenSignal !== "boolean") {
      isOpenSignal.value = newState;
    }

    if (onToggle) onToggle(newState);
    if (newState && onOpen) onOpen();
    if (!newState && onClose) onClose();
  };

  // Watch for state changes (can be used for side effects)
  // Pulse.effect(() => {
  //   const current =
  //     typeof isOpenSignal === "boolean" ? isOpenSignal : isOpenSignal.value;
  //   // Side effects can be added here if needed
  // });

  // Get current state for rendering
  const getCurrentState = () => {
    return typeof isOpenSignal === "boolean"
      ? isOpenSignal
      : isOpenSignal.value;
  };

  // Trigger button classes
  const getTriggerClasses = () => {
    if (triggerVariant === "link") {
      return cn(
        "inline-flex items-center gap-x-1",
        "text-sm font-semibold rounded-lg border border-transparent",
        "text-blue-600 decoration-2 hover:text-blue-700 hover:underline",
        "focus:outline-hidden focus:underline focus:text-blue-700",
        "disabled:opacity-50 disabled:pointer-events-none",
        "dark:text-blue-500 dark:hover:text-blue-600 dark:focus:text-blue-600",
        triggerClassName,
      );
    }

    // Button variant
    return cn(
      "py-3 px-4 inline-flex items-center gap-x-2",
      "text-sm font-medium rounded-lg border border-transparent",
      "bg-blue-600 text-white hover:bg-blue-700",
      "focus:outline-hidden focus:bg-blue-700",
      "disabled:opacity-50 disabled:pointer-events-none",
      triggerClassName,
    );
  };

  // Content classes
  const contentClasses = cn(
    "hs-collapse w-full overflow-hidden transition-[height]",
    !getCurrentState() && "hidden",
    className,
  );

  // Render trigger content
  const renderTriggerContent = () => {
    const isOpen = getCurrentState();

    if (openText || closedText) {
      return (
        <>
          {!isOpen && closedText && (
            <span class="hs-collapse-open:hidden">{closedText}</span>
          )}
          {isOpen && openText && (
            <span class="hs-collapse-open:block hidden">{openText}</span>
          )}
          {showIcon && <ChevronDownIcon />}
        </>
      );
    }

    if (typeof trigger === "string") {
      return (
        <>
          {trigger}
          {showIcon && <ChevronDownIcon />}
        </>
      );
    }

    return trigger;
  };

  // Render content
  const renderContent = () => {
    if (typeof children === "string") {
      return <p class="text-gray-500 dark:text-neutral-400">{children}</p>;
    }
    return children;
  };

  return (
    <div>
      <button
        type="button"
        id={triggerId}
        class={cn("hs-collapse-toggle", getTriggerClasses())}
        aria-expanded={getCurrentState() ? "true" : "false"}
        aria-controls={collapseId}
        onClick={handleToggle}
      >
        {renderTriggerContent()}
      </button>

      <div
        id={collapseId}
        class={contentClasses}
        style={`transition-duration: ${duration}ms; ${typeof style === "string" ? style : ""}`}
        aria-labelledby={triggerId}
      >
        {renderContent()}
      </div>
    </div>
  );
};

/**
 * CollapseContent - Just the collapsible content without trigger
 * Useful when you want to control the trigger separately
 */
export interface CollapseContentProps extends BaseComponentProps {
  isOpen?: boolean | Signal<boolean>;
  children?: HTMLElement | HTMLElement[] | string;
  duration?: number;
  triggerId?: string;
}

export const CollapseContent: Pulse.Fn<CollapseContentProps> = (
  props: CollapseContentProps,
): Pulse.JSX.Element => {
  const {
    isOpen: isOpenProp,
    children,
    duration = 300,
    triggerId,
    className,
    id,
    style,
  } = props;

  // Get current state
  const isOpen =
    typeof isOpenProp === "object" &&
    isOpenProp !== null &&
    "value" in isOpenProp
      ? (isOpenProp as any).value
      : isOpenProp || false;

  const collapseId =
    id || `collapse-content-${Math.random().toString(36).substr(2, 9)}`;

  const contentClasses = cn(
    "hs-collapse w-full overflow-hidden transition-[height]",
    !isOpen && "hidden",
    className,
  );

  const renderContent = () => {
    if (typeof children === "string") {
      return <p class="text-gray-500 dark:text-neutral-400">{children}</p>;
    }
    return children;
  };

  return (
    <div
      id={collapseId}
      class={contentClasses}
      style={`transition-duration: ${duration}ms; ${typeof style === "string" ? style : ""}`}
      aria-labelledby={triggerId}
    >
      {renderContent()}
    </div>
  );
};

/**
 * CollapseTrigger - Just the trigger button without content
 * Useful when you want to control the content separately
 */
export interface CollapseTriggerProps extends BaseComponentProps {
  isOpen?: boolean | Signal<boolean>;
  targetId: string;
  children?: HTMLElement | string;
  showIcon?: boolean;
  variant?: "button" | "link";
  onToggle?: (isOpen: boolean) => void;
}

export const CollapseTrigger: Pulse.Fn<CollapseTriggerProps> = (
  props: CollapseTriggerProps,
): Pulse.JSX.Element => {
  const {
    isOpen: isOpenProp,
    targetId,
    children,
    showIcon = true,
    variant = "button",
    onToggle,
    className,
    id,
  } = props;

  const isOpenSignal: any =
    typeof isOpenProp === "object" && "value" in isOpenProp
      ? isOpenProp
      : Pulse.signal(isOpenProp || false);

  const triggerId =
    id || `collapse-trigger-${Math.random().toString(36).substr(2, 9)}`;

  const handleToggle = () => {
    const currentState =
      typeof isOpenSignal === "boolean" ? isOpenSignal : isOpenSignal.value;
    const newState = !currentState;

    if (typeof isOpenSignal !== "boolean") {
      isOpenSignal.value = newState;
    }

    if (onToggle) onToggle(newState);
  };

  const getCurrentState = () => {
    return typeof isOpenSignal === "boolean"
      ? isOpenSignal
      : isOpenSignal.value;
  };

  const getTriggerClasses = () => {
    if (variant === "link") {
      return cn(
        "inline-flex items-center gap-x-1",
        "text-sm font-semibold rounded-lg border border-transparent",
        "text-blue-600 decoration-2 hover:text-blue-700 hover:underline",
        "focus:outline-hidden focus:underline focus:text-blue-700",
        "disabled:opacity-50 disabled:pointer-events-none",
        "dark:text-blue-500 dark:hover:text-blue-600 dark:focus:text-blue-600",
        className,
      );
    }

    return cn(
      "py-3 px-4 inline-flex items-center gap-x-2",
      "text-sm font-medium rounded-lg border border-transparent",
      "bg-blue-600 text-white hover:bg-blue-700",
      "focus:outline-hidden focus:bg-blue-700",
      "disabled:opacity-50 disabled:pointer-events-none",
      className,
    );
  };

  return (
    <button
      type="button"
      id={triggerId}
      class={cn("hs-collapse-toggle", getTriggerClasses())}
      aria-expanded={getCurrentState() ? "true" : "false"}
      aria-controls={targetId}
      onClick={handleToggle}
    >
      {typeof children === "string" ? children : children}
      {showIcon && <ChevronDownIcon />}
    </button>
  );
};

/**
 * ReadMoreCollapse - Preset for read more/less pattern
 */
export const ReadMoreCollapse: Pulse.Fn<CollapseProps> = (
  props: CollapseProps,
): Pulse.JSX.Element => {
  return (
    <Collapse
      {...props}
      triggerVariant="link"
      openText={props.openText || "Read less"}
      closedText={props.closedText || "Read more"}
    />
  );
};

export default Collapse;
