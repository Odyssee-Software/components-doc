/**
 * StepItem Component
 * A single step item for the Stepper component
 *
 * @example
 * ```tsx
 * import { StepItem } from '@odyssee/components';
 *
 * // Basic step item
 * <StepItem
 *   index={1}
 *   label="Account Details"
 *   status="completed"
 * />
 *
 * // With description
 * <StepItem
 *   index={2}
 *   label="Payment"
 *   description="Enter your payment information"
 *   status="active"
 * />
 *
 * // With custom icon
 * <StepItem
 *   index={3}
 *   label="Confirmation"
 *   status="pending"
 *   icon={<CustomIcon />}
 * />
 *
 * // With avatar
 * <StepItem
 *   index={1}
 *   label="Step 1"
 *   status="pending"
 *   avatar="https://example.com/avatar.jpg"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { StepItemProps } from "../../types";
import { cn, generateId } from "../../utils";
import { StepIndicator } from "./StepIndicator";

export const StepItem: Pulse.Fn<StepItemProps> = (props) => {
  const {
    index,
    label,
    description,
    status,
    variant = "default",
    orientation = "horizontal",
    isLast = false,
    isClickable = false,
    icon,
    avatar,
    onClick,
    children,
    className,
    id = generateId("step-item"),
    style,
    ...rest
  } = props;

  // Handle click
  const handleClick = () => {
    if (isClickable && onClick) {
      onClick(index);
    }
  };

  // Base classes for the item
  const itemBaseClasses = cn(
    orientation === "horizontal"
      ? "flex items-center gap-x-2 shrink basis-0 flex-1 group"
      : "md:shrink md:basis-0 flex-1 group flex gap-x-2 md:block",
    isClickable && status !== "active" ? "cursor-pointer" : "",
    className,
  );

  // Connector line classes
  const connectorClasses = cn(
    "bg-gray-200 dark:bg-neutral-700 transition-colors duration-200",
    // Change color based on status
    status === "success" || status === "completed"
      ? "bg-blue-600 dark:bg-blue-600"
      : status === "error"
        ? "bg-red-200 dark:bg-red-800"
        : "",
    // Orientation-specific classes
    orientation === "horizontal"
      ? "w-full h-px flex-1 ms-2 group-last:hidden"
      : "mt-2 w-px h-full md:mt-0 md:ms-2 md:w-full md:h-px md:flex-1 group-last:hidden",
  );

  // Label classes based on status
  const labelClasses = cn(
    "text-sm font-medium transition-colors duration-200",
    status === "active"
      ? "text-gray-800 dark:text-white"
      : status === "completed" || status === "success"
        ? "text-gray-700 dark:text-neutral-300"
        : status === "error"
          ? "text-red-600 dark:text-red-400"
          : "text-gray-600 dark:text-neutral-400",
  );

  // Description classes
  const descriptionClasses = cn(
    "text-sm transition-colors duration-200",
    status === "error"
      ? "text-red-500 dark:text-red-400"
      : "text-gray-500 dark:text-neutral-500",
  );

  // Wrapper for indicator and connector (horizontal layout)
  const renderHorizontalLayout = () => (
    <div class="min-w-7 min-h-7 inline-flex items-center text-xs align-middle w-full">
      <StepIndicator
        index={index}
        status={status}
        variant={variant}
        icon={icon}
        avatar={avatar}
      />
      {!isLast && <div class={connectorClasses}></div>}
    </div>
  );

  // Wrapper for indicator and connector (vertical layout)
  const renderVerticalLayout = () => (
    <div class="min-w-7 min-h-7 flex flex-col items-center md:w-full md:inline-flex md:flex-wrap md:flex-row text-xs align-middle">
      <StepIndicator
        index={index}
        status={status}
        variant={variant}
        icon={icon}
        avatar={avatar}
      />
      {!isLast && <div class={connectorClasses}></div>}
    </div>
  );

  // Linear layout (label inline with indicator)
  if (orientation === "horizontal" && !description && !children) {
    return (
      <li
        id={id}
        class={itemBaseClasses}
        style={style}
        onClick={handleClick}
        {...rest}
      >
        <div class="min-w-7 min-h-7 inline-flex justify-center items-center text-xs align-middle">
          <StepIndicator
            index={index}
            status={status}
            variant={variant}
            icon={icon}
            avatar={avatar}
          />
          <span class={cn("ms-2", labelClasses)}>{label}</span>
        </div>
        {!isLast && <div class={connectorClasses}></div>}
      </li>
    ) as Pulse.JSX.Element;
  }

  // Standard layout (vertical stacking with description/content)
  if (orientation === "horizontal") {
    return (
      <li
        id={id}
        class={itemBaseClasses}
        style={style}
        onClick={handleClick}
        {...rest}
      >
        <div class="w-full">
          {renderHorizontalLayout()}
          <div class="mt-3">
            <span class={cn("block", labelClasses)}>{label}</span>
            {description && (
              <p class={cn("mt-1", descriptionClasses)}>{description}</p>
            )}
            {children && <div class="mt-2">{children}</div>}
          </div>
        </div>
      </li>
    ) as Pulse.JSX.Element;
  }

  // Vertical/responsive layout
  return (
    <li
      id={id}
      class={itemBaseClasses}
      style={style}
      onClick={handleClick}
      {...rest}
    >
      {renderVerticalLayout()}
      <div class="grow md:grow-0 md:mt-3 pb-5">
        <span class={cn("block", labelClasses)}>{label}</span>
        {description && (
          <p class={cn("mt-1", descriptionClasses)}>{description}</p>
        )}
        {children && <div class="mt-2">{children}</div>}
      </div>
    </li>
  ) as Pulse.JSX.Element;
};

export default StepItem;
