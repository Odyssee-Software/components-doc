/**
 * TabPanel Component
 * Helper component for flexible tabs content composition
 *
 * @example
 * ```tsx
 * import { Tabs, TabPanel } from '@odyssee/components';
 *
 * // Basic usage
 * <Tabs>
 *   <TabPanel id="tab1" label="Tab 1">
 *     <p>Content 1</p>
 *   </TabPanel>
 *   <TabPanel id="tab2" label="Tab 2">
 *     <p>Content 2</p>
 *   </TabPanel>
 * </Tabs>
 *
 * // With icons
 * <Tabs>
 *   <TabPanel id="home" label="Home" icon={<HomeIcon />}>
 *     <Home />
 *   </TabPanel>
 *   <TabPanel id="profile" label="Profile" icon={<UserIcon />}>
 *     <Profile />
 *   </TabPanel>
 * </Tabs>
 *
 * // With badges
 * <Tabs>
 *   <TabPanel id="inbox" label="Inbox" badge="5">
 *     <Inbox />
 *   </TabPanel>
 *   <TabPanel id="sent" label="Sent">
 *     <Sent />
 *   </TabPanel>
 * </Tabs>
 *
 * // Disabled tab
 * <Tabs>
 *   <TabPanel id="tab1" label="Active">
 *     <p>Active content</p>
 *   </TabPanel>
 *   <TabPanel id="tab2" label="Disabled" disabled>
 *     <p>This tab is disabled</p>
 *   </TabPanel>
 * </Tabs>
 * ```
 */

import Pulse from "pulse-framework";
import type { TabPanelProps } from "../../types";

/**
 * TabPanel Component
 *
 * Note: This component is meant to be used as a child of the Tabs component.
 * The Tabs component will handle rendering the tab buttons and panels.
 * This component is mainly for providing a structured way to define tabs content.
 */
export const TabPanel: Pulse.Fn<TabPanelProps> = (props) => {
  const { id, label, children, icon, disabled, badge, className, ...rest } = props;

  // This component doesn't render anything directly
  // It's used by the Tabs component to extract tab configuration
  // The actual rendering is done by the parent Tabs component

  return (
    <div
      id={id}
      data-tab-label={typeof label === "string" ? label : undefined}
      data-tab-disabled={disabled}
      data-tab-badge={badge}
      class={className}
      {...rest}
    >
      {children}
    </div>
  ) as Pulse.JSX.Element;
};
