/**
 * Pagination Component
 * A flexible pagination component with multiple variants, sizes, and features
 *
 * This component reuses:
 * - Button for page numbers and prev/next buttons
 * - Input for "Go to page" jumper
 * - Tooltip for ellipsis hints
 *
 * @example
 * ```tsx
 * import { Pagination } from '@odyssee/components';
 *
 * // Basic pagination
 * const currentPage = Pulse.signal(1);
 * <Pagination
 *   currentPage={currentPage}
 *   totalPages={10}
 *   onPageChange={(page) => currentPage(page)}
 * />
 *
 * // Bordered variant
 * <Pagination
 *   currentPage={1}
 *   totalPages={8}
 *   variant="bordered"
 *   onPageChange={(page) => console.log(page)}
 * />
 *
 * // Bordered group variant
 * <Pagination
 *   currentPage={1}
 *   totalPages={8}
 *   variant="bordered-group"
 *   showPrevNextText={true}
 * />
 *
 * // Mini variant
 * <Pagination
 *   currentPage={1}
 *   totalPages={3}
 *   mini={true}
 * />
 *
 * // Pilled shape (rounded-full)
 * <Pagination
 *   currentPage={1}
 *   totalPages={8}
 *   shape="pilled"
 * />
 *
 * // With jumper (go to page)
 * <Pagination
 *   currentPage={1}
 *   totalPages={8}
 *   showJumper={true}
 *   jumperText="Go to"
 * />
 *
 * // Center aligned
 * <Pagination
 *   currentPage={1}
 *   totalPages={8}
 *   alignment="center"
 * />
 *
 * // Stretched layout
 * <Pagination
 *   currentPage={1}
 *   totalPages={3}
 *   stretched={true}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { PaginationProps, PaginationSize } from "../../types";
import { cn, generateId, isSignal } from "../../utils";

export const Pagination: Pulse.Fn<PaginationProps> = (props) => {
  const {
    currentPage: currentPageProp,
    totalPages,
    variant = "default",
    shape = "default",
    size: sizeRaw = "md",
    alignment = "start",
    showPrevNext = true,
    showPrevNextText = false,
    prevText = "Previous",
    nextText = "Next",
    showEllipsis = true,
    siblingCount = 1,
    showBoundaries = true,
    mini = false,
    showJumper = false,
    jumperText = "Go to",
    showItemsPerPage = false,
    itemsPerPageOptions = [5, 8, 10],
    itemsPerPage = 5,
    stretched = false,
    disabled = false,
    onPageChange,
    onItemsPerPageChange,
    className,
    id = generateId("pagination"),
    style,
    ...rest
  } = props;

  // Ensure size is always a valid PaginationSize
  const size = sizeRaw as PaginationSize;

  // Get current page value
  const getCurrentPage = () =>
    isSignal(currentPageProp) ? (currentPageProp as any)() : currentPageProp;

  // Size classes for buttons
  const sizeClasses: Record<
    PaginationSize,
    { button: string; prevNext: string }
  > = {
    sm: {
      button: "min-h-8 min-w-8 py-1.5 px-2.5 text-sm",
      prevNext: "min-h-8 min-w-8 py-2 px-2",
    },
    md: {
      button: "min-h-9.5 min-w-9.5 py-2 px-3 text-sm",
      prevNext: "min-h-9.5 min-w-9.5 py-2 px-2.5",
    },
    lg: {
      button: "min-h-11.5 min-w-11.5 py-3 px-4 text-sm",
      prevNext: "min-h-11.5 min-w-11.5 p-3",
    },
  };

  // Shape classes
  const shapeClasses = {
    default: "rounded-lg",
    pilled: "rounded-full",
  };

  // Border classes for bordered-group
  const borderedGroupClasses =
    variant === "bordered-group" ? "first:rounded-s-lg last:rounded-e-lg" : "";
  const borderedGroupPilledClasses =
    variant === "bordered-group" && shape === "pilled"
      ? "first:rounded-s-full last:rounded-e-full"
      : "";

  // Generate page numbers to display
  const generatePageNumbers = () => {
    const current = getCurrentPage();
    const pages: (number | "ellipsis")[] = [];

    if (totalPages <= 7) {
      // Show all pages if total is 7 or less
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      // Always show first page
      if (showBoundaries) {
        pages.push(1);
      }

      // Calculate range around current page
      const leftSibling = Math.max(current - siblingCount, 2);
      const rightSibling = Math.min(current + siblingCount, totalPages - 1);

      // Add left ellipsis
      if (leftSibling > 2 && showEllipsis) {
        pages.push("ellipsis");
      } else if (leftSibling === 2) {
        pages.push(2);
      }

      // Add middle pages
      for (let i = leftSibling; i <= rightSibling; i++) {
        if (i > 1 && i < totalPages) {
          pages.push(i);
        }
      }

      // Add right ellipsis
      if (rightSibling < totalPages - 1 && showEllipsis) {
        pages.push("ellipsis");
      } else if (rightSibling === totalPages - 1) {
        pages.push(totalPages - 1);
      }

      // Always show last page
      if (showBoundaries) {
        pages.push(totalPages);
      }
    }

    return pages;
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    if (disabled || page < 1 || page > totalPages || page === getCurrentPage())
      return;
    if (onPageChange) {
      onPageChange(page);
    }
  };

  // Previous icon
  const PrevIcon = () => (
    <svg
      class="shrink-0 size-3.5"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m15 18-6-6 6-6" />
    </svg>
  );

  // Next icon
  const NextIcon = () => (
    <svg
      class="shrink-0 size-3.5"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  );

  // Render previous button
  const renderPrevButton = () => {
    if (!showPrevNext) return null;

    const isDisabled = getCurrentPage() === 1 || disabled;
    const borderClass =
      variant === "bordered" || variant === "bordered-group"
        ? "border border-gray-200 dark:border-neutral-700"
        : "border-transparent";

    return (
      <button
        type="button"
        class={cn(
          sizeClasses[size].prevNext,
          "inline-flex justify-center items-center gap-x-1.5",
          variant === "bordered-group"
            ? shape === "pilled"
              ? "first:rounded-s-full"
              : "first:rounded-s-lg"
            : shapeClasses[shape],
          borderClass,
          "text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100",
          "disabled:opacity-50 disabled:pointer-events-none",
          "dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/10",
        )}
        aria-label="Previous"
        disabled={isDisabled}
        onClick={() => handlePageChange(getCurrentPage() - 1)}
      >
        <PrevIcon />
        {showPrevNextText && (
          <span class={cn("hidden sm:block")}>{prevText}</span>
        )}
        <span class="sr-only">Previous</span>
      </button>
    );
  };

  // Render next button
  const renderNextButton = () => {
    if (!showPrevNext) return null;

    const isDisabled = getCurrentPage() === totalPages || disabled;
    const borderClass =
      variant === "bordered" || variant === "bordered-group"
        ? "border border-gray-200 dark:border-neutral-700"
        : "border-transparent";

    return (
      <button
        type="button"
        class={cn(
          sizeClasses[size].prevNext,
          "inline-flex justify-center items-center gap-x-1.5",
          variant === "bordered-group"
            ? shape === "pilled"
              ? "last:rounded-e-full"
              : "last:rounded-e-lg"
            : shapeClasses[shape],
          borderClass,
          "text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100",
          "disabled:opacity-50 disabled:pointer-events-none",
          "dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/10",
        )}
        aria-label="Next"
        disabled={isDisabled}
        onClick={() => handlePageChange(getCurrentPage() + 1)}
      >
        {showPrevNextText && (
          <span class={cn("hidden sm:block")}>{nextText}</span>
        )}
        <NextIcon />
        <span class="sr-only">Next</span>
      </button>
    );
  };

  // Render page button
  const renderPageButton = (page: number) => {
    const isCurrent = page === getCurrentPage();
    const borderClass =
      variant === "bordered" || variant === "bordered-group"
        ? isCurrent
          ? "border border-gray-200 dark:border-neutral-700"
          : "border border-transparent"
        : "";

    const activeClass = isCurrent
      ? variant === "default"
        ? "bg-gray-200 text-gray-800 focus:bg-gray-300 dark:bg-neutral-600 dark:text-white dark:focus:bg-neutral-500"
        : "focus:bg-gray-50 dark:bg-white/10 dark:focus:bg-white/10"
      : "text-gray-800 hover:bg-gray-100 focus:bg-gray-100 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/10";

    return (
      <button
        type="button"
        class={cn(
          sizeClasses[size].button,
          "flex justify-center items-center",
          variant === "bordered-group"
            ? shape === "pilled"
              ? borderedGroupPilledClasses
              : borderedGroupClasses
            : shapeClasses[shape],
          borderClass,
          activeClass,
          "focus:outline-hidden disabled:opacity-50 disabled:pointer-events-none",
        )}
        aria-current={isCurrent ? "page" : undefined}
        disabled={disabled}
        onClick={() => handlePageChange(page)}
        key={`page-${page}`}
      >
        {page}
      </button>
    );
  };

  // Render ellipsis with tooltip
  const renderEllipsis = (key: string) => {
    const EllipsisButton = () => (
      <button
        type="button"
        class={cn(
          sizeClasses[size].button,
          "group flex justify-center items-center",
          "text-gray-400 hover:text-blue-600 p-2",
          variant === "bordered-group"
            ? "border border-gray-200 dark:border-neutral-700"
            : "",
          shapeClasses[shape],
          "focus:outline-hidden focus:bg-gray-100",
          "disabled:opacity-50 disabled:pointer-events-none",
          "dark:text-neutral-500 dark:hover:text-blue-500 dark:focus:bg-white/10",
        )}
      >
        <span class="group-hover:hidden text-xs">•••</span>
        <svg
          class="group-hover:block hidden shrink-0 size-5"
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="m6 17 5-5-5-5" />
          <path d="m13 17 5-5-5-5" />
        </svg>
      </button>
    );

    return (
      <div class="hs-tooltip inline-block" key={key}>
        <EllipsisButton />
        <span
          class="hs-tooltip-content hs-tooltip-shown:opacity-100 hs-tooltip-shown:visible opacity-0 transition-opacity inline-block absolute invisible z-10 py-1 px-2 bg-gray-900 text-xs font-medium text-white rounded-md shadow-2xs dark:bg-neutral-700"
          role="tooltip"
        >
          Next 4 pages
        </span>
      </div>
    );
  };

  // Render mini variant
  const renderMini = () => {
    const borderClass =
      variant === "bordered" || variant === "bordered-group"
        ? "border border-gray-200 dark:border-neutral-700"
        : "";

    return (
      <nav
        class={cn("flex items-center gap-x-1", className)}
        aria-label="Pagination"
        id={id}
        style={style}
        {...rest}
      >
        {renderPrevButton()}
        <div class="flex items-center gap-x-1">
          <span
            class={cn(
              sizeClasses[size].button,
              "flex justify-center items-center",
              borderClass,
              shapeClasses[shape],
              "text-gray-800 focus:outline-hidden focus:bg-gray-50",
              "disabled:opacity-50 disabled:pointer-events-none",
              "dark:text-white dark:focus:bg-white/10",
            )}
          >
            {getCurrentPage()}
          </span>
          <span
            class={cn(
              sizeClasses[size].button.includes("py-1")
                ? "py-1.5"
                : sizeClasses[size].button.includes("py-2")
                  ? "py-2"
                  : "py-3",
              "flex justify-center items-center px-1.5 text-sm",
              "text-gray-500 dark:text-neutral-500",
            )}
          >
            of
          </span>
          <span
            class={cn(
              sizeClasses[size].button.includes("py-1")
                ? "py-1.5"
                : sizeClasses[size].button.includes("py-2")
                  ? "py-2"
                  : "py-3",
              "flex justify-center items-center px-1.5 text-sm",
              "text-gray-500 dark:text-neutral-500",
            )}
          >
            {totalPages}
          </span>
        </div>
        {renderNextButton()}
      </nav>
    );
  };

  // Render jumper
  const renderJumper = () => {
    if (!showJumper) return null;

    return (
      <div class="flex items-center gap-x-2">
        <span class="text-sm text-gray-800 whitespace-nowrap dark:text-white">
          {jumperText}
        </span>
        <input
          type="number"
          class={cn(
            size === "sm"
              ? "min-h-8 py-1"
              : size === "md"
                ? "min-h-9.5 py-2"
                : "min-h-11.5 p-3",
            "px-2.5 block w-12 border-gray-200 rounded-lg text-sm text-center",
            "focus:border-blue-500 focus:ring-blue-500",
            "[&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none",
            "disabled:opacity-50 disabled:pointer-events-none",
            "dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-400",
            "dark:placeholder-neutral-500 dark:focus:ring-neutral-600",
          )}
          min="1"
          max={totalPages}
          disabled={disabled}
          onKeyDown={(e: KeyboardEvent) => {
            if (e.key === "Enter") {
              const target = e.target as HTMLInputElement;
              const page = parseInt(target.value, 10);
              if (page >= 1 && page <= totalPages) {
                handlePageChange(page);
                target.value = "";
              }
            }
          }}
        />
        <span class="text-sm text-gray-800 whitespace-nowrap dark:text-white">
          page
        </span>
      </div>
    );
  };

  // Mini variant
  if (mini) {
    return renderMini() as Pulse.JSX.Element;
  }

  // Regular pagination
  const pages = generatePageNumbers();
  const navClasses = cn(
    "flex items-center",
    variant === "bordered-group" ? "-space-x-px" : "gap-x-1",
    className,
  );

  const wrapperClasses = cn(
    "grid justify-center sm:flex sm:justify-start sm:items-center gap-2",
    alignment === "center" && "sm:justify-center",
    alignment === "end" && "sm:justify-end",
    stretched && "sm:justify-between",
  );

  return (
    <div class={wrapperClasses} id={id} style={style} {...rest}>
      <nav class={navClasses} aria-label="Pagination">
        {renderPrevButton()}
        <div
          class={cn(
            "flex items-center",
            variant === "bordered-group" ? "" : "gap-x-1",
          )}
        >
          {pages.map((page, index) =>
            page === "ellipsis"
              ? renderEllipsis(`ellipsis-${index}`)
              : renderPageButton(page),
          )}
        </div>
        {renderNextButton()}
      </nav>

      {showJumper && renderJumper()}
    </div>
  ) as Pulse.JSX.Element;
};

export default Pagination;
