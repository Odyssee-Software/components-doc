/**
 * Navbar Component
 * A responsive navigation bar component with collapsible mobile menu, brand, and dropdown support
 *
 * This component reuses:
 * - Link (NavLink) for navigation links
 * - Container for max-width wrapper
 * - Button for mobile toggle
 * - Badge for item badges
 * - Dropdown for sub-menus
 *
 * @example
 * ```tsx
 * import { Navbar } from '@odyssee/components';
 *
 * // Basic navbar with items array
 * <Navbar
 *   brand="Brand"
 *   items={[
 *     { label: 'Landing', href: '#', active: true },
 *     { label: 'Account', href: '#' },
 *     { label: 'Work', href: '#' },
 *     { label: 'Blog', href: '#' }
 *   ]}
 * />
 *
 * // Navbar with brand object (logo + text)
 * <Navbar
 *   brand={{
 *     content: 'Brand',
 *     logo: <img src="/logo.png" alt="Logo" />,
 *     href: '/'
 *   }}
 *   items={[...]}
 * />
 *
 * // Navbar with dropdown
 * <Navbar
 *   brand="Brand"
 *   items={[
 *     { label: 'Landing', href: '#', active: true },
 *     { label: 'Account', href: '#' },
 *     {
 *       label: 'Dropdown',
 *       dropdown: [
 *         { label: 'About', href: '#' },
 *         { label: 'Downloads', href: '#' },
 *         { label: 'Team Account', href: '#' }
 *       ]
 *     }
 *   ]}
 * />
 *
 * // Dark variant navbar
 * <Navbar
 *   brand="Brand"
 *   variant="dark"
 *   items={[...]}
 * />
 *
 * // Centered navbar with custom children
 * <Navbar
 *   brand="Brand"
 *   alignment="center"
 *   items={[...]}
 * >
 *   <Button size="sm">Sign In</Button>
 * </Navbar>
 *
 * // Sticky navbar
 * <Navbar
 *   brand="Brand"
 *   items={[...]}
 *   sticky={true}
 * />
 *
 * // With horizontal scroll on mobile
 * <Navbar
 *   brand="Brand"
 *   items={[...]}
 *   horizontalScroll={true}
 * />
 *
 * // Composable children approach
 * <Navbar brand="Brand">
 *   <NavbarLink href="#" active>Landing</NavbarLink>
 *   <NavbarLink href="#">Account</NavbarLink>
 *   <NavbarLink href="#">Work</NavbarLink>
 *   <NavbarLink href="#">Blog</NavbarLink>
 * </Navbar>
 * ```
 */

import Pulse from "pulse-framework";
import type { NavbarProps, NavbarItem, NavbarLinkProps } from "../../types";
import { cn, generateId } from "../../utils";
import { Badge } from "../base/Badge";

export const Navbar: Pulse.Fn<NavbarProps> = (props) => {
  const {
    brand,
    items = [],
    children,
    variant = "default",
    alignment = "right",
    collapsible = true,
    collapseBreakpoint = "sm",
    horizontalScroll = false,
    sticky = false,
    stickyOffset = "0",
    maxWidth = "max-w-[85rem]",
    centered = true,
    padding = "md",
    navClassName,
    containerClassName,
    brandClassName,
    itemsClassName,
    toggleClassName,
    onBrandClick,
    onItemClick,
    onToggle,
    className,
    id = generateId("navbar"),
    style,
    ...rest
  } = props;

  // Generate unique IDs for collapse functionality
  const collapseId = `${id}-collapse`;
  const collapseTriggerId = `${id}-collapse-trigger`;

  // Padding classes
  const paddingClasses = {
    sm: "py-2",
    md: "py-3",
    lg: "py-4",
  };

  // Variant classes for header
  const variantClasses = {
    default: "bg-white dark:bg-neutral-800",
    dark: "bg-gray-800 dark:bg-white",
    primary: "bg-blue-600",
    transparent: "bg-transparent",
  };

  // Text color classes based on variant
  const brandTextClasses = {
    default: "text-black dark:text-white",
    dark: "text-white dark:text-neutral-800",
    primary: "text-white",
    transparent: "text-black dark:text-white",
  };

  const linkActiveClasses = {
    default: "text-blue-500 dark:text-blue-500",
    dark: "text-white dark:text-black",
    primary: "text-white",
    transparent: "text-blue-500 dark:text-blue-500",
  };

  const linkNormalClasses = {
    default:
      "text-gray-600 hover:text-gray-400 focus:outline-hidden focus:text-gray-400 dark:text-neutral-400 dark:hover:text-neutral-500 dark:focus:text-neutral-500",
    dark: "text-gray-400 hover:text-gray-500 focus:outline-hidden focus:text-gray-500 dark:text-neutral-500 dark:hover:text-neutral-400 dark:focus:text-neutral-400",
    primary:
      "text-gray-300 hover:text-white focus:outline-hidden focus:text-white",
    transparent:
      "text-gray-600 hover:text-gray-400 focus:outline-hidden focus:text-gray-400 dark:text-neutral-400 dark:hover:text-neutral-500 dark:focus:text-neutral-500",
  };

  // Breakpoint classes for collapse display
  const collapseBreakpointClasses = {
    sm: "sm:hidden",
    md: "md:hidden",
    lg: "lg:hidden",
    xl: "xl:hidden",
  };

  const showBreakpointClasses = {
    sm: "sm:block",
    md: "md:block",
    lg: "lg:block",
    xl: "xl:block",
  };

  const flexBreakpointClasses = {
    sm: "sm:flex",
    md: "md:flex",
    lg: "lg:flex",
    xl: "xl:flex",
  };

  // Render brand
  const renderBrand = () => {
    const brandContent = typeof brand === "string" ? { content: brand } : brand;
    if (!brandContent) return null;

    const {
      content,
      href = "#",
      logo,
      logoAlt = "Logo",
      onClick,
    } = brandContent;

    const handleBrandClick = (e: Event) => {
      if (onClick) onClick(e);
      if (onBrandClick) onBrandClick(e);
    };

    const brandElement = logo ? (
      <span class="inline-flex items-center gap-x-2 text-xl font-semibold">
        {typeof logo === "string" ? (
          <img class="w-10 h-auto" src={logo} alt={logoAlt} />
        ) : (
          logo
        )}
        {content}
      </span>
    ) : (
      content
    );

    return (
      <a
        class={cn(
          "flex-none text-xl font-semibold focus:outline-hidden focus:opacity-80",
          brandTextClasses[variant],
          brandClassName,
        )}
        href={href}
        aria-label="Brand"
        onClick={handleBrandClick}
      >
        {brandElement}
      </a>
    );
  };

  // Render toggle button (hamburger menu) - USING Button component
  const renderToggle = () => {
    if (!collapsible) return null;

    const hamburgerIcon = (
      <svg
        class="hs-collapse-open:hidden shrink-0 size-4"
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <line x1="3" x2="21" y1="6" y2="6" />
        <line x1="3" x2="21" y1="12" y2="12" />
        <line x1="3" x2="21" y1="18" y2="18" />
      </svg>
    );

    const closeIcon = (
      <svg
        class="hs-collapse-open:block hidden shrink-0 size-4"
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="M18 6 6 18" />
        <path d="m6 6 12 12" />
      </svg>
    );

    // Custom button styling to match Preline toggle
    const toggleButtonClass = cn(
      "hs-collapse-toggle relative size-9 flex justify-center items-center gap-x-2 rounded-lg border shadow-2xs focus:outline-hidden disabled:opacity-50 disabled:pointer-events-none",
      variant === "default" &&
        "border-gray-200 bg-white text-gray-800 hover:bg-gray-50 focus:bg-gray-50 dark:bg-transparent dark:border-neutral-700 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/10",
      variant === "dark" &&
        "border-gray-700 bg-gray-800 text-gray-400 hover:bg-gray-700/20 focus:bg-gray-700/20 dark:bg-white dark:hover:bg-gray-100 dark:border-gray-200 dark:text-gray-600 dark:focus:bg-gray-100",
      variant === "primary" &&
        "border-white/20 bg-blue-600 text-white hover:bg-white/10 focus:bg-white/10",
      variant === "transparent" &&
        "border-gray-200 bg-white text-gray-800 hover:bg-gray-50 focus:bg-gray-50 dark:bg-transparent dark:border-neutral-700 dark:text-white dark:hover:bg-white/10 dark:focus:bg-white/10",
      toggleClassName,
    );

    return (
      <div class={collapseBreakpointClasses[collapseBreakpoint]}>
        <button
          type="button"
          class={toggleButtonClass}
          id={collapseTriggerId}
          aria-expanded="false"
          aria-controls={collapseId}
          aria-label="Toggle navigation"
          data-hs-collapse={`#${collapseId}`}
        >
          {hamburgerIcon}
          {closeIcon}
          <span class="sr-only">Toggle navigation</span>
        </button>
      </div>
    );
  };

  // Render navigation item
  const renderItem = (item: NavbarItem, index: number) => {
    const handleClick = (e: Event) => {
      if (item.onClick) item.onClick(e);
      if (onItemClick) onItemClick(item, index);
    };

    // If item has dropdown
    if (item.dropdown && item.dropdown.length > 0) {
      return (
        <div
          class="hs-dropdown [--strategy:static] sm:[--strategy:fixed] [--adaptive:none] sm:[--adaptive:adaptive]"
          key={item.id || `nav-item-${index}`}
        >
          <button
            id={`${id}-dropdown-${index}`}
            type="button"
            class={cn(
              "hs-dropdown-toggle flex items-center w-full font-medium focus:outline-hidden",
              item.active
                ? linkActiveClasses[variant]
                : linkNormalClasses[variant],
            )}
            aria-haspopup="menu"
            aria-expanded="false"
            aria-label="Dropdown"
          >
            {item.icon && <span class="mr-1.5">{item.icon}</span>}
            {item.label}
            <svg
              class="hs-dropdown-open:-rotate-180 sm:hs-dropdown-open:rotate-0 duration-300 ms-1 shrink-0 size-4"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="m6 9 6 6 6-6" />
            </svg>
          </button>

          <div
            class="hs-dropdown-menu transition-[opacity,margin] ease-in-out duration-[150ms] hs-dropdown-open:opacity-100 opacity-0 sm:w-48 z-10 bg-white sm:shadow-md rounded-lg p-1 space-y-1 dark:bg-neutral-800 sm:dark:border dark:border-neutral-700 dark:divide-neutral-700 before:absolute top-full sm:border border-gray-200 before:-top-5 before:start-0 before:w-full before:h-5 hidden"
            role="menu"
            aria-orientation="vertical"
            aria-labelledby={`${id}-dropdown-${index}`}
          >
            {item.dropdown.map((dropdownItem, dropdownIndex) => (
              <a
                class="flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-700 dark:hover:text-neutral-300 dark:focus:bg-neutral-700 dark:focus:text-neutral-300"
                href={dropdownItem.href || "#"}
                key={`dropdown-item-${dropdownIndex}`}
              >
                {dropdownItem.label}
              </a>
            ))}
          </div>
        </div>
      );
    }

    // Regular link - USING custom styled anchor (NavLink pattern)
    return (
      <a
        class={cn(
          "font-medium focus:outline-hidden",
          item.active ? linkActiveClasses[variant] : linkNormalClasses[variant],
          item.disabled && "opacity-50 pointer-events-none",
        )}
        href={item.href || "#"}
        aria-current={item.active ? "page" : undefined}
        onClick={handleClick}
        key={item.id || `nav-item-${index}`}
      >
        {item.icon && (
          <span class="mr-1.5 inline-flex items-center">{item.icon}</span>
        )}
        {item.label}
        {item.badge && (
          <Badge size="xs" variant="soft" color="primary" className="ml-2">
            {String(item.badge)}
          </Badge>
        )}
      </a>
    );
  };

  // Render navigation items
  const renderItems = () => {
    if (items.length === 0 && !children) return null;

    const itemsWrapperClasses = cn(
      "flex gap-5",
      alignment === "center"
        ? "flex-col mt-5 sm:flex-row sm:items-center sm:mt-0 sm:ps-5"
        : alignment === "left"
          ? "flex-col mt-5 sm:flex-row sm:items-center sm:mt-0 sm:ps-5"
          : "flex-col mt-5 sm:flex-row sm:items-center sm:justify-end sm:mt-0 sm:ps-5",
      horizontalScroll &&
        !collapsible &&
        "flex-row items-center pb-2 overflow-x-auto sm:pb-0 sm:overflow-x-visible [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:bg-gray-100 [&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-track]:bg-neutral-700 dark:[&::-webkit-scrollbar-thumb]:bg-neutral-500",
      itemsClassName,
    );

    return (
      <div class={itemsWrapperClasses}>
        {items.map((item, index) => renderItem(item, index))}
        {children}
      </div>
    );
  };

  // Header classes
  const headerClasses = cn(
    "flex flex-wrap sm:justify-start sm:flex-nowrap w-full text-sm",
    paddingClasses[padding],
    variantClasses[variant],
    sticky && "sticky z-50",
    className,
  );

  // Nav classes - USING Container pattern concept
  const navClasses = cn(
    maxWidth,
    "w-full px-4",
    centered && "mx-auto",
    flexBreakpointClasses[collapseBreakpoint],
    `${collapseBreakpoint}:items-center ${collapseBreakpoint}:justify-between`,
    navClassName,
  );

  // If not collapsible, render simple navbar
  if (!collapsible) {
    return (
      <header
        id={id}
        class={headerClasses}
        style={{
          ...(typeof style === "object" ? style : {}),
          ...(sticky ? { top: stickyOffset } : {}),
        }}
        {...rest}
      >
        <nav class={navClasses}>
          {renderBrand()}
          {renderItems()}
        </nav>
      </header>
    ) as Pulse.JSX.Element;
  }

  // Collapsible navbar
  return (
    <header
      id={id}
      class={cn(headerClasses, "relative")}
      style={{
        ...(typeof style === "object" ? style : {}),
        ...(sticky ? { top: stickyOffset } : {}),
      }}
      {...rest}
    >
      <nav class={navClasses}>
        <div class="flex items-center justify-between">
          {renderBrand()}
          {renderToggle()}
        </div>
        <div
          id={collapseId}
          class={cn(
            "hs-collapse hidden overflow-hidden transition-all duration-300 basis-full grow",
            showBreakpointClasses[collapseBreakpoint],
          )}
          aria-labelledby={collapseTriggerId}
        >
          {renderItems()}
        </div>
      </nav>
    </header>
  ) as Pulse.JSX.Element;
};

/**
 * NavbarLink - Composable link component for navbar children
 * Reuses the Link component concept but with navbar-specific styling
 */
export const NavbarLink: Pulse.Fn<NavbarLinkProps> = (props) => {
  const {
    href = "#",
    active = false,
    disabled = false,
    onClick,
    children,
    className,
  } = props;

  return (
    <a
      class={cn(
        "font-medium focus:outline-hidden",
        active
          ? "text-blue-500 dark:text-blue-500"
          : "text-gray-600 hover:text-gray-400 focus:text-gray-400 dark:text-neutral-400 dark:hover:text-neutral-500 dark:focus:text-neutral-500",
        disabled && "opacity-50 pointer-events-none",
        className,
      )}
      href={href}
      aria-current={active ? "page" : undefined}
      onClick={onClick}
    >
      {children}
    </a>
  ) as Pulse.JSX.Element;
};

/**
 * DarkNavbar - Pre-configured dark variant
 */
export const DarkNavbar: Pulse.Fn<NavbarProps> = (props) => {
  return <Navbar {...props} variant="dark" />;
};

/**
 * PrimaryNavbar - Pre-configured primary variant
 */
export const PrimaryNavbar: Pulse.Fn<NavbarProps> = (props) => {
  return <Navbar {...props} variant="primary" />;
};

/**
 * StickyNavbar - Pre-configured sticky navbar
 */
export const StickyNavbar: Pulse.Fn<NavbarProps> = (props) => {
  return <Navbar {...props} sticky={true} />;
};

export default Navbar;
