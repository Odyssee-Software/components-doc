/**
 * StepIndicator Component
 * A visual indicator for stepper steps with multiple states
 *
 * @example
 * ```tsx
 * import { StepIndicator } from '@odyssee/components';
 *
 * // Basic step indicator
 * <StepIndicator index={1} status="pending" />
 *
 * // Active step
 * <StepIndicator index={2} status="active" />
 *
 * // Completed step
 * <StepIndicator index={1} status="completed" />
 *
 * // Error step
 * <StepIndicator index={2} status="error" />
 *
 * // Processing step
 * <StepIndicator index={3} status="processed" />
 *
 * // With custom icon
 * <StepIndicator index={1} status="pending" icon={<CustomIcon />} />
 *
 * // With avatar
 * <StepIndicator index={1} status="pending" avatar="https://example.com/avatar.jpg" />
 * ```
 */

import Pulse from "pulse-framework";
import type { StepIndicatorProps } from "../../types";
import { cn, generateId } from "../../utils";
import { Spinner } from "../base/Spinner";

export const StepIndicator: Pulse.Fn<StepIndicatorProps> = (props) => {
  const {
    index,
    status,
    variant = "default",
    icon,
    avatar,
    showCheckmark = true,
    showError = true,
    showSpinner = true,
    className,
    id = generateId("step-indicator"),
    style,
    ...rest
  } = props;

  // Base classes
  const baseClasses =
    "size-7 flex justify-center items-center shrink-0 font-medium rounded-full transition-all duration-200";

  // Variant color classes based on status
  const variantColorClasses = {
    default: {
      pending: "bg-gray-100 text-gray-800 dark:bg-neutral-700 dark:text-white",
      active:
        "bg-blue-600 text-white dark:bg-blue-500 ring-2 ring-blue-200 dark:ring-blue-800",
      success: "bg-blue-600 text-white dark:bg-blue-500",
      completed: "bg-teal-500 text-white dark:bg-teal-500",
      error: "bg-red-500 text-white dark:bg-red-500",
      processed:
        "bg-white text-blue-600 border border-gray-200 dark:bg-neutral-800 dark:border-neutral-700 dark:text-blue-500",
    },
    white: {
      pending:
        "bg-white border border-gray-200 text-gray-800 dark:bg-neutral-900 dark:border-neutral-700 dark:text-white",
      active:
        "bg-blue-600 text-white border border-blue-600 dark:bg-blue-500 dark:border-blue-500 ring-2 ring-blue-200 dark:ring-blue-800",
      success:
        "bg-blue-600 text-white border border-blue-600 dark:bg-blue-500 dark:border-blue-500",
      completed:
        "bg-teal-500 text-white border border-teal-500 dark:bg-teal-500 dark:border-teal-500",
      error:
        "bg-red-500 text-white border border-red-500 dark:bg-red-500 dark:border-red-500",
      processed:
        "bg-white text-blue-600 border border-gray-200 dark:bg-neutral-900 dark:border-neutral-700 dark:text-blue-500",
    },
    solid: {
      pending:
        "bg-gray-800 text-white dark:bg-white dark:text-neutral-800 font-semibold",
      active:
        "bg-blue-600 text-white dark:bg-blue-500 ring-2 ring-blue-200 dark:ring-blue-800 font-semibold",
      success: "bg-blue-600 text-white dark:bg-blue-500 font-semibold",
      completed: "bg-teal-500 text-white dark:bg-teal-500 font-semibold",
      error: "bg-red-500 text-white dark:bg-red-500 font-semibold",
      processed:
        "bg-gray-800 text-white border border-gray-700 dark:bg-white dark:text-neutral-800 dark:border-gray-300 font-semibold",
    },
  };

  // Checkmark icon (for success/completed)
  const CheckmarkIcon = () => (
    <svg
      class="shrink-0 size-3"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="3"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );

  // Error icon (X mark)
  const ErrorIcon = () => (
    <svg
      class="shrink-0 size-3"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="3"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  );

  // Determine what to render inside the indicator
  const renderContent = () => {
    // Show avatar if provided
    if (avatar) {
      return (
        <img
          src={avatar}
          alt={`Step ${index}`}
          class="shrink-0 size-7 rounded-full object-cover"
        />
      );
    }

    // Show custom icon if provided (overrides default state icons)
    if (icon) {
      return icon;
    }

    // Show spinner for processed state
    if (status === "processed" && showSpinner) {
      return <Spinner size="sm" color="primary" />;
    }

    // Show checkmark for success/completed
    if ((status === "success" || status === "completed") && showCheckmark) {
      return <CheckmarkIcon />;
    }

    // Show error icon
    if (status === "error" && showError) {
      return <ErrorIcon />;
    }

    // Default: show index number
    return <span class="text-sm">{index}</span>;
  };

  // If avatar, render as image only (no background circle)
  if (avatar) {
    return (
      <span
        id={id}
        class={cn("shrink-0", className)}
        style={style}
        {...rest}
      >
        <img
          src={avatar}
          alt={`Step ${index}`}
          class="size-7 rounded-full object-cover"
        />
      </span>
    ) as Pulse.JSX.Element;
  }

  return (
    <span
      id={id}
      class={cn(baseClasses, variantColorClasses[variant][status], className)}
      style={style}
      {...rest}
    >
      {renderContent()}
    </span>
  ) as Pulse.JSX.Element;
};

export default StepIndicator;
