/**
 * TreeView Component
 * A hierarchical tree structure with expand/collapse, selection, and optional checkboxes
 *
 * Features:
 * - Recursive tree structure (folders/files)
 * - Expand/collapse using Accordion
 * - Single and multi-selection (Shift/Ctrl support)
 * - Optional checkboxes
 * - Keyboard navigation
 * - Accessibility (role="tree", aria-expanded, etc.)
 *
 * @example
 * ```tsx
 * import { TreeView } from '@odyssee/components';
 *
 * const nodes = [
 *   {
 *     value: 'folder1',
 *     label: 'Documents',
 *     isDir: true,
 *     children: [
 *       { value: 'file1', label: 'Report.pdf', isDir: false },
 *       { value: 'file2', label: 'Invoice.docx', isDir: false }
 *     ]
 *   },
 *   { value: 'file3', label: 'Notes.txt', isDir: false }
 * ];
 *
 * // Basic tree
 * <TreeView nodes={nodes} />
 *
 * // With selection
 * <TreeView nodes={nodes} selectable selected={selectedSignal} onSelect={handleSelect} />
 *
 * // With checkboxes
 * <TreeView nodes={nodes} showCheckboxes checked={checkedSignal} onCheck={handleCheck} />
 *
 * // Multi-select (Shift/Ctrl)
 * <TreeView nodes={nodes} selectable multiSelect selected={selectedSignal} />
 * ```
 */

import Pulse from "pulse-framework";
import { cn, generateId, isSignal } from "../../utils";
import type { TreeViewProps, TreeViewNode } from "../../types";
import { Checkbox } from "../forms/Checkbox";

/**
 * Default folder icon (closed)
 */
const FolderIcon: Pulse.Fn = () =>
  (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * Default folder icon (open)
 */
const FolderOpenIcon: Pulse.Fn = () =>
  (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * Default file icon
 */
const FileIcon: Pulse.Fn = () =>
  (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * Chevron Right Icon (collapsed)
 */
const ChevronRightIcon: Pulse.Fn = () =>
  (
    <svg
      class="hs-accordion-active:hidden block size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m9 18 6-6-6-6" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * Chevron Down Icon (expanded)
 */
const ChevronDownIcon: Pulse.Fn = () =>
  (
    <svg
      class="hs-accordion-active:block hidden size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m6 9 6 6 6-6" />
    </svg>
  ) as Pulse.JSX.Element;

/**
 * TreeNode internal component (recursive)
 */
interface TreeNodeProps {
  node: TreeViewNode;
  level: number;
  treeId: string;
  selectable?: boolean;
  multiSelect?: boolean;
  showCheckboxes?: boolean;
  showLines?: boolean;
  iconPosition?: "left" | "right";
  selected: string[];
  expanded: string[];
  checked: string[];
  onToggleExpand: (value: string) => void;
  onSelectNode: (value: string, event: MouseEvent) => void;
  onCheckNode: (value: string, isChecked: boolean) => void;
}

const TreeNode: Pulse.Fn<TreeNodeProps> = (props) => {
  const {
    node,
    level,
    treeId,
    selectable,
    multiSelect,
    showCheckboxes,
    showLines,
    iconPosition = "left",
    selected,
    expanded,
    checked,
    onToggleExpand,
    onSelectNode,
    onCheckNode,
  } = props;

  const nodeId = `${treeId}-node-${node.value}`;
  const collapseId = `${nodeId}-collapse`;
  const hasChildren = node.children && node.children.length > 0;
  const isExpanded = expanded.includes(node.value);
  const isSelected = selected.includes(node.value);
  const isChecked = checked.includes(node.value);
  const isDir = node.isDir ?? hasChildren;

  // Node item classes
  const nodeItemClasses = cn(
    "flex items-center gap-x-2 py-2 px-3 text-sm rounded-lg",
    "hover:bg-gray-100 dark:hover:bg-neutral-700",
    "focus:outline-none focus:bg-gray-100 dark:focus:bg-neutral-700",
    isSelected && "bg-gray-100 dark:bg-neutral-700 font-medium",
    node.disabled && "opacity-50 pointer-events-none",
    selectable && !node.disabled && "cursor-pointer",
  );

  // Render node icon
  const renderIcon = () => {
    // Custom icon
    if (node.icon) {
      if (typeof node.icon === "string") {
        return <span class="shrink-0">{node.icon}</span>;
      }
      return <span class="shrink-0">{node.icon}</span>;
    }

    // Default icons
    if (isDir) {
      return (
        <span class="shrink-0 text-gray-500 dark:text-neutral-500">
          {isExpanded ? <FolderOpenIcon /> : <FolderIcon />}
        </span>
      );
    }

    return (
      <span class="shrink-0 text-gray-500 dark:text-neutral-500">
        <FileIcon />
      </span>
    );
  };

  // Handle node click (selection)
  const handleNodeClick = (e: MouseEvent) => {
    if (node.disabled) return;

    if (selectable && !showCheckboxes) {
      onSelectNode(node.value, e);
    }
  };

  // Handle checkbox change
  const handleCheckboxChange = (isChecked: boolean) => {
    if (!node.disabled) {
      onCheckNode(node.value, isChecked);
    }
  };

  // Handle expand/collapse toggle
  const handleToggleExpand = (e: MouseEvent) => {
    e.stopPropagation();
    if (hasChildren && !node.disabled) {
      onToggleExpand(node.value);
    }
  };

  // Render node content
  const renderNodeContent = () => (
    <div
      class={nodeItemClasses}
      onClick={handleNodeClick}
      role="treeitem"
      aria-selected={selectable ? isSelected : undefined}
      aria-expanded={hasChildren ? isExpanded : undefined}
      aria-disabled={node.disabled}
      tabindex={node.disabled ? -1 : 0}
    >
      {/* Expand/collapse button (for folders with children) */}
      {hasChildren && (
        <button
          type="button"
          class="shrink-0 size-4 flex items-center justify-center hover:bg-gray-200 dark:hover:bg-neutral-600 rounded"
          onClick={handleToggleExpand}
          aria-label={isExpanded ? "Collapse" : "Expand"}
        >
          <ChevronRightIcon />
          <ChevronDownIcon />
        </button>
      )}

      {/* Spacer for files (no expand button) */}
      {!hasChildren && <span class="size-4 shrink-0"></span>}

      {/* Checkbox (optional) */}
      {showCheckboxes && (
        <Checkbox
          checked={isChecked}
          onChange={handleCheckboxChange}
          disabled={node.disabled}
          size="sm"
          className="shrink-0"
        />
      )}

      {/* Icon (left position) */}
      {iconPosition === "left" && renderIcon()}

      {/* Label */}
      <span class="flex-1 text-gray-800 dark:text-neutral-200">
        {node.label}
      </span>

      {/* Icon (right position) */}
      {iconPosition === "right" && renderIcon()}
    </div>
  );

  // If node has no children, render as simple item
  if (!hasChildren) {
    return (
      <div
        class="hs-accordion-group"
        style={`padding-left: ${level * 1.25}rem;`}
      >
        {renderNodeContent()}
      </div>
    ) as Pulse.JSX.Element;
  }

  // Node with children: use accordion structure
  return (
    <div
      class="hs-accordion"
      id={nodeId}
      style={`padding-left: ${level * 1.25}rem;`}
    >
      {/* Accordion toggle (folder header) */}
      <button
        type="button"
        class="hs-accordion-toggle w-full"
        aria-expanded={isExpanded ? "true" : "false"}
        aria-controls={collapseId}
        style="all: unset; display: block; width: 100%;"
      >
        {renderNodeContent()}
      </button>

      {/* Accordion content (children) */}
      <div
        id={collapseId}
        class={cn(
          "hs-accordion-content w-full overflow-hidden transition-[height] duration-300",
          !isExpanded && "hidden",
        )}
        aria-labelledby={nodeId}
      >
        <div class="hs-accordion-group">
          {node.children?.map((child) => (
            <TreeNode
              node={child}
              level={level + 1}
              treeId={treeId}
              selectable={selectable}
              multiSelect={multiSelect}
              showCheckboxes={showCheckboxes}
              showLines={showLines}
              iconPosition={iconPosition}
              selected={selected}
              expanded={expanded}
              checked={checked}
              onToggleExpand={onToggleExpand}
              onSelectNode={onSelectNode}
              onCheckNode={onCheckNode}
            />
          ))}
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

/**
 * TreeView component
 */
export const TreeView: Pulse.Fn<TreeViewProps> = (props) => {
  const {
    nodes,
    selectable = false,
    multiSelect = false,
    selected,
    onSelect,
    expanded,
    onExpand,
    alwaysOpen = false,
    showCheckboxes = false,
    checked,
    onCheck,
    draggable = false,
    showLines = false,
    iconPosition = "left",
    ariaLabel,
    ariaLabelledBy,
    className,
    id = generateId("tree-view"),
    style,
    ...rest
  } = props;

  // Internal state for selected nodes
  const internalSelected = Pulse.signal<string[]>([]);
  const selectedState = selected
    ? isSignal(selected)
      ? (selected as any)
      : Pulse.signal(selected)
    : internalSelected;

  // Internal state for expanded nodes
  const internalExpanded = Pulse.signal<string[]>([]);
  const expandedState = expanded
    ? isSignal(expanded)
      ? (expanded as any)
      : Pulse.signal(expanded)
    : internalExpanded;

  // Internal state for checked nodes
  const internalChecked = Pulse.signal<string[]>([]);
  const checkedState = checked
    ? isSignal(checked)
      ? (checked as any)
      : Pulse.signal(checked)
    : internalChecked;

  // Last clicked index for shift selection
  let lastClickedValue: string | null = null;

  // Flatten tree to get all node values (for shift selection)
  const flattenNodes = (nodes: TreeViewNode[]): string[] => {
    const result: string[] = [];
    const traverse = (nodes: TreeViewNode[]) => {
      for (const node of nodes) {
        result.push(node.value);
        if (node.children) {
          traverse(node.children);
        }
      }
    };
    traverse(nodes);
    return result;
  };

  // Handle expand/collapse toggle
  const handleToggleExpand = (value: string) => {
    const currentExpanded = isSignal(expandedState)
      ? (expandedState as any)()
      : expandedState;
    const isExpanded = currentExpanded.includes(value);

    let newExpanded: string[];
    if (isExpanded) {
      // Collapse
      newExpanded = currentExpanded.filter((v: string) => v !== value);
    } else {
      // Expand
      newExpanded = [...currentExpanded, value];
    }

    if (isSignal(expandedState)) {
      (expandedState as any)(newExpanded);
    }

    if (onExpand) {
      onExpand(newExpanded);
    }
  };

  // Handle node selection
  const handleSelectNode = (value: string, event: MouseEvent) => {
    if (!selectable) return;

    const currentSelected = isSignal(selectedState)
      ? (selectedState as any)()
      : selectedState;

    let newSelected: string[];

    if (multiSelect) {
      const flatNodes = flattenNodes(nodes);

      // Shift key: range selection
      if (event.shiftKey && lastClickedValue) {
        const lastIndex = flatNodes.indexOf(lastClickedValue);
        const currentIndex = flatNodes.indexOf(value);

        if (lastIndex !== -1 && currentIndex !== -1) {
          const start = Math.min(lastIndex, currentIndex);
          const end = Math.max(lastIndex, currentIndex);
          const range = flatNodes.slice(start, end + 1);

          // Add range to selection
          newSelected = Array.from(new Set([...currentSelected, ...range]));
        } else {
          newSelected = [...currentSelected, value];
        }
      }
      // Ctrl/Cmd key: toggle selection
      else if (event.ctrlKey || event.metaKey) {
        if (currentSelected.includes(value)) {
          newSelected = currentSelected.filter((v: string) => v !== value);
        } else {
          newSelected = [...currentSelected, value];
        }
      }
      // No modifier: replace selection
      else {
        newSelected = [value];
      }
    } else {
      // Single select: replace selection
      newSelected = [value];
    }

    lastClickedValue = value;

    if (isSignal(selectedState)) {
      (selectedState as any)(newSelected);
    }

    if (onSelect) {
      onSelect(newSelected);
    }
  };

  // Handle checkbox change
  const handleCheckNode = (value: string, isChecked: boolean) => {
    const currentChecked = isSignal(checkedState)
      ? (checkedState as any)()
      : checkedState;

    let newChecked: string[];
    if (isChecked) {
      newChecked = [...currentChecked, value];
    } else {
      newChecked = currentChecked.filter((v: string) => v !== value);
    }

    if (isSignal(checkedState)) {
      (checkedState as any)(newChecked);
    }

    if (onCheck) {
      onCheck(newChecked);
    }
  };

  // Container classes
  const containerClasses = cn(
    "hs-accordion-group",
    alwaysOpen && "hs-accordion-always-open",
    showLines && "border-l border-gray-200 dark:border-neutral-700",
    className,
  );

  // Render tree
  return (
    <div
      id={id}
      class={containerClasses}
      role="tree"
      aria-label={ariaLabel}
      aria-labelledby={ariaLabelledBy}
      aria-multiselectable={multiSelect}
      style={style}
      data-hs-accordion-always-open={alwaysOpen ? "true" : undefined}
      {...rest}
    >
      {nodes.map((node) => (
        <TreeNode
          node={node}
          level={0}
          treeId={id}
          selectable={selectable}
          multiSelect={multiSelect}
          showCheckboxes={showCheckboxes}
          showLines={showLines}
          iconPosition={iconPosition}
          selected={
            isSignal(selectedState) ? (selectedState as any)() : selectedState
          }
          expanded={
            isSignal(expandedState) ? (expandedState as any)() : expandedState
          }
          checked={
            isSignal(checkedState) ? (checkedState as any)() : checkedState
          }
          onToggleExpand={handleToggleExpand}
          onSelectNode={handleSelectNode}
          onCheckNode={handleCheckNode}
        />
      ))}
    </div>
  ) as Pulse.JSX.Element;
};
