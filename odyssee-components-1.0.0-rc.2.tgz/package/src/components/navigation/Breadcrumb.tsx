/**
 * Breadcrumb Component
 * A navigation component showing the current page's location within a navigational hierarchy
 *
 * @example
 * ```tsx
 * import { Breadcrumb } from '@odyssee/components';
 *
 * // Basic breadcrumb with chevron separators
 * <Breadcrumb items={['Home', 'App Center', 'Application']} />
 *
 * // With links
 * <Breadcrumb
 *   items={[
 *     { label: 'Home', href: '/' },
 *     { label: 'App Center', href: '/app-center' },
 *     { label: 'Application', active: true },
 *   ]}
 * />
 *
 * // With slash separators
 * <Breadcrumb
 *   items={['Home', 'App Center', 'Application']}
 *   separator="slash"
 * />
 *
 * // With icons
 * <Breadcrumb
 *   items={[
 *     { label: 'Home', href: '/', icon: <svg>...</svg> },
 *     { label: 'App Center', href: '/app-center', icon: <svg>...</svg> },
 *     { label: 'Application', active: true },
 *   ]}
 * />
 *
 * // Bordered
 * <Breadcrumb
 *   items={[
 *     { label: 'Home', href: '/', icon: <svg>...</svg> },
 *     { label: 'App Center', href: '/app-center', icon: <svg>...</svg> },
 *     { label: 'Application', active: true },
 *   ]}
 *   bordered
 * />
 *
 * // With 'more' indicator
 * <Breadcrumb
 *   items={[
 *     { label: 'Home', href: '/' },
 *     { label: 'Application', active: true },
 *   ]}
 *   showMore
 * />
 *
 * // Custom separator
 * <Breadcrumb
 *   items={['Home', 'App Center', 'Application']}
 *   separator="custom"
 *   customSeparator="→"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { BreadcrumbProps, BreadcrumbItem } from "../../types";
import { cn, generateId } from "../../utils";

/**
 * Chevron separator icon
 */
const ChevronSeparator: Pulse.Fn = () => (
  <svg
    class="shrink-0 mx-2 size-4 text-gray-400 dark:text-neutral-600"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m9 18 6-6-6-6"></path>
  </svg>
);

/**
 * Slash separator icon
 */
const SlashSeparator: Pulse.Fn = () => (
  <svg
    class="shrink-0 size-5 text-gray-400 dark:text-neutral-600 mx-2"
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path d="M6 13L10 3" stroke="currentColor" stroke-linecap="round"></path>
  </svg>
);

/**
 * More (ellipsis) icon
 */
const MoreIcon: Pulse.Fn = () => (
  <svg
    class="shrink-0 size-4"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <circle cx="12" cy="12" r="1"></circle>
    <circle cx="19" cy="12" r="1"></circle>
    <circle cx="5" cy="12" r="1"></circle>
  </svg>
);

export const Breadcrumb: Pulse.Fn<BreadcrumbProps> = (props) => {
  const {
    items = [],
    separator = "chevron",
    customSeparator,
    bordered = false,
    showMore = false,
    maxItems,
    collapsedItems = [],
    size = "sm",
    onItemClick,
    className,
    id = generateId("breadcrumb"),
    style,
    ...rest
  } = props;

  // Text size classes
  const sizeClasses = {
    xs: "text-xs",
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
  };

  // Render separator
  const renderSeparator = () => {
    if (separator === "chevron") {
      return <ChevronSeparator />;
    }

    if (separator === "slash") {
      return <SlashSeparator />;
    }

    if (separator === "custom" && customSeparator) {
      if (typeof customSeparator === "string") {
        return (
          <span class="mx-2 text-gray-400 dark:text-neutral-600">
            {customSeparator}
          </span>
        );
      }
      return customSeparator;
    }

    // Default to chevron
    return <ChevronSeparator />;
  };

  // Render item icon
  const renderIcon = (icon: HTMLElement | string) => {
    if (typeof icon === "string") {
      return <span class="shrink-0 me-3 size-4">{icon}</span>;
    }
    return icon;
  };

  // Render item content
  const renderItemContent = (item: string | BreadcrumbItem) => {
    if (typeof item === "string") {
      return item;
    }

    return (
      <>
        {item.icon && renderIcon(item.icon)}
        {typeof item.label === "string" ? item.label : item.label}
      </>
    );
  };

  // Handle item click
  const handleItemClick = (
    item: string | BreadcrumbItem,
    index: number,
    e: Event,
  ) => {
    const breadcrumbItem = typeof item === "string" ? { label: item } : item;

    if (breadcrumbItem.onClick) {
      breadcrumbItem.onClick(e);
    }

    if (onItemClick) {
      onItemClick(item, index);
    }
  };

  // Check if item is active
  const isActiveItem = (item: string | BreadcrumbItem, index: number) => {
    if (typeof item === "string") {
      return index === items.length - 1;
    }
    return item.active !== undefined ? item.active : index === items.length - 1;
  };

  // Base link classes
  const linkClasses = cn(
    "flex items-center text-gray-500 hover:text-blue-600",
    "focus:outline-hidden focus:text-blue-600",
    "dark:text-neutral-500 dark:hover:text-blue-500 dark:focus:text-blue-500",
  );

  // Active item classes
  const activeClasses = cn(
    "font-semibold text-gray-800 truncate",
    "dark:text-neutral-200",
  );

  // Container classes
  const containerClasses = cn(
    "flex items-center whitespace-nowrap",
    sizeClasses[size],
    bordered && "p-2 border-y border-gray-200 dark:border-neutral-700",
    className,
  );

  return (
    <ol
      id={id}
      class={containerClasses}
      style={style}
      role="navigation"
      aria-label="Breadcrumb"
      {...rest}
    >
      {/* Show 'more' indicator if enabled */}
      {showMore && collapsedItems.length > 0 && (
        <>
          <li class="inline-flex items-center">
            <a
              class={linkClasses}
              href={
                typeof items[0] === "string"
                  ? "#"
                  : (items[0] as BreadcrumbItem).href || "#"
              }
              onClick={(e: any) => handleItemClick(items[0], 0, e)}
            >
              {renderItemContent(items[0])}
            </a>
            {renderSeparator()}
          </li>
          <li class="text-sm">
            <div class="flex items-center text-gray-500 dark:text-neutral-500">
              <MoreIcon />
              {renderSeparator()}
            </div>
          </li>
        </>
      )}

      {/* Regular items */}
      {items.map((item, index) => {
        // Skip first item if showMore is enabled (already rendered)
        if (showMore && index === 0) {
          return null;
        }

        const isActive = isActiveItem(item, index);
        const isLast = index === items.length - 1;
        const breadcrumbItem =
          typeof item === "string" ? { label: item } : item;

        // Active/last item (no link)
        if (isActive) {
          return (
            <li
              key={index}
              class={cn("inline-flex items-center", activeClasses)}
              aria-current="page"
            >
              {renderItemContent(item)}
            </li>
          );
        }

        // Regular clickable item
        return (
          <li key={index} class="inline-flex items-center">
            <a
              class={linkClasses}
              href={breadcrumbItem.href || "#"}
              onClick={(e: any) => handleItemClick(item, index, e)}
            >
              {renderItemContent(item)}
              {!isLast && renderSeparator()}
            </a>
          </li>
        );
      })}
    </ol>
  ) as Pulse.JSX.Element;
};

/**
 * BreadcrumbChevron Component
 * Convenience component for breadcrumb with chevron separators
 *
 * @example
 * ```tsx
 * <BreadcrumbChevron items={['Home', 'App Center', 'Application']} />
 * ```
 */
export const BreadcrumbChevron: Pulse.Fn<Omit<BreadcrumbProps, "separator">> = (
  props,
) => {
  return <Breadcrumb {...(props as any)} separator="chevron" />;
};

/**
 * BreadcrumbSlash Component
 * Convenience component for breadcrumb with slash separators
 *
 * @example
 * ```tsx
 * <BreadcrumbSlash items={['Home', 'App Center', 'Application']} />
 * ```
 */
export const BreadcrumbSlash: Pulse.Fn<Omit<BreadcrumbProps, "separator">> = (
  props,
) => {
  return <Breadcrumb {...(props as any)} separator="slash" />;
};

/**
 * BreadcrumbBordered Component
 * Convenience component for bordered breadcrumb
 *
 * @example
 * ```tsx
 * <BreadcrumbBordered items={['Home', 'App Center', 'Application']} />
 * ```
 */
export const BreadcrumbBordered: Pulse.Fn<Omit<BreadcrumbProps, "bordered">> = (
  props,
) => {
  return <Breadcrumb {...(props as any)} bordered />;
};

export default Breadcrumb;
