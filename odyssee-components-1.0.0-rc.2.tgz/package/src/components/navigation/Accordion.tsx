/**
 * Accordion Component
 * A collapsible content panel component with multiple variants
 */

import Pulse from "pulse-framework";
import { cn } from "../../utils";
import type { AccordionProps, AccordionItem } from "../../types";

/**
 * Generate a unique ID for accordion items
 */
function generateId(prefix: string = "accordion"): string {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Plus Icon Component
 */
const PlusIcon: Pulse.Fn = () => (
  <svg
    class="hs-accordion-active:hidden block size-3.5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="M5 12h14"></path>
    <path d="M12 5v14"></path>
  </svg>
);

/**
 * Minus Icon Component
 */
const MinusIcon: Pulse.Fn = () => (
  <svg
    class="hs-accordion-active:block hidden size-3.5"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="M5 12h14"></path>
  </svg>
);

/**
 * Chevron Down Icon Component
 */
const ChevronDownIcon: Pulse.Fn = () => (
  <svg
    class="hs-accordion-active:hidden block size-4"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m6 9 6 6 6-6"></path>
  </svg>
);

/**
 * Chevron Up Icon Component
 */
const ChevronUpIcon: Pulse.Fn = () => (
  <svg
    class="hs-accordion-active:block hidden size-4"
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    stroke-linecap="round"
    stroke-linejoin="round"
  >
    <path d="m18 15-6-6-6 6"></path>
  </svg>
);

/**
 * Accordion Item Component
 */
interface AccordionItemComponentProps {
  item: AccordionItem;
  variant?:
    | "default"
    | "bordered"
    | "active-bordered"
    | "no-arrow"
    | "arrow"
    | "stretched";
  isNested?: boolean;
}

const AccordionItemComponent: Pulse.Fn<AccordionItemComponentProps> = (
  props: AccordionItemComponentProps,
): Pulse.JSX.Element => {
  const itemId = props.item.id || generateId("hs-accordion");
  const headingId = `${itemId}-heading`;
  const collapseId = `${itemId}-collapse`;
  const variant = props.variant || "default";
  const isNested = props.isNested || false;

  // Determine icon based on variant
  const renderIcon = () => {
    if (variant === "no-arrow") {
      return null;
    }

    if (variant === "arrow" || variant === "stretched") {
      return (
        <>
          <ChevronDownIcon />
          <ChevronUpIcon />
        </>
      );
    }

    // Default plus/minus icons (or nested variant)
    if (isNested) {
      return (
        <>
          <svg
            class="hs-accordion-active:hidden block size-3"
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M2.62421 7.86L13.6242 7.85999"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
            ></path>
            <path
              d="M8.12421 13.36V2.35999"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
            ></path>
          </svg>
          <svg
            class="hs-accordion-active:block hidden size-3"
            width="16"
            height="16"
            viewBox="0 0 16 16"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M2.62421 7.86L13.6242 7.85999"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
            ></path>
          </svg>
        </>
      );
    }

    return (
      <>
        <PlusIcon />
        <MinusIcon />
      </>
    );
  };

  // Container classes based on variant
  const containerClasses = cn(
    "hs-accordion",
    props.item.open && "active",
    variant === "bordered" &&
      "bg-white border border-gray-200 -mt-px first:rounded-t-lg last:rounded-b-lg dark:bg-neutral-800 dark:border-neutral-700",
    variant === "active-bordered" &&
      "hs-accordion-active:border-gray-200 bg-white border border-transparent rounded-xl dark:hs-accordion-active:border-neutral-700 dark:bg-neutral-800 dark:border-transparent",
  );

  // Button classes based on variant
  const buttonClasses = cn(
    "hs-accordion-toggle",
    "hs-accordion-active:text-blue-600",
    "inline-flex items-center w-full font-semibold text-start text-gray-800",
    "hover:text-gray-500 disabled:opacity-50 disabled:pointer-events-none",
    "dark:hs-accordion-active:text-blue-500 dark:text-neutral-200",
    "dark:hover:text-neutral-400 dark:focus:text-neutral-400",
    variant === "stretched" && "justify-between",
    variant === "stretched" && "rounded-lg focus:outline-hidden",
    variant !== "stretched" && "focus:outline-hidden focus:text-gray-500",
    variant === "bordered" || variant === "active-bordered"
      ? "py-4 px-5"
      : "py-3",
    variant === "no-arrow" || variant === "arrow" || variant === "stretched"
      ? ""
      : "gap-x-3",
  );

  // Content classes
  const contentClasses = cn(
    "hs-accordion-content",
    "w-full overflow-hidden transition-[height] duration-300",
    !props.item.open && "hidden",
  );

  const contentWrapperClasses = cn(
    variant === "bordered" || variant === "active-bordered" ? "pb-4 px-5" : "",
  );

  // Render content
  const renderContent = () => {
    if (typeof props.item.content === "string") {
      return (
        <p class="text-gray-800 dark:text-neutral-200">{props.item.content}</p>
      );
    }
    return props.item.content;
  };

  return (
    <div class={containerClasses} id={itemId}>
      <button
        class={buttonClasses}
        aria-expanded={props.item.open ? "true" : "false"}
        aria-controls={collapseId}
        disabled={props.item.disabled}
      >
        {variant !== "stretched" && renderIcon()}
        {props.item.title}
        {variant === "stretched" && renderIcon()}
      </button>
      <div
        id={collapseId}
        class={contentClasses}
        role="region"
        aria-labelledby={headingId}
      >
        {variant === "bordered" || variant === "active-bordered" ? (
          <div class={contentWrapperClasses}>{renderContent()}</div>
        ) : (
          renderContent()
        )}
      </div>
    </div>
  );
};

/**
 * Nested Accordion Support
 */
interface NestedAccordionProps {
  items: AccordionItem[];
  variant?:
    | "default"
    | "bordered"
    | "active-bordered"
    | "no-arrow"
    | "arrow"
    | "stretched";
}

const NestedAccordion: Pulse.Fn<NestedAccordionProps> = (
  props: NestedAccordionProps,
): Pulse.JSX.Element => {
  return (
    <div class="hs-accordion-group ps-6">
      {props.items.map((item) => (
        <AccordionItemComponent
          item={item}
          variant={props.variant}
          isNested={true}
        />
      ))}
    </div>
  );
};

/**
 * Accordion Component
 *
 * @example
 * ```tsx
 * const items: AccordionItem[] = [
 *   {
 *     id: "item-1",
 *     title: "Accordion #1",
 *     content: "This is the first item's accordion body.",
 *     open: true
 *   },
 *   {
 *     id: "item-2",
 *     title: "Accordion #2",
 *     content: "This is the second item's accordion body."
 *   }
 * ];
 *
 * <Accordion items={items} />
 * ```
 */
export const Accordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  const {
    items = [],
    multiple = false,
    bordered = false,
    className,
    id,
    style,
  } = props;

  // Determine variant based on props
  let variant:
    | "default"
    | "bordered"
    | "active-bordered"
    | "no-arrow"
    | "arrow"
    | "stretched" = "default";
  if (bordered) {
    variant = "bordered";
  }

  // Container classes
  const containerClasses = cn("hs-accordion-group", className);

  // Add data attribute for always-open mode
  const dataAttrs = multiple ? { "data-hs-accordion-always-open": "" } : {};

  return (
    <div id={id} class={containerClasses} style={style} {...dataAttrs}>
      {items.map((item) => (
        <AccordionItemComponent item={item} variant={variant} />
      ))}
    </div>
  );
};

/**
 * Accordion with different variants
 */

/**
 * Basic Accordion (default with plus/minus icons)
 */
export const BasicAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  return <Accordion {...props} />;
};

/**
 * Accordion with no arrow
 */
export const NoArrowAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  const containerClasses = cn("hs-accordion-group", props.className);

  return (
    <div
      id={props.id}
      class={containerClasses}
      style={props.style}
      {...(props.multiple ? { "data-hs-accordion-always-open": "" } : {})}
    >
      {props.items.map((item) => (
        <AccordionItemComponent item={item} variant="no-arrow" />
      ))}
    </div>
  );
};

/**
 * Accordion with chevron arrows
 */
export const ArrowAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  const containerClasses = cn("hs-accordion-group", props.className);

  return (
    <div
      id={props.id}
      class={containerClasses}
      style={props.style}
      {...(props.multiple ? { "data-hs-accordion-always-open": "" } : {})}
    >
      {props.items.map((item) => (
        <AccordionItemComponent item={item} variant="arrow" />
      ))}
    </div>
  );
};

/**
 * Accordion with title and arrow stretched
 */
export const StretchedAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  const containerClasses = cn("hs-accordion-group", props.className);

  return (
    <div
      id={props.id}
      class={containerClasses}
      style={props.style}
      {...(props.multiple ? { "data-hs-accordion-always-open": "" } : {})}
    >
      {props.items.map((item) => (
        <AccordionItemComponent item={item} variant="stretched" />
      ))}
    </div>
  );
};

/**
 * Bordered Accordion
 */
export const BorderedAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  return <Accordion {...props} bordered={true} />;
};

/**
 * Active Content Bordered Accordion
 */
export const ActiveBorderedAccordion: Pulse.Fn<AccordionProps> = (
  props: AccordionProps,
): Pulse.JSX.Element => {
  const containerClasses = cn("hs-accordion-group", props.className);

  return (
    <div
      id={props.id}
      class={containerClasses}
      style={props.style}
      {...(props.multiple ? { "data-hs-accordion-always-open": "" } : {})}
    >
      {props.items.map((item) => (
        <AccordionItemComponent item={item} variant="active-bordered" />
      ))}
    </div>
  );
};

/**
 * Export NestedAccordion for advanced use cases
 */
export { NestedAccordion };

export default Accordion;
