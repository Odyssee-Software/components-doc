/**
 * Stepper Component
 * A flexible stepper component for multi-step processes with navigation controls
 *
 * @example
 * ```tsx
 * import { Stepper } from '@odyssee/components';
 *
 * // Config-based approach
 * const steps = [
 *   {
 *     index: 1,
 *     label: "Account Details",
 *     description: "Enter your information",
 *     content: <AccountForm />
 *   },
 *   {
 *     index: 2,
 *     label: "Payment",
 *     description: "Enter payment details",
 *     content: <PaymentForm />
 *   },
 *   {
 *     index: 3,
 *     label: "Confirmation",
 *     content: <ConfirmationView />
 *   }
 * ];
 *
 * const currentStep = Pulse.signal(1);
 *
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   onStepChange={(step) => currentStep(step)}
 *   onComplete={() => console.log('Completed!')}
 * />
 *
 * // With custom controls
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   showControls={true}
 *   backText="Previous"
 *   nextText="Continue"
 *   finishText="Submit"
 * />
 *
 * // Linear mode (sequential)
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   mode="linear"
 * />
 *
 * // Non-linear mode (free navigation)
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   mode="non-linear"
 * />
 *
 * // Vertical orientation
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   orientation="vertical"
 * />
 *
 * // White variant
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   variant="white"
 * />
 *
 * // Center aligned
 * <Stepper
 *   steps={steps}
 *   currentStep={currentStep}
 *   alignment="center"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { StepperProps, StepItemData, StepStatus } from "../../types";
import { cn, generateId, isSignal } from "../../utils";
import { StepItem } from "./StepItem";
import { Button } from "../base/Button";

export const Stepper: Pulse.Fn<StepperProps> = (props) => {
  const {
    steps = [],
    currentStep: currentStepProp,
    mode = "linear",
    orientation = "horizontal",
    variant = "default",
    alignment = "start",
    showControls = true,
    backText = "Back",
    nextText = "Next",
    finishText = "Finish",
    resetText = "Reset",
    skipText = "Skip",
    completeStepText = "Complete Step",
    onStepChange,
    onComplete,
    onSkip,
    onReset,
    onBack,
    onNext,
    children,
    className,
    id = generateId("stepper"),
    style,
    ...rest
  } = props;

  // Get current step value
  const getCurrentStep = () =>
    isSignal(currentStepProp) ? (currentStepProp as any)() : currentStepProp;

  const currentStepIndex = getCurrentStep();
  const totalSteps = steps.length;
  const isFirstStep = currentStepIndex === 1;
  const isLastStep = currentStepIndex === totalSteps;
  const isCompleted = currentStepIndex > totalSteps;

  // Determine step status
  const getStepStatus = (step: StepItemData): StepStatus => {
    if (step.hasError) return "error";
    if (step.index < currentStepIndex || step.isCompleted) return "completed";
    if (step.index === currentStepIndex) return "active";
    return "pending";
  };

  // Handle navigation
  const handleBack = () => {
    if (!isFirstStep) {
      const newStep = currentStepIndex - 1;
      if (onStepChange) onStepChange(newStep);
      if (onBack) onBack();
    }
  };

  const handleNext = () => {
    if (!isLastStep) {
      const newStep = currentStepIndex + 1;
      if (onStepChange) onStepChange(newStep);
      if (onNext) onNext();
    }
  };

  const handleFinish = () => {
    if (onComplete) onComplete();
  };

  const handleReset = () => {
    if (onStepChange) onStepChange(1);
    if (onReset) onReset();
  };

  const handleSkip = () => {
    if (!isLastStep) {
      const currentStep = steps[currentStepIndex - 1];
      if (currentStep?.isOptional) {
        const newStep = currentStepIndex + 1;
        if (onStepChange) onStepChange(newStep);
        if (onSkip) onSkip(currentStepIndex);
      }
    }
  };

  const handleStepClick = (stepIndex: number) => {
    // In non-linear mode, allow clicking any step
    // In linear mode, only allow clicking completed steps
    if (mode === "non-linear" || stepIndex < currentStepIndex) {
      if (onStepChange) onStepChange(stepIndex);
    }
  };

  // Container classes
  const containerClasses = cn(
    "relative",
    alignment === "center" && "max-w-3xl mx-auto",
    alignment === "end" && "ml-auto",
    className,
  );

  // Steps list classes
  const stepsListClasses = cn(
    "relative flex gap-2",
    orientation === "horizontal" ? "flex-row" : "flex-col md:flex-row",
  );

  // Render step items
  const renderSteps = () => {
    return steps.map((step, index) => {
      const stepStatus = getStepStatus(step);
      const isClickable =
        mode === "non-linear" || step.index < currentStepIndex;

      return (
        <StepItem
          key={step.index}
          index={step.index}
          label={step.label}
          description={step.description}
          status={stepStatus}
          variant={variant}
          orientation={orientation}
          isLast={index === steps.length - 1}
          isClickable={isClickable}
          icon={step.icon}
          avatar={step.avatar}
          onClick={handleStepClick}
        />
      );
    });
  };

  // Render current step content
  const renderContent = () => {
    // If completed, show final content or nothing
    if (isCompleted) {
      return (
        <div class="mt-5 sm:mt-8">
          <div class="p-4 h-48 bg-gray-50 flex justify-center items-center border border-dashed border-gray-200 rounded-xl dark:bg-neutral-800 dark:border-neutral-700">
            <h3 class="text-gray-500 dark:text-neutral-500">
              All steps completed!
            </h3>
          </div>
        </div>
      );
    }

    const currentStep = steps[currentStepIndex - 1];
    if (!currentStep?.content) return null;

    return <div class="mt-5 sm:mt-8">{currentStep.content}</div>;
  };

  // Render controls
  const renderControls = () => {
    if (!showControls) return null;

    const currentStep = steps[currentStepIndex - 1];
    const showSkipButton =
      currentStep?.isOptional && !isLastStep && !isCompleted;

    // When completed, only show reset
    if (isCompleted) {
      return (
        <div class="mt-5 flex justify-between items-center gap-x-2">
          <div class="flex-1"></div>
          <Button
            type="reset"
            variant="solid"
            color="primary"
            onClick={handleReset}
          >
            {resetText}
          </Button>
        </div>
      );
    }

    return (
      <div class="mt-5 flex justify-between items-center gap-x-2">
        <Button
          type="button"
          variant="outline"
          color="secondary"
          onClick={handleBack}
          disabled={isFirstStep}
          icon={
            <svg
              class="shrink-0 size-4"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              stroke-linecap="round"
              stroke-linejoin="round"
            >
              <path d="m15 18-6-6 6-6"></path>
            </svg>
          }
          iconPosition="left"
        >
          {backText}
        </Button>

        <div class="flex gap-x-2">
          {showSkipButton && (
            <Button
              type="button"
              variant="ghost"
              color="secondary"
              onClick={handleSkip}
            >
              {skipText}
            </Button>
          )}

          {!isLastStep && (
            <Button
              type="button"
              variant="solid"
              color="primary"
              onClick={handleNext}
              icon={
                <svg
                  class="shrink-0 size-4"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <path d="m9 18 6-6-6-6"></path>
                </svg>
              }
              iconPosition="right"
            >
              {nextText}
            </Button>
          )}

          {isLastStep && (
            <Button
              type="button"
              variant="solid"
              color="primary"
              onClick={handleFinish}
            >
              {finishText}
            </Button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div id={id} class={containerClasses} style={style} {...rest}>
      {/* Stepper Nav */}
      <ul class={stepsListClasses}>{renderSteps()}</ul>
      {/* End Stepper Nav */}

      {/* Stepper Content */}
      {renderContent()}
      {/* End Stepper Content */}

      {/* Stepper Controls */}
      {renderControls()}
      {/* End Stepper Controls */}
    </div>
  ) as Pulse.JSX.Element;
};

export default Stepper;
