/**
 * Tabs Component
 * A tabbed navigation component with Preline integration
 *
 * @example
 * ```tsx
 * import { Tabs } from '@odyssee/components';
 *
 * // Basic tabs with items array
 * <Tabs
 *   items={[
 *     { id: 'tab1', label: 'Tab 1', content: <p>Content 1</p> },
 *     { id: 'tab2', label: 'Tab 2', content: <p>Content 2</p> },
 *     { id: 'tab3', label: 'Tab 3', content: <p>Content 3</p> }
 *   ]}
 * />
 *
 * // With active tab control
 * const activeTab = Pulse.signal('tab2');
 * <Tabs
 *   items={[...]}
 *   activeTab={activeTab}
 *   onChange={(tabId) => activeTab(tabId)}
 * />
 *
 * // With icons
 * <Tabs
 *   items={[
 *     { id: 'home', label: 'Home', icon: <HomeIcon />, content: <Home /> },
 *     { id: 'profile', label: 'Profile', icon: <UserIcon />, content: <Profile /> }
 *   ]}
 * />
 *
 * // Pills variant
 * <Tabs
 *   variant="pills"
 *   items={[...]}
 * />
 *
 * // Hover activation
 * <Tabs
 *   eventType="hover"
 *   items={[...]}
 * />
 *
 * // With children (flexible approach)
 * <Tabs>
 *   <TabPanel id="tab1" label="Tab 1">
 *     <p>Content 1</p>
 *   </TabPanel>
 *   <TabPanel id="tab2" label="Tab 2">
 *     <p>Content 2</p>
 *   </TabPanel>
 * </Tabs>
 *
 * // Vertical tabs
 * <Tabs variant="vertical" items={[...]} />
 * ```
 */

import Pulse from "pulse-framework";
import type { TabsProps, TabItem } from "../../types";
import { cn, generateId, isSignal } from "../../utils";

export const Tabs: Pulse.Fn<TabsProps> = (props) => {
  const {
    items,
    children,
    activeTab: activeTabProp,
    variant = "underline",
    eventType = "click",
    bordered = true,
    fullWidth = false,
    size = "md",
    tablistClassName,
    contentClassName,
    onChange,
    className,
    id = generateId("tabs"),
    ...rest
  } = props;

  // Default active tab (first tab's id)
  const defaultActiveTab = items && items.length > 0 ? items[0].id : "";
  const activeTab = activeTabProp || defaultActiveTab;

  // Get reactive active tab value
  const getActiveTab = () =>
    isSignal(activeTab) ? (activeTab as any)() : activeTab;

  // Size classes for tabs
  const tabSizeClasses = {
    sm: "py-2 px-2 text-xs",
    md: "py-4 px-1 text-sm",
    lg: "py-5 px-2 text-base",
  };

  // Variant classes
  const getTabVariantClasses = (isActive: boolean) => {
    switch (variant) {
      case "underline":
        return cn(
          "hs-tab-active:font-semibold hs-tab-active:border-blue-600 hs-tab-active:text-blue-600",
          tabSizeClasses[size],
          "inline-flex items-center gap-x-2 border-b-2 border-transparent whitespace-nowrap text-gray-500 hover:text-blue-600 focus:outline-hidden focus:text-blue-600 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:text-blue-500 dark:focus:text-blue-500",
          isActive && "active font-semibold border-blue-600 text-blue-600",
        );

      case "pills":
        return cn(
          "hs-tab-active:bg-blue-600 hs-tab-active:text-white",
          tabSizeClasses[size],
          "inline-flex items-center gap-x-2 rounded-lg whitespace-nowrap text-gray-500 hover:text-blue-600 hover:bg-blue-50 focus:outline-hidden focus:bg-blue-50 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:text-blue-500 dark:hover:bg-neutral-700 dark:focus:bg-neutral-700",
          isActive && "active bg-blue-600 text-white dark:bg-blue-600",
        );

      case "enclosed":
        return cn(
          "hs-tab-active:bg-white hs-tab-active:border-b-transparent hs-tab-active:text-blue-600",
          tabSizeClasses[size],
          "inline-flex items-center gap-x-2 border border-transparent rounded-t-lg whitespace-nowrap text-gray-500 hover:text-blue-600 focus:outline-hidden disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:text-blue-500",
          isActive &&
            "active bg-white border-gray-200 border-b-transparent text-blue-600 dark:bg-neutral-800 dark:border-neutral-700",
        );

      case "vertical":
        return cn(
          "hs-tab-active:bg-gray-100 hs-tab-active:border-s-blue-600 hs-tab-active:text-blue-600",
          tabSizeClasses[size],
          "inline-flex items-center gap-x-2 border-s-2 border-transparent whitespace-nowrap text-gray-500 hover:text-blue-600 focus:outline-hidden focus:text-blue-600 disabled:opacity-50 disabled:pointer-events-none dark:text-neutral-400 dark:hover:text-blue-500",
          isActive &&
            "active bg-gray-100 border-s-blue-600 text-blue-600 dark:bg-neutral-700 dark:border-s-blue-600",
        );

      default:
        return "";
    }
  };

  // Tablist wrapper classes
  const tablistWrapperClasses = cn(
    variant === "underline" &&
      bordered &&
      "border-b border-gray-200 dark:border-neutral-700",
    variant === "enclosed" && "border-b border-gray-200 dark:border-neutral-700",
    className,
  );

  // Tablist classes
  const tablistClasses = cn(
    "flex",
    variant === "vertical" ? "flex-col" : "gap-x-2",
    variant === "pills" && "gap-2",
    fullWidth && "w-full",
    tablistClassName,
  );

  // Event type data attribute
  const eventTypeAttr =
    eventType === "hover" ? { "data-hs-tabs": JSON.stringify({ eventType: "hover" }) } : {};

  // Render tabs from items array
  const renderTabButtons = () => {
    if (!items || items.length === 0) return null;

    return items.map((item: TabItem) => {
      const isActive = getActiveTab() === item.id;
      const tabClasses = getTabVariantClasses(isActive);

      return (
        <button
          type="button"
          class={tabClasses}
          id={`${id}-item-${item.id}`}
          data-hs-tab={`#${id}-panel-${item.id}`}
          aria-controls={`${id}-panel-${item.id}`}
          aria-selected={isActive}
          role="tab"
          disabled={item.disabled}
        >
          {item.icon && (
            <span class="inline-flex items-center">{item.icon}</span>
          )}
          {item.label}
          {item.badge && (
            <span class="ms-1 py-0.5 px-1.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-neutral-700 dark:text-neutral-300">
              {item.badge}
            </span>
          )}
        </button>
      );
    });
  };

  // Render tab panels from items array
  const renderTabPanels = () => {
    if (!items || items.length === 0) return null;

    return items.map((item: TabItem) => {
      const isActive = getActiveTab() === item.id;

      return (
        <div
          id={`${id}-panel-${item.id}`}
          class={!isActive ? "hidden" : ""}
          role="tabpanel"
          aria-labelledby={`${id}-item-${item.id}`}
        >
          {item.content}
        </div>
      );
    });
  };

  // Vertical layout wrapper
  if (variant === "vertical") {
    return (
      <div
        class={cn("flex gap-x-4", className)}
        id={id}
        {...eventTypeAttr}
        {...rest}
      >
        <nav
          class={tablistClasses}
          aria-label="Tabs"
          role="tablist"
          aria-orientation="vertical"
        >
          {items && items.length > 0 ? renderTabButtons() : children}
        </nav>

        <div class={cn("grow", contentClassName)}>
          {items && items.length > 0 ? renderTabPanels() : null}
        </div>
      </div>
    ) as Pulse.JSX.Element;
  }

  // Horizontal layouts (underline, pills, enclosed)
  return (
    <div class={cn("w-full", className)} id={id} {...rest}>
      <div class={tablistWrapperClasses}>
        <nav
          class={tablistClasses}
          aria-label="Tabs"
          role="tablist"
          aria-orientation="horizontal"
          {...eventTypeAttr}
        >
          {items && items.length > 0 ? renderTabButtons() : children}
        </nav>
      </div>

      <div class={cn("mt-3", contentClassName)}>
        {items && items.length > 0 ? renderTabPanels() : null}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
