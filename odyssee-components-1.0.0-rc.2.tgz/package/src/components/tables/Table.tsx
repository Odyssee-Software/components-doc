/**
 * Table Component
 * A comprehensive data table component with sorting, filtering, pagination, and selection
 *
 * @example
 * ```tsx
 * import { Table } from '@odyssee/components';
 *
 * // Basic table
 * const columns = [
 *   { key: 'name', label: 'Name', sortable: true },
 *   { key: 'age', label: 'Age', align: 'center' },
 *   { key: 'address', label: 'Address' },
 * ];
 *
 * const data = [
 *   { id: 1, name: 'John Brown', age: 45, address: 'New York' },
 *   { id: 2, name: 'Jim Green', age: 27, address: 'London' },
 * ];
 *
 * <Table columns={columns} data={data} />
 *
 * // Striped + Hoverable
 * <Table columns={columns} data={data} variant="striped" hoverable />
 *
 * // With selection
 * const selected = Pulse.signal<number[]>([]);
 * <Table
 *   columns={columns}
 *   data={data}
 *   selectable
 *   selectedRows={selected}
 *   onSelectionChange={(sel) => selected(sel)}
 * />
 *
 * // With sorting
 * const sortBy = Pulse.signal<string | null>(null);
 * const sortDirection = Pulse.signal<'asc' | 'desc' | null>(null);
 * <Table
 *   columns={columns}
 *   data={data}
 *   sortable
 *   sortBy={sortBy}
 *   sortDirection={sortDirection}
 *   onSort={(col, dir) => {
 *     sortBy(col);
 *     sortDirection(dir);
 *   }}
 * />
 *
 * // With search + pagination
 * const search = Pulse.signal('');
 * const page = Pulse.signal(1);
 * <Table
 *   columns={columns}
 *   data={data}
 *   searchable
 *   searchValue={search}
 *   onSearch={(val) => search(val)}
 *   paginated
 *   currentPage={page}
 *   pageSize={10}
 *   totalPages={5}
 *   onPageChange={(p) => page(p)}
 * />
 *
 * // With custom cell renderers
 * const columns = [
 *   {
 *     key: 'user',
 *     label: 'User',
 *     render: (_, row) => (
 *       <div class="flex items-center gap-2">
 *         <Avatar src={row.avatar} size="sm" />
 *         <span>{row.name}</span>
 *       </div>
 *     )
 *   },
 *   {
 *     key: 'status',
 *     label: 'Status',
 *     render: (value) => (
 *       <Badge color={value === 'active' ? 'success' : 'danger'}>
 *         {value}
 *       </Badge>
 *     )
 *   },
 * ];
 *
 * // Loading state
 * const loading = Pulse.signal(false);
 * <Table columns={columns} data={data} loading={loading} loadingRows={5} />
 *
 * // Bordered + Rounded + Gray header
 * <Table
 *   columns={columns}
 *   data={data}
 *   variant="bordered"
 *   theadVariant="gray"
 *   size="lg"
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { TableProps, TableColumn, TableSortDirection } from "../../types";
import { cn, generateId, isSignal } from "../../utils";
import { Checkbox } from "../forms/Checkbox";
import { Input } from "../forms/Input";
import { Pagination } from "../navigation/Pagination";
import { Skeleton } from "../base/Skeleton";

export const Table = <T extends Record<string, any> = Record<string, any>>(
  props: TableProps<T>,
): Pulse.JSX.Element => {
  const {
    // Data
    columns,
    data,

    // Variants & Styling
    variant = "default",
    theadVariant = "default",
    size = "md",
    hoverable = false,

    // Features
    selectable = false,
    selectedRows: selectedRowsProp,
    onSelectionChange,

    sortable = false,
    sortBy: sortByProp,
    sortDirection: sortDirectionProp,
    onSort,

    searchable = false,
    searchValue: searchValueProp,
    searchPlaceholder = "Search...",
    onSearch,

    paginated = false,
    currentPage: currentPageProp,
    pageSize = 10,
    totalPages = 1,
    onPageChange,

    // Anatomy
    caption,
    showFooter = false,
    footerContent,
    headless = false,

    // Loading & Empty states
    loading: loadingProp = false,
    loadingRows = 5,
    emptyMessage = "No data available",

    // Events
    onRowClick,

    // Advanced
    rowClassName,
    rowKey = "id" as keyof T,

    className,
    id = generateId("table"),
    style,
    ...rest
  } = props;

  // Internal signals
  const internalSelectedRows = Pulse.signal<(string | number)[]>([]);
  const internalSortBy = Pulse.signal<string | null>(null);
  const internalSortDirection = Pulse.signal<TableSortDirection>(null);
  const internalSearchValue = Pulse.signal("");
  const internalCurrentPage = Pulse.signal(1);

  // Get reactive values
  const getSelectedRows = () => {
    if (selectedRowsProp !== undefined) {
      return isSignal(selectedRowsProp)
        ? (selectedRowsProp as any)()
        : selectedRowsProp;
    }
    return internalSelectedRows();
  };

  const getSortBy = () => {
    if (sortByProp !== undefined) {
      return isSignal(sortByProp) ? (sortByProp as any)() : sortByProp;
    }
    return internalSortBy();
  };

  const getSortDirection = () => {
    if (sortDirectionProp !== undefined) {
      return isSignal(sortDirectionProp)
        ? (sortDirectionProp as any)()
        : sortDirectionProp;
    }
    return internalSortDirection();
  };

  const getSearchValue = () => {
    if (searchValueProp !== undefined) {
      return isSignal(searchValueProp)
        ? (searchValueProp as any)()
        : searchValueProp;
    }
    return internalSearchValue();
  };

  const getCurrentPage = () => {
    if (currentPageProp !== undefined) {
      return isSignal(currentPageProp)
        ? (currentPageProp as any)()
        : currentPageProp;
    }
    return internalCurrentPage();
  };

  const getLoading = () => {
    return isSignal(loadingProp) ? (loadingProp as any)() : loadingProp;
  };

  // Update internal signals
  const setSelectedRows = (value: (string | number)[]) => {
    if (selectedRowsProp === undefined) {
      internalSelectedRows(value);
    }
    if (onSelectionChange) {
      onSelectionChange(value);
    }
  };

  const setSortBy = (column: string | null) => {
    if (sortByProp === undefined) {
      internalSortBy(column);
    }
  };

  const setSortDirection = (direction: TableSortDirection) => {
    if (sortDirectionProp === undefined) {
      internalSortDirection(direction);
    }
  };

  const setSearchValue = (value: string) => {
    if (searchValueProp === undefined) {
      internalSearchValue(value);
    }
    if (onSearch) {
      onSearch(value);
    }
  };

  const setCurrentPage = (page: number) => {
    if (currentPageProp === undefined) {
      internalCurrentPage(page);
    }
    if (onPageChange) {
      onPageChange(page);
    }
  };

  // Size classes
  const sizeClasses = {
    sm: "px-4 py-2",
    md: "px-6 py-3",
    lg: "px-8 py-4",
  };

  const cellSizeClasses = {
    sm: "px-4 py-2",
    md: "px-6 py-4",
    lg: "px-8 py-5",
  };

  // Variant classes for container
  const getContainerClasses = () => {
    const base: string[] = [];

    if (
      variant === "bordered" ||
      variant === "rounded" ||
      variant === "shadow"
    ) {
      base.push("border border-gray-200 dark:border-neutral-700");
    }

    if (variant === "rounded" || variant === "shadow") {
      base.push("rounded-lg");
    }

    if (variant === "shadow") {
      base.push("shadow-xs dark:shadow-gray-900");
    }

    if (searchable || paginated) {
      base.push("divide-y divide-gray-200 dark:divide-neutral-700");
    }

    return base.join(" ");
  };

  // Thead classes
  const getTheadClasses = () => {
    if (theadVariant === "gray") {
      return "bg-gray-50 dark:bg-neutral-700";
    }
    return "";
  };

  const getTheadRowClasses = () => {
    if (theadVariant === "divided") {
      return "divide-x divide-gray-200 dark:divide-neutral-700";
    }
    return "";
  };

  // Row classes
  const getRowClasses = (row: T, index: number) => {
    const classes: string[] = [];

    if (variant === "striped") {
      classes.push(
        "odd:bg-white even:bg-gray-100 dark:odd:bg-neutral-900 dark:even:bg-neutral-800",
      );
    }

    if (hoverable) {
      if (variant === "striped") {
        classes.push("hover:bg-gray-100 dark:hover:bg-neutral-700");
      } else {
        classes.push("hover:bg-gray-100 dark:hover:bg-neutral-700");
      }
    }

    if (onRowClick) {
      classes.push("cursor-pointer");
    }

    if (rowClassName) {
      classes.push(rowClassName(row, index));
    }

    return classes.join(" ");
  };

  // Selection handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = data.map((row) => row[rowKey] as string | number);
      setSelectedRows(allIds);
    } else {
      setSelectedRows([]);
    }
  };

  const handleSelectRow = (rowId: string | number, checked: boolean) => {
    const selected = getSelectedRows();
    if (checked) {
      setSelectedRows([...selected, rowId]);
    } else {
      setSelectedRows(selected.filter((id: string | number) => id !== rowId));
    }
  };

  const isRowSelected = (rowId: string | number) => {
    return getSelectedRows().includes(rowId);
  };

  const areAllRowsSelected = () => {
    return data.length > 0 && getSelectedRows().length === data.length;
  };

  // Sort handlers
  const handleSort = (column: TableColumn<T>) => {
    if (!column.sortable && !sortable) return;

    const currentSortBy = getSortBy();
    const currentDirection = getSortDirection();

    let newDirection: TableSortDirection = "asc";

    if (currentSortBy === column.key) {
      if (currentDirection === "asc") {
        newDirection = "desc";
      } else if (currentDirection === "desc") {
        newDirection = null;
      }
    }

    setSortBy(newDirection === null ? null : column.key);
    setSortDirection(newDirection);

    if (onSort) {
      onSort(column.key, newDirection);
    }
  };

  // Sort icon
  const renderSortIcon = (column: TableColumn<T>) => {
    if (!column.sortable && !sortable) return null;

    const currentSortBy = getSortBy();
    const currentDirection = getSortDirection();

    if (currentSortBy !== column.key || currentDirection === null) {
      return (
        <svg
          class="size-3.5 ms-1.5 inline-block text-gray-400"
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="m7 15 5 5 5-5"></path>
          <path d="m7 9 5-5 5 5"></path>
        </svg>
      );
    }

    if (currentDirection === "asc") {
      return (
        <svg
          class="size-3.5 ms-1.5 inline-block text-gray-800 dark:text-neutral-200"
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="m7 15 5 5 5-5"></path>
          <path d="m7 9 5-5 5 5"></path>
        </svg>
      );
    }

    return (
      <svg
        class="size-3.5 ms-1.5 inline-block text-gray-800 dark:text-neutral-200"
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      >
        <path d="m7 15 5 5 5-5"></path>
        <path d="m7 9 5-5 5 5"></path>
      </svg>
    );
  };

  // Cell alignment
  const getAlignClass = (align?: "start" | "center" | "end") => {
    return align === "center"
      ? "text-center"
      : align === "end"
        ? "text-end"
        : "text-start";
  };

  // Render cell content
  const renderCellContent = (column: TableColumn<T>, row: T, index: number) => {
    if (column.render) {
      return column.render(row[column.key], row, index);
    }
    return String(row[column.key] ?? "");
  };

  // Render loading skeleton rows
  const renderLoadingRows = () => {
    return Array.from({ length: loadingRows }).map((_, index) => (
      <tr key={`loading-${index}`}>
        {selectable && (
          <td class={cn(cellSizeClasses[size])}>
            <Skeleton className="h-4 w-4" />
          </td>
        )}
        {columns.map((_, colIndex) => (
          <td
            key={`loading-${index}-col-${colIndex}`}
            class={cn(cellSizeClasses[size], "whitespace-nowrap")}
          >
            <Skeleton className="h-4 w-full" />
          </td>
        ))}
      </tr>
    ));
  };

  // Render empty state
  const renderEmptyState = () => {
    return (
      <tr>
        <td
          colSpan={columns.length + (selectable ? 1 : 0)}
          class="px-6 py-8 text-center"
        >
          <div class="flex flex-col items-center justify-center text-gray-500 dark:text-neutral-500">
            {typeof emptyMessage === "string" ? (
              <p class="text-sm">{emptyMessage}</p>
            ) : (
              emptyMessage
            )}
          </div>
        </td>
      </tr>
    );
  };

  // Render table body rows
  const renderRows = () => {
    if (getLoading()) {
      return renderLoadingRows();
    }

    if (data.length === 0) {
      return renderEmptyState();
    }

    return data.map((row, index) => {
      const rowId = row[rowKey] as string | number;
      const selected = isRowSelected(rowId);

      return (
        <tr
          key={rowId ?? index}
          class={getRowClasses(row, index)}
          onClick={() => onRowClick && onRowClick(row, index)}
        >
          {selectable && (
            <td
              class={cn(cellSizeClasses[size].replace("py-4", "py-3"), "ps-4")}
            >
              <div class="flex items-center h-5">
                <Checkbox
                  checked={selected}
                  onChange={(checked) => handleSelectRow(rowId, checked)}
                  aria-label={`Select row ${index + 1}`}
                />
              </div>
            </td>
          )}
          {columns.map((column) => (
            <td
              key={column.key}
              class={cn(
                cellSizeClasses[size],
                "whitespace-nowrap text-sm",
                getAlignClass(column.align),
                column.key === columns[0].key && !selectable
                  ? "font-medium text-gray-800 dark:text-neutral-200"
                  : "text-gray-800 dark:text-neutral-200",
                column.className,
              )}
              style={column.width ? { width: column.width } : undefined}
            >
              {renderCellContent(column, row, index)}
            </td>
          ))}
        </tr>
      );
    });
  };

  return (
    <div class="flex flex-col" id={id} style={style} {...rest}>
      <div class="-m-1.5 overflow-x-auto">
        <div class="p-1.5 min-w-full inline-block align-middle">
          <div class={cn("overflow-hidden", getContainerClasses(), className)}>
            {/* Search input */}
            {searchable && (
              <div class="py-3 px-4">
                <div class="relative max-w-xs">
                  <Input
                    type="text"
                    value={getSearchValue()}
                    placeholder={searchPlaceholder}
                    onChange={(value: string) => setSearchValue(value)}
                    className="py-1.5 sm:py-2 px-3 ps-9"
                    size="sm"
                  />
                  <div class="absolute inset-y-0 start-0 flex items-center pointer-events-none ps-3">
                    <svg
                      class="size-4 text-gray-400 dark:text-neutral-500"
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      stroke-width="2"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    >
                      <circle cx="11" cy="11" r="8"></circle>
                      <path d="m21 21-4.3-4.3"></path>
                    </svg>
                  </div>
                </div>
              </div>
            )}

            {/* Table */}
            <div class="overflow-hidden">
              <table class="min-w-full divide-y divide-gray-200 dark:divide-neutral-700">
                {caption && (
                  <caption class="py-2 text-start text-sm text-gray-600 dark:text-neutral-500">
                    {caption}
                  </caption>
                )}

                {/* Thead */}
                {!headless && (
                  <thead class={getTheadClasses()}>
                    <tr class={getTheadRowClasses()}>
                      {selectable && (
                        <th
                          scope="col"
                          class={cn(
                            sizeClasses[size].replace("py-3", "py-3"),
                            "ps-4 pe-0",
                          )}
                        >
                          <div class="flex items-center h-5">
                            <Checkbox
                              checked={areAllRowsSelected()}
                              onChange={(checked) => handleSelectAll(checked)}
                              aria-label="Select all rows"
                            />
                          </div>
                        </th>
                      )}
                      {columns.map((column) => (
                        <th
                          key={column.key}
                          scope="col"
                          class={cn(
                            sizeClasses[size],
                            "text-xs font-medium uppercase",
                            getAlignClass(column.align),
                            theadVariant === "gray"
                              ? "text-gray-500 dark:text-neutral-400"
                              : "text-gray-500 dark:text-neutral-500",
                            (column.sortable || sortable) &&
                              "cursor-pointer select-none",
                            column.headerClassName,
                          )}
                          onClick={() => handleSort(column)}
                        >
                          {column.headerRender ? (
                            column.headerRender()
                          ) : (
                            <>
                              {column.label}
                              {renderSortIcon(column)}
                            </>
                          )}
                        </th>
                      ))}
                    </tr>
                  </thead>
                )}

                {/* Tbody */}
                <tbody
                  class={
                    variant === "striped"
                      ? ""
                      : "divide-y divide-gray-200 dark:divide-neutral-700"
                  }
                >
                  {renderRows()}
                </tbody>

                {/* Tfoot */}
                {showFooter && footerContent && <tfoot>{footerContent}</tfoot>}
              </table>
            </div>

            {/* Pagination */}
            {paginated && (
              <div class="py-1 px-4">
                <Pagination
                  currentPage={getCurrentPage()}
                  totalPages={totalPages}
                  onPageChange={(page) => setCurrentPage(page)}
                  size="sm"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};

export default Table;
