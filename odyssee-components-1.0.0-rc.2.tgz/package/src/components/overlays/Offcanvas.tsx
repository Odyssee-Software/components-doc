/**
 * Offcanvas Component
 * A sliding panel (drawer) that can be positioned on any side of the screen
 *
 * @example
 * ```tsx
 * import { Offcanvas } from '@odyssee/components';
 *
 * // Basic offcanvas from right
 * const isOpen = Pulse.signal(false);
 * <Offcanvas
 *   isOpen={isOpen}
 *   title="Offcanvas Title"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>This is the offcanvas content</p>
 * </Offcanvas>
 *
 * // From left
 * <Offcanvas
 *   isOpen={isOpen}
 *   placement="left"
 *   title="Left Panel"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>Content from left side</p>
 * </Offcanvas>
 *
 * // From top
 * <Offcanvas
 *   isOpen={isOpen}
 *   placement="top"
 *   size="lg"
 *   title="Top Panel"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>Content from top</p>
 * </Offcanvas>
 *
 * // No backdrop, allow body scroll
 * <Offcanvas
 *   isOpen={isOpen}
 *   placement="right"
 *   backdrop={false}
 *   bodyScroll={true}
 *   title="No Backdrop"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>Body can scroll, no backdrop</p>
 * </Offcanvas>
 *
 * // With footer
 * <Offcanvas
 *   isOpen={isOpen}
 *   title="With Footer"
 *   onClose={() => isOpen(false)}
 *   footer={
 *     <>
 *       <button onClick={() => isOpen(false)}>Cancel</button>
 *       <button onClick={handleSave}>Save</button>
 *     </>
 *   }
 * >
 *   <p>Offcanvas content</p>
 * </Offcanvas>
 *
 * // Custom backdrop color
 * <Offcanvas
 *   isOpen={isOpen}
 *   title="Custom Backdrop"
 *   backdropColor="bg-blue-950/90"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>Custom blue backdrop</p>
 * </Offcanvas>
 * ```
 */

import Pulse from "pulse-framework";
import type { OffcanvasProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Offcanvas: Pulse.Fn<OffcanvasProps> = (props) => {
  const {
    isOpen,
    placement = "right",
    size = "md",
    title,
    children,
    footer,
    showCloseButton = true,
    staticBackdrop = false,
    closeOnEscape = true,
    backdrop = true,
    backdropColor = "bg-black/50",
    bodyScroll = false,
    onClose,
    className,
    id = generateId("offcanvas"),
    ...rest
  } = props;

  // Size classes based on placement
  const sizeClasses = {
    horizontal: {
      xs: "max-w-xs",
      sm: "max-w-sm",
      md: "max-w-md",
      lg: "max-w-lg",
      xl: "max-w-xl",
      full: "max-w-full",
    },
    vertical: {
      xs: "max-h-32",
      sm: "max-h-40",
      md: "max-h-60",
      lg: "max-h-80",
      xl: "max-h-96",
      full: "max-h-full",
    },
  };

  // Placement-specific classes
  const placementClasses = {
    right: {
      position: "fixed top-0 end-0 h-full",
      width: sizeClasses.horizontal[size] + " w-full",
      border: "border-s",
      initial: "translate-x-full",
      open: "translate-x-0",
    },
    left: {
      position: "fixed top-0 start-0 h-full",
      width: sizeClasses.horizontal[size] + " w-full",
      border: "border-e",
      initial: "-translate-x-full",
      open: "translate-x-0",
    },
    top: {
      position: "fixed top-0 inset-x-0",
      width: "w-full " + sizeClasses.vertical[size],
      border: "border-b",
      initial: "-translate-y-full",
      open: "translate-y-0",
    },
    bottom: {
      position: "fixed bottom-0 inset-x-0",
      width: "w-full " + sizeClasses.vertical[size],
      border: "border-t",
      initial: "translate-y-full",
      open: "translate-y-0",
    },
  };

  const currentPlacement = placementClasses[placement];

  // Get reactive visibility
  const isVisible = () => (isSignal(isOpen) ? (isOpen as any)() : isOpen);

  // Handle close
  const handleClose = () => {
    if (onClose) {
      onClose();
    }
  };

  // Handle backdrop click
  const handleBackdropClick = () => {
    if (!staticBackdrop) {
      handleClose();
    }
  };

  // Handle escape key
  Pulse.effect(() => {
    if (!closeOnEscape) return;

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isVisible()) {
        handleClose();
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  });

  // Handle body scroll lock
  Pulse.effect(() => {
    if (isVisible() && !bodyScroll) {
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = "";
      };
    }
  });

  // Don't render if not visible
  if (!isVisible()) {
    return (<></>) as Pulse.JSX.Element;
  }

  return (
    <div class="fixed inset-0 z-[80] overflow-hidden" {...rest}>
      {/* Backdrop */}
      {backdrop && (
        <div
          class={cn(
            "fixed inset-0 transition-opacity duration-300",
            backdropColor,
          )}
          onClick={handleBackdropClick}
        />
      )}

      {/* Offcanvas Panel */}
      <div
        id={id}
        role="dialog"
        tabindex="-1"
        aria-modal="true"
        class={cn(
          currentPlacement.position,
          currentPlacement.width,
          currentPlacement.border,
          "transition-all duration-300 transform z-[90]",
          "bg-white border-gray-200 dark:bg-neutral-800 dark:border-neutral-700",
          "flex flex-col",
          isVisible() ? currentPlacement.open : currentPlacement.initial,
          className,
        )}
      >
        {/* Header */}
        {(title || showCloseButton) && (
          <div class="flex justify-between items-center py-3 px-4 border-b border-gray-200 dark:border-neutral-700 shrink-0">
            {title && (
              <h3 class="font-bold text-gray-800 dark:text-white">{title}</h3>
            )}
            {!title && <div />}

            {showCloseButton && (
              <button
                type="button"
                class="size-8 inline-flex justify-center items-center gap-x-2 rounded-full border border-transparent bg-gray-100 text-gray-800 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-700 dark:hover:bg-neutral-600 dark:text-neutral-400 dark:focus:bg-neutral-600 transition-colors"
                aria-label="Close"
                onClick={handleClose}
              >
                <span class="sr-only">Close</span>
                <svg
                  class="shrink-0 size-4"
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  stroke-width="2"
                  stroke-linecap="round"
                  stroke-linejoin="round"
                >
                  <path d="M18 6 6 18" />
                  <path d="m6 6 12 12" />
                </svg>
              </button>
            )}
          </div>
        )}

        {/* Body */}
        <div class="p-4 overflow-y-auto flex-1">{children}</div>

        {/* Footer */}
        {footer && (
          <div class="flex items-center justify-end gap-2 px-4 py-3 border-t border-gray-200 dark:border-neutral-700 shrink-0">
            {footer}
          </div>
        )}
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
