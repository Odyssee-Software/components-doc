/**
 * ContextMenu Component
 * A wrapper around Dropdown that provides right-click context menu functionality
 *
 * Features:
 * - Right-click (contextmenu) trigger
 * - All Dropdown features inherited (items, placement, nested menus, etc.)
 * - Works with any trigger element (div, card, button, etc.)
 * - Support for icons, dividers, nested submenus
 * - Dark mode support
 * - Customizable placement and styling
 */

import Pulse from "pulse-framework";
import type { ContextMenuProps } from "../../types";
import { Dropdown } from "./Dropdown";

export const ContextMenu: Pulse.Fn<ContextMenuProps> = (props) => {
  // All props pass through to Dropdown except we force triggerType to "contextmenu"
  return (
    <Dropdown {...(props as any)} triggerType="contextmenu" />
  ) as Pulse.JSX.Element;
};
