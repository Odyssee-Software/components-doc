/**
 * Tooltip Component
 * A lightweight tooltip component that displays helpful information on hover or focus
 *
 * @example
 * ```tsx
 * import { Tooltip } from '@odyssee/components';
 *
 * // Basic tooltip
 * <Tooltip content="Tooltip on top" placement="top">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * // Different placements
 * <Tooltip content="Tooltip on bottom" placement="bottom">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * <Tooltip content="Tooltip on left" placement="left">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * <Tooltip content="Tooltip on right" placement="right">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * // Auto positioning
 * <Tooltip content="Auto positioned" placement="auto">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * // Light variant
 * <Tooltip content="Light tooltip" variant="light">
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * // With delays
 * <Tooltip
 *   content="Delayed tooltip"
 *   showDelay={500}
 *   hideDelay={200}
 * >
 *   <button>Hover me</button>
 * </Tooltip>
 *
 * // Click trigger
 * <Tooltip content="Click to show" trigger="click">
 *   <button>Click me</button>
 * </Tooltip>
 * ```
 */

import Pulse from "pulse-framework";
import type { TooltipProps } from "../../types";
import { cn } from "../../utils";

export const Tooltip: Pulse.Fn<TooltipProps> = (props) => {
  const {
    content,
    placement = "top",
    trigger = "hover",
    children,
    showDelay = 0,
    hideDelay = 0,
    variant = "dark",
    arrow = false,
    className,
    id,
    style,
    ...rest
  } = props;

  // Variant classes
  const variantClasses = {
    dark: "bg-gray-900 text-white dark:bg-neutral-700",
    light: "bg-white text-gray-800 border border-gray-200 shadow-lg dark:bg-neutral-800 dark:border-neutral-700 dark:text-white",
  };

  // Placement data attribute
  const placementAttr = `[--placement:${placement}]`;

  return (
    <div class={cn("hs-tooltip inline-block", placementAttr)} {...rest}>
      {children}
      <span
        class={cn(
          "hs-tooltip-content hs-tooltip-shown:opacity-100 hs-tooltip-shown:visible opacity-0 transition-opacity inline-block absolute invisible z-10 py-1 px-2 text-xs font-medium rounded-md shadow-2xs",
          variantClasses[variant],
          className,
        )}
        role="tooltip"
        style={style}
      >
        {content}
      </span>
    </div>
  ) as Pulse.JSX.Element;
};
