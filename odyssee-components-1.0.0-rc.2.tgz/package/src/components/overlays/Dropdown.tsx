/**
 * Dropdown Component
 * A dropdown menu component with Preline and Floating UI integration
 *
 * @example
 * ```tsx
 * import { Dropdown } from '@odyssee/components';
 *
 * // Basic dropdown with items array
 * <Dropdown
 *   trigger="Actions"
 *   items={[
 *     { label: 'Newsletter', onClick: () => console.log('Newsletter') },
 *     { label: 'Purchases', href: '/purchases' },
 *     { isDivider: true },
 *     { label: 'Downloads', icon: <DownloadIcon /> }
 *   ]}
 * />
 *
 * // Custom trigger button
 * <Dropdown
 *   trigger={
 *     <button class="custom-button">
 *       <Avatar src="..." />
 *       <span>John Doe</span>
 *     </button>
 *   }
 *   items={[...]}
 * />
 *
 * // With children (flexible approach)
 * <Dropdown trigger="Actions">
 *   <DropdownItem>Newsletter</DropdownItem>
 *   <DropdownItem href="/purchases">Purchases</DropdownItem>
 *   <DropdownDivider />
 *   <DropdownItem icon={<Icon />}>Downloads</DropdownItem>
 * </Dropdown>
 *
 * // Different placements
 * <Dropdown
 *   trigger="Menu"
 *   placement="top-start"
 *   items={[...]}
 * />
 *
 * // Hover trigger
 * <Dropdown
 *   trigger="Hover me"
 *   triggerType="hover"
 *   items={[...]}
 * />
 *
 * // Auto-close behavior
 * <Dropdown
 *   trigger="Options"
 *   autoClose="outside"
 *   items={[...]}
 * />
 * ```
 */

import Pulse from "pulse-framework";
import type { DropdownProps, DropdownItem } from "../../types";
import { cn, generateId } from "../../utils";

export const Dropdown: Pulse.Fn<DropdownProps> = (props) => {
  const {
    trigger,
    triggerClassName,
    items,
    children,
    placement = "bottom",
    strategy = "fixed",
    offset = 10,
    flip = true,
    scope = "parent",
    triggerType = "click",
    autoClose = true,
    closeOnSelect = true,
    hasAutofocus = true,
    isOpen,
    menuClassName,
    onOpen,
    onClose,
    onSelect,
    className,
    id = generateId("dropdown"),
    ...rest
  } = props;

  // Build placement class
  const placementClass = `[--placement:${placement}]`;

  // Build strategy class
  const strategyClass = `[--strategy:${strategy}]`;

  // Build trigger class
  const triggerClass = `[--trigger:${triggerType}]`;

  // Build auto-close class
  const autoCloseClass =
    typeof autoClose === "boolean"
      ? `[--auto-close:${autoClose}]`
      : `[--auto-close:${autoClose}]`;

  // Build flip class
  const flipClass = `[--flip:${flip}]`;

  // Build offset class
  const offsetClass = `[--offset:${offset}]`;

  // Build has-autofocus class
  const autofocusClass = `[--has-autofocus:${hasAutofocus}]`;

  // Build scope class
  const scopeClass = `[--scope:${scope}]`;

  // Container classes
  const containerClasses = cn(
    "hs-dropdown relative inline-flex",
    placementClass,
    strategyClass,
    triggerClass,
    autoCloseClass,
    flipClass,
    offsetClass,
    autofocusClass,
    scopeClass,
    className,
  );

  // Chevron icon
  const ChevronIcon = () => (
    <svg
      class="hs-dropdown-open:rotate-180 size-4"
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
    >
      <path d="m6 9 6 6 6-6"></path>
    </svg>
  );

  // Render trigger button
  const renderTrigger = () => {
    if (typeof trigger === "string") {
      // Default button trigger
      return (
        <button
          id={`${id}-trigger`}
          type="button"
          class={cn(
            "hs-dropdown-toggle py-3 px-4 inline-flex items-center gap-x-2 text-sm font-medium rounded-lg border border-gray-200 bg-white text-gray-800 shadow-2xs hover:bg-gray-50 focus:outline-hidden focus:bg-gray-50 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-800 dark:border-neutral-700 dark:text-white dark:hover:bg-neutral-700 dark:focus:bg-neutral-700",
            triggerClassName,
          )}
          aria-haspopup="menu"
          aria-expanded="false"
          aria-label="Dropdown"
        >
          {trigger}
          <ChevronIcon />
        </button>
      );
    }

    // Custom trigger element - add hs-dropdown-toggle class
    const triggerElement = trigger as HTMLElement;
    if (triggerElement.classList) {
      triggerElement.classList.add("hs-dropdown-toggle");
    } else if (triggerElement.className) {
      triggerElement.className += " hs-dropdown-toggle";
    }
    if (triggerClassName) {
      if (triggerElement.classList) {
        triggerElement.classList.add(...triggerClassName.split(" "));
      } else if (triggerElement.className) {
        triggerElement.className += " " + triggerClassName;
      }
    }
    return triggerElement;
  };

  // Render dropdown items from array
  const renderItems = () => {
    if (!items || items.length === 0) return null;

    return items.map((item: DropdownItem) => {
      // Divider
      if (item.isDivider) {
        return <div class="border-t border-gray-200 dark:border-neutral-700" />;
      }

      // Regular item
      const itemClasses = cn(
        "flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-700 dark:hover:text-neutral-300 dark:focus:bg-neutral-700",
        item.disabled && "opacity-50 pointer-events-none cursor-not-allowed",
        item.className,
      );

      const handleItemClick = (e: Event) => {
        if (item.disabled) {
          e.preventDefault();
          return;
        }

        if (item.onClick) {
          item.onClick();
        }

        if (onSelect && item.value !== undefined) {
          onSelect(item.value);
        }

        // Close dropdown if closeOnSelect is true and it's not a link
        if (closeOnSelect && !item.href) {
          // Preline will handle closing
        }
      };

      if (item.href) {
        return (
          <a class={itemClasses} href={item.href} onClick={handleItemClick}>
            {item.icon && (
              <span class="shrink-0 inline-flex items-center">{item.icon}</span>
            )}
            {item.label}
          </a>
        );
      }

      return (
        <button
          type="button"
          class={itemClasses}
          onClick={handleItemClick}
          disabled={item.disabled}
        >
          {item.icon && (
            <span class="shrink-0 inline-flex items-center">{item.icon}</span>
          )}
          {item.label}
        </button>
      );
    });
  };

  // Menu classes
  const menuClasses = cn(
    "hs-dropdown-menu transition-[opacity,margin] duration hs-dropdown-open:opacity-100 opacity-0 hidden min-w-60 bg-white shadow-md rounded-lg mt-2 dark:bg-neutral-800 dark:border dark:border-neutral-700 dark:divide-neutral-700",
    "after:h-4 after:absolute after:-bottom-4 after:start-0 after:w-full before:h-4 before:absolute before:-top-4 before:start-0 before:w-full",
    menuClassName,
  );

  return (
    <div class={containerClasses} id={id} {...rest}>
      {renderTrigger()}

      <div
        class={menuClasses}
        role="menu"
        aria-orientation="vertical"
        aria-labelledby={`${id}-trigger`}
      >
        <div class="p-1 space-y-0.5">
          {items && items.length > 0 ? renderItems() : children}
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
