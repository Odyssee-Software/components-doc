/**
 * Modal Component
 * A flexible modal/dialog overlay component following Preline design patterns
 *
 * @example
 * ```tsx
 * import { Modal, Button } from '@odyssee/components';
 *
 * // Basic modal with reactive state
 * const isOpen = Pulse.signal(false);
 *
 * <Modal
 *   isOpen={isOpen}
 *   title="Modal Title"
 *   onClose={() => isOpen(false)}
 * >
 *   <p>This is the modal content</p>
 * </Modal>
 *
 * // With footer actions
 * <Modal
 *   isOpen={isOpen}
 *   title="Confirm Action"
 *   onClose={() => isOpen(false)}
 *   footer={
 *     <>
 *       <Button variant="outline" onClick={() => isOpen(false)}>Close</Button>
 *       <Button variant="solid" color="primary" onClick={handleSave}>Save changes</Button>
 *     </>
 *   }
 * >
 *   <p>Are you sure you want to proceed?</p>
 * </Modal>
 *
 * // Different sizes
 * <Modal isOpen={isOpen} title="Large Modal" size="lg" onClose={() => isOpen(false)}>
 *   <p>Large modal content</p>
 * </Modal>
 *
 * // Vertically centered
 * <Modal isOpen={isOpen} title="Centered" centered={true} onClose={() => isOpen(false)}>
 *   <p>Centered modal content</p>
 * </Modal>
 *
 * // Static backdrop (can't close by clicking outside)
 * <Modal isOpen={isOpen} title="Static" staticBackdrop={true} onClose={() => isOpen(false)}>
 *   <p>Click close button to dismiss</p>
 * </Modal>
 *
 * // Fullscreen
 * <Modal isOpen={isOpen} title="Fullscreen" fullscreen={true} onClose={() => isOpen(false)}>
 *   <p>Fullscreen content</p>
 * </Modal>
 *
 * // Scale animation
 * <Modal isOpen={isOpen} title="Animated" animation="scale" onClose={() => isOpen(false)}>
 *   <p>Modal with scale animation</p>
 * </Modal>
 * ```
 */

import Pulse from "pulse-framework";
import type { ModalProps } from "../../types";
import { cn, isSignal, generateId } from "../../utils";

export const Modal: Pulse.Fn<ModalProps> = (props) => {
  const {
    isOpen,
    title,
    children,
    footer,
    size = "md",
    centered = false,
    staticBackdrop = false,
    fullscreen = false,
    showCloseButton = true,
    closeOnEscape = true,
    animation = "slideDown",
    onClose,
    className,
    id = generateId("modal"),
    ...rest
  } = props;

  // Get open state
  const getIsOpen = () => (isSignal(isOpen) ? (isOpen as any)() : isOpen);

  // Size classes (Preline style)
  const sizeClasses = {
    sm: "sm:max-w-lg",
    md: "md:max-w-2xl",
    lg: "lg:max-w-4xl",
    xl: "xl:max-w-6xl",
    "2xl": "2xl:max-w-7xl",
  };

  // Animation classes based on variant
  const getAnimationClasses = () => {
    if (animation === "scale") {
      return {
        container: "hs-overlay-animation-target",
        open: "hs-overlay-open:scale-100 hs-overlay-open:opacity-100",
        closed: "scale-95 opacity-0",
        transition: "ease-in-out transition-all duration-200",
      };
    }
    if (animation === "slideDown") {
      return {
        container: "",
        open: "hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500",
        closed: "mt-0 opacity-0",
        transition: "ease-out transition-all",
      };
    }
    if (animation === "slideUp") {
      return {
        container: "",
        open: "hs-overlay-open:mt-7 hs-overlay-open:opacity-100 hs-overlay-open:duration-500",
        closed: "mt-14 opacity-0",
        transition: "ease-out transition-all",
      };
    }
    return {
      container: "",
      open: "hs-overlay-open:opacity-100",
      closed: "opacity-0",
      transition: "transition-opacity duration-300",
    };
  };

  const animClasses = getAnimationClasses();

  // Handle backdrop click
  const handleBackdropClick = (e: Event) => {
    if (!staticBackdrop && onClose && e.target === e.currentTarget) {
      onClose();
    }
  };

  // Handle close button click
  const handleClose = () => {
    if (onClose) {
      onClose();
    }
  };

  // Handle escape key
  Pulse.effect(() => {
    if (!closeOnEscape) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && getIsOpen() && onClose) {
        onClose();
      }
    };

    if (getIsOpen()) {
      document.addEventListener("keydown", handleKeyDown);
      // Prevent body scroll
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  });

  return (
    <div
      id={id}
      class={cn(
        "hs-overlay size-full fixed top-0 start-0 z-80 overflow-x-hidden overflow-y-auto pointer-events-none",
        getIsOpen() ? "hs-overlay-open" : "hidden",
        staticBackdrop && "[--overlay-backdrop:static]",
      )}
      role="dialog"
      tabindex="-1"
      aria-labelledby={`${id}-label`}
      onClick={handleBackdropClick}
      {...rest}
    >
      {/* Modal Dialog Container */}
      <div
        class={cn(
          "sm:w-full m-3 sm:mx-auto",
          animClasses.container,
          animClasses.open,
          animClasses.closed,
          animClasses.transition,
          centered && "min-h-[calc(100%-56px)] flex items-center",
          fullscreen ? "max-w-full max-h-full h-full" : sizeClasses[size],
        )}
      >
        {/* Modal Content */}
        <div
          class={cn(
            "flex flex-col bg-white border border-gray-200 shadow-2xs rounded-xl pointer-events-auto dark:bg-neutral-800 dark:border-neutral-700 dark:shadow-neutral-700/70",
            fullscreen && "max-w-full max-h-full h-full rounded-none",
            centered && "w-full",
            className,
          )}
          onClick={(e: Event) => e.stopPropagation()}
        >
          {/* Header */}
          {(title || showCloseButton) && (
            <div class="flex justify-between items-center py-3 px-4 border-b border-gray-200 dark:border-neutral-700">
              {title && (
                <h3
                  id={`${id}-label`}
                  class="font-bold text-gray-800 dark:text-white"
                >
                  {title}
                </h3>
              )}
              {showCloseButton && (
                <button
                  type="button"
                  class="size-8 inline-flex justify-center items-center gap-x-2 rounded-full border border-transparent bg-gray-100 text-gray-800 hover:bg-gray-200 focus:outline-none focus:bg-gray-200 disabled:opacity-50 disabled:pointer-events-none dark:bg-neutral-700 dark:hover:bg-neutral-600 dark:text-neutral-400 dark:focus:bg-neutral-600"
                  aria-label="Close"
                  onClick={handleClose}
                >
                  <span class="sr-only">Close</span>
                  <svg
                    class="shrink-0 size-4"
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="2"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  >
                    <path d="M18 6 6 18"></path>
                    <path d="m6 6 12 12"></path>
                  </svg>
                </button>
              )}
            </div>
          )}

          {/* Body */}
          <div class="p-4 overflow-y-auto">{children}</div>

          {/* Footer */}
          {footer && (
            <div class="flex justify-end items-center gap-x-2 py-3 px-4 border-t border-gray-200 dark:border-neutral-700">
              {footer}
            </div>
          )}
        </div>
      </div>
    </div>
  ) as Pulse.JSX.Element;
};
