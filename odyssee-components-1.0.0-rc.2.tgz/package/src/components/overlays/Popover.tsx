/**
 * Popover Component
 * A wrapper around Tooltip that supports rich content with header, body, and footer
 *
 * @example
 * ```tsx
 * import { Popover } from '@odyssee/components';
 *
 * // Basic popover with simple content
 * <Popover content="Simple popover content">
 *   <button>Click me</button>
 * </Popover>
 *
 * // Rich popover with header, body, footer
 * <Popover
 *   header="Popover Title"
 *   body="This is the popover content with more details."
 *   footer={<button>Action</button>}
 *   placement="top"
 * >
 *   <button>Click me</button>
 * </Popover>
 *
 * // Review popover example
 * <Popover
 *   header={<h4>5.0 ⭐⭐⭐⭐⭐</h4>}
 *   body={
 *     <div>
 *       <Progress value={78} label="5 star" />
 *       <Progress value={20} label="4 star" />
 *     </div>
 *   }
 *   footer={<a href="#">How reviews work</a>}
 *   maxWidth="sm"
 * >
 *   <button>View reviews</button>
 * </Popover>
 *
 * // User popover example
 * <Popover
 *   header={
 *     <div class="flex items-center gap-x-3">
 *       <Avatar src="..." />
 *       <div>
 *         <h4>Amanda Harvey</h4>
 *         <p>Storyteller</p>
 *       </div>
 *     </div>
 *   }
 *   body={
 *     <ul>
 *       <li>Company: Pixeel Ltd.</li>
 *       <li>Phone: (892) 312-5483</li>
 *       <li>Email: amanda@email.com</li>
 *     </ul>
 *   }
 *   footer={<button>Follow</button>}
 * >
 *   <div>User Card</div>
 * </Popover>
 *
 * // Different placements
 * <Popover content="Left popover" placement="left">
 *   <button>Left</button>
 * </Popover>
 *
 * <Popover content="Right popover" placement="right">
 *   <button>Right</button>
 * </Popover>
 *
 * // Auto positioning
 * <Popover content="Auto positioned" placement="auto">
 *   <button>Auto</button>
 * </Popover>
 *
 * // Hover trigger (like tooltip)
 * <Popover content="Hover me" trigger="hover">
 *   <button>Hover</button>
 * </Popover>
 *
 * // Focus trigger
 * <Popover content="Focus me" trigger="focus">
 *   <button>Focus</button>
 * </Popover>
 * ```
 */

import Pulse from "pulse-framework";
import type { PopoverProps } from "../../types";
import { cn } from "../../utils";
import { Tooltip } from "./Tooltip";

export const Popover: Pulse.Fn<PopoverProps> = (props) => {
  const {
    header,
    body,
    footer,
    content,
    trigger = "click", // Default to click for popovers
    placement = "top",
    maxWidth = "xs",
    children,
    className,
    ...rest
  } = props;

  // Max-width classes
  const maxWidthClasses = {
    xs: "max-w-xs",
    sm: "max-w-sm",
    md: "max-w-md",
    lg: "max-w-lg",
    xl: "max-w-xl",
    "2xl": "max-w-2xl",
  };

  // If simple content is provided, use it directly
  if (content && !header && !body && !footer) {
    return (
      <Tooltip
        content={content as any}
        trigger={trigger}
        placement={placement}
        variant="light"
        className={cn(
          "py-3 px-4 text-sm text-gray-600 dark:text-neutral-400",
          maxWidthClasses[maxWidth],
          className,
        )}
        {...rest}
      >
        {children}
      </Tooltip>
    ) as Pulse.JSX.Element;
  }

  // Build rich content structure
  const richContent = (
    <div class={cn("w-full", maxWidthClasses[maxWidth])}>
      {header && (
        <div class="py-3 px-4 border-b border-gray-200 dark:border-neutral-700">
          {typeof header === "string" ? (
            <span class="block text-lg font-bold text-gray-800 dark:text-white">
              {header}
            </span>
          ) : (
            header
          )}
        </div>
      )}

      {body && (
        <div class="py-3 px-4 text-sm text-gray-600 dark:text-neutral-400">
          {body}
        </div>
      )}

      {footer && (
        <div class="py-2 px-4 flex justify-between items-center bg-gray-100 dark:bg-neutral-800">
          {footer}
        </div>
      )}
    </div>
  ) as Pulse.JSX.Element;

  return (
    <Tooltip
      content={richContent as any}
      trigger={trigger}
      placement={placement}
      variant="light"
      className={cn(
        "text-start rounded-lg shadow-md",
        !header && !body && !footer && "py-3 px-4",
        className,
      )}
      {...rest}
    >
      {children}
    </Tooltip>
  ) as Pulse.JSX.Element;
};
