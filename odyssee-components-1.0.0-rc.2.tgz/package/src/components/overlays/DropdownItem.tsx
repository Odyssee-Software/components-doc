/**
 * DropdownItem and DropdownDivider Components
 * Helper components for flexible dropdown content composition
 *
 * @example
 * ```tsx
 * import { Dropdown, DropdownItem, DropdownDivider } from '@odyssee/components';
 *
 * // Basic usage
 * <Dropdown trigger="Menu">
 *   <DropdownItem>Newsletter</DropdownItem>
 *   <DropdownItem href="/purchases">Purchases</DropdownItem>
 *   <DropdownDivider />
 *   <DropdownItem onClick={() => console.log('clicked')}>Downloads</DropdownItem>
 * </Dropdown>
 *
 * // With icons
 * <Dropdown trigger="Actions">
 *   <DropdownItem icon={<BellIcon />}>Newsletter</DropdownItem>
 *   <DropdownItem icon={<CartIcon />}>Purchases</DropdownItem>
 * </Dropdown>
 *
 * // With disabled state
 * <Dropdown trigger="Options">
 *   <DropdownItem>Active Item</DropdownItem>
 *   <DropdownItem disabled>Disabled Item</DropdownItem>
 * </Dropdown>
 *
 * // With active state
 * <Dropdown trigger="Menu">
 *   <DropdownItem active>Current Page</DropdownItem>
 *   <DropdownItem>Other Page</DropdownItem>
 * </Dropdown>
 * ```
 */

import Pulse from "pulse-framework";
import type { DropdownItemProps, DropdownDividerProps } from "../../types";
import { cn } from "../../utils";

/**
 * DropdownItem Component
 */
export const DropdownItem: Pulse.Fn<DropdownItemProps> = (props) => {
  const {
    children,
    icon,
    href,
    disabled = false,
    active = false,
    onClick,
    className,
    ...rest
  } = props;

  // Item classes
  const itemClasses = cn(
    "flex items-center gap-x-3.5 py-2 px-3 rounded-lg text-sm text-gray-800 hover:bg-gray-100 focus:outline-hidden focus:bg-gray-100 dark:text-neutral-400 dark:hover:bg-neutral-700 dark:hover:text-neutral-300 dark:focus:bg-neutral-700",
    disabled && "opacity-50 pointer-events-none cursor-not-allowed",
    active && "bg-gray-100 dark:bg-neutral-700",
    className,
  );

  const handleClick = (e: Event) => {
    if (disabled) {
      e.preventDefault();
      return;
    }

    if (onClick) {
      onClick();
    }
  };

  // Render as link if href is provided
  if (href) {
    return (
      <a class={itemClasses} href={href} onClick={handleClick} {...rest}>
        {icon && <span class="shrink-0 inline-flex items-center">{icon}</span>}
        {children}
      </a>
    ) as Pulse.JSX.Element;
  }

  // Render as button
  return (
    <button
      type="button"
      class={itemClasses}
      onClick={handleClick}
      disabled={disabled}
      {...rest}
    >
      {icon && <span class="shrink-0 inline-flex items-center">{icon}</span>}
      {children}
    </button>
  ) as Pulse.JSX.Element;
};

/**
 * DropdownDivider Component
 */
export const DropdownDivider: Pulse.Fn<DropdownDividerProps> = (props) => {
  const { className, ...rest } = props;

  return (
    <div
      class={cn(
        "my-1 border-t border-gray-200 dark:border-neutral-700",
        className,
      )}
      {...rest}
    />
  ) as Pulse.JSX.Element;
};
