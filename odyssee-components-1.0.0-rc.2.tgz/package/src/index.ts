/**
 * Odyssee Components
 * A comprehensive UI component library built with Pulse Framework and styled with Tailwind CSS + Preline
 */

// Import styles
import "./styles.css";

// Types
export * from "./types";
export * from "./utils";

// Base Components
export { Button } from "./components/base/Button";
export { Alert } from "./components/base/Alert";
export { Badge } from "./components/base/Badge";
export { Card } from "./components/base/Card";
export { Avatar } from "./components/base/Avatar";
export {
  AvatarGroup,
  StackAvatarGroup,
  GridAvatarGroup,
} from "./components/base/AvatarGroup";
export type {
  AvatarGroupProps,
  AvatarGroupItem,
} from "./components/base/AvatarGroup";
export {
  Blockquote,
  BorderedBlockquote,
  MinimalBlockquote,
} from "./components/base/Blockquote";
export type {
  BlockquoteProps,
  BlockquoteAuthor,
} from "./components/base/Blockquote";
export { Progress } from "./components/base/Progress";
export {
  ButtonGroup,
  HorizontalButtonGroup,
  VerticalButtonGroup,
  ToolbarButtonGroup,
  ResponsiveButtonGroup,
} from "./components/base/ButtonGroup";
export type {
  ButtonGroupProps,
  ButtonGroupItem,
} from "./components/base/ButtonGroup";
export {
  ChatBubble,
  ChatBubbleList,
  UserChatBubble,
  BotChatBubble,
} from "./components/base/ChatBubble";
export type {
  ChatBubbleProps,
  ChatBubbleListProps,
  ChatContentItem,
  ChatStatus,
} from "./components/base/ChatBubble";
export {
  Carousel,
  AutoPlayCarousel,
  ThumbnailCarousel,
} from "./components/base/Carousel";
export type { CarouselProps, CarouselSlide } from "./components/base/Carousel";
export {
  Collapse,
  CollapseContent,
  CollapseTrigger,
  ReadMoreCollapse,
} from "./components/base/Collapse";
export type {
  CollapseProps,
  CollapseContentProps,
  CollapseTriggerProps,
} from "./components/base/Collapse";
export {
  Divider,
  VerticalDivider,
  DividerWithText,
} from "./components/base/Divider";
export { DatePicker } from "./components/base/DatePicker";
export { Device, MobileDevice, BrowserDevice } from "./components/base/Device";
export { Icon } from "./components/base/Icon";
export { FileUploadProgress } from "./components/base/FileUploadProgress";
export { Spinner, ButtonSpinner } from "./components/base/Spinner";
export { Skeleton } from "./components/base/Skeleton";
export { List } from "./components/base/List";
export { ListGroup } from "./components/base/ListGroup";
export { Kbd } from "./components/base/Kbd";
export { Rating } from "./components/base/Rating";
export { LegendIndicator } from "./components/base/LegendIndicator";
export {
  Timeline,
  TimelineItem,
  TimelineHeading,
} from "./components/base/Timeline";
export { Toast } from "./components/base/Toast";
export {
  ToastContainer,
  TopRightToastContainer,
  TopCenterToastContainer,
  BottomRightToastContainer,
  BottomCenterToastContainer,
} from "./components/base/ToastContainer";
export type {
  ToastProps,
  ToastContainerProps,
  ToastType,
  ToastVariant,
  ToastPosition,
  ToastAction,
} from "./types";
export type {
  RatingProps,
  RatingMode,
  RatingSymbol,
  RatingSize,
} from "./types";
export type {
  TimelineProps,
  TimelineItemProps,
  TimelineHeadingProps,
  TimelineItemData,
  TimelineItemUser,
  TimelineGroup,
  TimelineItemIcon,
} from "./types";
export type {
  LegendIndicatorProps,
  LegendIndicatorSize,
  LegendIndicatorShape,
} from "./types";

// Layout Components
export { Container } from "./components/layout/Container";
export { Grid } from "./components/layout/Grid";
export { Columns } from "./components/layout/Columns";
export {
  H1,
  H2,
  H3,
  H4,
  H5,
  H6,
  Text,
  Lead,
  Muted,
  Small,
  Strong,
  Em,
  Mark,
  Del,
  Ins,
  Underline,
  Strikethrough,
  Code,
  Pre,
  GradientText,
} from "./components/layout/Typography";
export { Link } from "./components/layout/Link";
export { Image } from "./components/layout/Image";
export { LayoutSplitter } from "./components/layout/LayoutSplitter";
export { CustomScrollbar } from "./components/layout/CustomScrollbar";

// Form Components
export { Input } from "./components/forms/Input";
export { Select } from "./components/forms/Select";
export { Checkbox } from "./components/forms/Checkbox";
export { Radio } from "./components/forms/Radio";
export { RadioGroup } from "./components/forms/RadioGroup";
export { Toggle } from "./components/forms/Toggle";
export { Textarea } from "./components/forms/Textarea";
export { FileInput } from "./components/forms/FileInput";
export { RangeSlider } from "./components/forms/RangeSlider";
export { ColorPicker } from "./components/forms/ColorPicker";
export { TimePicker } from "./components/forms/TimePicker";
export { TogglePassword } from "./components/forms/TogglePassword";
export { InputNumber } from "./components/forms/InputNumber";
export { PinInput } from "./components/forms/PinInput";
export { CopyMarkup } from "./components/forms/CopyMarkup";
export { StrongPassword } from "./components/forms/StrongPassword";
export { ComboBox } from "./components/forms/ComboBox";
export { SearchBox } from "./components/forms/SearchBox";
export { ToggleCount, ToggleCountValue } from "./components/forms/ToggleCount";
export { FormGroup } from "./components/forms/FormGroup";
export { InputGroup } from "./components/forms/InputGroup";

// Overlay Components
export { Modal } from "./components/overlays/Modal";
export { Offcanvas } from "./components/overlays/Offcanvas";
export { Tooltip } from "./components/overlays/Tooltip";
export { Popover } from "./components/overlays/Popover";
export { Dropdown } from "./components/overlays/Dropdown";
export { ContextMenu } from "./components/overlays/ContextMenu";
export {
  DropdownItem,
  DropdownDivider,
} from "./components/overlays/DropdownItem";

// Navigation Components
export {
  Accordion,
  BasicAccordion,
  NoArrowAccordion,
  ArrowAccordion,
  StretchedAccordion,
  BorderedAccordion,
  ActiveBorderedAccordion,
  NestedAccordion,
} from "./components/navigation/Accordion";
export { Tabs } from "./components/navigation/Tabs";
export { TabPanel } from "./components/navigation/TabPanel";
export { TreeView } from "./components/navigation/TreeView";
export {
  Navbar,
  NavbarLink,
  DarkNavbar,
  PrimaryNavbar,
  StickyNavbar,
} from "./components/navigation/Navbar";
export type { NavbarProps, NavbarItem, NavbarBrand } from "./types";
export { Breadcrumb } from "./components/navigation/Breadcrumb";
export type { BreadcrumbProps, BreadcrumbItem } from "./types";
export { Pagination } from "./components/navigation/Pagination";
export type { PaginationProps } from "./types";
export { Stepper } from "./components/navigation/Stepper";
export { StepItem } from "./components/navigation/StepItem";
export { StepIndicator } from "./components/navigation/StepIndicator";
export type {
  StepperProps,
  StepItemProps,
  StepIndicatorProps,
  StepItemData,
  StepStatus,
  StepperMode,
  StepperOrientation,
  StepperVariant,
} from "./types";

// Table Components
export { Table } from "./components/tables/Table";
export type {
  TableProps,
  TableColumn,
  TableRow,
  TableVariant,
  TableTheadVariant,
  TableSize,
  TableSortDirection,
} from "./types";

// InputGroup types
export type { InputGroupProps, InputGroupAddon } from "./types";

// TimePicker types
export type { TimePickerProps } from "./types";

// TogglePassword types
export type { TogglePasswordProps } from "./types";

// InputNumber types
export type { InputNumberProps } from "./types";

// PinInput types
export type { PinInputProps } from "./types";

// CopyMarkup types
export type { CopyMarkupProps } from "./types";

// StrongPassword types
export type { StrongPasswordProps } from "./types";

// ComboBox types
export type { ComboBoxProps, ComboBoxOption } from "./types";

// SearchBox types
export type { SearchBoxProps, SearchBoxOption } from "./types";

// Popover types
export type { PopoverProps } from "./types";

// ContextMenu types
export type { ContextMenuProps } from "./types";

// Device types
export type { DeviceProps } from "./types";

// Icon types
export type { IconProps } from "./types";

// FileUploadProgress types
export type { FileUploadProgressProps, FileUploadItem } from "./types";

// Re-export Pulse for convenience
export { default as Pulse } from "pulse-framework";
