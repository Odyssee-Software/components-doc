/**
 * Base types for Odyssee Components
 * Types and interfaces used across all components
 */

import type Pulse from "pulse-framework";

/**
 * Base component props
 */
export interface BaseComponentProps {
  id?: string;
  className?: string;
  style?: Partial<CSSStyleDeclaration> | string;
  [key: string]: any;
}

/**
 * Component size variants
 */
export type Size = "xs" | "sm" | "md" | "lg" | "xl";

/**
 * Component color variants
 */
export type Color =
  | "primary"
  | "secondary"
  | "success"
  | "danger"
  | "warning"
  | "info"
  | "light"
  | "dark";

/**
 * Component variant types
 */
export type Variant = "solid" | "outline" | "ghost" | "soft" | "link";

/**
 * Position types
 */
export type Position =
  | "top"
  | "top-start"
  | "top-end"
  | "bottom"
  | "bottom-start"
  | "bottom-end"
  | "left"
  | "left-start"
  | "left-end"
  | "right"
  | "right-start"
  | "right-end";

/**
 * Alignment types
 */
export type Alignment = "start" | "center" | "end" | "stretch" | "baseline";

/**
 * Direction types
 */
export type Direction = "horizontal" | "vertical";

/**
 * Callback types
 */
export type EventCallback<T = void> = (event?: Event) => T;
export type ChangeCallback<T = any> = (value: T) => void;
export type ClickCallback = EventCallback<void>;

/**
 * Pulse signal types
 */
export type Signal<T> = ReturnType<typeof Pulse.signal<T>>;
export type Computed<T> = ReturnType<typeof Pulse.computed<T>>;

/**
 * Button props
 */
export interface ButtonProps extends BaseComponentProps {
  type?: "button" | "submit" | "reset";
  variant?: Variant;
  color?: Color;
  size?: Size;
  disabled?: boolean;
  loading?: boolean;
  icon?: string | Pulse.JSX.Element;
  iconPosition?: "left" | "right";
  fullWidth?: boolean;
  onClick?: ClickCallback;
  children?: string | HTMLElement | HTMLElement[];
  spinnerProps?: Partial<SpinnerProps>;
}

/**
 * Input props
 */
export interface InputProps extends BaseComponentProps {
  type?: "text" | "email" | "password" | "number" | "tel" | "url" | "search";
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  icon?: string;
  iconPosition?: "left" | "right";
  onChange?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
}

/**
 * Select option
 */
export interface SelectOption {
  value: string | number;
  label: string;
  disabled?: boolean;
  group?: string;
}

/**
 * Select props
 */
export interface SelectProps extends BaseComponentProps {
  value?: string | number | Signal<string | number>;
  options: SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  multiple?: boolean;
  searchable?: boolean;
  onChange?: ChangeCallback<string | number | (string | number)[]>;
}

/**
 * Checkbox props
 */
export interface CheckboxProps extends BaseComponentProps {
  checked?: boolean | Signal<boolean>;
  indeterminate?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: Size;
  labelPosition?: "left" | "right";
  name?: string;
  value?: string | number;
  onChange?: ChangeCallback<boolean>;
}

/**
 * Radio props
 */
export interface RadioProps extends BaseComponentProps {
  name?: string;
  value?: string | number;
  checked?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: Size;
  labelPosition?: "left" | "right";
  onChange?: ChangeCallback<string | number>;
}

/**
 * Toggle props
 */
export interface ToggleProps extends BaseComponentProps {
  checked?: boolean | Signal<boolean>;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  description?: string;
  error?: string | boolean;
  success?: string | boolean;
  size?: "xs" | "sm" | "md" | "lg";
  variant?: "default" | "soft";
  showIcons?: boolean;
  labelPosition?: "left" | "right";
  name?: string;
  onChange?: ChangeCallback<boolean>;
}

/**
 * Textarea props
 */
export interface TextareaProps extends BaseComponentProps {
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  rows?: number;
  maxLength?: number;
  showCount?: boolean;
  autoResize?: boolean;
  minRows?: number;
  maxRows?: number;
  onChange?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  name?: string;
  autocomplete?: string;
}

/**
 * Radio group option
 */
export interface RadioGroupOption {
  value: string | number;
  label: string;
  description?: string;
  disabled?: boolean;
}

/**
 * RadioGroup props
 */
export interface RadioGroupProps extends BaseComponentProps {
  name?: string;
  value?: string | number | Signal<string | number>;
  options: RadioGroupOption[];
  label?: string;
  hint?: string;
  error?: string;
  required?: boolean;
  disabled?: boolean;
  size?: Size;
  direction?: "vertical" | "horizontal";
  onChange?: ChangeCallback<string | number>;
}

/**
 * FileInput props
 */
export interface FileInputProps extends BaseComponentProps {
  label?: string;
  hint?: string;
  error?: string;
  accept?: string;
  multiple?: boolean;
  required?: boolean;
  disabled?: boolean;
  size?: Size;
  variant?: "default" | "button";
  buttonText?: string;
  placeholder?: string;
  maxSize?: number;
  onChange?: ChangeCallback<FileList>;
  name?: string;
}

/**
 * RangeSlider props
 */
export interface RangeSliderProps extends BaseComponentProps {
  value?: number | Signal<number>;
  min?: number;
  max?: number;
  step?: number;
  label?: string;
  hint?: string;
  error?: string;
  disabled?: boolean;
  showValue?: boolean;
  valueFormat?: (value: number) => string;
  onChange?: ChangeCallback<number>;
  name?: string;
}

/**
 * FormGroup props
 */
export interface FormGroupProps extends BaseComponentProps {
  label?: string;
  description?: string;
  children?: HTMLElement | HTMLElement[];
  direction?: "vertical" | "horizontal";
  gap?: Size;
  bordered?: boolean;
}

/**
 * ColorPicker props
 */
export interface ColorPickerProps extends BaseComponentProps {
  value?: string | Signal<string>;
  label?: string;
  hint?: string;
  error?: string;
  disabled?: boolean;
  required?: boolean;
  size?: Size;
  showValue?: boolean;
  onChange?: ChangeCallback<string>;
  name?: string;
}

/**
 * TimePicker props
 */
export interface TimePickerProps extends BaseComponentProps {
  value?: string | Signal<string>;
  format?: "12h" | "24h";
  label?: string;
  hint?: string;
  error?: string;
  placeholder?: string;
  disabled?: boolean;
  required?: boolean;
  size?: Size;
  minuteStep?: number;
  showNowButton?: boolean;
  onChange?: ChangeCallback<string>;
  name?: string;
}

/**
 * TogglePassword props
 */
export interface TogglePasswordProps extends BaseComponentProps {
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  error?: string;
  label?: string;
  hint?: string;
  size?: Size;
  defaultVisible?: boolean;
  showToggleButton?: boolean;
  onChange?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  name?: string;
}

/**
 * InputNumber props
 */
export interface InputNumberProps extends BaseComponentProps {
  value?: number | Signal<number>;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
  label?: string;
  description?: string;
  error?: string;
  hint?: string;
  variant?: "default" | "vertical" | "horizontal" | "mini";
  size?: Size;
  buttonShape?: "rounded" | "square";
  showButtons?: boolean;
  onChange?: ChangeCallback<number>;
  name?: string;
}

/**
 * PinInput props
 */
export interface PinInputProps extends BaseComponentProps {
  length?: number;
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  masked?: boolean;
  type?: "alphanumeric" | "numeric";
  pattern?: string;
  variant?: "default" | "gray" | "underline";
  size?: "sm" | "md" | "lg";
  focusEffect?: "scale" | "none";
  error?: string;
  label?: string;
  hint?: string;
  onChange?: ChangeCallback<string>;
  onComplete?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  autoComplete?: string;
}

/**
 * CopyMarkup props
 */
export interface CopyMarkupProps extends BaseComponentProps {
  template: Pulse.JSX.Element;
  buttonText?: string;
  buttonIcon?: Pulse.JSX.Element;
  buttonVariant?: "outline" | "solid" | "ghost" | "danger";
  buttonPosition?: "left" | "center" | "right";
  limit?: number;
  initialCount?: number;
  showRemoveButton?: boolean;
  removeButtonText?: string;
  spacing?: "sm" | "md" | "lg" | "xl";
  onChange?: ChangeCallback<number>;
  onAdd?: ChangeCallback<number>;
  onRemove?: ChangeCallback<number>;
  buttonClassName?: string;
  wrapperClassName?: string;
  disabled?: boolean;
}

/**
 * StrongPassword props
 */
export interface StrongPasswordProps extends BaseComponentProps {
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  label?: string;
  hint?: string;
  error?: string;
  size?: Size;
  minLength?: number;
  requireLowercase?: boolean;
  requireUppercase?: boolean;
  requireNumbers?: boolean;
  requireSpecialChars?: boolean;
  specialCharsSet?: string;
  strengthLevels?: string[];
  showHints?: boolean;
  hintsMode?: "inline" | "popover";
  showToggleButton?: boolean;
  checksExclude?: string[];
  stripCount?: number;
  onChange?: (value: string, strength: number, strengthLevel: string) => void;
  onStrengthChange?: (strength: number, strengthLevel: string) => void;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  name?: string;
}

/**
 * ComboBox option type
 */
export interface ComboBoxOption {
  [key: string]: any;
}

/**
 * ComboBox props
 */
export interface ComboBoxProps extends BaseComponentProps {
  options?: ComboBoxOption[];
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  label?: string;
  hint?: string;
  error?: string;
  size?: Size;
  displayField?: string;
  valueField?: string;
  searchFields?: string[];
  minSearchLength?: number;
  showCloseButton?: boolean;
  maxHeight?: string;
  apiUrl?: string;
  apiSearchQuery?: string;
  onChange?: (item: ComboBoxOption | null) => void;
  onSearch?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  dropdownClassName?: string;
  name?: string;
  renderItem?: (item: ComboBoxOption) => Pulse.JSX.Element;
}

/**
 * SearchBox option type
 */
export interface SearchBoxOption {
  [key: string]: any;
}

/**
 * SearchBox props
 */
export interface SearchBoxProps extends BaseComponentProps {
  options?: SearchBoxOption[];
  value?: string | Signal<string>;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  required?: boolean;
  label?: string;
  hint?: string;
  error?: string;
  size?: Size;
  displayField?: string;
  valueField?: string;
  searchFields?: string[];
  groupBy?: string;
  showGroupTitles?: boolean;
  minSearchLength?: number;
  isOpenOnFocus?: boolean;
  preventSelection?: boolean;
  preserveSelectionOnEmpty?: boolean;
  maxHeight?: string;
  apiUrl?: string;
  apiSearchQuery?: string;
  loading?: boolean | Signal<boolean>;
  onSelect?: (item: SearchBoxOption) => void;
  onSearch?: ChangeCallback<string>;
  onFocus?: EventCallback;
  onBlur?: EventCallback;
  dropdownClassName?: string;
  name?: string;
  renderItem?: (item: SearchBoxOption) => Pulse.JSX.Element;
  renderGroupTitle?: (title: string) => Pulse.JSX.Element;
}

/**
 * ToggleCount props
 */
export interface ToggleCountProps extends BaseComponentProps {
  type?: "radio" | "switch";
  variant?: "default" | "pills";
  options: [string, string]; // Exactly 2 options
  value?: 0 | 1 | Signal<0 | 1>;
  defaultValue?: 0 | 1;
  disabled?: boolean;
  onChange?: (index: number, label: string) => void;
}

/**
 * ToggleCountValue props
 */
export interface ToggleCountValueProps extends BaseComponentProps {
  target: string; // ID of the ToggleCount component
  min: number;
  max: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  formatter?: (value: number) => string;
}

/**
 * InputGroup addon
 */
export interface InputGroupAddon {
  type: "text" | "icon" | "button" | "checkbox" | "radio" | "select";
  content?: string | Pulse.JSX.Element;

  // For button addon
  buttonProps?: ButtonProps;
  onClick?: () => void;

  // For checkbox/radio addon
  checked?: boolean | Signal<boolean>;
  onChange?: (checked: boolean) => void;

  // For select addon
  selectOptions?: SelectOption[];
  selectValue?: string | Signal<string>;
  onSelectChange?: (value: string) => void;

  // Styling
  className?: string;
}

/**
 * InputGroup props
 */
export interface InputGroupProps extends Omit<
  InputProps,
  "icon" | "iconPosition"
> {
  // Add-ons (single or object)
  leadingAddon?: InputGroupAddon | string | Pulse.JSX.Element;
  trailingAddon?: InputGroupAddon | string | Pulse.JSX.Element;

  // Multiple add-ons
  leadingAddons?: (InputGroupAddon | string | Pulse.JSX.Element)[];
  trailingAddons?: (InputGroupAddon | string | Pulse.JSX.Element)[];

  // Inline icons (absolute positioned)
  leadingIcon?: Pulse.JSX.Element;
  trailingIcon?: Pulse.JSX.Element;

  // Loading state (shows spinner)
  loading?: boolean | Signal<boolean>;
  loadingPosition?: "leading" | "trailing";

  // Inline select (absolute positioned)
  leadingSelect?: {
    options: SelectOption[];
    value?: string | Signal<string>;
    onChange?: (value: string) => void;
    label?: string;
  };
  trailingSelect?: {
    options: SelectOption[];
    value?: string | Signal<string>;
    onChange?: (value: string) => void;
    label?: string;
  };

  // Container props
  containerClassName?: string;
  containerStyle?: Record<string, any>;
}

/**
 * Modal props
 */
export interface ModalProps extends BaseComponentProps {
  isOpen?: boolean | Signal<boolean>;
  title?: string | HTMLElement;
  children?: string | HTMLElement | HTMLElement[];
  footer?: HTMLElement | HTMLElement[];
  size?: "sm" | "md" | "lg" | "xl" | "2xl";
  centered?: boolean;
  staticBackdrop?: boolean;
  fullscreen?: boolean;
  showCloseButton?: boolean;
  closeOnEscape?: boolean;
  animation?: "scale" | "slideDown" | "slideUp" | "fade";
  onClose?: EventCallback;
}

/**
 * Offcanvas placement
 */
export type OffcanvasPlacement = "left" | "right" | "top" | "bottom";

/**
 * Offcanvas props
 */
export interface OffcanvasProps extends BaseComponentProps {
  isOpen?: boolean | Signal<boolean>;
  placement?: OffcanvasPlacement;
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "full";
  title?: string | HTMLElement;
  children?: string | HTMLElement | HTMLElement[];
  footer?: HTMLElement | HTMLElement[];
  showCloseButton?: boolean;
  staticBackdrop?: boolean;
  closeOnEscape?: boolean;
  backdrop?: boolean;
  backdropColor?: string;
  bodyScroll?: boolean;
  onClose?: EventCallback;
}

/**
 * Dropdown item
 */
export interface DropdownItem {
  label: string | HTMLElement;
  value?: string | number;
  icon?: HTMLElement | string;
  href?: string;
  disabled?: boolean;
  isDivider?: boolean;
  onClick?: () => void;
  className?: string;
}

/**
 * Dropdown placement
 */
export type DropdownPlacement =
  | "top"
  | "top-start"
  | "top-end"
  | "bottom"
  | "bottom-start"
  | "bottom-end"
  | "left"
  | "left-start"
  | "left-end"
  | "right"
  | "right-start"
  | "right-end"
  | "auto";

/**
 * Dropdown trigger type
 */
export type DropdownTrigger = "click" | "hover" | "contextmenu";

/**
 * Dropdown auto-close behavior
 */
export type DropdownAutoClose = boolean | "inside" | "outside";

/**
 * Dropdown props
 */
export interface DropdownProps extends BaseComponentProps {
  // Trigger
  trigger: HTMLElement | string;
  triggerClassName?: string;

  // Items (structured approach)
  items?: DropdownItem[];

  // Children (flexible approach)
  children?: HTMLElement | HTMLElement[];

  // Positioning (Floating UI)
  placement?: DropdownPlacement;
  strategy?: "fixed" | "absolute";
  offset?: number;
  flip?: boolean;
  scope?: "parent" | "window";

  // Behavior
  triggerType?: DropdownTrigger;
  autoClose?: DropdownAutoClose;
  closeOnSelect?: boolean;
  hasAutofocus?: boolean;

  // State
  isOpen?: boolean | Signal<boolean>;

  // Styling
  menuClassName?: string;

  // Callbacks
  onOpen?: () => void;
  onClose?: () => void;
  onSelect?: (value: string | number) => void;
}

/**
 * DropdownItem component props (for flexible children approach)
 */
export interface DropdownItemProps extends BaseComponentProps {
  children: string | HTMLElement;
  icon?: HTMLElement | string;
  href?: string;
  disabled?: boolean;
  active?: boolean;
  onClick?: () => void;
}

/**
 * DropdownDivider component props
 */
export interface DropdownDividerProps extends BaseComponentProps {}

/**
 * Tab item
 */
export interface TabItem {
  id: string;
  label: string | HTMLElement;
  content: string | HTMLElement | HTMLElement[];
  icon?: HTMLElement | string;
  disabled?: boolean;
  badge?: string | number;
}

/**
 * Tabs event type
 */
export type TabsEventType = "click" | "hover";

/**
 * Tabs variant
 */
export type TabsVariant = "underline" | "pills" | "enclosed" | "vertical";

/**
 * Tabs props
 */
export interface TabsProps extends BaseComponentProps {
  // Items (structured approach)
  items?: TabItem[];

  // Children (flexible approach)
  children?: HTMLElement | HTMLElement[];

  // Active tab
  activeTab?: string | Signal<string>;

  // Variant
  variant?: TabsVariant;

  // Event trigger type
  eventType?: TabsEventType;

  // With border
  bordered?: boolean;

  // Full width tabs
  fullWidth?: boolean;

  // Size
  size?: "sm" | "md" | "lg";

  // Styling
  tablistClassName?: string;
  contentClassName?: string;

  // Callbacks
  onChange?: (tabId: string, prevTabId: string) => void;
}

/**
 * TabPanel component props (for flexible children approach)
 */
export interface TabPanelProps extends BaseComponentProps {
  id: string;
  label: string | HTMLElement;
  children: string | HTMLElement | HTMLElement[];
  icon?: HTMLElement | string;
  disabled?: boolean;
  badge?: string | number;
}

/**
 * Tooltip props
 */
export interface TooltipProps extends BaseComponentProps {
  // Content
  content: string | HTMLElement;

  // Positioning
  placement?:
    | "top"
    | "top-start"
    | "top-end"
    | "bottom"
    | "bottom-start"
    | "bottom-end"
    | "left"
    | "left-start"
    | "left-end"
    | "right"
    | "right-start"
    | "right-end"
    | "auto";

  // Trigger element
  trigger?: "hover" | "click" | "focus";
  children?: HTMLElement | HTMLElement[] | string;

  // Delays
  showDelay?: number;
  hideDelay?: number;

  // Styling
  variant?: "dark" | "light";
  arrow?: boolean;
}

/**
 * Popover props
 */
export interface PopoverProps extends Omit<TooltipProps, "content"> {
  // Content structure (structured approach)
  header?: string | Pulse.JSX.Element;
  body?: string | Pulse.JSX.Element;
  footer?: Pulse.JSX.Element;

  // Simple content (if no header/body/footer)
  content?: string | Pulse.JSX.Element;

  // Styling
  maxWidth?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl";

  // Override defaults (default trigger is "click" for Popover)
  trigger?: "hover" | "click" | "focus";
}

/**
 * ContextMenu props (extends Dropdown with contextmenu trigger)
 */
export interface ContextMenuProps extends Omit<DropdownProps, "triggerType"> {
  // triggerType is forced to "contextmenu" for right-click behavior
  // All other props inherited from DropdownProps
}

/**
 * Device props (mobile and browser mockups)
 */
export interface DeviceProps extends BaseComponentProps {
  // Variant
  variant: "mobile" | "browser";

  // Content
  src?: string;
  alt?: string;
  children?: HTMLElement | HTMLElement[] | string;

  // Browser specific
  url?: string;
  showControls?: boolean;

  // Sizing
  maxWidth?: string;

  // Alignment
  align?: "left" | "center" | "right";

  // Styling
  imageClassName?: string;
  frameClassName?: string;
}

/**
 * Icon props
 */
export interface IconProps extends BaseComponentProps {
  // Icon name (from Lucide or custom)
  name?: string;

  // Or custom SVG children
  children?: Pulse.JSX.Element | HTMLElement | HTMLElement[];

  // Size
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "2xl";

  // Custom size (overrides size prop)
  width?: number | string;
  height?: number | string;

  // Color (uses Tailwind color classes)
  color?: Color;

  // Variant
  variant?: "solid" | "outline" | "ghost" | "soft" | "soft-outline";

  // Shape
  shape?: "square" | "rounded" | "circular";

  // Stroke width (for outline icons)
  strokeWidth?: number;

  // Fill (for solid icons)
  fill?: boolean;

  // Additional styling
  containerClassName?: string; // For wrapper div (if shape is applied)
}

/**
 * Divider props
 */
export interface DividerProps extends BaseComponentProps {
  // Orientation
  orientation?: "horizontal" | "vertical";

  // Label
  label?: string | HTMLElement;
  labelPosition?: "left" | "center" | "right";

  // Styling
  color?: "default" | "gray" | "teal" | "blue" | "red" | "yellow" | "white";
  thickness?: 1 | 2 | 4 | 8;

  // Spacing
  spacing?: Size;

  // Responsive behavior
  responsiveOrientation?: {
    sm?: "horizontal" | "vertical";
    md?: "horizontal" | "vertical";
    lg?: "horizontal" | "vertical";
  };
}

/**
 * Kbd props
 */
export interface KbdProps extends BaseComponentProps {
  // Content
  children?: string | HTMLElement;

  // Variant
  variant?: "text" | "text-dark" | "solid" | "bordered" | "shadow";

  // Size
  size?: "xs" | "sm" | "md" | "lg";

  // Icon
  icon?: HTMLElement | string;

  // Square (for icons only)
  square?: boolean;
}

/**
 * KbdGroup props
 */
export interface KbdGroupProps extends BaseComponentProps {
  // Keys to display
  keys: (string | HTMLElement | KbdProps)[];

  // Separator between keys
  separator?: string;

  // Variant for all keys
  variant?: "text" | "text-dark" | "solid" | "bordered" | "shadow";

  // Size for all keys
  size?: "xs" | "sm" | "md" | "lg";
}

/**
 * Spinner props
 */
export interface SpinnerProps extends BaseComponentProps {
  // Size
  size?: "xs" | "sm" | "md" | "lg" | "xl";

  // Color
  color?:
    | "primary"
    | "secondary"
    | "success"
    | "danger"
    | "warning"
    | "info"
    | "gray"
    | "white"
    | "indigo"
    | "purple"
    | "pink"
    | "orange";

  // Border width
  thickness?: 2 | 3 | 4;

  // Label
  label?: string;
  showLabel?: boolean;

  // Center in container
  centered?: boolean;
}

/**
 * Skeleton props
 */
export interface SkeletonProps extends BaseComponentProps {
  // Variant
  variant?: "text" | "circular" | "rectangular";

  // Width (can be percentage string like "40%" or pixel number)
  width?: string | number;

  // Height
  height?: string | number;

  // Animation
  animate?: boolean;

  // Number of lines (for text variant)
  lines?: number;

  // Gap between lines
  gap?: "sm" | "md" | "lg";
}

/**
 * SkeletonAvatar props
 */
export interface SkeletonAvatarProps extends BaseComponentProps {
  // Size
  size?: "xs" | "sm" | "md" | "lg" | "xl";

  // Animation
  animate?: boolean;
}

/**
 * SkeletonCard props
 */
export interface SkeletonCardProps extends BaseComponentProps {
  // Show avatar
  avatar?: boolean;

  // Avatar size
  avatarSize?: "xs" | "sm" | "md" | "lg" | "xl";

  // Number of lines
  lines?: number;

  // Animation
  animate?: boolean;

  // Title width percentage
  titleWidth?: string;
}

/**
 * List item
 */
export interface ListItem {
  id?: string;
  content: string | HTMLElement;
  icon?: HTMLElement | string;
  iconColor?:
    | Color
    | "gray"
    | "white"
    | "teal"
    | "indigo"
    | "purple"
    | "pink"
    | "orange";
  iconVariant?: "simple" | "soft" | "solid";
}

/**
 * List props
 */
export interface ListProps extends BaseComponentProps {
  // Items
  items: (string | ListItem)[];

  // List type
  type?: "disc" | "decimal" | "none" | "check" | "inline";

  // Spacing
  spacing?: "sm" | "md" | "lg";

  // Marker color (for disc/decimal)
  markerColor?: string;

  // Check icon color
  checkColor?:
    | Color
    | "gray"
    | "white"
    | "teal"
    | "indigo"
    | "purple"
    | "pink"
    | "orange";

  // Check icon variant
  checkVariant?: "simple" | "soft" | "solid";

  // Inline separator (for inline lists)
  separator?: "dot" | "pipe" | "slash" | "none";

  // Text size
  size?: "xs" | "sm" | "md" | "lg";

  // Ordered list start number
  start?: number;
}

/**
 * ListGroup item
 */
export interface ListGroupItem {
  id?: string;
  content: string | HTMLElement;
  icon?: HTMLElement | string;
  badge?: string | number;
  badgeColor?: Color;
  href?: string;
  active?: boolean;
  disabled?: boolean;
  onClick?: ClickCallback;
}

/**
 * ListGroup props
 */
export interface ListGroupProps extends BaseComponentProps {
  // Items
  items: (string | ListGroupItem)[];

  // Variant
  variant?: "default" | "flush" | "horizontal";

  // Item type
  as?: "li" | "button" | "a";

  // Striped
  striped?: boolean;

  // No gutters (no horizontal padding)
  noGutters?: boolean;

  // Size
  size?: "sm" | "md" | "lg";

  // Active item index
  activeIndex?: number | Signal<number>;

  // Callbacks
  onItemClick?: (item: ListGroupItem | string, index: number) => void;
}

/**
 * Breadcrumb item
 */
export interface BreadcrumbItem {
  id?: string;
  label: string | HTMLElement;
  href?: string;
  icon?: HTMLElement | string;
  active?: boolean;
  onClick?: ClickCallback;
}

/**
 * Breadcrumb props
 */
export interface BreadcrumbProps extends BaseComponentProps {
  // Items
  items: (string | BreadcrumbItem)[];

  // Separator type
  separator?: "chevron" | "slash" | "custom";

  // Custom separator element
  customSeparator?: HTMLElement | string;

  // With border
  bordered?: boolean;

  // Show 'more' indicator for collapsed items
  showMore?: boolean;

  // Number of items to show before collapsing (if showMore is true)
  maxItems?: number;

  // Collapsed items (when using showMore)
  collapsedItems?: (string | BreadcrumbItem)[];

  // Text size
  size?: "xs" | "sm" | "md" | "lg";

  // Callbacks
  onItemClick?: (item: BreadcrumbItem | string, index: number) => void;
}

/**
 * Alert props
 */
export interface AlertProps extends BaseComponentProps {
  variant?: "solid" | "soft" | "bordered";
  color?: Color;
  title?: string | HTMLElement;
  children?: string | HTMLElement | HTMLElement[];
  icon?: string;
  dismissible?: boolean;
  isVisible?: boolean | Signal<boolean>;
  actions?: HTMLElement | HTMLElement[];
  onDismiss?: EventCallback;
}

/**
 * Badge props
 */
export interface BadgeProps extends BaseComponentProps {
  variant?: Variant;
  color?: Color;
  size?: Size;
  rounded?: boolean | "full";
  dot?: boolean;
  icon?: HTMLElement | string;
  dismissible?: boolean;
  onDismiss?: EventCallback;
  children?: string | HTMLElement;
}

/**
 * Card props
 */
export interface CardProps extends BaseComponentProps {
  // Content
  title?: string;
  subtitle?: string;
  children?: HTMLElement | HTMLElement[] | string;

  // Header & Footer
  header?: HTMLElement | string;
  headerBordered?: boolean;
  footer?: HTMLElement | string;
  footerBordered?: boolean;

  // Image
  image?: string;
  imageAlt?: string;
  imagePosition?: "top" | "bottom";
  imageOverlay?: boolean;
  imageRounded?: boolean;

  // Variants & Styling
  variant?: "default" | "bordered" | "shadow";
  size?: "sm" | "md" | "lg";

  // Layout
  horizontal?: boolean;
  centered?: boolean;

  // States & Interactions
  clickable?: boolean;
  href?: string;
  onClick?: ClickCallback;

  // Special modes
  scrollable?: boolean;
  scrollHeight?: string;
  emptyState?: boolean;
  emptyStateIcon?: string;
  emptyStateText?: string;

  // Animations
  hoverEffect?: "shadow" | "scale" | "none";
}

/**
 * Accordion item
 */
export interface AccordionItem {
  id: string;
  title: string;
  content: HTMLElement | string;
  disabled?: boolean;
  open?: boolean;
}

/**
 * Accordion props
 */
export interface AccordionProps extends BaseComponentProps {
  items: AccordionItem[];
  multiple?: boolean;
  bordered?: boolean;
}

/**
 * TreeView node
 */
export interface TreeViewNode {
  value: string; // Unique identifier
  label: string; // Display text
  isDir?: boolean; // true = folder, false = file
  icon?: Pulse.JSX.Element | string;
  disabled?: boolean;
  children?: TreeViewNode[];
}

/**
 * TreeView props
 */
export interface TreeViewProps extends BaseComponentProps {
  nodes: TreeViewNode[];

  // Selection
  selectable?: boolean;
  multiSelect?: boolean; // Support shift/ctrl selection
  selected?: string[] | Signal<string[]>;
  onSelect?: (selected: string[]) => void;

  // Expand / collapse
  expanded?: string[] | Signal<string[]>;
  onExpand?: (expanded: string[]) => void;
  alwaysOpen?: boolean; // Keep all expanded (data-hs-accordion-always-open)

  // Checkboxes
  showCheckboxes?: boolean;
  checked?: string[] | Signal<string[]>;
  onCheck?: (checked: string[]) => void;

  // Draggable (optional, requires Sortable.js)
  draggable?: boolean;
  onDragEnd?: (nodes: TreeViewNode[]) => void;

  // Visual options
  showLines?: boolean; // Vertical connection lines
  iconPosition?: "left" | "right";

  // Accessibility
  ariaLabel?: string;
  ariaLabelledBy?: string;
}

/**
 * DatePicker props
 */
export interface DatePickerProps extends BaseComponentProps {
  // Value
  value?: Date | Signal<Date>;
  defaultValue?: Date;

  // Range mode
  mode?: "single" | "range";
  rangeStart?: Date | Signal<Date>;
  rangeEnd?: Date | Signal<Date>;

  // Time picker
  showTime?: boolean;
  timeFormat?: "12h" | "24h";

  // Constraints
  minDate?: Date;
  maxDate?: Date;
  disabledDates?: Date[] | ((date: Date) => boolean);

  // Display
  showFooter?: boolean;
  showWeekNumbers?: boolean;
  firstDayOfWeek?: 0 | 1; // 0 = Sunday, 1 = Monday

  // Localization
  locale?: string;
  monthNames?: string[];
  dayNames?: string[];

  // Callbacks
  onChange?: (date: Date | null) => void;
  onRangeChange?: (start: Date | null, end: Date | null) => void;
  onCancel?: () => void;
  onApply?: () => void;
}

/**
 * Avatar props
 */
export interface AvatarProps extends BaseComponentProps {
  // Image
  src?: string;
  alt?: string;

  // Text/Initials
  name?: string;
  initials?: string;

  // Variants
  variant?: "image" | "initials" | "icon";

  // Styling
  size?: Size;
  rounded?: boolean | "full" | "lg";

  // Colors (for initials/icon variants)
  color?:
    | "gray"
    | "primary"
    | "secondary"
    | "success"
    | "danger"
    | "warning"
    | "info"
    | "white";
  colorVariant?: "solid" | "soft" | "outline";

  // Status indicator
  status?: "online" | "offline" | "away" | "busy" | "none";
  statusPosition?: "top" | "bottom";
  statusColor?: string;

  // Badge/notification
  badge?: string | number;
  badgePosition?: "top" | "bottom";

  // Icon (for brand logos, etc.)
  icon?: HTMLElement | string;
  iconBg?: boolean;

  // Tooltip
  tooltip?: string;

  // Interactions
  href?: string;
  onClick?: ClickCallback;
}

/**
 * Progress props
 */
export interface ProgressProps extends BaseComponentProps {
  // Value
  value: number | Signal<number>;
  max?: number;
  min?: number;

  // Display
  label?: string;
  showValue?: boolean;
  valuePosition?: "inside" | "end" | "top" | "floating";
  valueFormat?: (value: number, max: number) => string;

  // Styling
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  color?: Color;
  variant?: "default" | "striped" | "gradient";

  // Shape
  rounded?: boolean;
  vertical?: boolean;
  height?: string;

  // Multiple bars (segmented)
  segments?: number;
  segmentGap?: string;

  // Circular/Gauge
  type?: "linear" | "circular" | "gauge" | "gauge-half";
  circularSize?: number;
  strokeWidth?: number;

  // Animation
  animated?: boolean;
  transition?: boolean;

  // Status
  showStatus?: boolean;
  statusIcon?: HTMLElement | string;
}

/**
 * Carousel props
 */
export interface CarouselProps extends BaseComponentProps {
  items: HTMLElement[];
  autoplay?: boolean;
  interval?: number;
  showControls?: boolean;
  showIndicators?: boolean;
  loop?: boolean;
}

/**
 * File upload item data
 */
export interface FileUploadItem {
  id: string;
  name: string;
  size: string | number; // "7 KB" or number in bytes
  progress: number | Signal<number>; // 0-100
  status: "uploading" | "completed" | "error" | "paused";
  icon?: Pulse.JSX.Element | HTMLElement; // Custom file icon
}

/**
 * FileUploadProgress props
 */
export interface FileUploadProgressProps extends BaseComponentProps {
  // Single file mode
  file?: FileUploadItem;

  // Multiple files mode
  files?: FileUploadItem[];

  // Display options
  showPercentage?: boolean;
  showActions?: boolean;
  variant?: "inline" | "card"; // inline = single row, card = wrapped in card with footer

  // Callbacks
  onPause?: (fileId: string) => void;
  onResume?: (fileId: string) => void;
  onDelete?: (fileId: string) => void;
  onPauseAll?: () => void;
  onResumeAll?: () => void;
  onDeleteAll?: () => void;

  // Card-specific (when variant="card")
  footerText?: string;
  footerActions?: Pulse.JSX.Element | HTMLElement;
}

/**
 * Container props
 */
export interface ContainerProps extends BaseComponentProps {
  fluid?: boolean;
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "full";
  centered?: boolean;
  children?: HTMLElement | HTMLElement[];
}

/**
 * Grid props
 */
export interface GridProps extends BaseComponentProps {
  cols?: number | { sm?: number; md?: number; lg?: number; xl?: number };
  gap?: number | string;
  children?: HTMLElement | HTMLElement[];
}

/**
 * Navbar item (navigation link)
 */
export interface NavbarItem {
  id?: string;
  label: string | HTMLElement;
  href?: string;
  active?: boolean;
  disabled?: boolean;
  onClick?: ClickCallback;
  dropdown?: DropdownItem[];
  badge?: string | number;
  icon?: HTMLElement | string;
}

/**
 * Navbar brand configuration
 */
export interface NavbarBrand {
  // Brand content (text, image, svg, or custom element)
  content: string | HTMLElement;
  // Brand link
  href?: string;
  // Additional brand content (e.g., logo + text)
  logo?: HTMLElement | string;
  // Logo alt text (for images)
  logoAlt?: string;
  // Brand click handler
  onClick?: ClickCallback;
  // Custom className for brand
  className?: string;
}

/**
 * Navbar variant
 */
export type NavbarVariant = "default" | "dark" | "primary" | "transparent";

/**
 * Navbar alignment
 */
export type NavbarAlignment = "left" | "center" | "right";

/**
 * Navbar props
 */
export interface NavbarProps extends BaseComponentProps {
  // Brand configuration
  brand?: NavbarBrand | string;

  // Navigation items (structured approach)
  items?: NavbarItem[];

  // Children (flexible approach)
  children?: HTMLElement | HTMLElement[];

  // Variant
  variant?: NavbarVariant;

  // Alignment
  alignment?: NavbarAlignment;

  // Collapsible behavior (responsive)
  collapsible?: boolean;

  // Collapse breakpoint (when to show mobile toggle)
  collapseBreakpoint?: "sm" | "md" | "lg" | "xl";

  // Horizontal scroll on mobile
  horizontalScroll?: boolean;

  // Sticky navbar
  sticky?: boolean;
  stickyOffset?: string;

  // Max width container
  maxWidth?: "sm" | "md" | "lg" | "xl" | "2xl" | "full" | string;

  // Container centered
  centered?: boolean;

  // Padding
  padding?: "sm" | "md" | "lg";

  // Custom classNames
  navClassName?: string;
  containerClassName?: string;
  brandClassName?: string;
  itemsClassName?: string;
  toggleClassName?: string;

  // Callbacks
  onBrandClick?: ClickCallback;
  onItemClick?: (item: NavbarItem, index: number) => void;
  onToggle?: (isOpen: boolean) => void;
}

/**
 * NavbarLink props (for composable children approach)
 */
export interface NavbarLinkProps extends BaseComponentProps {
  href?: string;
  active?: boolean;
  disabled?: boolean;
  onClick?: ClickCallback;
  children?: string | HTMLElement | HTMLElement[];
}

/**
 * Pagination variant
 */
export type PaginationVariant = "default" | "bordered" | "bordered-group";

/**
 * Pagination shape
 */
export type PaginationShape = "default" | "pilled";

/**
 * Pagination alignment
 */
export type PaginationAlignment = "start" | "center" | "end";

/**
 * Pagination size
 */
export type PaginationSize = "sm" | "md" | "lg";

/**
 * Pagination props
 */
export interface PaginationProps extends BaseComponentProps {
  // Current page (1-indexed)
  currentPage: number | Signal<number>;

  // Total number of pages
  totalPages: number;

  // Variant
  variant?: PaginationVariant;

  // Shape
  shape?: PaginationShape;

  // Size
  size?: PaginationSize;

  // Alignment
  alignment?: PaginationAlignment;

  // Show previous/next buttons
  showPrevNext?: boolean;

  // Show previous/next text (on larger screens)
  showPrevNextText?: boolean;

  // Previous button text
  prevText?: string;

  // Next button text
  nextText?: string;

  // Show ellipsis with tooltip
  showEllipsis?: boolean;

  // Number of page buttons to show around current page
  siblingCount?: number;

  // Show boundary pages (first and last)
  showBoundaries?: boolean;

  // Mini variant (shows "1 of 3" format)
  mini?: boolean;

  // Show jumper (go to page input)
  showJumper?: boolean;

  // Jumper text
  jumperText?: string;

  // Show items per page dropdown
  showItemsPerPage?: boolean;

  // Items per page options
  itemsPerPageOptions?: number[];

  // Current items per page
  itemsPerPage?: number;

  // Stretched layout (space-between)
  stretched?: boolean;

  // Disabled state
  disabled?: boolean;

  // Callbacks
  onPageChange?: (page: number) => void;
  onItemsPerPageChange?: (itemsPerPage: number) => void;
}

/**
 * Step status
 */
export type StepStatus =
  | "pending"
  | "active"
  | "success"
  | "completed"
  | "error"
  | "processed";

/**
 * Stepper mode
 */
export type StepperMode = "linear" | "non-linear";

/**
 * Stepper orientation
 */
export type StepperOrientation = "horizontal" | "vertical";

/**
 * Stepper variant
 */
export type StepperVariant = "default" | "white" | "solid";

/**
 * Step item data
 */
export interface StepItemData {
  index: number;
  label: string;
  description?: string;
  icon?: Pulse.JSX.Element;
  avatar?: string;
  content?: Pulse.JSX.Element;
  isOptional?: boolean;
  isCompleted?: boolean;
  hasError?: boolean;
}

/**
 * Step indicator props
 */
export interface StepIndicatorProps extends BaseComponentProps {
  index: number;
  status: StepStatus;
  variant?: StepperVariant;
  icon?: Pulse.JSX.Element;
  avatar?: string;
  showCheckmark?: boolean;
  showError?: boolean;
  showSpinner?: boolean;
}

/**
 * Step item props
 */
export interface StepItemProps extends BaseComponentProps {
  index: number;
  label: string;
  description?: string;
  status: StepStatus;
  variant?: StepperVariant;
  orientation?: StepperOrientation;
  isLast?: boolean;
  isClickable?: boolean;
  icon?: Pulse.JSX.Element;
  avatar?: string;
  onClick?: (index: number) => void;
  children?: Pulse.JSX.Element;
}

/**
 * Stepper props
 */
export interface StepperProps extends BaseComponentProps {
  // Steps data (config-based approach)
  steps?: StepItemData[];

  // Current step (1-indexed)
  currentStep: number | Signal<number>;

  // Mode
  mode?: StepperMode;

  // Orientation
  orientation?: StepperOrientation;

  // Variant
  variant?: StepperVariant;

  // Alignment
  alignment?: "start" | "center" | "end";

  // Controls
  showControls?: boolean;
  backText?: string;
  nextText?: string;
  finishText?: string;
  resetText?: string;
  skipText?: string;
  completeStepText?: string;

  // Callbacks
  onStepChange?: (step: number) => void;
  onComplete?: () => void;
  onSkip?: (step: number) => void;
  onReset?: () => void;
  onBack?: () => void;
  onNext?: () => void;

  // Children (composable approach)
  children?: Pulse.JSX.Element | Pulse.JSX.Element[];
}

/**
 * Toast type
 */
export type ToastType = "info" | "success" | "error" | "warning" | "default";

/**
 * Toast variant
 */
export type ToastVariant = "default" | "solid" | "soft";

/**
 * Toast position
 */
export type ToastPosition =
  | "top-left"
  | "top-center"
  | "top-right"
  | "center"
  | "bottom-left"
  | "bottom-center"
  | "bottom-right";

/**
 * Toast action
 */
export interface ToastAction {
  label: string;
  onClick: (e: Event) => void;
  variant?: "default" | "primary";
}

/**
 * Toast props
 */
export interface ToastProps extends BaseComponentProps {
  // Type of toast (determines icon and color)
  type?: ToastType;

  // Variant
  variant?: ToastVariant;

  // Title
  title?: string;

  // Message content
  message: string | Pulse.JSX.Element;

  // Custom icon (overrides type icon)
  icon?: Pulse.JSX.Element;

  // Avatar for notification-style toasts
  avatar?: string;

  // Auto-dismiss duration in ms (0 = no auto-dismiss)
  duration?: number;

  // Show close button
  dismissible?: boolean;

  // Action buttons
  actions?: ToastAction[];

  // Progress value (0-100)
  progress?: number;

  // Progress label
  progressLabel?: string;

  // Show loading spinner
  loading?: boolean;

  // Visible state
  visible?: boolean | Signal<boolean>;

  // Callbacks
  onClose?: () => void;

  // Animation
  animated?: boolean;
}

/**
 * Toast container props
 */
export interface ToastContainerProps extends BaseComponentProps {
  // Position in viewport
  position?: ToastPosition;

  // Maximum number of toasts to display
  maxToasts?: number;

  // Offset from viewport edge (in pixels)
  offset?: number;

  // Gap between toasts (in pixels)
  gap?: number;

  // Children (Toast components)
  children?: Pulse.JSX.Element | Pulse.JSX.Element[];
}

/**
 * Rating mode
 */
export type RatingMode = "interactive" | "readonly";

/**
 * Rating symbol type
 */
export type RatingSymbol = "star" | "heart" | "emoji" | "thumbs" | "custom";

/**
 * Rating size
 */
export type RatingSize = "sm" | "md" | "lg";

/**
 * Rating props
 */
export interface RatingProps extends BaseComponentProps {
  // Value
  value?: number | Signal<number>;
  max?: number;

  // Behavior
  mode?: RatingMode;
  onChange?: (value: number) => void;

  // Appearance
  symbol?: RatingSymbol;
  customSymbol?: Pulse.JSX.Element | Pulse.JSX.Element[] | string[];
  size?: RatingSize;
  color?: string;
  inactiveColor?: string;

  // Label
  showLabel?: boolean;
  label?: string;

  // Accessibility
  name?: string;
  disabled?: boolean;
  required?: boolean;
}

/**
 * Timeline item icon type
 */
export type TimelineItemIcon = "dot" | "avatar" | "icon" | "badge";

/**
 * Timeline item user
 */
export interface TimelineItemUser {
  name: string;
  avatar?: string;
  initials?: string;
  onClick?: () => void;
}

/**
 * Timeline item data
 */
export interface TimelineItemData {
  // Content
  title: string | Pulse.JSX.Element;
  description?: string | Pulse.JSX.Element;

  // Icon
  icon?: TimelineItemIcon;
  iconContent?: Pulse.JSX.Element;
  avatar?: string;
  initials?: string;

  // User attribution
  user?: TimelineItemUser;

  // Time
  time?: string;

  // Interaction
  href?: string;
  onClick?: () => void;
  hoverable?: boolean;
}

/**
 * Timeline group
 */
export interface TimelineGroup {
  heading: string;
  items: TimelineItemData[];
}

/**
 * Timeline props
 */
export interface TimelineProps extends BaseComponentProps {
  // Items (data-driven)
  items?: TimelineItemData[];

  // Grouping
  grouped?: boolean;
  groups?: TimelineGroup[];

  // Display
  showTime?: boolean;
  timePosition?: "left" | "right";

  // Interaction
  hoverable?: boolean;
  collapsible?: boolean;
  collapsedItemsCount?: number;
  collapseLabel?: string;

  // Appearance
  lineColor?: string;
  dotColor?: string;

  // Children (manual composition)
  children?: Pulse.JSX.Element | Pulse.JSX.Element[];
}

/**
 * Timeline item props
 */
export interface TimelineItemProps extends BaseComponentProps {
  // Content
  title: string | Pulse.JSX.Element;
  description?: string | Pulse.JSX.Element;

  // Icon
  icon?: TimelineItemIcon;
  iconContent?: Pulse.JSX.Element;
  avatar?: string;
  initials?: string;

  // User
  user?: TimelineItemUser;

  // Time
  time?: string;
  showTime?: boolean;
  timePosition?: "left" | "right";

  // Interaction
  href?: string;
  onClick?: () => void;
  hoverable?: boolean;

  // Style
  isLast?: boolean;
  lineColor?: string;
  dotColor?: string;
}

/**
 * Timeline heading props
 */
export interface TimelineHeadingProps extends BaseComponentProps {
  children: string | Pulse.JSX.Element;
}

/**
 * Legend indicator size
 */
export type LegendIndicatorSize = "xs" | "sm" | "md" | "lg";

/**
 * Legend indicator shape
 */
export type LegendIndicatorShape = "circle" | "square";

/**
 * Legend indicator props
 */
export interface LegendIndicatorProps extends BaseComponentProps {
  // Label
  label: string | Pulse.JSX.Element;

  // Appearance
  color?: string;
  size?: LegendIndicatorSize;
  shape?: LegendIndicatorShape;

  // Custom classes
  dotClassName?: string;
  labelClassName?: string;
}

// =============================================================================
// Tables Types
// =============================================================================

/**
 * Table column definition
 */
export interface TableColumn<T = any> {
  key: string;
  label: string;
  width?: string;
  align?: "start" | "center" | "end";
  sortable?: boolean;
  render?: (value: any, row: T, index: number) => Pulse.JSX.Element | string;
  headerRender?: () => Pulse.JSX.Element | string;
  className?: string;
  headerClassName?: string;
}

/**
 * Table row data (generic)
 */
export interface TableRow {
  id?: string | number;
  [key: string]: any;
}

/**
 * Table variants
 */
export type TableVariant =
  | "default"
  | "striped"
  | "bordered"
  | "rounded"
  | "shadow";

/**
 * Table thead variants
 */
export type TableTheadVariant = "default" | "gray" | "divided";

/**
 * Table size
 */
export type TableSize = "sm" | "md" | "lg";

/**
 * Sort direction
 */
export type TableSortDirection = "asc" | "desc" | null;

/**
 * Table props
 */
export interface TableProps<T = TableRow> extends BaseComponentProps {
  // Data
  columns: TableColumn<T>[];
  data: T[];

  // Variants & Styling
  variant?: TableVariant;
  theadVariant?: TableTheadVariant;
  size?: TableSize;
  hoverable?: boolean;

  // Features
  selectable?: boolean;
  selectedRows?: Signal<(string | number)[]> | (string | number)[];
  onSelectionChange?: (selected: (string | number)[]) => void;

  sortable?: boolean;
  sortBy?: Signal<string | null> | string | null;
  sortDirection?: Signal<TableSortDirection> | TableSortDirection;
  onSort?: (column: string, direction: TableSortDirection) => void;

  searchable?: boolean;
  searchValue?: Signal<string> | string;
  searchPlaceholder?: string;
  onSearch?: (value: string) => void;

  paginated?: boolean;
  currentPage?: Signal<number> | number;
  pageSize?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;

  // Anatomy
  caption?: string;
  showFooter?: boolean;
  footerContent?: Pulse.JSX.Element;
  headless?: boolean;

  // Loading & Empty states
  loading?: boolean | Signal<boolean>;
  loadingRows?: number;
  emptyMessage?: string | Pulse.JSX.Element;

  // Events
  onRowClick?: (row: T, index: number) => void;

  // Advanced
  rowClassName?: (row: T, index: number) => string;
  rowKey?: keyof T;
}
